# Tooth-scale stress localisation — computational replay
Eliguli Han · Preprint, 25 November 2026

This archive provides deterministic source, selected exact inputs, worked outputs and a checksum-pinned manifest of public input archives. Nothing here is a mechanical solve of the complete 18 µm porous tooth. That domain is **awaiting solution**; its completed native tetrahedron count is zero.

## Reproduce the new CT-local result

Python 3.13 with NumPy 2.3.4, SciPy 1.16.3 and Matplotlib 3.10.7 is the reference environment. Re-run from the directory containing this README.

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install -r requirements-local.txt
python output/ct_cavity_mechanics_2026-11-25/cavity_fem.py \
  --roi output/ct_cavity_mechanics_2026-11-25/ct-cavity-crop.npz --output reproduced-local
```

The native section crop is included, as are the original MHA and trace geometry to repeat the extraction. To repeat extraction instead of using the crop, replace the `--roi` argument with `--mha full_3D/Megalodon_FullCT_SpecimenMask_18um.mha --traces native-microtubes.json`. Plane-strain elastic calculations use identical boundary displacements, mesh pitch and nominal properties in the retained-void and filled controls. Re-run plots and compare the JSON results with the archived run. Tiny floating-point variations across BLAS implementations are expected. The crack quantity is the maximum-circumferential-stress initial kink estimate for a prescribed crack.

## Geometry, cases and source records

Run `python download_inputs.py` to list the public locked assets. Pass the names of the input archives needed for a given experiment; the downloader validates SHA-256 and size before accepting each file. The multi-gigabyte 3MF, PLY and FE archives remain separate. No COMSOL binary or source photographs requiring separate licence are redistributed in this bundle.

| Experiment | Replay source and inputs |
| --- | --- |
| Native geometry and mask | The original MHA is bundled. Native 74M and reduced 32M 3MF, and the refined 200M display PLY are linked in the lockfile. Reconstruction, image analysis, CT plots, rendering and native mask tools are under their original project-relative paths. |
| Threshold, regional, material and support sensitivity | `output/publication_validation_2026-11-12/README_reproduction.md` maps exact meshes, tensors and mask inputs to each script. Use the A2/A3 regional, threshold, interface and P1/P2 downloads. `scripts/reproduce_table9.py` recomputes the weighted quantiles from the raw field exports. |
| Jaw and tooth–jaw attachment conditions | The separate jaw and transfer downloads include the operators, exact initial states, finite-element inputs and readback programs. Solver and plotting sources included under `output/jaw_full_stvk_2026-11-20/` and `output/jaw_tooth_transfer_2026-11-22/` use the input archive directory structure. |
| 100 mm MR5 and coupons | The separate native-scale numerical ZIP supplies the input, solve, display and readback for this case. Read its README before running. |
| Figures 9 and 10 | Raster and drawing sources are under `output/pdf/debunk_myth_preprint_figures_2026-11-25/`. Run in the preserved directory structure. The 320-bin axial ordinates and exact native raster counts are included. Shape-preserving interpolation generates display ordinates between computed data. Audit files record projection limits and provenance. |
| Prospective native porous domain | In `output/native_domain_module_2026-11-24/`, run `python module/smoke_validation.py` from the module’s parent to reproduce the four synthetic cases. `solve_mpi.py` requires a certified volume mesh plus PETSc and MPI for whole-tooth use. Those prerequisites have yet to be met. |

Historical proprietary COMSOL-model setup and raw CT acquisition are distinct from the documented numerical replay. For older archive fields the supplied saved exports or checkpoint are the starting point. Individual replay records list remaining upstream inputs and environment constraints. The paper bibliography and release metadata retain the original model and software credits.

### Standalone Figure 10 checkpoint

```sh
figures=output/pdf/debunk_myth_preprint_figures_2026-11-25
python "$figures/scripts/replot_figure10.py" \
  "$figures/review/figure10_display_checkpoint.npz" Figure10-replayed.pdf
```

The checkpoint preserves the visible sample fields and audit quantities. Replaying it redraws the plot; regenerating the checkpoint from original surfaces is a separate, larger calculation.

The exact legacy surface arrays are available as the locked `megalodon-figure10-archive-surface.zip`. Extract into the replay root to supply `output/tooth_continuous_surfaces/cache/fe_v.npy` and `fe_f.npy` without regenerating them from BDF. Detailed preparation steps are in `Figure10-replay.md`.
