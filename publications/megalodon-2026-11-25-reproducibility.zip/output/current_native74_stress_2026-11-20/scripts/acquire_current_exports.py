"""Fetch the released 5/10 cm files and verify their published SHA-256 digests."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
import hashlib
import json
import time
import urllib.request

O = Path(__file__).resolve().parents[1]
API = 'https://api.github.com/repos/Eliguli712/Antiterrastrae/releases/tags/megalodon-independent-sizes-r5'
with urllib.request.urlopen(API, timeout=60) as response:
    release = json.load(response)
assets = {entry['name']: entry for entry in release['assets']}
names = ['export-manifest.json']
for size in [50, 100]:
    names += [f'{size}mm-properties.json', f'{size}mm-summary.json', f'{size}mm-solution.npz']
    names += [f'Megalodon_Native74_{size}mm_{suffix}' for suffix in ['Stress.3mf', 'OBJ.zip', 'STL.zip']]

def get(name):
    entry = assets[name]
    path = O / 'inputs' / name
    expected = entry['digest'].removeprefix('sha256:')
    start = time.monotonic()
    if path.exists():
        with path.open('rb') as stream:
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        if digest == expected:
            print('Cached verified ' + name, flush=True)
            return {'file': name, 'bytes': path.stat().st_size, 'sha256': digest, 'url': entry['browser_download_url'], 'status': 'verified'}
    part = path.with_suffix(path.suffix + '.part')
    digest = hashlib.sha256()
    with urllib.request.urlopen(entry['browser_download_url'], timeout=120) as response, part.open('wb') as stream:
        while block := response.read(8 << 20):
            stream.write(block)
            digest.update(block)
    assert part.stat().st_size == entry['size'], name
    assert digest.hexdigest() == expected, name
    part.replace(path)
    print(f'Verified {name}: {path.stat().st_size:,} bytes ({time.monotonic() - start:.1f}s)', flush=True)
    return {'file': name, 'bytes': path.stat().st_size, 'sha256': digest.hexdigest(), 'url': entry['browser_download_url'], 'status': 'verified'}

records = []
with ThreadPoolExecutor(max_workers=3) as executor:
    futures = [executor.submit(get, name) for name in names]
    for future in as_completed(futures):
        records.append(future.result())
manifest = {'status': 'verified', 'release': release['tag_name'], 'release_url': release['html_url'],
    'published_at': release['published_at'], 'release_id': release['id'],
    'verification': 'Every input archive and numerical file matches the SHA-256 digest published by the GitHub release API.',
    'files': sorted(records, key=lambda entry: entry['file'])}
(O / 'review' / 'acquisition_manifest.json').write_text(json.dumps(manifest, indent=2))
print('ALL CURRENT INPUTS VERIFIED', flush=True)
