#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>

constexpr uint64_t NV=37951699,NF=74293846;
struct Map {
    int fd; void* pointer; size_t bytes;
    Map(const std::string& path) {
        fd=open(path.c_str(),O_RDONLY); if(fd<0)throw std::runtime_error("Cannot open "+path);
        struct stat s;fstat(fd,&s);bytes=s.st_size;
        pointer=mmap(nullptr,bytes,PROT_READ,MAP_PRIVATE,fd,0);
        if(pointer==MAP_FAILED)throw std::runtime_error("Cannot map "+path);
    }
    ~Map(){munmap(pointer,bytes);close(fd);}
};

int main(int argc,char** argv) { try {
    if(argc!=4)return 2;
    std::string mode=argv[1],cache=argv[2],size=argv[3];
    bool create=mode=="create";
    Map fields(cache+"/"+size+"mm-values.f32"),predicted(cache+"/"+size+"mm-colour-index.u16");
    auto scalar=(const float*)fields.pointer;auto prediction=(const uint16_t*)predicted.pointer;
    std::unique_ptr<Map> oldv,oldf;
    std::ofstream v64,v32,faces;
    if(create){v64.open(cache+"/vertices.f64",std::ios::binary);v32.open(cache+"/vertices.f32",std::ios::binary);faces.open(cache+"/triangles.u32",std::ios::binary);}
    else{oldv=std::make_unique<Map>(cache+"/vertices.f64");oldf=std::make_unique<Map>(cache+"/triangles.u32");}
    std::vector<uint16_t> literal(NV,65535);
    std::string carry;std::vector<char> bytes(8<<20);
    uint64_t nv=0,nf=0,boundary_count=0;double max_bin_error=0.;
    const double lo=253167.0947190341,hi=250522132.64670932,den=log(hi)-log(lo);
    while(std::cin){
        std::cin.read(bytes.data(),bytes.size());carry.append(bytes.data(),std::cin.gcount());
        size_t end=carry.rfind('>');if(end==std::string::npos)continue;
        std::string block=carry.substr(0,end+1);carry.erase(0,end+1);
        char* p=block.data();
        while((p=strchr(p,'<'))){
            if(strncmp(p,"<vertex ",8)==0){
                if(nv>=NV)throw std::runtime_error("Excess vertices");
                char* e=p;double q[3];float r[3];
                for(int k=0;k<3;k++){e=strchr(e,'"')+1;q[k]=strtod(e,&e);r[k]=q[k];e++;}
                if(create){v64.write((char*)q,24);v32.write((char*)r,12);}
                else for(int k=0;k<3;k++)if(q[k]!=((double*)oldv->pointer)[3*nv+k])throw std::runtime_error("Native vertex mismatch");
                nv++;
            }else if(strncmp(p,"<triangle ",10)==0){
                if(nf>=NF)throw std::runtime_error("Excess triangles");
                char* e=p;uint32_t q[7];
                for(int k=0;k<7;k++){e=strchr(e,'"')+1;q[k]=strtoul(e,&e,10);e++;}
                if(q[3]!=2)throw std::runtime_error("Unexpected colour group");
                for(int k=0;k<3;k++){
                    auto id=q[k],colour=q[k+4];
                    if(id>=NV||colour>256)throw std::runtime_error("Invalid vertex or colour index");
                    if(!create&&id!=((uint32_t*)oldf->pointer)[3*nf+k])throw std::runtime_error("Ordered triangle differs");
                    bool valid=std::isfinite(scalar[id])&&scalar[id]>0;
                    if((colour==256)==valid)throw std::runtime_error("Unsupported colour disagrees with raw field");
                    if(valid){
                        double coordinate=std::clamp((log(std::max((double)scalar[id],lo))-log(lo))/den,0.,1.)*255.;
                        double error=std::abs(colour-coordinate);max_bin_error=std::max(max_bin_error,error);
                        if(error>.5003)throw std::runtime_error("Colour outside numerical half-bin tolerance at vertex "+std::to_string(id)+"; error="+std::to_string(error));
                    }
                    if(literal[id]==65535){literal[id]=colour;if(colour!=prediction[id])boundary_count++;}
                    else if(literal[id]!=colour)throw std::runtime_error("Inconsistent colour at shared vertex");
                }
                if(create)faces.write((char*)q,12);
                nf++;
            }
            p++;
        }
    }
    if(nv!=NV||nf!=NF)throw std::runtime_error("Incomplete source surface");
    uint64_t unused=0;
    for(uint64_t i=0;i<NV;i++)if(literal[i]==65535){unused++;literal[i]=prediction[i];}
    std::ofstream colours(cache+"/"+size+"mm-literal-colour-index.u16",std::ios::binary);
    colours.write((char*)literal.data(),NV*2);
    std::cout.precision(17);
    std::cout<<"{\"vertices_checked\":"<<nv<<",\"triangles_checked\":"<<nf
        <<",\"literal_corner_assignments_checked\":"<<nf*3
        <<",\"half_bin_rounding_vertices\":"<<boundary_count
        <<",\"max_distance_from_colour_bin_center\":"<<max_bin_error
        <<",\"unreferenced_vertices\":"<<unused<<"}\n";
    std::cerr<<"Verified complete 3MF geometry and literal corner colours: "<<nv<<" vertices, "<<nf<<" triangles\n";
    return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<"\n";return 10;}}
