"""Compose quantitative figures from the audited full-resolution 3MF renders."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import colors, cm, ticker
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.font_manager import FontProperties
from matplotlib.patches import Patch
import numpy as np
from PIL import Image

O = Path(__file__).resolve().parents[1]
RUN = O / 'review' / 'run002'
P = O / 'plots'
P.mkdir(exist_ok=True)
result = json.loads((RUN / 'result.json').read_text())
assert result['status'] == 'passed'
manifest = json.loads((RUN / 'manifest.json').read_text())
assert manifest['run']['status'] == 'completed'
properties = {size: json.loads((O / 'inputs' / f'{size}mm-properties.json').read_text()) for size in [50, 100]}
palette = np.asarray(properties[50]['stress']['color_palette_rgb'], dtype='u1')
assert np.array_equal(palette, np.asarray(properties[100]['stress']['color_palette_rgb']))
lo, hi = (properties[50]['stress'][key] / 1e6 for key in ['shared_color_min_Pa', 'shared_color_max_Pa'])
norm = colors.LogNorm(lo, hi)
cmap = colors.ListedColormap(palette[:256] / 255, name='Literal released 3MF Turbo256')
cmap.set_bad(palette[256] / 255)
scalar = cm.ScalarMappable(norm=norm, cmap=cmap)
plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'DejaVu Sans'],
    'font.size': 15, 'text.color': '#17394d', 'axes.labelcolor': '#17394d',
    'xtick.color': '#17394d', 'ytick.color': '#17394d', 'pdf.fonttype': 42,
    'savefig.facecolor': '#f6fafc', 'figure.facecolor': '#f6fafc'})
serif = FontProperties(fname='/System/Library/Fonts/Supplemental/Baskerville.ttc', style='italic')
# Use the extracted face for the title when available, never for numerical data.
italic = O.parent / 'acrylic_baskerville_v4_2026-11-20/review/font_cache/Baskerville-Italic.ttf'
if italic.exists():
    serif = FontProperties(fname=str(italic))

def source_image(size, view):
    return np.asarray(Image.open(RUN / 'plots' / f'Von_Mises_{size}mm_{view}_native74.png').convert('RGBA'))

def title(fig, subtitle):
    fig.text(.055, .953, 'Astraeus Krystallisia', fontproperties=serif, fontsize=31, color='#172d3c', va='top')
    fig.text(.057, .902, subtitle, fontsize=16, color='#466276', va='top')

def colourbar(fig, bounds, vertical=False):
    ax = fig.add_axes(bounds)
    bar = fig.colorbar(scalar, cax=ax, orientation='vertical' if vertical else 'horizontal', extend='both', extendfrac=.025)
    ticks = [lo, .5, 1, 2, 5, 10, 20, 50, 100, hi]
    bar.set_ticks(ticks)
    labels = ['0.253', '0.5', '1', '2', '5', '10', '20', '50', '100', '250.522']
    if vertical:
        bar.ax.set_yticklabels(labels, fontsize=10)
        bar.set_label('Von Mises stress (MPa) - logarithmic', fontsize=12, labelpad=13)
    else:
        bar.ax.set_xticklabels(labels, fontsize=12)
        bar.set_label('Von Mises stress (MPa) - logarithmic; original released limits', fontsize=13, labelpad=10)
    bar.ax.minorticks_off()
    bar.outline.set_linewidth(.6)
    return bar

def footer(fig, y=.022):
    fig.text(.057, y + .027, '1 MPa distributed crown pressure | fixed bilateral root caps | 74,293,846 source triangles per view', fontsize=11, color='#36556a')
    fig.text(.057, y, 'Literal 3MF corner colours; shared unlit rendering. Closed-solid FEM projected to native CT surface.', fontsize=10, color='#526b7a')

figures = []
# Main four-panel view, with identical normalized camera framing for both sizes.
fig = plt.figure(figsize=(16, 14.5))
title(fig, 'Von Mises stress | 5 cm and 10 cm | Front and Reverse from current native 74M exports')
grid = fig.add_gridspec(2, 2, left=.09, right=.93, bottom=.18, top=.838, hspace=.16, wspace=.08)
for row, size in enumerate([50, 100]):
    for col, view in enumerate(['front', 'reverse']):
        ax = fig.add_subplot(grid[row, col])
        ax.imshow(source_image(size, view), interpolation='nearest')
        ax.set_axis_off()
        ax.set_title(f'{size // 10} cm / {view.title()}', fontsize=19, fontweight='bold', pad=12)
colourbar(fig, [.18, .105, .65, .016])
fig.legend(handles=[Patch(facecolor=palette[256] / 255, label='Grey: unsupported stress projection in the source 3MF')],
    loc='lower center', bbox_to_anchor=(.5, .143), frameon=False, fontsize=11)
footer(fig)
path = P / 'Von_Mises_5cm_10cm_Front_Reverse.png'
fig.savefig(path, dpi=300)
figures.append(fig)

for size in [50, 100]:
    fig = plt.figure(figsize=(18, 9.5))
    title(fig, f'Von Mises stress | {size // 10} cm ({size} mm) | current coloured 3MF, checked against OBJ and STL')
    grid = fig.add_gridspec(1, 3, left=.04, right=.95, bottom=.23, top=.815, wspace=.04)
    for col, view in enumerate(['front', 'reverse', 'oblique']):
        ax = fig.add_subplot(grid[0, col])
        ax.imshow(source_image(size, view), interpolation='nearest')
        ax.set_axis_off()
        ax.set_title(view.title(), fontsize=18, fontweight='bold', pad=12)
    colourbar(fig, [.2, .14, .60, .022])
    fig.legend(handles=[Patch(facecolor=palette[256] / 255, label='Unsupported projection retained from source')],
        loc='lower center', bbox_to_anchor=(.5, .192), frameon=False, fontsize=10)
    footer(fig, .028)
    fig.savefig(P / f'Von_Mises_{size}mm_three_views_current_native74.png', dpi=300)
    figures.append(fig)

pdf_path = O.parents[1] / 'output' / 'pdf' / 'current_native74_stress_5cm_10cm_2026-11-20.pdf'
pdf_path.parent.mkdir(parents=True, exist_ok=True)
with PdfPages(pdf_path, metadata={'Title': 'Astraeus Krystallisia - current 5 cm and 10 cm von Mises contours',
    'Subject': 'Direct released 3MF colours; full topology cross-checked against OBJ and STL; shared quantitative logarithmic legend',
    'Author': 'eliguli712'}) as pdf:
    for fig in figures:
        pdf.savefig(fig, dpi=300)
        plt.close(fig)

# Individual view files have their own quantitative legend and explicit case.
for size in [50, 100]:
    for view in ['front', 'reverse', 'oblique']:
        fig = plt.figure(figsize=(8, 11))
        fig.text(.07, .962, 'Astraeus Krystallisia', fontproperties=serif, fontsize=24, va='top')
        fig.text(.075, .91, f'Von Mises stress | {size // 10} cm | {view.title()}', fontsize=15, fontweight='bold')
        fig.text(.075, .878, 'Current native 74M coloured 3MF / 1 MPa pressure', fontsize=10, color='#526b7a')
        ax = fig.add_axes([.065, .17, .69, .67])
        ax.imshow(source_image(size, view), interpolation='nearest')
        ax.set_axis_off()
        colourbar(fig, [.825, .24, .025, .50], vertical=True)
        fig.legend(handles=[Patch(facecolor=palette[256] / 255, label='Unsupported projection')],
            loc='lower center', bbox_to_anchor=(.48, .115), frameon=False, fontsize=10)
        fig.text(.075, .077, '74,293,846 triangles / no decimation / unlit corner colours', fontsize=10, color='#36556a')
        fig.text(.075, .049, 'Closed-solid FEM projected to native CT; raw values unchanged.', fontsize=9, color='#526b7a')
        fig.savefig(P / f'Von_Mises_{size}mm_{view}_current_native74.png', dpi=300)
        plt.close(fig)

shutil.copy2(pdf_path, O / pdf_path.name)
acquisition = json.loads((O / 'review' / 'acquisition_manifest.json').read_text())
readme = '''Astraeus Krystallisia - current native 74M stress contour plots

Source: the published megalodon-independent-sizes-r5 release, retrieved and checked for this delivery. All six current OBJ/STL/coloured 3MF archive SHA-256 digests match the GitHub release API. Exact download links and hashes are in review/acquisition_manifest.json.

The 5 cm and 10 cm numerical fields are read directly from the corresponding coloured 3MF, including its literal 257-entry colour group and original per-corner colour indices. Every 3MF triangle/property index is checked. The complete OBJ vertex/face order, every face material, its raw field, and the STL corner coordinates are checked against the corresponding 3MF geometry and print transform. STL has no standard stress colours; its corresponding released 3MF provides the field.

All 37,951,699 vertices and 74,293,846 source triangles are retained. Every triangle is submitted to every camera, including internal void surfaces; ordinary depth occlusion determines visibility. No surface reduction, hole filling or alternate silhouette is used. The Front and Reverse are opposite orthographic cameras, not a mirrored substitute. Oblique is a third camera. Case magnification is normalized for figure comparison; physical case heights remain explicitly labelled.

Palette: literal released Turbo256, shared logarithmic limits 0.253167094719 to 250.522132647 MPa. Figure ticks are MPa. Colours are unlit, with linear per-corner RGB interpolation as in the coloured 3MF. Below/above-limit saturation and unsupported grey are retained. Raw Float32 Pa values are never changed. Grey areas are not fabricated or inpainted. This numerical legend is not the unrelated reference-art legend shown on the earlier acrylic proof.

These plots preserve the two independently assembled and solved source cases under 1 MPa distributed crown pressure and fixed bilateral root caps. No new FEM solve or stress rescaling is performed in this plotting task. The archived model is homogeneous isotropic small-strain elasticity on a closed-solid proxy (lambda 29 GPa, mu 28.5 GPa). Native CT pores are visible in the rendering but are not resolved in the mechanical domain. The archived tip ROI convergence criterion is Q95, Q99 and integrated strain energy changing <2% over two successive local refinement steps; it does not certify singular point peaks or unresolved serration tips.

Deliverables: a four-panel Front/Reverse comparison, one three-view figure per size, six individually labelled plots, and a three-page PDF with vector text/colourbars. The large original mesh archives are kept in inputs/ in the working directory and are not duplicated in the plot ZIP.

Reproduce: run scripts/acquire_current_exports.py, then the argv array in review/run_command.json (use a fresh run output directory). scripts/audit_and_render.py writes the full verification and render record; scripts/make_plot_delivery.py composes the final figures. The bounded computation runner is supplied by the installed mathbox computation-audit skill. The run manifest records inputs before/after, software and execution status. Rendered mesh geometry is Float64 up to the screen projection; pixels and the depth buffer use Float32.
'''
(O / 'README.txt').write_text(readme)

html = '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Current 5/10 cm von Mises contours</title><style>body{font:17px/1.6 system-ui;background:#f6fafc;color:#17394d;max-width:1500px;margin:auto;padding:30px}h1{font:italic 44px Baskerville,Georgia,serif}img{max-width:100%;height:auto}a{color:#08728b;margin-right:24px}p{max-width:1100px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:20px}</style><h1>Astraeus Krystallisia</h1><p>Current 5 cm and 10 cm von Mises contours, rendered from the released coloured 3MF files and checked against the full OBJ and STL geometry. 74,293,846 triangles per camera; original shared Turbo256 logarithmic scale in MPa.</p><p><a href="current_native74_stress_5cm_10cm_2026-11-20.pdf">Three-page PDF</a><a href="Current_Native74_5cm_10cm_Stress_Plots.zip">Plots and audit</a><a href="README.txt">Numerical scope and reproduction</a></p><img src="plots/Von_Mises_5cm_10cm_Front_Reverse.png" alt="5 cm and 10 cm front and reverse stress contours"><img src="plots/Von_Mises_50mm_three_views_current_native74.png" alt="5 cm front reverse and oblique"><img src="plots/Von_Mises_100mm_three_views_current_native74.png" alt="10 cm front reverse and oblique"><p>Source fields use 1 MPa pressure on a homogeneous closed-solid FEM proxy. Grey retains unsupported projection; no stress is rescaled or inferred from the reference artwork.</p></html>'''
(O / 'index.html').write_text(html)

selected = [O / 'README.txt', O / 'index.html', O / pdf_path.name,
    O / 'review/acquisition_manifest.json', O / 'review/contract.json', O / 'review/run_command.json',
    RUN / 'manifest.json', RUN / 'result.json', RUN / 'stdout.txt', RUN / 'stderr.txt']
selected += list(P.glob('*.png'))
selected += list((O / 'scripts').glob('*.py')) + list((O / 'scripts').glob('*.cpp'))
selected += list(RUN.glob('*-check.txt'))
selected += [O / 'inputs' / f'{size}mm-{kind}.json' for size in [50, 100] for kind in ['summary', 'properties']]
selected.append(O / 'inputs/export-manifest.json')
selected = sorted(set(selected))
delivery = {'status': 'passed', 'source_release': acquisition['release'], 'source_triangles_per_case_per_view': 74293846,
    'actual_run_status': manifest['run']['status'], 'PDF': pdf_path.name,
    'scale_MPa': [lo, hi], 'scale_type': 'logarithmic', 'palette': 'Literal released 3MF Turbo256', 'files': []}
for path in selected:
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    delivery['files'].append({'path': str(path.relative_to(O)), 'bytes': path.stat().st_size, 'sha256': digest})
(O / 'delivery_manifest.json').write_text(json.dumps(delivery, indent=2))
selected.append(O / 'delivery_manifest.json')
target = O / 'Current_Native74_5cm_10cm_Stress_Plots.zip'
with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED, compresslevel=5) as archive:
    for path in selected:
        archive.write(path, path.relative_to(O))
with zipfile.ZipFile(target) as archive:
    assert archive.testzip() is None
print(json.dumps({'status': 'passed', 'plot_PNGs': len(list(P.glob('*.png'))), 'PDF': str(pdf_path),
    'ZIP_bytes': target.stat().st_size, 'source_triangles_per_camera': 74293846}, indent=2), flush=True)
