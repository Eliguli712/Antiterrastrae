"""Validate all current release formats, then render literal 3MF colours."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import re
import shutil
import struct
import subprocess
import time
import zipfile

import numpy as np
from PIL import Image

O = Path(__file__).resolve().parents[1]
I, C = O / 'inputs', O / 'cache'
NV, NF = 37951699, 74293846
args = argparse.ArgumentParser(description=__doc__)
args.add_argument('--run-dir', required=True, type=Path)
RUN = args.parse_args().run_dir.resolve()
RUN.mkdir(parents=True, exist_ok=True)
C.mkdir(exist_ok=True)
(RUN / 'plots').mkdir(exist_ok=True)
started = time.monotonic()

def log(*values):
    print(time.strftime('%H:%M:%S'), *values, flush=True)

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def jsonsave(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False))

for src, target in [('verify_native_exports.cpp', 'verify_native_exports'), ('inspect_current_3mf.cpp', 'inspect_current_3mf'), ('raster_current.cpp', 'raster_current')]:
    subprocess.run(['c++', '-O3', '-std=c++17', str(O / 'scripts' / src), '-o', str(C / target)], check=True)

acquisition = json.loads((O / 'review' / 'acquisition_manifest.json').read_text())
published = {entry['file']: entry for entry in acquisition['files']}

def numerical_field(archive, member, size, props):
    target = C / f'{size}mm-values.f32'
    with zipfile.ZipFile(archive) as z, z.open(member) as source, target.open('wb') as destination:
        assert z.getinfo(member).file_size == NV * 4
        shutil.copyfileobj(source, destination, 8 << 20)
    assert sha(target) == props['stress']['native_vertex_field_sha256']
    scalar = np.memmap(target, dtype='<f4', mode='r', shape=(NV,))
    index = np.memmap(C / f'{size}mm-colour-index.u16', dtype='<u2', mode='w+', shape=(NV,))
    lo, hi = props['stress']['shared_color_min_Pa'], props['stress']['shared_color_max_Pa']
    good_count = 0
    below = above = 0
    for first in range(0, NV, 500000):
        values = scalar[first:first + 500000]
        good = np.isfinite(values) & (values > 0)
        out = np.full(len(values), 256, dtype='<u2')
        coordinate = (np.log(np.maximum(values[good], lo)) - math.log(lo)) / (math.log(hi) - math.log(lo))
        out[good] = np.rint(np.clip(coordinate, 0, 1) * 255).astype('<u2')
        index[first:first + len(values)] = out
        good_count += int(good.sum())
        below += int((good & (values < lo)).sum())
        above += int((good & (values > hi)).sum())
    index.flush()
    assert good_count == props['stress']['mapped_vertices']
    assert NV - good_count == props['stress']['unmapped_vertices']
    return {'field_sha256': sha(target), 'supported_vertices': good_count,
        'unsupported_vertices': NV - good_count, 'vertices_below_display_min': below,
        'vertices_above_display_max': above, 'raw_values_modified': False}

def model_stream(archive, mode, size, props):
    """Hash every original vertex byte while the C++ checker visits every face."""
    stderr = RUN / f'{size}mm-3mf-check.txt'
    with stderr.open('w') as err:
        process = subprocess.Popen([str(C / 'inspect_current_3mf'), mode, str(C), str(size)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err)
        full_hash, vertices_hash = hashlib.sha256(), hashlib.sha256()
        state = 'header'
        carry = b''
        header, tail = b'', b''
        with zipfile.ZipFile(archive) as z, z.open('3D/3dmodel.model') as stream:
            embedded = json.loads(z.read('Metadata/properties.json'))
            assert embedded == props
            while block := stream.read(8 << 20):
                process.stdin.write(block)
                full_hash.update(block)
                tail = (tail + block)[-65536:]
                carry += block
                cut = carry.rfind(b'>') + 1
                if not cut:
                    continue
                chunk, carry = carry[:cut], carry[cut:]
                if state == 'header':
                    if b'<vertices>' not in chunk:
                        header += chunk
                        continue
                    before, chunk = chunk.split(b'<vertices>', 1)
                    header += before
                    state = 'vertices'
                if state == 'vertices':
                    if b'</vertices>' in chunk:
                        vertices_hash.update(chunk.split(b'</vertices>', 1)[0])
                        state = 'triangles'
                    else:
                        vertices_hash.update(chunk)
        process.stdin.close()
        inspection = process.stdout.read()
        assert process.wait() == 0, stderr.read_text()
        inspection = json.loads(inspection)
    assert vertices_hash.hexdigest() == props['source_vertex_xml_sha256']
    actual_palette = np.asarray([[int(colour[k:k + 2], 16) for k in [0, 2, 4]]
        for colour in re.findall(rb'<m:color color="#([0-9A-Fa-f]{8})"/>', header)], dtype='u1')
    assert np.array_equal(actual_palette, np.asarray(props['stress']['color_palette_rgb'], dtype='u1'))
    actual_transform = np.fromstring(re.search(rb'<item objectid="1" transform="([^"]+)"', tail)[1].decode(), sep=' ')
    expected_transform = np.r_[np.asarray(props['print_transform']['R']).T.ravel(), props['print_transform']['T']]
    assert np.allclose(actual_transform, expected_transform, atol=1e-14, rtol=0)
    assert b'unit="millimeter"' in header
    return {'vertices_checked': NV, 'triangles_and_corner_colours_checked': NF,
        'literal_vertex_xml_sha256': vertices_hash.hexdigest(), 'uncompressed_model_sha256': full_hash.hexdigest(),
        'palette_matches_embedded_properties': True, 'print_transform_matches_properties': True,
        'source_coordinates_and_order_preserved': True, 'literal_colour_inspection': inspection}

def check_obj(archive, size, props):
    R = np.asarray(props['print_transform']['R'])
    T = np.asarray(props['print_transform']['T'])
    arguments = [str(C / 'verify_native_exports'), 'verifyobj', str(C), str(size)]
    arguments += [format(float(x), '.17g') for x in np.r_[R.ravel(), T]]
    errpath = RUN / f'{size}mm-obj-check.txt'
    with zipfile.ZipFile(archive) as z, errpath.open('w') as err:
        assert json.loads(z.read('properties.json')) == props
        with z.open('stress_vertex_values_Pa.f32') as stream:
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == props['stress']['native_vertex_field_sha256']
        materials = z.read('tooth.mtl').decode()
        rgb = np.asarray([[float(x) for x in match] for match in re.findall(r'^Kd (\S+) (\S+) (\S+)$', materials, re.M)])
        assert np.allclose(rgb, np.asarray(props['stress']['color_palette_rgb']) / 255, atol=6e-10, rtol=0)
        process = subprocess.Popen(arguments, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=err)
        with z.open('tooth.obj') as stream:
            shutil.copyfileobj(stream, process.stdin, 8 << 20)
        process.stdin.close()
        record = json.loads(process.stdout.read())
        assert process.wait() == 0, errpath.read_text()
    record.update({'all_face_material_assignments_checked': True, 'palette_checked': True, 'raw_field_identical_to_3MF': True})
    return record

def check_stl(archive, size, props):
    vertices = np.memmap(C / 'vertices.f64', dtype='<f8', mode='r', shape=(NV, 3))
    triangles = np.memmap(C / 'triangles.u32', dtype='<u4', mode='r', shape=(NF, 3))
    R, T = np.asarray(props['print_transform']['R']), np.asarray(props['print_transform']['T'])
    record_type = np.dtype([('normal', '<f4', 3), ('vertices', '<f4', (3, 3)), ('attribute', '<u2')])
    error = 0.0
    count = 0
    with zipfile.ZipFile(archive) as z:
        assert json.loads(z.read('properties.json')) == props
        assert z.getinfo('tooth.stl').file_size == 84 + NF * 50
        with z.open('tooth.stl') as stream:
            header = stream.read(84)
            assert b'units=mm' in header[:80] and struct.unpack('<I', header[80:])[0] == NF
            for first in range(0, NF, 200000):
                length = min(200000, NF - first)
                block = stream.read(length * 50)
                assert len(block) == length * 50
                data = np.frombuffer(block, dtype=record_type)
                expected = vertices[triangles[first:first + length]] @ R.T + T
                difference = float(np.max(np.abs(expected - data['vertices'])))
                error = max(error, difference)
                assert np.isfinite(data['vertices']).all() and not data['attribute'].any()
                count += length
            assert not stream.read(1)
    assert count == NF and error < 2e-5, error
    return {'ordered_triangles_checked': count, 'all_corner_coordinates_checked': NF * 3,
        'max_coordinate_error_mm': error, 'millimetre_units_verified': True,
        'stress_colour_source': 'STL is geometry only; matching released 3MF supplies stress colours.'}

def render(size, props):
    vertices = np.memmap(C / 'vertices.f64', dtype='<f8', mode='r', shape=(NV, 3))
    faces = np.memmap(C / 'triangles.u32', dtype='<u4', mode='r', shape=(NF, 3))
    indices = np.memmap(C / f'{size}mm-literal-colour-index.u16', dtype='<u2', mode='r', shape=(NV,))
    palette = np.asarray(props['stress']['color_palette_rgb'], dtype='u1')
    R, T = np.asarray(props['print_transform']['R']), np.asarray(props['print_transform']['T'])
    target = C / f'raster-{size}'
    target.mkdir(exist_ok=True)
    with (RUN / f'{size}mm-raster-check.txt').open('w') as err:
        process = subprocess.Popen([str(C / 'raster_current'), str(target)], stdin=subprocess.PIPE, stderr=err)
        for first in range(0, NF, 1000000):
            ff = faces[first:first + 1000000]
            ids, local = np.unique(ff, return_inverse=True)
            positions = vertices[ids] @ R.T + T
            # Magnification is normalized for side-by-side appearance only.
            # Neither the source mesh nor a numerical stress value is rescaled.
            positions[:, 2] -= size / 2
            positions *= 100 / size
            colour = palette[indices[ids]].astype('f4') / 255
            data = np.column_stack([positions, colour]).astype('<f4')
            process.stdin.write(struct.pack('<II', len(ids), len(ff)))
            process.stdin.write(data.tobytes())
            process.stdin.write(local.astype('<u4').tobytes())
            if first % 10000000 == 0:
                log('Rasterized', size, first + len(ff), '/', NF, 'triangles per view')
        process.stdin.close()
        assert process.wait() == 0
    plots = []
    for view in ['front', 'reverse', 'oblique']:
        source = target / f'{view}.rgba'
        image = Image.frombytes('RGBA', (2400, 3200), source.read_bytes())
        bbox = image.getchannel('A').getbbox()
        assert bbox and bbox[0] > 0 and bbox[1] > 0 and bbox[2] < 2400 and bbox[3] < 3200
        cropped = image.crop(bbox)
        path = RUN / 'plots' / f'Von_Mises_{size}mm_{view}_native74.png'
        cropped.save(path)
        plots.append({'view': view, 'file': str(path.relative_to(O)), 'pixels': list(cropped.size),
            'sha256': sha(path), 'source_triangles_per_view': NF, 'full_canvas_crop_bbox': list(bbox)})
        source.unlink()
    return plots

records = []
for size in [50, 100]:
    props = json.loads((I / f'{size}mm-properties.json').read_text())
    summary = json.loads((I / f'{size}mm-summary.json').read_text())
    assert props['FEM'] == summary
    assert props['triangles'] == NF and props['vertices'] == NV
    assert not props['face_reduction'] and not props['stress']['stress_rescaling_used']
    assert summary['independent_matrix_assembly_and_solve'] and not summary['stress_rescaling_used']
    assert summary['loads']['pressure_MPa'] == 1 and summary['tip_roi']['criterion_met']
    assert sha(I / f'{size}mm-solution.npz') == props['stress']['source_independent_solution_sha256']
    case = {'size_mm': size, 'properties_sha256': sha(I / f'{size}mm-properties.json'),
        'independent_FEM_solution_sha256': props['stress']['source_independent_solution_sha256']}
    model = I / f'Megalodon_Native74_{size}mm_Stress.3mf'
    log('Reading released numerical field', size)
    case['field'] = numerical_field(model, 'Metadata/stress_vertex_values_Pa.f32', size, props)
    log('Checking every 3MF vertex/triangle/corner colour', size)
    case['3MF'] = model_stream(model, 'create' if size == 50 else 'verify', size, props)
    for name, length in [('vertices.f64', NV * 24), ('vertices.f32', NV * 12), ('triangles.u32', NF * 12)]:
        assert (C / name).stat().st_size == length
    log('Checking every released OBJ vertex/face/material', size)
    case['OBJ'] = check_obj(I / f'Megalodon_Native74_{size}mm_OBJ.zip', size, props)
    log('Checking every released STL corner coordinate', size)
    case['STL'] = check_stl(I / f'Megalodon_Native74_{size}mm_STL.zip', size, props)
    log('Rendering original 3MF colours', size)
    case['plots'] = render(size, props)
    records.append(case)
    jsonsave(RUN / f'{size}mm-result.json', case)

assert records[0]['field']['field_sha256'] != records[1]['field']['field_sha256']
result = {'status': 'passed', 'assertion_tested': 'All six released mesh archives agree in full ordered geometry; all 3MF corner colours and OBJ face materials agree with the corresponding embedded, unmodified numerical field; each camera receives every source triangle.',
    'release': acquisition['release'], 'release_url': acquisition['release_url'],
    'triangles_per_case_per_view': NF, 'vertices_per_case': NV,
    'views': ['front', 'reverse', 'oblique'], 'lighting': 'unlit',
    'palette_source': 'Literal released 3MF colorgroup, checked against Metadata/properties.json.',
    'stress_scale': 'Shared Turbo256 log 253167.0947190341..250522132.64670932 Pa, with original clipping and unsupported grey.',
    'new_FEM_solve': False, 'stress_rescaling': False,
    'non_claims': ['The 74M display surface is not a 74M-element volume FEM.', 'The original mechanical domain is a homogeneous closed-solid proxy, not native-pore-resolved FEM.', 'Archived tip ROI convergence does not certify point peaks at unresolved serration tips.'],
    'cases': records, 'wall_time_seconds': time.monotonic() - started}
jsonsave(RUN / 'result.json', result)
log('ALL FORMAT CHECKS AND FULL-RESOLUTION RENDERS PASSED')
