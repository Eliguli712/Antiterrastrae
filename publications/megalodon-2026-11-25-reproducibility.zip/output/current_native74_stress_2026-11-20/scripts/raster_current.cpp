#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

// Unlit, orthographic, full-topology rendering of released 3MF corner colours.
constexpr int W = 2400, H = 3200;
constexpr uint64_t EXPECTED_FACES = 74293846;
struct Vertex { float x,y,z,r,g,b; };
struct Pixel { float x,y,z,r,g,b; };
struct Plate { std::vector<float> depth; std::vector<uint8_t> rgba; };

void triangle(Plate& image, const Pixel& a, const Pixel& b, const Pixel& c) {
    float area = (b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
    if (std::abs(area)<1e-8f) return;
    int x0=std::max(0,(int)std::floor(std::min({a.x,b.x,c.x})));
    int x1=std::min(W-1,(int)std::ceil(std::max({a.x,b.x,c.x})));
    int y0=std::max(0,(int)std::floor(std::min({a.y,b.y,c.y})));
    int y1=std::min(H-1,(int)std::ceil(std::max({a.y,b.y,c.y})));
    for (int y=y0;y<=y1;++y) for (int x=x0;x<=x1;++x) {
        float u=((b.x-x-.5f)*(c.y-y-.5f)-(b.y-y-.5f)*(c.x-x-.5f))/area;
        float v=((c.x-x-.5f)*(a.y-y-.5f)-(c.y-y-.5f)*(a.x-x-.5f))/area;
        float w=1-u-v;
        if (std::min({u,v,w})<-.00001f) continue;
        float z=u*a.z+v*b.z+w*c.z;
        int index=y*W+x;
        if (z>image.depth[index]) continue;
        image.depth[index]=z;
        float rgb[3]={u*a.r+v*b.r+w*c.r,u*a.g+v*b.g+w*c.g,u*a.b+v*b.b+w*c.b};
        for (int k=0;k<3;++k) image.rgba[4*index+k]=(uint8_t)std::clamp(std::lround(rgb[k]*255.f),0l,255l);
        image.rgba[4*index+3]=255;
    }
}

int main(int argc,char** argv) {
    if (argc!=2) return 2;
    std::array<Plate,3> images;
    for (auto& image:images) {
        image.depth.assign(W*H,1e30f);
        image.rgba.assign(W*H*4,0);
    }
    const float yaw[3]={0,3.14159265358979323846f,.49f};
    const float pitch[3]={0,0,.20f};
    const char* names[3]={"front","reverse","oblique"};
    uint32_t nv,nf;
    uint64_t count=0;
    while (std::cin.read((char*)&nv,4)) {
        std::cin.read((char*)&nf,4);
        if (nv>10000000 || nf>2000000) return 3;
        std::vector<Vertex> vertices(nv);
        std::vector<uint32_t> faces((size_t)nf*3);
        std::cin.read((char*)vertices.data(),(size_t)nv*sizeof(Vertex));
        std::cin.read((char*)faces.data(),(size_t)nf*12);
        if (!std::cin) return 4;
        for (int view=0;view<3;++view) {
            float sy=std::sin(yaw[view]),cy=std::cos(yaw[view]);
            float sp=std::sin(pitch[view]),cp=std::cos(pitch[view]);
            std::vector<Pixel> projected(nv);
            for (uint32_t i=0;i<nv;++i) {
                const auto& q=vertices[i];
                projected[i]={W*.5f+(cy*q.x+sy*q.y)*26.f,
                    H*.5f-(-sy*sp*q.x+cy*sp*q.y+cp*q.z)*26.f,
                    -(sy*cp*q.x-cy*cp*q.y+sp*q.z),q.r,q.g,q.b};
            }
            for (uint32_t i=0;i<nf;++i) {
                const auto a=faces[3*i],b=faces[3*i+1],c=faces[3*i+2];
                if (std::max({a,b,c})>=nv) return 5;
                triangle(images[view],projected[a],projected[b],projected[c]);
            }
        }
        count+=nf;
    }
    for (int view=0;view<3;++view) {
        std::ofstream out(std::string(argv[1])+"/"+names[view]+".rgba",std::ios::binary);
        out.write((const char*)images[view].rgba.data(),images[view].rgba.size());
        if (!out) return 6;
    }
    std::cerr<<"All source triangles submitted per camera: "<<count<<"\n";
    return count==EXPECTED_FACES?0:7;
}
