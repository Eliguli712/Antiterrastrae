"""Same-domain P1/P2 check of one unit margin load, fixed and jaw-coupled."""
from pathlib import Path
import gc,json,sys,time
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import cg

R=Path(__file__).resolve().parents[1];P=R.parents[1]
N=P/'output/pdf/debunk_myth_preprint_2026-11-19';B=P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31'
sys.path.insert(0,str(N/'scripts'))
import p1_p2_common_domain_v2 as p2

D=R/'p2_edge_data_v2';D.mkdir(exist_ok=True)
start=time.monotonic();np.random.seed(20261122)
I=np.eye(3)


def log(stage,**kwargs):
    row=dict(stage=stage,elapsed_seconds=round(time.monotonic()-start,3),**kwargs)
    with (D/'progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
    print(json.dumps(row),flush=True)


def main():
    assert not (D/'results.json').exists()
    base=np.load(B/'numerics/L0/solution.npz');p,t=base['points_m'],base['tets'];maskfile=np.load(B/'numerics/L0/region_masks.npz')
    op=np.load(R/'data_v3/condensed_operators.npz');registration=np.load(R/'data_v3/registration.npz');unit=np.load(R/'edge_data/unit_response_basis.npz')
    records=json.loads((R/'edge_data/results.json').read_text())['cases'];p1fixed=next(c for c in records if c['name']=='RA_pose0_oblique0_fixed');p1coupled=next(c for c in records if c['name']=='RA_pose0_oblique0_tied')
    direction=np.array(p1fixed['direction_body']);patch=unit['patch_face_ids_RA']
    pairs,lookup=np.unique(np.sort(t[:,p2.EDGES].reshape(-1,2),axis=1),axis=0,return_inverse=True)
    nodes=np.vstack([p,p[pairs].mean(1)]);conn=np.column_stack([t,len(p)+lookup.reshape(-1,6)])
    assert len(nodes)==90728
    X=p[t[:,1:]]-p[t[:,:1]];inv=np.linalg.inv(X);g=np.empty((len(t),4,3));g[:,1:]=inv.transpose(0,2,1);g[:,0]=-g[:,1:].sum(1);V=abs(np.linalg.det(X))/6
    f,area,normal=p2.core.boundary_faces(p,t);np.testing.assert_array_equal(f,base['boundary_faces'])
    keys=pairs[:,0]*len(p)+pairs[:,1];ee=np.sort(f[:,[[0,1],[1,2],[2,0]]].reshape(-1,2),axis=1);where=np.searchsorted(keys,ee[:,0]*len(p)+ee[:,1]);mid=(len(p)+where).reshape(-1,3)
    force=np.zeros_like(nodes)
    for k in range(3):np.add.at(force,mid[patch,k],area[patch,None]*direction/(3*area[patch].sum()))
    assert np.linalg.norm(force.sum(0)-direction)<1e-12
    fixed1=np.zeros(len(p),bool);fixed1[base['fixed_node_indices']]=True;fixed2=np.r_[fixed1,fixed1[pairs].all(1)]
    fd=(3*np.flatnonzero(fixed2)[:,None]+np.arange(3)).ravel();free=np.setdiff1d(np.arange(3*len(nodes)),fd)
    source_modes=op['tooth_unit_displacements'];embedded_modes=np.concatenate([source_modes,source_modes[pairs].mean(1)],axis=0)
    Dt=embedded_modes.reshape(-1,12)[fd]
    pressure1=unit['unit_displacement_m_per_N'][0]@direction;u1fixed=pressure1.reshape(-1,3);q1=np.array(p1coupled['root_generalised_displacement_m']);u1coupled=u1fixed+source_modes@q1
    def embed(u):return np.vstack([u,u[pairs].mean(1)])
    alpha=.5854101966249685;beta=.1381966011250105;bary=np.full((4,4),beta);np.fill_diagonal(bary,alpha)
    rr=np.empty(len(t)*900,np.int32);cc=np.empty_like(rr);dd=np.empty(len(rr))
    for begin in range(0,len(t),1500):
        sl=slice(begin,min(begin+1500,len(t)));G=p2.gradients(g[sl],bary)
        K=p2.LA*np.einsum('eqai,eqbk->eaibk',G,G)/4+p2.MU*np.einsum('eqak,eqbi->eaibk',G,G)/4
        K+=p2.MU*np.einsum('eab,ik->eaibk',np.einsum('eqaj,eqbj->eab',G,G)/4,I)
        K=(K*V[sl,None,None,None,None]).reshape(-1,30,30);dof=(3*conn[sl,:,None]+np.arange(3)).reshape(-1,30);dest=slice(begin*900,sl.stop*900)
        rr[dest]=np.broadcast_to(dof[:,:,None],K.shape).ravel();cc[dest]=np.broadcast_to(dof[:,None,:],K.shape).ravel();dd[dest]=K.ravel()
    A=coo_matrix((dd,(rr,cc)),shape=(3*len(nodes),3*len(nodes))).tocsr();del rr,cc,dd,K,G;gc.collect()
    Af=A[free][:,free].tocsr();Afc=A[free][:,fd].tocsr();Acc=A[fd][:,fd].tocsr()
    x=(nodes-nodes.mean(0))/np.ptp(nodes,axis=0).max();modes=np.zeros((len(nodes),3,6));modes[:,:,:3]=I
    for k in range(3):modes[:,:,3+k]=np.cross(I[k],x)
    ml=p2.pyamg.smoothed_aggregation_solver(Af.tobsr(blocksize=(3,3)),B=modes.reshape(-1,6)[free],symmetry='symmetric',max_coarse=250,max_levels=12,presmoother=('block_gauss_seidel',{'sweep':'symmetric'}),postsmoother=('block_gauss_seidel',{'sweep':'symmetric'}));M=ml.aspreconditioner()
    log('assembled_P2',DOF=A.shape[0],free_DOF=len(free))
    checks=[]
    def solve(rhs,guess,label):
        count=[0]
        def callback(_):count[0]+=1
        value,code=cg(Af,rhs,x0=guess,M=M,rtol=2e-10,atol=0,maxiter=2500,callback=callback)
        error=float(np.linalg.norm(Af@value-rhs)/np.linalg.norm(rhs));assert code==0 and error<2e-6
        checks.append(dict(column=label,iterations=count[0],actual_relative_residual=error));log('P2_solve',**checks[-1]);return value
    v=solve(force.ravel()[free],embed(u1fixed).ravel()[free],'unit_margin')
    W=np.empty((len(free),12));forcing=-Afc@Dt
    for k in range(12):W[:,k]=solve(forcing[:,k],embedded_modes.reshape(-1,12)[free,k],'root_mode_'+str(k))
    St=Dt.T@(Afc.T@W+Acc@Dt);St=(St+St.T)/2;rzero=Dt.T@(Afc.T@v-force.ravel()[fd])
    Q=registration['reference_rotation'];H=np.zeros((12,12));H[:3,:3]=H[3:6,3:6]=H[6:9,6:9]=H[9:12,9:12]=Q.T
    C=H@op['jaw_compliance_m_per_N']@H.T;Ci=np.linalg.inv(C);q=np.linalg.solve(Ci+St,-rzero)
    states={}
    for name,qq,u1,oldq in [('fixed',np.zeros(12),u1fixed,np.zeros(12)),('coupled',q,u1coupled,q1)]:
        u=np.zeros(3*len(nodes));u[fd]=Dt@qq;u[free]=v+W@qq;u=u.reshape(-1,3)
        # Root-mode solves have large unit-rotation right-hand sides. Refine
        # the final small unit-force state against the full coupled residual.
        qq=qq.copy()
        for polish in range(4):
            raw=A@u.ravel()-force.ravel();rf=raw[free]
            rq=Dt.T@raw[fd]+(Ci@qq if name=='coupled' else 0)
            force_error=float(np.linalg.norm(rf)/np.linalg.norm(force.ravel()[free]))
            root_error=float(np.linalg.norm(rq)/max(np.linalg.norm(force),1e-30)) if name=='coupled' else 0.
            log('final_state_residual',state=name,polish=polish,free_residual=force_error,root_residual=root_error)
            if max(force_error,root_error)<2e-7:break
            correction,info=cg(Af,-rf,M=M,rtol=1e-10,atol=0,maxiter=2500)
            assert info==0
            dq=np.linalg.solve(Ci+St,-rq-Dt.T@(Afc.T@correction)) if name=='coupled' else np.zeros(12)
            u.ravel()[free]+=correction+W@dq;qq+=dq;u.ravel()[fd]=Dt@qq
        assert max(force_error,root_error)<2e-6
        ujaw=float(qq@Ci@qq/2) if name=='coupled' else 0.;total=float(u.ravel()@(A@u.ravel())/2+ujaw)
        old=embed(u1);U1=float(old.ravel()@(A@old.ravel())/2+(oldq@Ci@oldq/2 if name=='coupled' else 0.))
        difference=u-old;dq=qq-oldq;gap=float(difference.ravel()@(A@difference.ravel())/2+(dq@Ci@dq/2 if name=='coupled' else 0.))
        identity=abs(total-U1-gap)/max(abs(total),1e-30);assert identity<2e-6 and gap>0
        work=float(np.sum(force*u));energy_error=abs(work-2*total)/max(abs(work),1e-30);assert energy_error<2e-6
        states[name]=dict(displacement=u,q=qq,P1_energy_J=U1,P2_energy_J=total,half_energy_gap_J=gap,nested_energy_identity_relative_error=identity,relative_discrete_energy_norm_gap_percent=100*np.sqrt(gap/total),free_residual=force_error,work_energy_error=energy_error)
    # Positive stress quadrature, on the two frozen physical margins only.
    selected=np.unique(np.r_[maskfile['RA'],maskfile['RB']]);history=[];previous=None;final=None
    for order in [5,7,9,11]:
        qb,qw=p2.duffy(order);summaries=[]
        for name,state in states.items():
            vm=np.empty((len(selected),len(qw)));ten=np.empty_like(vm)
            for begin in range(0,len(selected),300):
                idx=selected[begin:begin+300];G=p2.gradients(g[idx],qb);grad=np.einsum('eai,eqaj->eqij',state['displacement'][conn[idx]],G);_,vv,ttens,_=p2.tensor(grad);vm[begin:begin+len(idx)]=vv;ten[begin:begin+len(idx)]=ttens
            for region in ['RA','RB']:
                use=np.isin(selected,maskfile[region]);weights=(V[selected[use],None]*qw).ravel();qqvm=p2.wquant(vm[use].ravel(),weights)/1e6;qqt=p2.wquant(ten[use].ravel(),weights)/1e6
                summaries.append(dict(state=name,region=region,P2_vm_Q90_Q95_Q99_MPa_per_N=qqvm.tolist(),P2_tensile_Q90_Q95_Q99_MPa_per_N=qqt.tolist()))
        current=np.array([r[k] for r in summaries for k in ['P2_vm_Q90_Q95_Q99_MPa_per_N','P2_tensile_Q90_Q95_Q99_MPa_per_N']]).ravel()
        change=None if previous is None else float((abs(current-previous)/np.maximum(abs(current),1e-12)).max()*100)
        history.append(dict(order=order,points_per_cell=len(qw),maximum_percentile_change_percent=change));previous=current;final=summaries;log('positive_margin_quadrature',**history[-1])
        if order>=7 and change is not None and change<.2:break
    for name,state in states.items():
        np.savez_compressed(D/(name+'_fields.npz'),points_m=nodes,tets_P2=conn,displacement_m=state.pop('displacement'),root_q_m=state.pop('q'),force_N=force,fixed_nodes=np.flatnonzero(fixed2))
    result=dict(status='passed_same_domain_unit_edge_P1_P2',load='RA, pose0, rootward unit1N on the same116 frozen inward-facing boundary faces.',tooth_tetrahedra=len(t),P2_nodes=len(nodes),same_jaw_operator=True,same_root_support_subcomplex=True,load_resultant_N=force.sum(0).tolist(),states=states,quadrature=history,regional_percentiles=final,linear_solves=checks,scope='One matched unit edge load, fixed and jaw-coupled; nested discrete energy differences are not continuum upper bounds. Quadrature changes and P2 differences are retained, not relabelled as physical uncertainty.',runtime_seconds=time.monotonic()-start)
    (D/'results.json').write_text(json.dumps(result,indent=2));(R/'review/p2_edge_run_002/results.json').write_text(json.dumps(result,indent=2));log('COMPLETED_P1_P2_EDGE_PAIR',summary=result)


if __name__=='__main__':main()
