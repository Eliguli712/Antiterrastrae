#!/usr/bin/env python3
"""Conservative two-way linear jaw/tooth transmission through rigid root patches.

This is a geometric candidate and a linear response study, not an anatomical
socket/contact reconstruction or a nonlinear bite/fracture calculation.
"""
from pathlib import Path
import gc, json, sys, time
import numpy as np
import pyvista as pv
from scipy.optimize import minimize
from scipy.sparse import csr_matrix, vstack
from scipy.sparse.linalg import cg, splu

R = Path(__file__).resolve().parents[1]
P = R.parents[1]
B = P / 'output/pdf/debunk_myth_full_reconstruction_2026-10-31'
OLD = P / 'output/ct_fea_calibrated_2026-11-08'
sys.path.insert(0, str(P / 'output/publication_validation_2026-11-12/scripts'))
import elastic_diagnostics as fe
import pyamg

D = R / 'data_v3'; D.mkdir(parents=True, exist_ok=True)
RUN = R / 'review/run_003'
start = time.monotonic(); np.random.seed(20261122)
I = np.eye(3)


def log(stage, **values):
    row = dict(stage=stage, elapsed_seconds=round(time.monotonic()-start, 3), **values)
    with (D / 'progress.jsonl').open('a') as f: f.write(json.dumps(row) + '\n')
    print(json.dumps(row), flush=True)


def modes(x, centre, length):
    out = np.zeros((len(x), 3, 6)); out[:, :, :3] = I
    for j in range(3): out[:, :, j+3] = np.cross(I[j], x-centre) / length
    return out.reshape(-1, 6)


def skew(x):
    return np.array([[0., -x[2], x[1]], [x[2], 0., -x[0]], [-x[1], x[0], 0.]])


def percentile(v, w, q=.95):
    order = np.argsort(v); mass = np.cumsum(w[order], dtype=np.longdouble)
    return float(v[order[np.searchsorted(mass, q*mass[-1])]])


def assemble(p, t, fixed, la, mu):
    g, V = fe.basis_data(p, t)
    K = fe.assemble(p, t, g, V, np.full(len(t), la), np.full(len(t), mu))
    fixed_dof = (3*fixed[:, None] + np.arange(3)).ravel()
    free = np.setdiff1d(np.arange(3*len(p)), fixed_dof)
    return K, free, fixed_dof, g, V


def main():
    assert not (D / 'results.json').exists(), 'Use a new immutable run for a rerun.'
    tooth = np.load(B / 'numerics/L0/solution.npz')
    jaw = np.load(OLD / 'data/jaw_L2_full_1kPa/fields.npz')
    pt, tt, ft, fixed_t = [tooth[k] for k in ['points_m', 'tets', 'boundary_faces', 'fixed_node_indices']]
    pj, tj, fj, fixed_j = [jaw[k] for k in ['points_m', 'tets', 'boundary_faces', 'fixed_node_indices']]
    assert len(tt) == 55852 and len(tj) == 589700
    cap = np.zeros(len(pt), bool); cap[fixed_t] = True
    root_face_ids = np.flatnonzero(cap[ft].all(1))
    root_faces = ft[root_face_ids]; cx = pt[root_faces].mean(1)
    area = np.linalg.norm(np.cross(pt[root_faces[:,1]]-pt[root_faces[:,0]], pt[root_faces[:,2]]-pt[root_faces[:,0]]),axis=1)/2
    basis, centre = tooth['basis'], tooth['center_m']
    side = (((cx-centre)@basis)[:,0] >= 0).astype(int)
    centres = np.array([np.average(cx[side==k],axis=0,weights=area[side==k]) for k in [0,1]])
    length = float(np.linalg.norm(centres[1]-centres[0]))
    assert .01 < length < .05
    cmean = centres.mean(0); rotation = basis.T
    assert abs(np.linalg.det(rotation)-1)<1e-12
    cloud = (cx-cmean)@rotation.T
    # A geometrically specified positive-Y candidate, with X station fixed at 0.
    # This does not identify a tooth socket, dental position or fossil jaw scale.
    lo, hi = pj.min(0), pj.max(0); span = hi-lo
    roi = pj[fj].mean(1)[:,1] >= lo[1]+.65*span[1]
    roi_ids = np.flatnonzero(roi); roi_faces = fj[roi]
    poly = pv.PolyData(pj, np.column_stack([np.full(len(roi_faces),3),roi_faces]).ravel())
    weights = area/area.sum()
    def objective(yz):
        location=np.array([0.,yz[0],yz[1]]); q=cloud+location
        _, closest=poly.find_closest_cell(q,return_closest_point=True)
        difference=q-closest
        return float(np.sum(weights*np.sum(difference*difference,1))), 2*np.sum(weights[:,None]*difference,axis=0)[1:]
    fits=[]
    limits=[(lo[1]+.80*span[1],hi[1]-.025*span[1]),(lo[2]+.002,hi[2]-.002)]
    for z in np.linspace(lo[2]+.15*span[2],hi[2]-.15*span[2],5):
        fit=minimize(objective,[lo[1]+.90*span[1],z],jac=True,bounds=limits,method='L-BFGS-B',options=dict(maxiter=120,ftol=1e-15,gtol=1e-10))
        fits.append(fit)
    best=min(fits,key=lambda r:r.fun); location=np.array([0.,*best.x])
    posed=cloud+location; local_ids,projected=poly.find_closest_cell(posed,return_closest_point=True)
    face_ids=roi_ids[local_ids]; triangles=fj[face_ids]; vertices=pj[triangles]
    x=vertices[:,1:]-vertices[:,:1]; rhs=projected-vertices[:,0]
    gram=np.einsum('eik,ejk->eij',x,x); tail=np.linalg.solve(gram,np.einsum('eik,ek->ei',x,rhs)[:,:,None])[:,:,0]
    bary=np.column_stack([1-tail.sum(1),tail]); assert bary.min()>-1e-7 and bary.max()<1+1e-7
    np.testing.assert_allclose(np.einsum('ei,eij->ej',bary,vertices),projected,atol=1e-11,rtol=0)
    gap=np.linalg.norm(posed-projected,axis=1)
    jaw_centres=(centres-cmean)@rotation.T+location
    extract=[]; rigid_fit_checks=[]
    for k in [0,1]:
        selected=np.flatnonzero(side==k); m=len(selected)
        Dj=modes(projected[selected],jaw_centres[k],length)
        w=np.repeat(area[selected]/area[selected].sum(),3)
        gram=Dj.T@(w[:,None]*Dj);assert np.linalg.cond(gram)<1e8
        least=np.linalg.solve(gram,Dj.T*w)
        rows=[]; cols=[]; data=[]
        for j,index in enumerate(selected):
            for c in range(3):
                for v in range(3):
                    rows.append(3*j+c);cols.append(3*triangles[index,v]+c);data.append(bary[index,v])
        projection=csr_matrix((data,(rows,cols)),shape=(3*m,3*len(pj)))
        operator=csr_matrix(least)@projection
        test=operator@modes(pj,jaw_centres[k],length)
        rigid_fit_checks.append(float(np.max(abs(test-np.eye(6)))))
        assert rigid_fit_checks[-1]<1e-9
        extract.append(operator)
    Bj=vstack(extract).tocsr()
    np.savez_compressed(D/'registration.npz',tooth_points_m=pt,tooth_tets=tt,tooth_boundary_faces=ft,root_faces=root_faces,root_face_side=side,root_face_area_m2=area,root_centres_tooth_m=centres,root_centres_jaw_m=jaw_centres,reference_rotation=rotation,reference_location_m=location,tooth_root_centre_m=cmean,projected_points_m=projected,posed_root_points_m=posed,projection_face_ids=face_ids,barycentric_weights=bary,bridge_distances_m=gap,rotation_length_m=length)
    log('candidate_registration',area_weighted_RMS_gap_mm=float(np.sqrt(weights@(gap*gap))*1000),max_gap_mm=float(gap.max()*1000),root_span_mm=1000*length,location_mm=(location*1000).tolist())

    # Exact static condensation of the tooth, with two six-DOF rigid caps.
    Kt, free_t, fixed_dof_t, gt, Vt=assemble(pt,tt,fixed_t,29e9,28.5e9)
    force_t=np.zeros_like(pt);loaded=ft[tooth['loaded_face_indices']]
    facevector=np.cross(pt[loaded[:,1]]-pt[loaded[:,0]],pt[loaded[:,2]]-pt[loaded[:,0]])/2
    for j in range(3):np.add.at(force_t,loaded[:,j],-1e6*facevector/3)
    ndt=3*len(pt);cap_side=(((pt[fixed_t]-centre)@basis)[:,0]>=0).astype(int)
    Dt=np.zeros((len(fixed_dof_t),12))
    for k in [0,1]:
        use=np.flatnonzero(cap_side==k);dd=(3*use[:,None]+np.arange(3)).ravel()
        Dt[np.ix_(dd,np.arange(6*k,6*k+6))]=modes(pt[fixed_t[use]],centres[k],length)
    Kff=Kt[free_t][:,free_t].tocsc();Kfc=Kt[free_t][:,fixed_dof_t].tocsr();Kcc=Kt[fixed_dof_t][:,fixed_dof_t].tocsr()
    factor=splu(Kff);v=factor.solve(force_t.ravel()[free_t]);W=factor.solve(-Kfc@Dt)
    prescribed=np.zeros((ndt,12));prescribed[fixed_dof_t]=Dt;prescribed[free_t]=W
    baseline=np.zeros(ndt);baseline[free_t]=v
    baseline_difference=float(np.linalg.norm(baseline-tooth['displacement_m'].ravel())/np.linalg.norm(baseline))
    assert baseline_difference<2e-6
    St=Dt.T@(Kfc.T@W+Kcc@Dt);r0=Dt.T@(Kfc.T@v-force_t.ravel()[fixed_dof_t])
    tooth_sym=float(np.linalg.norm(St-St.T)/np.linalg.norm(St));assert tooth_sym<1e-8;St=(St+St.T)/2
    # Each row block is [translation at centre; length*angular velocity].
    rigidq=np.zeros((12,6))
    for k in [0,1]:
        rigidq[6*k:6*k+3]=modes(centres[k:k+1],np.zeros(3),length)
        rigidq[6*k+3:6*k+6,3:]=I
    rigid_displacement_error=float(np.linalg.norm(prescribed@rigidq-modes(pt,np.zeros(3),length))/np.linalg.norm(modes(pt,np.zeros(3),length)))
    assert rigid_displacement_error<2e-7
    cap_metric=[]
    for k in [0,1]:
        dd=modes(cx[side==k],centres[k],length)
        cap_metric.append(dd.T@(np.repeat(area[side==k],3)[:,None]*dd))
    del factor,Kff,Kfc,Kcc;gc.collect()
    log('tooth_condensation',baseline_displacement_relative_error=baseline_difference,rigid_motion_relative_error=rigid_displacement_error,condensed_symmetry_relative_error=tooth_sym)

    Kj, free_j, fixed_dof_j, gj, Vj=assemble(pj,tj,fixed_j,150e6*.3/(1.3*.4),150e6/2.6)
    K=Kj[free_j][:,free_j].tocsr(); rhs=Bj[:,free_j].T.tocsc()
    coordinates=(pj-pj.mean(0))/span.max();rb=modes(coordinates,np.zeros(3),1.)
    ml=pyamg.smoothed_aggregation_solver(K.tobsr(blocksize=(3,3)),B=rb[free_j],symmetry='symmetric',presmoother=('block_gauss_seidel',{'sweep':'symmetric'}),postsmoother=('block_gauss_seidel',{'sweep':'symmetric'}),max_coarse=250,max_levels=12)
    M=ml.aspreconditioner();units=np.zeros((len(free_j),12));unit_checks=[]
    for j in range(12):
        b=rhs[:,j].toarray().ravel();count=[0]
        def cb(_):count[0]+=1
        solution,status=cg(K,b,M=M,rtol=1e-9,atol=0,maxiter=2000,callback=cb)
        residual=float(np.linalg.norm(K@solution-b)/np.linalg.norm(b))
        log('unit_initial_true_residual',column=j,status=int(status),relative_residual=residual)
        for polish in range(3):
            if residual<1e-7:break
            correction,istat=cg(K,b-K@solution,M=M,rtol=1e-5,atol=0,maxiter=1200)
            solution+=correction;residual=float(np.linalg.norm(K@solution-b)/np.linalg.norm(b))
            log('unit_residual_correction',column=j,polish=polish,status=int(istat),relative_residual=residual)
        assert residual<2e-6
        units[:,j]=solution;unit_checks.append(dict(column=j,iterations=count[0],relative_residual=residual))
        log('jaw_generalised_unit_solve',**unit_checks[-1])
    Cj=Bj[:,free_j]@units;reciprocity=float(np.linalg.norm(Cj-Cj.T)/np.linalg.norm(Cj));assert reciprocity<1e-6
    Cj=(Cj+Cj.T)/2;assert np.linalg.eigvalsh(Cj).min()>0
    q0=np.asarray(Bj@jaw['linear_displacement_m'].ravel())
    baseline_jaw_res=float(np.linalg.norm((Kj@jaw['linear_displacement_m'].ravel()-jaw['force_N'].ravel())[free_j])/np.linalg.norm(jaw['force_N'].ravel()[free_j]))
    assert baseline_jaw_res<2e-6
    np.savez_compressed(D/'condensed_operators.npz',tooth_stiffness_N_per_m=St,tooth_root_reaction_at_zero_N=r0,jaw_compliance_m_per_N=Cj,jaw_generalised_background_m=q0,tooth_pressure_displacement_m=baseline.reshape(-1,3),tooth_unit_displacements=prescribed.reshape(-1,3,12),jaw_free_dof=free_j,jaw_unit_displacements_m_per_N=units,cap_metric=np.array(cap_metric),tooth_force_N=force_t)
    log('jaw_condensation',reciprocity_relative_error=reciprocity,linear_1kPa_source_residual=baseline_jaw_res)

    masks0=np.load(B/'numerics/L0/region_masks.npz');allrows=[];cases=[]
    def stress(displacement):
        G=np.einsum('eai,eaj->eij',displacement[tt[:,1:]]-displacement[tt[:,:1]],gt[:,1:]);eps=(G+G.transpose(0,2,1))/2
        return 29e9*np.trace(eps,axis1=1,axis2=2)[:,None,None]*I+57e9*eps
    def evaluate(name,u,**metadata):
        sigma=stress(u);principal=np.linalg.eigvalsh(sigma);vm=np.sqrt(1.5*np.sum((sigma-np.trace(sigma,axis1=1,axis2=2)[:,None,None]*I/3)**2,(1,2)))
        rows=[]
        for key in ['R0','RA','RB','Rtip','Rcr','Rroot']:
            select=masks0[key];w=Vt[select]
            row=dict(region=key,vm_Q95_MPa=percentile(vm[select],w)/1e6,tensile_Q95_MPa=percentile(np.maximum(principal[select,-1],0),w)/1e6)
            # Opening/shear on geometric planes, without assigning a real crack.
            for axis,label in enumerate(['transverse','rootward','thickness']):
                normal=basis[:,axis];traction=sigma[select]@normal;sn=traction@normal;tau=np.linalg.norm(traction-sn[:,None]*normal,axis=1)
                row[label+'_opening_Q95_MPa']=percentile(np.maximum(sn,0),w)/1e6;row[label+'_shear_Q95_MPa']=percentile(tau,w)/1e6
            rows.append(row);allrows.append(dict(case=name,**row))
        result=dict(name=name,regions=rows,max_displacement_mm=float(np.linalg.norm(u,axis=1).max()*1000),**metadata)
        np.savez_compressed(D/(name+'.npz'),displacement_m=u,stress_Pa=sigma,principal_stresses_Pa=principal)
        cases.append(result);return result
    evaluate('fixed_caps_1MPa',baseline.reshape(-1,3),scope='Original L0 zero-cap benchmark.')
    for angle in [-15,0,15]:
        theta=np.deg2rad(angle);rz=np.array([[np.cos(theta),-np.sin(theta),0],[np.sin(theta),np.cos(theta),0],[0,0,1.]])
        Q=rz@rotation;ct=(centres-cmean)@Q.T+location
        H=np.zeros((12,12))
        for k in [0,1]:
            e=ct[k]-jaw_centres[k];sl=slice(6*k,6*k+6)
            H[sl,sl]=np.block([[Q.T,-Q.T@skew(e)/length],[np.zeros((3,3)),Q.T]])
        for stiffness in [None,1e13,1e15]:
            Ca=np.zeros((12,12))
            if stiffness is not None:
                for k in [0,1]:Ca[6*k:6*k+6,6*k:6*k+6]=np.linalg.inv(stiffness*cap_metric[k])
            C=H@Cj@H.T+Ca;C=(C+C.T)/2;Ci=np.linalg.inv(C)
            for background in ([0,1] if angle==0 and stiffness is None else [0]):
                qref=background*(H@q0);q=np.linalg.solve(Ci+St,Ci@qref-r0);Qroot=St@q+r0
                u=(baseline+prescribed@q).reshape(-1,3);Qjaw=H.T@Qroot
                uj=background*jaw['linear_displacement_m'].copy();uj.ravel()[free_j]-=units@Qjaw
                reaction_j=Kj@uj.ravel()-background*jaw['force_N'].ravel()+Bj.T@Qjaw
                residual_j=float(np.linalg.norm(reaction_j[free_j])/max(np.linalg.norm((background*jaw['force_N'].ravel()-Bj.T@Qjaw)[free_j]),1e-30))
                residual_t=(Kt@u.ravel()-force_t.ravel())[free_t]
                residual_t=float(np.linalg.norm(residual_t)/np.linalg.norm(force_t.ravel()[free_t]))
                compatibility=float(np.linalg.norm(q-H@(Bj@uj.ravel())+Ca@Qroot)/max(np.linalg.norm(q),1e-30))
                Et=float(u.ravel()@(Kt@u.ravel())/2);Ej=float(uj.ravel()@(Kj@uj.ravel())/2);Ea=float(Qroot@Ca@Qroot/2)
                work=float(force_t.ravel()@u.ravel()+background*jaw['force_N'].ravel()@uj.ravel())
                energy_error=abs(2*(Et+Ej+Ea)-work)/max(abs(work),1e-30)
                reaction=np.zeros_like(pj);reaction.ravel()[fixed_dof_j]=reaction_j[fixed_dof_j]
                ftworld=force_t@Q.T;posed_tooth=(pt-cmean)@Q.T+location
                net=background*jaw['force_N'].sum(0)+reaction.sum(0)+ftworld.sum(0)
                moment=(np.cross(pj,background*jaw['force_N']+reaction).sum(0)+np.cross(posed_tooth,ftworld).sum(0))
                force_error=float(np.linalg.norm(net)/np.linalg.norm(force_t.sum(0)))
                moment_error=float(np.linalg.norm(moment)/(np.linalg.norm(force_t.sum(0))*span.max()))
                assert max(residual_j,residual_t,compatibility,energy_error,force_error,moment_error)<2e-5
                name='coupled_a'+str(angle).replace('-','minus')+('_tied' if stiffness is None else '_k'+str(int(np.log10(stiffness))))+'_jaw'+str(background)+'kPa'
                result=evaluate(name,u,angle_deg=angle,attachment_N_per_m3=stiffness,jaw_background_kPa=background,tooth_pressure_MPa=1.,root_generalised_displacement_m=q.tolist(),root_generalised_reaction_N=Qroot.tolist(),jaw_max_displacement_mm=float(np.linalg.norm(uj,axis=1).max()*1000),tooth_free_residual=residual_t,jaw_free_residual=residual_j,compatibility_relative_error=compatibility,energy_work_relative_error=energy_error,global_force_relative_error=force_error,reference_moment_relative_error=moment_error,elastic_energy_J=[Et,Ej,Ea])
                log('verified_coupled_case',name=name,edge_tensile_Q95_MPa=[r['tensile_Q95_MPa'] for r in result['regions'] if r['region'] in ['RA','RB']],jaw_max_displacement_mm=result['jaw_max_displacement_mm'])
                if angle==0 and stiffness is None and background==0:np.savez_compressed(D/'jaw_coupled_display.npz',points_m=pj,tets=tj,boundary_faces=fj,displacement_m=uj,force_N=jaw['force_N']*0,reaction_N=reaction)
                if angle==0 and stiffness is None and background==1:
                    qo=np.linalg.solve(Ci+St,Ci@(H@q0));ro=St@qo
                    uto=(prescribed@qo).reshape(-1,3)
                    ujo=jaw['linear_displacement_m'].copy();ujo.ravel()[free_j]-=units@(H.T@ro)
                    rj=Kj@ujo.ravel()-jaw['force_N'].ravel()+Bj.T@(H.T@ro)
                    den=max(np.linalg.norm(jaw['force_N'].ravel()[free_j]),1e-30)
                    erj=float(np.linalg.norm(rj[free_j])/den)
                    ert=float(np.linalg.norm((Kt@uto.ravel())[free_t])/np.linalg.norm(force_t.ravel()[free_t]))
                    eo=float(uto.ravel()@(Kt@uto.ravel())+ujo.ravel()@(Kj@ujo.ravel()))
                    wo=float(jaw['force_N'].ravel()@ujo.ravel());ew=abs(eo-wo)/max(abs(wo),1e-30)
                    assert max(erj,ert,ew)<2e-5
                    evaluate('jaw_only_a0_tied',uto,angle_deg=0,attachment_N_per_m3=None,jaw_background_kPa=1,tooth_pressure_MPa=0.,root_generalised_displacement_m=qo.tolist(),root_generalised_reaction_N=ro.tolist(),jaw_max_displacement_mm=float(np.linalg.norm(ujo,axis=1).max()*1000),tooth_free_residual=ert,jaw_free_residual=erj,energy_work_relative_error=ew,scope='Isolated jaw-driven contribution on the same coupled linear operators; no crown bite/contact load.')
    import csv
    with (D/'regional_edge_diagnostics.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=allrows[0].keys());writer.writeheader();writer.writerows(allrows)
    result=dict(status='passed_finite_linear_transmission_study',tooth_tetrahedra=len(tt),jaw_tetrahedra=len(tj),root_generalised_DOF=12,registration=dict(station='Geometric positive-Y region, fixed X=0; two translation parameters fitted to closest surface.',rotation=rotation.tolist(),location_mm=(location*1000).tolist(),area_weighted_RMS_gap_mm=float(np.sqrt(weights@(gap*gap))*1000),max_gap_mm=float(gap.max()*1000),rotation_length_mm=1000*length,meaning='Rigid massless bridge candidate; no socket, anatomical dental position, tissue attachment or fossil jaw scale identified.'),checks=dict(root_extraction_rigid_modes=rigid_fit_checks,tooth_baseline_displacement_relative_error=baseline_difference,tooth_rigid_motion_relative_error=rigid_displacement_error,jaw_compliance_reciprocity_relative_error=reciprocity,jaw_linear_1kPa_baseline_residual=baseline_jaw_res,jaw_unit_solves=unit_checks),cases=cases,scope='Two-way static condensation with work-conjugate translation/rotation extraction. Small-strain response coefficients only. Root forces AND moments transfer; no scalar stress multiplication.',non_claims=['No validated fossil placement, nonlinear contact or coupled nonlinear bite.', 'The tooth mesh is L0; no resolved serration-tip fracture or A3/P2 coupled convergence.', 'Large linear displacement coefficients are outside a literal small-motion interpretation.', 'Principal tension and geometric-plane opening/shear are diagnostics; strength, toughness, flaws and load history are unmeasured.'],runtime_seconds=time.monotonic()-start)
    (D/'results.json').write_text(json.dumps(result,indent=2));(RUN/'results.json').write_text(json.dumps(result,indent=2));log('COMPLETED_LINEAR_TRANSMISSION',case_count=len(cases))


if __name__=='__main__':main()
