#!/usr/bin/env python3
"""Unit-force macroscopic margin response, with fixed or coupled root support.

All patches are frozen and compressive in the sampled load directions. Tangential
traction is prescribed, not obtained from a calibrated friction/contact law.
"""
from pathlib import Path
import csv,json,sys,time
import numpy as np
from scipy.sparse.linalg import splu

R=Path(__file__).resolve().parents[1];P=R.parents[1]
B=P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31'
sys.path.insert(0,str(P/'output/publication_validation_2026-11-12/scripts'))
import elastic_diagnostics as fe

OUT=R/'edge_data';OUT.mkdir(exist_ok=True)
I=np.eye(3);start=time.monotonic()


def skew(x):return np.array([[0.,-x[2],x[1]],[x[2],0.,-x[0]],[-x[1],x[0],0.]])
def mode(x,c,L):
    d=np.zeros((len(x),3,6));d[:,:,:3]=I
    for j in range(3):d[:,:,j+3]=np.cross(I[j],x-c)/L
    return d.reshape(-1,6)
def wq(x,w,q=.95):
    order=np.argsort(x);mass=np.cumsum(w[order],dtype=np.longdouble)
    return float(x[order[np.searchsorted(mass,q*mass[-1])]])


def main():
    assert not (OUT/'results.json').exists()
    result=json.loads((R/'data_v3/results.json').read_text());assert result['status']=='passed_finite_linear_transmission_study'
    a=np.load(B/'numerics/L0/solution.npz');reg=np.load(R/'data_v3/registration.npz');op=np.load(R/'data_v3/condensed_operators.npz')
    p,t,f,fixed=[a[k] for k in ['points_m','tets','boundary_faces','fixed_node_indices']]
    masks=np.load(B/'numerics/L0/region_masks.npz');basis=a['basis'];centres=reg['root_centres_tooth_m'];cmean=reg['tooth_root_centre_m'];location=reg['reference_location_m'];Q0=reg['reference_rotation'];L=float(reg['rotation_length_m']);jawcentres=reg['root_centres_jaw_m']
    St,Cj,Dm,metric=[op[k] for k in ['tooth_stiffness_N_per_m','jaw_compliance_m_per_N','tooth_unit_displacements','cap_metric']]
    Dm=Dm.reshape(-1,12);Sdisp=[];root_reactions=[];nodal_weights=[];patches=[]
    g,V=fe.basis_data(p,t);K=fe.assemble(p,t,g,V,np.full(len(t),29e9),np.full(len(t),28.5e9))
    fd=(3*fixed[:,None]+np.arange(3)).ravel();free=np.setdiff1d(np.arange(3*len(p)),fd);Kff=K[free][:,free].tocsc();Kfc=K[free][:,fd].tocsr();factor=splu(Kff)
    Dt=Dm[fd]
    allface=t[:,[[1,2,3],[0,2,3],[0,1,3],[0,1,2]]].reshape(-1,3)
    lookup={tuple(sorted(face)):j//4 for j,face in enumerate(allface)}
    owner=np.array([lookup[tuple(sorted(face))] for face in f])
    vector=np.cross(p[f[:,1]]-p[f[:,0]],p[f[:,2]]-p[f[:,0]])/2;area=np.linalg.norm(vector,axis=1);normal=vector/area[:,None]
    directions=[]
    for angle in [-15,0,15]:
        th=np.deg2rad(angle);rz=np.array([[np.cos(th),-np.sin(th),0],[np.sin(th),np.cos(th),0],[0,0,1.]])
        Q=rz@Q0
        for oblique in [0,15,30]:
            beta=np.deg2rad(oblique);world=np.cos(beta)*np.array([0.,1,0])+np.sin(beta)*(Q0@basis[:,2])
            directions.append(Q.T@world)
    directions=np.array(directions)
    # Frozen intersection: every retained face receives inward normal traction
    # for every tested pose/obliquity. This does not impose a friction coefficient.
    inward=(normal@directions.T).max(1)<-.15
    sidewall=abs(normal@basis[:,2])<=.65
    for margin in ['RA','RB']:
        select=np.isin(owner,masks[margin]) & inward & sidewall
        ids=np.flatnonzero(select);assert len(ids)>=3 and area[select].sum()>1e-7
        weight=np.zeros(len(p))
        for j in range(3):np.add.at(weight,f[select,j],area[select]/(3*area[select].sum()))
        assert abs(weight.sum()-1)<1e-12
        U=np.zeros((3*len(p),3));rzero=np.zeros((12,3))
        for axis in range(3):
            force=np.zeros_like(p);force[:,axis]=weight
            U[free,axis]=factor.solve(force.ravel()[free])
            rzero[:,axis]=Dt.T@(Kfc.T@U[free,axis]-force.ravel()[fd])
            assert np.linalg.norm((K@U[:,axis]-force.ravel())[free])/np.linalg.norm(force.ravel()[free])<2e-7
        Sdisp.append(U);root_reactions.append(rzero);nodal_weights.append(weight)
        patches.append(dict(margin=margin,face_ids=ids.tolist(),faces=len(ids),area_mm2=float(area[select].sum()*1e6),selection='Frozen L0 margin owner, abs(n dot thickness)<=.65, inward dot<-0.15 for all 9 prescribed directions.'))
    np.savez_compressed(OUT/'unit_response_basis.npz',unit_displacement_m_per_N=np.array(Sdisp),root_reaction_N_per_N=np.array(root_reactions),nodal_force_weights=np.array(nodal_weights),patch_face_ids_RA=np.array(patches[0]['face_ids']),patch_face_ids_RB=np.array(patches[1]['face_ids']))
    rows=[];cases=[]
    for angle in [-15,0,15]:
        th=np.deg2rad(angle);rz=np.array([[np.cos(th),-np.sin(th),0],[np.sin(th),np.cos(th),0],[0,0,1.]])
        Q=rz@Q0;ct=(centres-cmean)@Q.T+location;H=np.zeros((12,12))
        for k in [0,1]:
            e=ct[k]-jawcentres[k];H[6*k:6*k+6,6*k:6*k+6]=np.block([[Q.T,-Q.T@skew(e)/L],[np.zeros((3,3)),Q.T]])
        for oblique in [0,15,30]:
            beta=np.deg2rad(oblique);world=np.cos(beta)*np.array([0.,1,0])+np.sin(beta)*(Q0@basis[:,2]);direction=Q.T@world
            for mi,margin in enumerate(['RA','RB']):
                base=Sdisp[mi]@direction;rzero=root_reactions[mi]@direction;force=nodal_weights[mi][:,None]*direction
                for support in ['fixed','tied','k13']:
                    Ca=np.zeros((12,12))
                    if support=='k13':
                        for k in [0,1]:Ca[6*k:6*k+6,6*k:6*k+6]=np.linalg.inv(1e13*metric[k])
                    if support=='fixed':q=np.zeros(12)
                    else:
                        C=H@Cj@H.T+Ca;C=(C+C.T)/2;Ci=np.linalg.inv(C);q=np.linalg.solve(Ci+St,-rzero)
                    u=(base+Dm@q).reshape(-1,3);root=St@q+rzero
                    G=np.linalg.solve(p[t[:,1:]]-p[t[:,:1]],u[t[:,1:]]-u[t[:,:1]]).transpose(0,2,1);eps=(G+G.transpose(0,2,1))/2
                    sigma=29e9*np.trace(eps,axis1=1,axis2=2)[:,None,None]*I+57e9*eps;ev=np.linalg.eigvalsh(sigma);dev=sigma-np.trace(sigma,axis1=1,axis2=2)[:,None,None]*I/3;vm=np.sqrt(1.5*np.sum(dev*dev,(1,2)))
                    residual=(K@u.ravel()-force.ravel())[free];rcheck=float(np.linalg.norm(residual)/np.linalg.norm(force.ravel()[free]))
                    Qjaw=H.T@root;Ej=0 if support=='fixed' else float(Qjaw@Cj@Qjaw/2);Ea=float(root@Ca@root/2);Et=float(u.ravel()@(K@u.ravel())/2);work=float(np.sum(force*u));energy=abs(2*(Et+Ej+Ea)-work)/max(abs(work),1e-30)
                    assert max(rcheck,energy)<2e-5
                    c=dict(name=f'{margin}_pose{angle}_oblique{oblique}_{support}',loaded_margin=margin,pose_deg=angle,obliquity_deg=oblique,support=support,resultant_N=1.,direction_world=world.tolist(),direction_body=direction.tolist(),root_generalised_displacement_m=q.tolist(),root_generalised_reaction_N=root.tolist(),root_generalised_reaction_jaw_N=Qjaw.tolist(),free_residual=rcheck,work_energy_error=energy,max_tooth_displacement_mm=float(np.linalg.norm(u,axis=1).max()*1000),max_tooth_displacement_gradient=float(np.linalg.norm(G,axis=(1,2)).max()),regions=[])
                    if support!='fixed':c['max_jaw_displacement_mm']=float(np.linalg.norm((op['jaw_unit_displacements_m_per_N']@Qjaw).reshape(-1,3),axis=1).max()*1000)
                    for region in ['R0','RA','RB','Rtip','Rcr','Rroot']:
                        use=masks[region];w=V[use];rr=dict(region=region,tensile_Q95_MPa_per_N=wq(np.maximum(ev[use,-1],0),w)/1e6,vm_Q95_MPa_per_N=wq(vm[use],w)/1e6)
                        for axis,label in enumerate(['transverse','rootward','thickness']):
                            nn=basis[:,axis];traction=sigma[use]@nn;sn=traction@nn;tau=np.linalg.norm(traction-sn[:,None]*nn,axis=1)
                            rr[label+'_opening_Q95_MPa_per_N']=wq(np.maximum(sn,0),w)/1e6;rr[label+'_shear_Q95_MPa_per_N']=wq(tau,w)/1e6
                        c['regions'].append(rr);rows.append(dict(case=c['name'],loaded_margin=margin,pose_deg=angle,obliquity_deg=oblique,support=support,**rr))
                    cases.append(c)
                    if angle==0 and oblique in [0,30] and margin=='RA' and support in ['fixed','tied']:
                        np.savez_compressed(OUT/(c['name']+'.npz'),displacement_m=u,stress_Pa=sigma,principal_stresses_Pa=ev,force_N=force)
    with (OUT/'regional_response.csv').open('w') as stream:
        writer=csv.DictWriter(stream,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
    output=dict(status='passed_finite_unit_margin_response',cases=cases,patches=patches,tooth_tetrahedra=len(t),jaw_tetrahedra=589700,reference_force_N=1.,scope='One geometric registration, fixed inward-facing macroscopic margin patches, poses-15/0/15degrees, out-of-plane obliquity0/15/30degrees and fixed/tied/k1e13 support. No solved contact/friction or fracture criterion.',non_claims=['No observed fossil crack initiation, serration-tip strength or biological bite load.','No convergence/P2 test for these new margin-traction cases; original P1/P2 differences apply only to their own pressure test.','The jaw scale and fitted root connections are assumed geometric candidates.'],runtime_seconds=time.monotonic()-start)
    (OUT/'results.json').write_text(json.dumps(output,indent=2));(R/'review/edge_run_001/results.json').write_text(json.dumps(output,indent=2))
    print(json.dumps(dict(status=output['status'],cases=len(cases),patches=patches,runtime_seconds=output['runtime_seconds']),indent=2))


if __name__=='__main__':main()
