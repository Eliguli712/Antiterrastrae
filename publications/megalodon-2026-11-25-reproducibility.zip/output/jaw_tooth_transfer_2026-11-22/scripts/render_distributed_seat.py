#!/usr/bin/env python3
"""Render the fitted elastic seat diagnostics from the verified local solve."""

import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm, TwoSlopeNorm
import numpy as np
import pyvista as pv
from scipy.spatial import cKDTree

R = Path(__file__).resolve().parents[1]
PAPER = R.parents[1] / 'output/pdf/debunk_myth_preprint_2026-11-19'
DATA = R / 'distributed_seat'


def unit(a):
    return a/np.linalg.norm(a)


def main():
    state = np.load(DATA/'seat_display.npz')
    records = json.loads((DATA/'summary.json').read_text())['cases']
    area, side, point = state['area'], state['side'], state['point']
    mean = np.average(point,axis=0,weights=area)
    xaxis = unit(np.average(point[side==1],axis=0,weights=area[side==1])-
                 np.average(point[side==0],axis=0,weights=area[side==0]))
    # Principal tangent view anchored to both existing load-transfer lobes.
    plane = np.linalg.svd(np.sqrt(area)[:,None]*(point-mean),full_matrices=False)[2][-1]
    zaxis = unit(plane-xaxis*(xaxis@plane))
    full = np.load(R.parents[1]/'output/ct_fea_calibrated_2026-11-08/data/jaw_L2_full_1kPa/fields.npz')
    registration = np.load(R/'data_v3/registration.npz')
    keep = registration['bridge_distances_m'] <= .0015
    ids_on_jaw = registration['projection_face_ids'][keep]
    tri = full['points_m'][full['boundary_faces'][ids_on_jaw]]
    owner = full['points_m'][full['tets'][full['boundary_owner'][ids_on_jaw]]].mean(1)
    n = np.cross(tri[:,1]-tri[:,0], tri[:,2]-tri[:,0])
    n /= np.linalg.norm(n, axis=1, keepdims=True)
    n[np.einsum('ij,ij->i', n, owner-tri.mean(1)) > 0] *= -1
    if zaxis @ np.average(n, axis=0, weights=area) < 0:
        zaxis *= -1
    yaxis = np.cross(zaxis,xaxis)
    frame = np.column_stack((xaxis,yaxis,zaxis))
    uv = (point-mean)@frame*1000
    jaw_points = (state['jaw_points']-mean)@frame*1000
    tets = state['jaw_tets']
    cell = state['jaw_cell_vm_Pa']/1e6
    volume = state['jaw_volume_m3']
    den = sum(np.bincount(tets[:,k],weights=volume,minlength=len(jaw_points)) for k in range(4))
    num = sum(np.bincount(tets[:,k],weights=volume*cell,minlength=len(jaw_points)) for k in range(4))
    local_vm = num/den
    limits = (.002,.2)
    original_points = (full['points_m']-mean)@frame*1000
    faces = state['jaw_boundary_faces']
    ids = state['jaw_node_ids']
    np.testing.assert_allclose(original_points[ids],jaw_points,atol=1.e-10)
    outside = np.ones(len(original_points),bool)
    outside[ids] = False
    distance = cKDTree(original_points[outside]).query(jaw_points,workers=2)[0]
    a = np.clip(distance/5.,0.,1.)[:,None]
    a = a*a*(3-2*a)
    context = np.array([.90,.84,.72])
    recovered = plt.colormaps['turbo'](LogNorm(*limits,clip=True)(np.maximum(local_vm,limits[0])))[:,:3]
    rgb_local = a*recovered+(1-a)*context
    geometry = pv.PolyData(jaw_points,np.column_stack((np.full(len(faces),3),faces)).ravel())
    geometry.point_data['mapped_rgb'] = np.round(255*rgb_local).astype(np.uint8)
    plotter = pv.Plotter(off_screen=True,window_size=(1200,750))
    plotter.set_background('white')
    plotter.add_mesh(geometry,scalars='mapped_rgb',rgb=True,show_scalar_bar=False,
                     ambient=1.,diffuse=0.,lighting=False)
    plotter.camera_position=[(0,0,150),(0,0,0),(0,1,0)]
    plotter.enable_parallel_projection()
    # Show the cropped physical surface rather than the tetrahedral cut.
    plotter.camera.parallel_scale=21.
    rgb=plotter.screenshot(return_img=True)
    plotter.close()

    plt.rcParams.update({'font.family':'sans-serif','font.size':6,'axes.spines.top':False,
                         'axes.spines.right':False,'pdf.fonttype':42})
    f=plt.figure(figsize=(183/25.4,43/25.4))
    a=f.add_axes((.025,.25,.294,.655))
    a.imshow(rgb,extent=(-33.6,33.6,-21,21))
    for lobe, color in ((0,'#4a5db1'),(1,'#bd3b69')):
        take=side==lobe
        a.scatter(uv[take,0],uv[take,1],s=3,facecolors='white',edgecolors=color,linewidths=.35)
    a.set(xlim=(-24,24),ylim=(-14,14))
    a.set_axis_off()
    u=f.colorbar(plt.cm.ScalarMappable(norm=LogNorm(*limits),cmap='turbo'),
                 cax=f.add_axes((.067,.167,.207,.042)),orientation='horizontal',
                 ticks=[.002,.02,.2],extend='both')
    u.ax.set_xlabel(r'Local jaw von Mises (MPa N$^{-1}$)',labelpad=2)
    u.ax.set_xticklabels(['0.002','0.02','0.2'])
    u.ax.tick_params(labelsize=5.5,pad=1.3)
    b=f.add_axes((.385,.425,.24,.45))
    normal=state['seat_normal_MPa_per_N']
    n=TwoSlopeNorm(0,vmin=-1.5,vmax=1.5)
    dots=b.scatter(uv[:,0],uv[:,1],s=4+1.7e7*area,c=normal,cmap='RdBu_r',norm=n,
                   edgecolors='#394b58',linewidths=.13)
    b.set_xlabel('Across root lobes (mm)',labelpad=1)
    b.set_ylabel('In-plane (mm)',labelpad=1)
    b.tick_params(pad=1)
    b.text(.06,.78,'0',transform=b.transAxes,color='#4a5db1')
    b.text(.92,.81,'1',transform=b.transAxes,color='#bd3b69')
    cb=f.colorbar(dots,cax=f.add_axes((.431,.167,.151,.042)),orientation='horizontal',extend='both')
    cb.set_ticks([-1.5,0,1.5])
    cb.ax.set_xlabel(r'Signed normal traction (MPa N$^{-1}$)',labelpad=2)
    cb.ax.tick_params(labelsize=5.5,pad=1.3)
    c=f.add_axes((.730,.28,.258,.60))
    use=lambda k: next(x for x in records if x['radius_mm']==24 and
                      x['k_n_N_per_m3']==k and x['name']=='RA_pose0_oblique30_tied')
    soft,stiff=use(1e12),use(1e13)
    group=np.arange(3)
    for offset,key,item,color in [(-.25,'archived_rigid_tooth_q95_MPa_per_N',stiff,'#8490a5'),
             (0,'tooth_tensile_q95_MPa_per_N',soft,'#4d99aa'),
             (.25,'tooth_tensile_q95_MPa_per_N',stiff,'#b63e68')]:
        values=[item[key][r] for r in ('RA','RB','Rcr')]
        c.bar(group+offset,values,width=.23,color=color)
    c.set_xticks(group,['A margin','B margin','Cervical'])
    c.set_ylabel(r'Tensile $Q_{0.95}$ (MPa N$^{-1}$)')
    legend=f.legend(c.containers,['Rigid seats',r'$k_n=10^{12}$',r'$k_n=10^{13}$'],
                    loc='lower right',bbox_to_anchor=(.996,.035),ncol=3,frameon=False,
                    columnspacing=.9,handlelength=.9)
    assert legend
    for xpos,letter,title in ((.017,'e','Recovered local jaw field'),(.351,'f','Two fitted seat footprints'),(.695,'g','Tooth tensile response')):
        f.text(xpos,.965,letter,weight='bold',va='top')
        f.text(xpos+.025,.965,title,weight='bold',va='top')
    stem=PAPER/'figures/jaw_root_connection_FEA'
    f.savefig(stem.with_suffix('.pdf'),dpi=550)
    f.savefig(stem.with_suffix('.png'),dpi=300)
    plt.close(f)


if __name__=='__main__':
    main()
