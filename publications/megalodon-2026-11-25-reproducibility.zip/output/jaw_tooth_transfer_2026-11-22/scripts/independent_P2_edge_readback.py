"""Recover quadratic strain energy/internal forces without the assembled matrix."""
from pathlib import Path
import json,time
import numpy as np

R=Path(__file__).resolve().parents[1];P=R.parents[1]
B=P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31'
I=np.eye(3);edges=[(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]


def recover(p,t,u):
    bary=np.full((4,4),.1381966011250105);np.fill_diagonal(bary,.5854101966249685)
    fi=np.zeros_like(p);energy=0.
    for start in range(0,len(t),1000):
        tt=t[start:start+1000];X=p[tt[:,1:4]]-p[tt[:,:1]];inv=np.linalg.solve(X,np.broadcast_to(I,X.shape))
        g=np.empty((len(tt),4,3));g[:,1:]=inv.transpose(0,2,1);g[:,0]=-g[:,1:].sum(1)
        ng=np.empty((len(tt),4,10,3));ng[:,:,:4]=(4*bary[None,:,:,None]-1)*g[:,None]
        for k,(a,b) in enumerate(edges):ng[:,:,4+k]=4*(bary[None,:,a,None]*g[:,None,b]+bary[None,:,b,None]*g[:,None,a])
        grad=np.einsum('eai,eqaj->eqij',u[tt],ng);eps=(grad+grad.transpose(0,1,3,2))/2
        sig=29e9*np.trace(eps,axis1=2,axis2=3)[:,:,None,None]*I+57e9*eps;V=abs(np.linalg.det(X))/6
        local=np.einsum('eqij,eqaj,e->eai',sig,ng,V)/4
        for k in range(10):np.add.at(fi,tt[:,k],local[:,k])
        energy+=float(np.einsum('eqij,eqij,e->',sig,eps,V))/8
    return fi,energy


def main():
    begin=time.monotonic();base=np.load(B/'numerics/L0/solution.npz');reg=np.load(R/'data_v3/registration.npz');op=np.load(R/'data_v3/condensed_operators.npz');unit=np.load(R/'edge_data/unit_response_basis.npz')
    Q=reg['reference_rotation'];H=np.zeros((12,12))
    for k in range(4):H[3*k:3*k+3,3*k:3*k+3]=Q.T
    Ci=np.linalg.inv(H@op['jaw_compliance_m_per_N']@H.T)
    cases=json.loads((R/'edge_data/results.json').read_text())['cases'];fixedcase=next(c for c in cases if c['name']=='RA_pose0_oblique0_fixed');direction=np.array(fixedcase['direction_body'])
    p1fixed=(unit['unit_displacement_m_per_N'][0]@direction).reshape(-1,3);q1=np.array(next(c for c in cases if c['name']=='RA_pose0_oblique0_tied')['root_generalised_displacement_m']);p1coupled=p1fixed+op['tooth_unit_displacements']@q1
    original=base['points_m'];tet=base['tets'];pairs=np.unique(np.sort(tet[:,edges].reshape(-1,2),axis=1),axis=0)
    results=[]
    for name,old,oldq in [('fixed',p1fixed,np.zeros(12)),('coupled',p1coupled,q1)]:
        a=np.load(R/'p2_edge_data_v2'/(name+'_fields.npz'));p,t,u,fixed,force,q=[a[k] for k in ['points_m','tets_P2','displacement_m','fixed_nodes','force_N','root_q_m']]
        np.testing.assert_array_equal(p[:len(original)],original);np.testing.assert_allclose(p[len(original):],original[pairs].mean(1),rtol=0,atol=0)
        fint,Et=recover(p,t,u);free=np.ones(len(p),bool);free[fixed]=False;error=float(np.linalg.norm((fint-force)[free])/np.linalg.norm(force[free]))
        Ej=float(q@Ci@q/2) if name=='coupled' else 0.;work=float(np.sum(force*u));energy=abs(2*(Et+Ej)-work)/max(abs(work),1e-30)
        embedded=np.vstack([old,old[pairs].mean(1)]);_,gap_tooth=recover(p,t,u-embedded)
        gap_jaw=float((q-oldq)@Ci@(q-oldq)/2) if name=='coupled' else 0.
        assert max(error,energy)<2e-6
        row=dict(case=name,independent_internal_force_residual=error,independent_tooth_energy_J=Et,independent_jaw_energy_J=Ej,independent_work_energy_relative_error=energy,tooth_half_energy_gap_J=gap_tooth,jaw_half_energy_gap_J=gap_jaw,tooth_discrete_energy_norm_difference_percent=100*np.sqrt(gap_tooth/Et),total_discrete_energy_norm_difference_percent=100*np.sqrt((gap_tooth+gap_jaw)/(Et+Ej)))
        results.append(row)
    result=dict(status='passed',cases=results,scope='Independent four-point exact polynomial strain/force integration on both P2 fields. Energy-norm differences compare finite discrete solutions, without a continuum upper bound.',runtime_seconds=time.monotonic()-begin)
    (R/'review/P2_edge_audit_001/results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))


if __name__=='__main__':main()
