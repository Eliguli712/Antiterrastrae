#!/usr/bin/env python3
"""Finite tooth / local white-shark jaw solution with paired elastic seat samples."""

import csv
import json
from pathlib import Path
import sys

import numpy as np
from scipy.sparse import block_diag, coo_matrix
from scipy.sparse.linalg import splu
from scipy.spatial import cKDTree

RUN = Path(__file__).resolve().parents[1]
PROJECT = RUN.parents[1]
PAPER = PROJECT / 'output/pdf/debunk_myth_preprint_2026-11-19'
TOOTH = PROJECT / 'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0'
JAW = PROJECT / 'output/ct_fea_calibrated_2026-11-08/data/jaw_L2_full_1kPa/fields.npz'
OUT = RUN / 'distributed_seat'
sys.path.insert(0, str(PROJECT / 'output/publication_validation_2026-11-12/scripts'))
import elastic_diagnostics as elasticity

XYZ = np.arange(3)
I = np.eye(3)
REGIONS = ('RA', 'RB', 'Rcr', 'Rtip')
CONTACT_DISTANCE_M = .0015


def constitutive(points, cells, lam, mu):
    g, vol = elasticity.basis_data(points, cells)
    K = elasticity.assemble(points, cells, g, vol, np.full(len(cells), lam), np.full(len(cells), mu))
    return K, g, vol


def stress(cells, gradient, displacement, lam, mu):
    grad_u = np.einsum('eai,eaj->eij', displacement[cells], gradient)
    strain = (grad_u + grad_u.transpose(0, 2, 1)) / 2
    return lam * np.trace(strain, axis1=1, axis2=2)[:, None, None] * I + 2*mu*strain


def quantile(values, weights, q=.95):
    order = np.argsort(values)
    mass = np.cumsum(weights[order], dtype=np.longdouble)
    return float(values[order[np.searchsorted(mass, q*mass[-1])]])


def nodal_force(cells, sigma, gradient, volume, count):
    local = np.einsum('eij,eaj,e->eai', sigma, gradient, volume)
    f = np.zeros((count, 3))
    np.add.at(f, cells.ravel(), local.reshape(-1, 3))
    return f


def local_jaw(jaw, radius, q, global_contact_owner):
    points, cells = jaw['points_m'], jaw['tets']
    close = cKDTree(q).query(points[cells].mean(1), workers=2)[0] <= radius
    close[global_contact_owner] = True
    cell_ids = np.flatnonzero(close)
    node_ids = np.unique(cells[close])
    mask = np.isin(node_ids, np.unique(cells[~close])) | np.isin(node_ids, jaw['fixed_node_indices'])
    nodes = np.searchsorted(node_ids, cells[close])
    assert mask.any() and not mask.all() and np.array_equal(node_ids[nodes], cells[close])
    displayed = close[jaw['boundary_owner']]
    faces = np.searchsorted(node_ids, jaw['boundary_faces'][displayed])
    return dict(x=points[node_ids], t=nodes, fixed=mask, nid=node_ids, cid=cell_ids,
                f=faces, boundary_owner=np.searchsorted(cell_ids, jaw['boundary_owner'][displayed]))


def seat_operator(contact, nt, jaw_mesh, jaw_gradient):
    """Relative motion with a jaw spin term across the finite registration gap."""
    jaw_indices = np.searchsorted(jaw_mesh['nid'], contact['jaw_face_nodes'])
    local_jaw_owner = np.searchsorted(jaw_mesh['cid'], contact['jaw_owner'])
    jaw_tet_nodes = jaw_mesh['t'][local_jaw_owner]
    g = jaw_gradient[local_jaw_owner]
    offsets = contact['tooth_centroid'] - contact['jaw_centroid']
    # The spin correction makes every spring null under a common infinitesimal
    # rigid rotation despite the measured distance between its two samples.
    spin = (np.einsum('eai,ei->ea', g, offsets)[:, :, None, None]*I
            - g[:, :, :, None]*offsets[:, None, None, :]) / 2
    rows, cols, vals = [], [], []
    for k, tooth_nodes in enumerate(contact['tooth_face_nodes']):
        for nodes, aff in ((tooth_nodes, np.broadcast_to(I/3, (3, 3, 3))),
                           (nt+jaw_indices[k], -contact['bary'][k,:,None,None]*I),
                           (nt+jaw_tet_nodes[k], -spin[k])):
            for node, A in zip(nodes, aff):
                rows.extend(np.repeat(3*k+XYZ, 3))
                cols.extend(np.tile(3*node+XYZ, 3))
                vals.extend(A.ravel())
    return coo_matrix((vals, (rows, cols)), shape=(3*len(contact['area']), 3*(nt+len(jaw_mesh['x'])))).tocsr()


def read_contact(tooth_world, registration, jaw):
    passes = registration['bridge_distances_m'] <= CONTACT_DISTANCE_M
    tooth_face = registration['root_faces'][passes]
    face_ids = registration['projection_face_ids'][passes]
    jaw_face = jaw['boundary_faces'][face_ids]
    owner = jaw['boundary_owner'][face_ids]
    xyz = jaw['points_m'][jaw_face]
    normal = np.cross(xyz[:,1]-xyz[:,0], xyz[:,2]-xyz[:,0])
    normal /= np.linalg.norm(normal, axis=1)[:,None]
    centre = xyz.mean(1)
    toward_interior = jaw['points_m'][jaw['tets'][owner]].mean(1) - centre
    normal[np.einsum('ei,ei->e', normal, toward_interior)>0] *= -1
    bary = registration['barycentric_weights'][passes]
    foot = np.einsum('ei,eij->ej', bary, xyz)
    np.testing.assert_allclose(foot, registration['projected_points_m'][passes], rtol=0, atol=1e-12)
    tooth_mid = tooth_world[tooth_face].mean(1)
    np.testing.assert_allclose(tooth_mid, registration['posed_root_points_m'][passes], rtol=0, atol=1e-12)
    return dict(tooth_face_nodes=tooth_face, jaw_face_nodes=jaw_face, jaw_owner=owner,
                area=registration['root_face_area_m2'][passes], lobe=registration['root_face_side'][passes],
                tooth_centroid=tooth_mid, jaw_centroid=foot, normal=normal, bary=bary)


def resolve(K, G, F, outside, fixed, points, t, gt, vt, jaw, gj, vj, C, contact, lu, masks):
    u = outside.copy()
    u[~fixed] = lu.solve((F-K@outside)[~fixed])
    ut, uj = u.reshape(-1,3)[:len(points)], u.reshape(-1,3)[len(points):]
    st = stress(t, gt, ut, 29e9, 28.5e9)
    sj = stress(jaw['t'], gj, uj, 150e6*.3/(1.3*.4), 150e6/2.6)
    relative = (G @ u).reshape(-1,3)
    sample_force = np.einsum('eij,ej->ei', C, relative)
    force_tooth_on_jaw = sample_force
    force_jaw_on_tooth = -sample_force
    ffrom_s = np.concatenate((nodal_force(t, st, gt, vt, len(ut)),
                              nodal_force(jaw['t'], sj, gj, vj, len(uj)))).ravel()
    reconstructed = ffrom_s + G.T @ sample_force.ravel() - F
    residual = K@u-F
    np.testing.assert_allclose(reconstructed, residual, rtol=1e-5, atol=3e-8)
    reaction = np.where(fixed, reconstructed, 0.).reshape(-1,3)
    total_load = F.reshape(-1,3)+reaction
    total_points = np.vstack((points,jaw['x']))
    ref = contact['jaw_centroid'].mean(0)
    force_error = np.linalg.norm(total_load.sum(0))
    moment_error = np.linalg.norm(np.cross(total_points-ref,total_load).sum(0))
    energy_error = abs(u@(K@u)-np.dot(u,F)-np.dot(u[fixed],residual[fixed]))/max(abs(u@(K@u)),1e-30)
    assert max(np.linalg.norm(reconstructed[~fixed]),force_error,moment_error/.05,energy_error)<4e-6
    tooth_tension = np.maximum(np.linalg.eigvalsh(st)[:,-1],0)
    principal = np.linalg.eigvalsh(sj)
    vm_jaw = np.sqrt(.5*((principal[:,0]-principal[:,1])**2+
                         (principal[:,1]-principal[:,2])**2+(principal[:,2]-principal[:,0])**2))
    own_l = np.searchsorted(jaw['cid'],contact['jaw_owner'])
    normal_mpa = (np.einsum('ei,ei->e',force_jaw_on_tooth,contact['normal'])/contact['area'])/1e6
    shear_mpa = np.linalg.norm(force_jaw_on_tooth/contact['area'][:,None]/1e6
                              - normal_mpa[:,None]*contact['normal'],axis=1)
    summary = dict(tooth_tensile_q95_MPa_per_N={r:quantile(tooth_tension[masks[r]],vt[masks[r]])/1e6
                                             for r in REGIONS},
                   force_error_N=float(force_error),moment_error_Nm=float(moment_error),
                   free_residual_N=float(np.linalg.norm(reconstructed[~fixed])),
                   energy_error_fraction=float(energy_error),
                   tooth_max_displacement_mm=float(np.linalg.norm(ut,axis=1).max()*1e3),
                   jaw_max_displacement_mm=float(np.linalg.norm(uj,axis=1).max()*1e3),
                   jaw_local_vm_q95_MPa_per_N=quantile(vm_jaw[own_l],contact['area'])/1e6,
                   mouth_of_seat=[])
    for lobe in (0,1):
        use = contact['lobe']==lobe
        w = contact['area'][use]
        summary['mouth_of_seat'].append(dict(lobe=lobe, area_mm2=float(w.sum()*1e6),
            axial_normal_signed_mean_MPa_per_N=float(np.average(normal_mpa[use],weights=w)),
            compressive_normal_q95_MPa_per_N=quantile(np.maximum(normal_mpa[use],0),w),
            tensile_normal_q95_MPa_per_N=quantile(np.maximum(-normal_mpa[use],0),w),
            shear_q95_MPa_per_N=quantile(shear_mpa[use],w),
            root_to_jaw_resultant_N=force_tooth_on_jaw[use].sum(0).tolist(),
            seat_relative_displacement_q95_mm=quantile(np.linalg.norm(relative[use],axis=1)*1000,w)))
    return summary, (vm_jaw, normal_mpa, shear_mpa, ut, uj)


def main():
    OUT.mkdir(exist_ok=True)
    registration = np.load(RUN / 'data_v3/registration.npz')
    tooth = np.load(TOOTH / 'solution.npz')
    jaw = np.load(JAW)
    masks = np.load(TOOTH / 'region_masks.npz')
    old = np.load(RUN/'data_v3/condensed_operators.npz')
    loads = np.load(RUN/'edge_data/unit_response_basis.npz')['nodal_force_weights']
    archived_results = json.loads((RUN/'edge_data/results.json').read_text())['cases']
    cases = {r['name']:r for r in archived_results}
    rotation = registration['reference_rotation']
    points = (tooth['points_m']-registration['tooth_root_centre_m'])@rotation.T+registration['reference_location_m']
    t = tooth['tets']
    contact = read_contact(points, registration, jaw)
    Kt, gt, vt = constitutive(points, t,29e9,28.5e9)
    far_fields = {}
    for name in ('RA_pose0_oblique0_tied','RA_pose0_oblique30_tied','RB_pose0_oblique0_tied'):
        force = loads[['RA','RB'].index(name[:2]),:,None]*np.asarray(cases[name]['direction_world'])
        np.testing.assert_allclose(np.linalg.norm(force.sum(0)),1.,atol=1e-12)
        source = np.zeros(3*len(jaw['points_m']))
        source[old['jaw_free_dof']] = -old['jaw_unit_displacements_m_per_N']@np.asarray(cases[name]['root_generalised_reaction_jaw_N'])
        far_fields[name] = (force,source.reshape(-1,3))
    results = []
    for radius in (.016,.024):
        patch = local_jaw(jaw,radius,contact['jaw_centroid'],contact['jaw_owner'])
        surface_index = np.searchsorted(patch['nid'],contact['jaw_face_nodes'])
        assert not patch['fixed'][surface_index].any()
        Kj, gj, vj = constitutive(patch['x'],patch['t'],150e6*.3/(1.3*.4),150e6/2.6)
        Klinear = block_diag((Kt,Kj),format='csr')
        G = seat_operator(contact,len(points),patch,gj)
        x = np.vstack((points,patch['x']))
        for mode in I:
            np.testing.assert_allclose(G@np.tile(mode,len(x)),0.,atol=2e-14)
            np.testing.assert_allclose(G@np.cross(mode,x).ravel(),0.,atol=2e-14)
        print(f'Radius {radius*1e3:g} mm, {len(patch["t"]):,} jaw cells',flush=True)
        is_fixed = np.r_[np.zeros(len(points),bool),patch['fixed']].repeat(3)
        N = np.einsum('ei,ej->eij',contact['normal'],contact['normal'])
        for stiffness in (1e12,1e13):
            C = stiffness*contact['area'][:,None,None]*(.25*I+.75*N)
            Cs = block_diag(list(C),format='csr')
            K = (Klinear + G.T @ Cs @ G).tocsr()
            lu = splu(K[~is_fixed][:,~is_fixed].tocsc())
            for name,(force,far) in far_fields.items():
                nodal_load = np.vstack((force,np.zeros_like(patch['x']))).ravel()
                outside = np.r_[np.zeros(3*len(points)),far[patch['nid']].ravel()]
                outside[~is_fixed] = 0
                row,field = resolve(K,G,nodal_load,outside,is_fixed,points,t,gt,vt,
                                    patch,gj,vj,C,contact,lu,masks)
                row.update(radius_mm=radius*1e3, jaw_tetrahedra=len(patch['t']), name=name,
                           k_n_N_per_m3=stiffness, k_t_N_per_m3=stiffness/4,
                           archived_rigid_tooth_q95_MPa_per_N={r['region']:r['tensile_Q95_MPa_per_N']
                               for r in cases[name]['regions'] if r['region'] in REGIONS})
                print(name,stiffness,row['tooth_tensile_q95_MPa_per_N'],flush=True)
                results.append(row)
                if radius==.024 and stiffness==1e13 and name=='RA_pose0_oblique30_tied':
                    vm,normal,shear,ut,uj = field
                    np.savez_compressed(OUT/'seat_display.npz',jaw_node_ids=patch['nid'],
                        jaw_points=patch['x'],jaw_tets=patch['t'],jaw_boundary_faces=patch['f'],
                        jaw_boundary_owner=patch['boundary_owner'],jaw_volume_m3=vj,jaw_cell_vm_Pa=vm,
                        tooth_points=points,tooth_faces=tooth['boundary_faces'],
                        tooth_displacement_m=ut,jaw_displacement_m=uj,
                        point=contact['jaw_centroid'],area=contact['area'],side=contact['lobe'],
                        seat_normal_MPa_per_N=normal,seat_shear_MPa_per_N=shear)
    info = dict(status='solved_and_verified', load='1 N applied on an archived crown margin patch',
        interface='Centroid quadrature and 1.5 mm fitted-distance cutoff. Independent tied elastic springs with zero preload and a jaw spin bridge term permit local displacement and transmit force and moment.',
        cut='Prescribed far-field displacements from the archived rigid-seat full jaw for the matching load. Structural sensitivity to 16/24 mm jaw subdomain measured separately; this is not a globally refitted bite.',
        orientation='Compression positive relative to the outward jaw normal; tension and shear are reported separately.',
        assumption='Uncalibrated k_n and k_t, small strain, elastic, bilateral. No anatomical contact, fracture or failure threshold assigned.',
        tooth_tetrahedra=len(t),contact_count=len(contact['area']),
        lobe_count=np.bincount(contact['lobe']).tolist(),cases=results)
    (OUT/'summary.json').write_text(json.dumps(info,indent=2)+'\n')
    with (OUT/'seat_samples.csv').open('w') as f:
        writer=csv.writer(f)
        writer.writerow(['lobe','tooth_x_m','tooth_y_m','tooth_z_m','jaw_x_m','jaw_y_m','jaw_z_m','area_m2'])
        writer.writerows(zip(contact['lobe'],*contact['tooth_centroid'].T,*contact['jaw_centroid'].T,contact['area']))


if __name__ == '__main__':
    main()
