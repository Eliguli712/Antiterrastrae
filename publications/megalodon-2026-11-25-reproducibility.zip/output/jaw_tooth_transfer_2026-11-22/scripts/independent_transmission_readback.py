"""Independent local-gradient and virtual-work readback of the transfer study."""
from pathlib import Path
import json,time
import numpy as np
from scipy.sparse import csr_matrix,vstack

R=Path(__file__).resolve().parents[1];P=R.parents[1]
B=P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31'
OLD=P/'output/ct_fea_calibrated_2026-11-08'
I=np.eye(3);start=time.monotonic()


def skew(x):return np.array([[0.,-x[2],x[1]],[x[2],0.,-x[0]],[-x[1],x[0],0.]])
def rigid(x,c,L):
    out=np.zeros((len(x),3,6));out[:,:,:3]=I
    for j in range(len(x)):out[j,:,3:]=-skew(x[j]-c)/L
    return out.reshape(-1,6)


def recover(p,t,u,la,mu):
    internal=np.zeros_like(p);sigma=np.empty((len(t),3,3));vol=np.empty(len(t));maxgrad=0.;energy=0.
    for i in range(0,len(t),12000):
        sl=slice(i,min(i+12000,len(t)));tt=t[sl];X=p[tt[:,1:]]-p[tt[:,:1]]
        G=np.linalg.solve(X,u[tt[:,1:]]-u[tt[:,:1]]).transpose(0,2,1);eps=(G+G.transpose(0,2,1))/2
        sig=la*np.trace(eps,axis1=1,axis2=2)[:,None,None]*I+2*mu*eps;V=abs(np.linalg.det(X))/6
        gradients=np.empty((len(tt),4,3));gradients[:,1:]=np.linalg.solve(X,np.broadcast_to(I,X.shape)).transpose(0,2,1);gradients[:,0]=-gradients[:,1:].sum(1)
        local=np.einsum('eij,eaj,e->eai',sig,gradients,V)
        for j in range(4):np.add.at(internal,tt[:,j],local[:,j])
        energy+=float(np.einsum('eij,eij,e->',sig,eps,V))/2
        sigma[sl],vol[sl]=sig,V;maxgrad=max(maxgrad,float(np.linalg.norm(G,axis=(1,2)).max()))
    return internal,sigma,vol,energy,maxgrad


def q95(x,w):
    order=np.argsort(x);c=np.cumsum(w[order],dtype=np.longdouble)
    return float(x[order[np.searchsorted(c,.95*c[-1])]])


def main():
    a=np.load(B/'numerics/L0/solution.npz');j=np.load(OLD/'data/jaw_L2_full_1kPa/fields.npz')
    reg=np.load(R/'data_v3/registration.npz');op=np.load(R/'data_v3/condensed_operators.npz');edge=np.load(R/'edge_data/unit_response_basis.npz')
    pt,tt,ft,fixed=[a[k] for k in ['points_m','tets','boundary_faces','fixed_node_indices']]
    pj,tj,fj=[j[k] for k in ['points_m','tets','boundary_faces']]
    free=np.ones(len(pt),bool);free[fixed]=False
    freej=np.ones(len(pj),bool);freej[j['fixed_node_indices']]=False
    masks=np.load(B/'numerics/L0/region_masks.npz');basis=a['basis'];centres=reg['root_centres_tooth_m'];cmean=reg['tooth_root_centre_m'];Q0=reg['reference_rotation'];loc=reg['reference_location_m'];L=float(reg['rotation_length_m']);jc=reg['root_centres_jaw_m']
    project=reg['projected_points_m'];tris=fj[reg['projection_face_ids']];bary=reg['barycentric_weights'];side=reg['root_face_side'];area=reg['root_face_area_m2']
    operators=[];rigid_errors=[]
    for k in [0,1]:
        use=np.flatnonzero(side==k);n=len(use);A=rigid(project[use],jc[k],L);w=np.repeat(area[use]/area[use].sum(),3);rootw=np.sqrt(w)
        least=np.linalg.pinv(rootw[:,None]*A)*rootw
        rows=[];cols=[];data=[]
        for row,i in enumerate(use):
            for comp in range(3):
                for v in range(3):rows.append(3*row+comp);cols.append(3*tris[i,v]+comp);data.append(bary[i,v])
        Pj=csr_matrix((data,(rows,cols)),shape=(3*n,3*len(pj)));operator=csr_matrix(least)@Pj
        rigid_errors.append(float(np.max(abs(operator@rigid(pj,jc[k],L)-np.eye(6)))))
        operators.append(operator)
    Bj=vstack(operators).tocsr();assert max(rigid_errors)<1e-9
    rng=np.random.default_rng(20261122);z=rng.normal(size=3*len(pj));q=rng.normal(size=12)
    left=float((Bj@z)@q);right=float(z@(Bj.T@q));work_error=abs(left-right)/max(abs(left),abs(right),1.)
    assert work_error<1e-12
    basisu=edge['unit_displacement_m_per_N'];weights=edge['nodal_force_weights'];Dm=op['tooth_unit_displacements'].reshape(-1,12)
    document=json.loads((R/'edge_data/results.json').read_text());records=[]
    representative=['RA_pose0_oblique0_tied','RA_pose0_oblique30_tied','RB_pose0_oblique30_tied']
    for c in document['cases']:
        mi=['RA','RB'].index(c['loaded_margin']);direction=np.array(c['direction_body']);q=np.array(c['root_generalised_displacement_m']);Qroot=np.array(c['root_generalised_reaction_N'])
        u=(basisu[mi]@direction+Dm@q).reshape(-1,3);force=weights[mi][:,None]*direction
        internal,sigma,V,Et,gmax=recover(pt,tt,u,29e9,28.5e9)
        residual=float(np.linalg.norm((internal-force)[free])/np.linalg.norm(force[free]));ev=np.linalg.eigvalsh(sigma)
        gap=0.
        for row in c['regions']:
            use=masks[row['region']];value=q95(np.maximum(ev[use,-1],0),V[use])/1e6
            gap=max(gap,abs(value-row['tensile_Q95_MPa_per_N'])/max(abs(value),1e-30))
        assert max(residual,gap)<2e-5
        record=dict(case=c['name'],tooth_free_force_residual=residual,regional_tensile_Q95_relative_difference=gap,max_tooth_gradient=gmax)
        if c['name'] in representative:
            Qjaw=np.array(c['root_generalised_reaction_jaw_N']);uj=np.zeros_like(pj);uj.ravel()[op['jaw_free_dof']]=-(op['jaw_unit_displacements_m_per_N']@Qjaw)
            fij,sigj,Vj,Ej,jmax=recover(pj,tj,uj,150e6*.3/(1.3*.4),150e6/2.6)
            expected=-(Bj.T@Qjaw).reshape(-1,3);rj=fij-expected
            relative=float(np.linalg.norm(rj[freej])/np.linalg.norm(expected[freej]));reaction=np.zeros_like(pj);reaction[~freej]=rj[~freej]
            theta=np.deg2rad(c['pose_deg']);rz=np.array([[np.cos(theta),-np.sin(theta),0],[np.sin(theta),np.cos(theta),0],[0,0,1.]])
            Q=rz@Q0;worldforce=force@Q.T;worldpoint=(pt-cmean)@Q.T+loc
            net=float(np.linalg.norm(reaction.sum(0)+worldforce.sum(0)))
            moment=float(np.linalg.norm(np.cross(pj,reaction).sum(0)+np.cross(worldpoint,worldforce).sum(0))/np.ptp(pj,axis=0).max())
            energy=abs(2*(Et+Ej)-float(np.sum(force*u)))/max(abs(float(np.sum(force*u))),1e-30)
            assert max(relative,net,moment,energy)<2e-5
            record.update(jaw_free_residual=relative,global_force_relative_error=net,reference_moment_relative_error=moment,energy_work_relative_error=energy,max_jaw_gradient=jmax)
        records.append(record)
    output=dict(status='passed',tooth_cases_independently_recovered=len(records),jaw_cases_independently_recovered=representative,root_rigid_motion_extraction_error=rigid_errors,virtual_work_adjoint_relative_error=work_error,cases=records,scope='Every tooth cell in54 cases; three corresponding complete jaw fields via independent local gradients, forces, energy and global wrench balance. No fracture/contact calibration or continuum convergence is claimed.',runtime_seconds=time.monotonic()-start)
    (R/'review/independent_transfer_audit_001/results.json').write_text(json.dumps(output,indent=2));print(json.dumps(output,indent=2))


if __name__=='__main__':main()
