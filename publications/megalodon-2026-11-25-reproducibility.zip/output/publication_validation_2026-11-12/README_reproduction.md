# Numerical validation for the 19 November 2026 preprint

Primary contract: homogeneous 1 MPa crown-face experiment on the calibrated fixed closed-solid proxy, six frozen L0 region unions, volume-weighted inverse-CDF Q90/Q95/Q99. A3 has 1,739,398 tetrahedra. Final adjacent-step Q95 changes are all <0.233%, apex <0.081%; all 18 changes <0.60%. Candidate bilayer changes are separately all <0.64%. These finite-step differences are not certified continuum error estimates.

Extract at a task root to retain the output/ and full_3D/ relative structure. Use Python 3.13 with requirements.txt. Original full-native DICOM threshold regeneration requires the source 3050 DICOM files at DICOM_16um/exports/_unzipped_dicom_tmp; their byte hashes are supplied, and their raw intensities are not part of this package. All three full-volume threshold masks, exact 72 um occupancy counts and all saved FE input meshes are included, so the geometry/FE results can be inspected and recomputed without inventing missing CT data. The supplied meshes and masks are the reproduction entry points.

Recompute Table 9 directly from the raw stress tensors and physical masks:
  python output/publication_validation_2026-11-12/scripts/reproduce_table9.py --output table9_readback

Run primary scripts from the task root:
  python output/publication_validation_2026-11-12/scripts/adaptive_experiment.py
  python output/publication_validation_2026-11-12/scripts/material_attachment_experiments.py
  python output/publication_validation_2026-11-12/scripts/threshold_voxel_fea.py
The scripts create/overwrite named derived case directories, so execute them only in a new extracted workspace, preserving the supplied record. Extended A3 candidate/Robin calculations are in extended_material_attachment.py. Separate candidate surfaces are extracted cell-face boundaries of the saved phases using extract_candidate_surfaces.py --output NEW_DIRECTORY. The adjacent A2 candidate is bilayer_adjacent_mesh.py; full bilayer finite strain is run_bilayer_stvk.py.

Independent readback: audit_publication_fields_v3.py records the original 19-case set and checks every saved cell, tensor, force and region. It intentionally asserts 19; the later adjacent A2 case must be omitted from that historical iterator. For a current 20-case audit, import the function definitions via AST as demonstrated in final_readback.py and call one(folder) explicitly on each desired case. Do not change a hash-pinned historical script. audit_bilayer_stvk.py independently recovers nonlinear tensors/forces. final_readback.py audits the added A2 case and prints the finite comparisons. Historical result directories and contracts are retained; a fresh bounded runner output name is required for re-execution.

Successful authoritative run records: threshold_run_002, adaptive_run_001, material_run_001, extended_material_run_001, threshold_grid_run_001, bilayer_adjacent_run_001, bilayer_stvk_run_001, publication_readback_003, bilayer_stvk_readback_001, final_readback_001. They passed the installed mathbox v2 manifest validator against current code/input hashes. Failed attempts are retained in review/ with their actual statuses and are not scientific evidence. A3 is below the predeclared 1.8M cell cap; proposed A4 3.307M is excluded.

Geometric phases are candidates, not independently identified fossil enameloid/dentine. Chosen Young moduli 100/30 GPa and nu=.25 are assumptions; extant reduced indentation moduli are not substituted as calibrated fossil Young moduli. Robin k=10^10..10^15 N/m^3 is an unfitted sensitivity grid. Soft linear cases have large displacements and no small-motion physical interpretation. Principal-stress summaries are not fracture criteria. Native thresholds have no HU/tissue calibration.

The 200M exterior is distributed separately at the public release link in the paper, because it is a 5.38 GB PLY, losslessly packaged as 1.883 GB .zst. Its values are homogeneous L1 StVK projections with explicit validity distances, not a 200M FE solve or the candidate bilayer.
