#!/usr/bin/env python3
"""Matched solid-reference FEA on three independently reconstructed CT thresholds."""
from pathlib import Path
import json,time,hashlib
import numpy as np
from scipy import ndimage as ndi
from skimage.measure import marching_cubes
import trimesh,gmsh,pyvista as pv
import elastic_diagnostics as fe
R=fe.R;P=fe.P;folder=R/'data/thresholds';OUT=R/'data/threshold_meshes';OUT.mkdir(exist_ok=True)
gate=json.loads((R/'review/threshold_reconstruction.json').read_text());assert gate['status']=='passed'
rows=[];geometry=[];start=time.monotonic()
for case in ['T095','T100','T105']:
 occupancy=np.load(folder/(case+'_occupancy64_72um.npy'),mmap_mode='r');binary=occupancy>=32
 filled=ndi.binary_fill_holes(binary);labels,n=ndi.label(filled);sizes=np.bincount(labels.ravel());sizes[0]=0;solid=labels==sizes.argmax();del labels,filled
 # Full extent at 72 um, using 4^3 native occupancy. No smoothing operation.
 v,f,_,_=marching_cubes(np.pad(solid.astype(np.uint8),1),.5,spacing=(.072,)*3,method='lewiner',allow_degenerate=False)
 xyz=v[:,[2,1,0]]+.027-.072;surface=trimesh.Trimesh(xyz,f,process=True);surface.fix_normals(multibody=True);assert surface.is_watertight
 high=pv.PolyData(surface.vertices,np.column_stack([np.full(len(surface.faces),3),surface.faces]).ravel())
 reduction=max(0.,1-30000/high.n_cells);low=high.decimate_pro(reduction,preserve_topology=True,splitting=False,boundary_vertex_deletion=False)
 low=low.clean();sf=low.faces.reshape(-1,4)[:,1:];mesh=trimesh.Trimesh(low.points,sf,process=True);mesh.fix_normals(multibody=True);assert mesh.is_watertight and mesh.volume>0
 path=OUT/(case+'_solid_reference.stl');mesh.export(path)
 # Finite closest-surface error on deterministic area-uniform source samples.
 rng=np.random.default_rng(20261112);tri=surface.vertices[surface.faces];areas=np.linalg.norm(np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]),axis=1)/2;idx=np.searchsorted(np.cumsum(areas),rng.random(10000)*areas.sum());u=np.sqrt(rng.random(10000));w=rng.random(10000);sample=(1-u[:,None])*tri[idx,0]+(u*(1-w))[:,None]*tri[idx,1]+(u*w)[:,None]*tri[idx,2];_,close=low.find_closest_cell(sample,return_closest_point=True);dist=np.linalg.norm(sample-close,axis=1)
 record=dict(case=case,native_selected_volume_mm3=next(x['volume_mm3'] for x in gate['cases'] if x['case']==case),coarse_pitch_mm=.072,block_occupancy_threshold=32,coarse_material_voxels=int(binary.sum()),solid_voxels=int(solid.sum()),filled_coarse_void_voxels=int(solid.sum()-binary.sum()),original_surface_faces=len(surface.faces),FE_boundary_faces=len(mesh.faces),FE_reference_volume_mm3=float(mesh.volume),sampled_decimation_RMS_mm=float(np.sqrt(np.mean(dist**2))),sampled_decimation_p99_mm=float(np.quantile(dist,.99)),scope='Matched 72 um closed-solid references; native void-preserving masks are separate. No surface smoothing; finite 10000-point approximation check, not Hausdorff.')
 del tri,high,low,surface,solid,binary,occupancy
 gmsh.initialize()
 try:
  gmsh.option.setNumber('General.NumThreads',2);gmsh.option.setNumber('General.Terminal',1);gmsh.merge(str(path));loop=gmsh.model.geo.addSurfaceLoop([tag for _,tag in gmsh.model.getEntities(2)]);gmsh.model.geo.addVolume([loop]);gmsh.model.geo.synchronize();gmsh.option.setNumber('Mesh.Algorithm3D',1);gmsh.option.setNumber('Mesh.MeshSizeMin',.15);gmsh.option.setNumber('Mesh.MeshSizeMax',1.0);gmsh.option.setNumber('Mesh.MeshSizeFromCurvature',0);gmsh.option.setNumber('Mesh.MeshSizeExtendFromBoundary',0);field=gmsh.model.mesh.field.add('MathEval');gmsh.model.mesh.field.setString(field,'F','1.0');gmsh.model.mesh.field.setAsBackgroundMesh(field);gmsh.model.mesh.generate(3);gmsh.model.mesh.optimize('');tags,coords,_=gmsh.model.mesh.getNodes();p=np.asarray(coords).reshape(-1,3);types,_,node_tags=gmsh.model.mesh.getElements(3);assert list(types)==[4];ids=np.asarray(node_tags[0]).reshape(-1,4);order=np.argsort(tags);t=order[np.searchsorted(np.asarray(tags)[order],ids)];used,inv=np.unique(t,return_inverse=True);p=p[used];t=inv.reshape(-1,4).astype(np.int32)
 finally:gmsh.finalize()
 volume=abs(np.linalg.det(p[t[:,1:]]-p[t[:,:1]]))/6;assert volume.min()>1e-15 and abs(volume.sum()/mesh.volume-1)<1e-6
 record.update(nodes=len(p),tetrahedra=len(t),relative_domain_volume_error=float(abs(volume.sum()/mesh.volume-1)));geometry.append(record)
 np.savez_compressed(OUT/(case+'_mesh.npz'),points_mm=p,tets=t)
 print('Threshold geometry audited',record,flush=True)
 r=fe.solve('geometry_'+case,p*.001,t,frozen=False);r['geometry']=record;(R/'data'/('geometry_'+case)/'results.json').write_text(json.dumps(r,indent=2));rows.append(r)
result=dict(status='passed',cases=rows,geometry=geometry,runtime_seconds=time.monotonic()-start,scope='Full native threshold reconstruction followed by fixed-protocol, separately declared 72 um solid-reference FE geometry. Across-threshold windows share L0 coordinates, rather than identical physical volumes. No pore-resolving FE claim.')
(R/'review/threshold_fea_run_001/results.json').write_text(json.dumps(result,indent=2));(R/'review/threshold_fea.json').write_text(json.dumps(result,indent=2))
