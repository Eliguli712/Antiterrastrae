#!/usr/bin/env python3
"""Recalculate Table 9 directly from delivered raw fields, physical masks and volumes.

Run in a fresh extracted workspace:
python output/publication_validation_2026-11-12/scripts/reproduce_table9.py --output table9_readback
"""
from pathlib import Path
import argparse,csv,json
import numpy as np
R=Path(__file__).resolve().parents[1];P=R.parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
assert not args.output.exists(),'Choose a new output directory to preserve existing results.'
args.output.mkdir(parents=True)
base=np.load(P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0/region_masks.npz')
def recover(name):
    a=np.load(R/'data'/name/'fields.npz');stress=a['stress_Pa'];dev=stress-np.trace(stress,axis1=1,axis2=2)[:,None,None]*np.eye(3)/3
    vm=np.sqrt(1.5*np.einsum('eij,eij->e',dev,dev))/1e6;volume=a['volumes_m3'];parent=a['parent_L0'];rows=[]
    for key in ['R0','RA','RB','Rtip','Rcr','Rroot']:
        use=np.isin(parent,base[key]);values=vm[use];weights=volume[use].astype(np.longdouble);order=np.argsort(values,kind='stable');cdf=np.cumsum(weights[order]);cdf/=cdf[-1];q=values[order][np.searchsorted(cdf,[.90,.95,.99])]
        rows.append(dict(region=key,volume_mm3=float(volume[use].sum()*1e9),Q90_MPa=float(q[0]),Q95_MPa=float(q[1]),Q99_MPa=float(q[2]),SAF95=float(q[1])))
    return rows
a=recover('local_A2');b=recover('local_A3');difference=[]
for old,row in zip(a,b):
    changes=[100*abs(row[k]-old[k])/row[k] for k in ['Q90_MPa','Q95_MPa','Q99_MPa']];row['last_Q95_change_percent']=changes[1];difference+=changes
assert max(x['last_Q95_change_percent'] for x in b)<.233
assert max(difference)<.60
with (args.output/'table9_recomputed.csv').open('w',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(b[0]));writer.writeheader();writer.writerows(b)
(args.output/'summary.json').write_text(json.dumps(dict(status='passed',rows=b,maximum_last_step_18_percent=max(difference),scope='Finite-model volume inverse-CDF summaries, not pointwise fracture criteria or certified continuum error bounds.'),indent=2))
print(json.dumps(b,indent=2))
