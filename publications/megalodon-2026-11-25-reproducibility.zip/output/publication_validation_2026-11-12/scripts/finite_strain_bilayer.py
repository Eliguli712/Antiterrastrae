#!/usr/bin/env python3
"""Energy-consistent P1 linear/StVK reference calculations, SI internally.

Jaw: small-strain bulk and StVK in a declared sharp-edge band. Tooth: full
StVK. Dead reference tractions; no contact, fracture, growth or fluid solve.
"""
from pathlib import Path
import os,sys,json,time,hashlib
from datetime import datetime,timezone
os.environ.setdefault('OPENBLAS_NUM_THREADS','2');os.environ.setdefault('OMP_NUM_THREADS','2')
R=Path(__file__).resolve().parents[1];P=Path(os.environ.get('FEA_MEG_ROOT',str(R.parents[1])));sys.path.insert(0,str(R/'runtime'))
import numpy as np,meshio,pyamg
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import cg, minres
from scipy.spatial import cKDTree
I=np.eye(3)

def boundary(p,t):
    loc=np.array([[1,2,3],[0,3,2],[0,1,3],[0,2,1]])
    fs=t[:,loc].reshape(-1,3)
    _,ix,c=np.unique(np.sort(fs,axis=1),axis=0,return_index=True,return_counts=True)
    assert c.max()==2
    owner=ix[c==1]//4;f=fs[ix[c==1]].copy();x=p[f]
    n=np.cross(x[:,1]-x[:,0],x[:,2]-x[:,0]);flip=np.einsum('ij,ij->i',n,p[t[owner]].mean(1)-x.mean(1))>0
    f[flip]=f[flip][:,[0,2,1]];n[flip]*=-1
    area=np.linalg.norm(n,axis=1)/2
    return f,owner,area,n/(2*area[:,None])

def tensor(F,lam,mu,nonlinear,G=None):
    lam=np.broadcast_to(lam,(len(F),));mu=np.broadcast_to(mu,(len(F),))
    if G is None:G=F-I
    eps=(G+G.transpose(0,2,1))/2;green=eps+.5*np.einsum('eji,ejk->eik',G,G)
    E=np.where(nonlinear[:,None,None],green,eps)
    S=2*mu[:,None,None]*E+lam[:,None,None]*np.trace(E,axis1=1,axis2=2)[:,None,None]*I
    PP=S.copy();PP[nonlinear]=F[nonlinear]@S[nonlinear]
    W=.5*lam*np.trace(E,axis1=1,axis2=2)**2+mu*np.einsum('eij,eij->e',E,E)
    return PP,S,W,E

def tangent(F,S,lam,mu,nonlinear):
    lam=np.broadcast_to(lam,(len(F),));mu=np.broadcast_to(mu,(len(F),))
    A=lam[:,None,None,None,None]*np.einsum('ij,kl->ijkl',I,I)+mu[:,None,None,None,None]*(np.einsum('ik,jl->ijkl',I,I)+np.einsum('il,jk->ijkl',I,I))
    if nonlinear.any():
        f=F[nonlinear];s=S[nonlinear];b=f@f.transpose(0,2,1);la=lam[nonlinear,None,None,None,None];m=mu[nonlinear,None,None,None,None]
        A[nonlinear]=np.einsum('ik,elj->eijkl',I,s)+la*np.einsum('eij,ekl->eijkl',f,f)+m*(np.einsum('eil,ekj->eijkl',f,f)+np.einsum('jl,eik->eijkl',I,b))
    return A

def selfcheck():
    rng=np.random.default_rng(712);F=I+rng.normal(0,.03,(4,3,3));mask=np.array([True,False,True,False]);la=2.;mu=3.
    p,s,w,e=tensor(F,la,mu,mask);A=tangent(F,s,la,mu,mask);direction=rng.normal(size=F.shape);h=1e-6
    pp=tensor(F+h*direction,la,mu,mask)[0];pm=tensor(F-h*direction,la,mu,mask)[0]
    rel=np.linalg.norm((pp-pm)/(2*h)-np.einsum('eijkl,ekl->eij',A,direction))/np.linalg.norm((pp-pm)/(2*h))
    assert rel<1e-8
    Wp=tensor(F+h*direction,la,mu,mask)[2];Wm=tensor(F-h*direction,la,mu,mask)[2]
    np.testing.assert_allclose((Wp-Wm)/(2*h),np.einsum('eij,eij->e',p,direction),rtol=1e-7,atol=1e-8)
    # Rigid rotations of the full StVK material have zero stored energy.
    Q,_=np.linalg.qr(rng.normal(size=(3,3)));Q[:,0]*=np.linalg.det(Q)
    assert tensor(Q[None],la,mu,np.array([True]))[2][0]<1e-25
    return {'consistent_tangent_directional_relative_error':float(rel),'energy_gradient_checked':True,'StVK_rigid_rotation_energy_zero':True}

def run(name,p,t,fixed,force,nonlinear,lam,mu,metadata,load_levels):
    dest=R/'data'/name;dest.mkdir(parents=True,exist_ok=True);start=time.monotonic()
    if (dest/'fields.npz').exists() or (dest/'results.json').exists():
        raise FileExistsError('Use a fresh case name to preserve the prior result: '+name)
    def progress(row):
        with (dest/'progress.jsonl').open('a') as stream:stream.write(json.dumps({'utc':datetime.now(timezone.utc).isoformat(),**row})+'\n')
    progress({'stage':'geometry_and_assembly_start'})
    np.random.seed(20261108)
    edges=p[t[:,1:]]-p[t[:,:1]]
    inverse=np.linalg.inv(edges)
    g=np.empty((len(t),4,3));g[:,1:]=inverse.transpose(0,2,1);g[:,0]=-g[:,1:].sum(1)
    vol=np.abs(np.linalg.det(p[t[:,1:]]-p[t[:,:1]]))/6
    assert np.min(vol)>1e-24
    dof=(3*t[:,:,None]+np.arange(3)).reshape(len(t),12).astype(np.int32)
    rr=np.repeat(dof,12,axis=1).ravel();cc=np.tile(dof,(1,12)).ravel();n=3*len(p)
    free=np.setdiff1d(np.arange(n),3*np.asarray(fixed)[:,None]+np.arange(3));u=np.zeros((len(p),3));f=force.ravel()
    def assemble(u,stiff=True):
        fint=np.zeros(n);energy=0.;values=[];minJ=1e10
        for begin in range(0,len(t),2500):
            sl=slice(begin,min(begin+2500,len(t)));G=np.einsum('eai,eaJ->eiJ',u[t[sl,1:]]-u[t[sl,:1]],g[sl,1:]);F=I+G
            PP,S,W,E=tensor(F,lam[sl],mu[sl],nonlinear[sl],G=G);minJ=min(minJ,float(np.linalg.det(F).min()));energy+=float(vol[sl]@W)
            re=np.einsum('eiJ,eaJ,e->eai',PP,g[sl],vol[sl]).reshape(-1,12)
            np.add.at(fint,dof[sl].ravel(),re.ravel())
            if stiff:
                A=tangent(F,S,lam[sl],mu[sl],nonlinear[sl])
                BB=np.zeros((len(F),9,12))
                for ii in range(3):
                    for jj in range(3):BB[:,3*ii+jj,ii::3]=g[sl,:,jj]
                ke=(BB.transpose(0,2,1)@A.reshape(-1,9,9)@BB)*vol[sl,None,None]
                values.append(ke.ravel())
        K=coo_matrix((np.concatenate(values),(rr,cc)),shape=(n,n)).tocsr() if stiff else None
        return fint,energy,minJ,K
    _,_,_,K0=assemble(u);Kf=K0[free][:,free]
    q=p-p.mean(0);modes=np.zeros((len(p),3,6));modes[:,:,:3]=I
    for j in range(3):modes[:,:,j+3]=np.cross(np.broadcast_to(I[j],q.shape),q)
    progress({'stage':'AMG_start','stiffness_nnz':int(Kf.nnz)})
    ml=pyamg.smoothed_aggregation_solver(Kf.tobsr(blocksize=(3,3)),B=modes.reshape(n,6)[free],symmetry='symmetric');M=ml.aspreconditioner()
    progress({'stage':'AMG_ready','levels':len(ml.levels),'operator_complexity':float(ml.operator_complexity())})
    def linear_solve(K,rhs,indefinite=False):
        count=[0]
        def cb(x):
            count[0]+=1
            if count[0]%100==0:progress({'stage':'CG','iterations':count[0]})
        if indefinite:
            sol,info=minres(K,rhs,M=M,rtol=2e-11,maxiter=3000,callback=cb)
        else:sol,info=cg(K,rhs,M=M,rtol=2e-10,atol=0,maxiter=2000,callback=cb)
        if info!=0:raise RuntimeError(('CG failure',info))
        progress({'stage':'CG_done','iterations':count[0],'status':int(info)})
        return sol,count[0]
    ul,lit=linear_solve(Kf,f[free]);linear=np.zeros(n);linear[free]=ul;linear=linear.reshape(-1,3)
    records=[]
    if metadata.get('linear_only',False):u=linear.copy()
    if metadata.get('initial_displacement_file'):
        u=np.load(metadata['initial_displacement_file']).copy()
        assert u.shape==linear.shape and np.isfinite(u).all()
        progress({'stage':'initial_displacement_read','path':metadata['initial_displacement_file']})
    u[fixed]=0
    for level in load_levels:
        for iteration in range(50):
            fi,W,minJ,K=assemble(u);res=fi-level*f;rel=np.linalg.norm(res[free])/max(np.linalg.norm(level*f[free]),1e-30)
            print(name,level,iteration,'res',rel,'Jmin',minJ,flush=True)
            progress({'stage':'Newton','load_factor':level,'iteration':iteration,'residual':float(rel),'J_min':float(minJ)})
            np.save(dest/'u_last.npy',u)
            if rel<2e-7:break
            step,it=linear_solve(K[free][:,free],-res[free],indefinite=True);du=np.zeros(n);du[free]=step;du=du.reshape(-1,3)
            potential=W-level*np.dot(f,u.ravel());slope=np.dot(res,du.ravel());alpha=1.
            if slope>=0:
                du[:]=0;du.ravel()[free]=-(M@res[free]);slope=np.dot(res,du.ravel())
                progress({'stage':'positive_energy_descent_fallback'})
            assert slope<0
            for ls in range(22):
                trial=u+alpha*du;ft,Wt,jt,_=assemble(trial,False);pt=Wt-level*np.dot(f,trial.ravel())
                roundoff=64*np.finfo(float).eps*max(abs(Wt),abs(W),abs(level*np.dot(f,trial.ravel())),1e-30)
                if jt>.2 and pt<=potential+1e-4*alpha*slope+roundoff:break
                alpha*=.5
            else:raise RuntimeError('Line search did not find a positive-J energy decrease')
            progress({'stage':'line_search','alpha':float(alpha),'energy_roundoff_allowance_J':float(roundoff)})
            u=trial
        else:raise RuntimeError('Newton iteration limit')
        records.append({'load_factor':level,'newton_iterations':iteration,'free_residual_relative':float(rel),'minimum_J':minJ,'max_displacement_mm':float(np.linalg.norm(u,axis=1).max()*1000)})
        np.save(dest/f'displacement_factor_{level:g}.npy',u)
        (dest/'load_curve.json').write_text(json.dumps(records,indent=2))
    def recover(u,mask):
        G=np.einsum('eai,eaJ->eiJ',u[t[:,1:]]-u[t[:,:1]],g[:,1:]);F=I+G;PP,S,W,E=tensor(F,lam,mu,mask,G=G);J=np.linalg.det(F)
        sigma=PP.copy();sigma[mask]=np.einsum('eij,ekj->eik',PP[mask],F[mask])/J[mask,None,None]
        dev=sigma-np.trace(sigma,axis1=1,axis2=2)[:,None,None]*I/3
        vm=np.sqrt(1.5*np.einsum('eij,eij->e',dev,dev));ev=E-np.trace(E,axis1=1,axis2=2)[:,None,None]*I/3
        eq=np.sqrt(2/3*np.einsum('eij,eij->e',ev,ev))
        return vm,eq,sigma,E,J
    vm,eq,sigma,E,J=recover(u,nonlinear);vml,eql,sl,el,jl=recover(linear,np.zeros(len(t),bool))
    faces,owner,area,norm=boundary(p,t);fi,W,minJ,_=assemble(u,False);res=fi-f
    reaction=res.reshape(-1,3)[fixed].sum(0);balance=np.linalg.norm(reaction+force.sum(0))/max(np.linalg.norm(force.sum(0)),1e-30)
    assert balance<1e-6
    np.savez_compressed(dest/'fields.npz',points_m=p,tets=t,boundary_faces=faces,boundary_owner=owner,volumes_m3=vol,displacement_m=u,linear_displacement_m=linear,
        von_mises_Pa=vm,linear_von_mises_Pa=vml,equivalent_strain=eq,linear_equivalent_strain=eql,cauchy_stress_Pa=sigma,strain_tensor=E,linear_stress_Pa=sl,green_or_linear_flag=nonlinear,J=J,lambda_element_Pa=lam,mu_element_Pa=mu,fixed_node_indices=fixed,force_N=force)
    def q(v):
        order=np.argsort(v);cdf=np.cumsum(vol[order])/vol.sum();return v[order[np.searchsorted(cdf,[.5,.95,.99])]].tolist()
    result={**metadata,'nodes':len(p),'tetrahedra':len(t),'surface_triangles':len(faces),'lambda_range_Pa':[float(lam.min()),float(lam.max())],'mu_range_Pa':[float(mu.min()),float(mu.max())],'nonlinear_elements':int(nonlinear.sum()),
      'nonlinear_volume_fraction':float(vol[nonlinear].sum()/vol.sum()),'load_steps':records,'force_balance_relative':float(balance),
      'linear_Q50_Q95_Q99_MPa':(np.array(q(vml))/1e6).tolist(),'nonlinear_Q50_Q95_Q99_MPa':(np.array(q(vm))/1e6).tolist(),
      'max_von_mises_MPa':float(vm.max()/1e6),'linear_max_von_mises_MPa':float(vml.max()/1e6),'max_equivalent_strain':float(eq.max()),
      'max_displacement_mm':float(np.linalg.norm(u,axis=1).max()*1000),'linear_max_displacement_mm':float(np.linalg.norm(linear,axis=1).max()*1000),
      'stress_relative_volume_L2_difference':float(np.sqrt(np.sum(vol*(vm-vml)**2)/np.sum(vol*vml**2))),
      'linear_cg_iterations':lit,'runtime_seconds':time.monotonic()-start,'software':{'numpy':np.__version__,'pyamg':pyamg.__version__}}
    (dest/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2),flush=True)
    return result

def main():
    (R/'review').mkdir(exist_ok=True);(R/'review/finite_strain_selfcheck.json').write_text(json.dumps(selfcheck(),indent=2))
    what=sys.argv[1] if len(sys.argv)>1 else 'jaw'
    if what=='replay':
        name=sys.argv[2];src=R/'data'/name/'fields.npz';a=np.load(src);r=json.loads((R/'data'/name/'results.json').read_text())
        run('replay_'+name,a['points_m'],a['tets'],a['fixed_node_indices'],a['force_N'],a['green_or_linear_flag'],r['lambda_Pa'],r['mu_Pa'],
            {'replay_source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'constitutive':r['constitutive'],'source_geometry_and_loads_preserved':True},[.25,.5,.75,1.])
        return
    if what in ['jaw','jaw_full','jaw_narrow']:
        src=P/'applied_forces/custom_solver/great_white_jaw_vol_tet_vol.msh';mesh=meshio.read(src);p=mesh.points*.001;t=mesh.cells_dict['tetra']
        faces,owner,area,normal=boundary(p,t);ymin,ymax=p[:,1].min(),p[:,1].max();lo=ymin+.12*(ymax-ymin);hi=ymax-.12*(ymax-ymin)
        fixed=np.flatnonzero(p[:,1]<=lo);loaded=p[faces,1].mean(1)>=hi;force=np.zeros_like(p)
        for j in range(3):np.add.at(force,faces[loaded,j],np.array([0.,-1e4,0.])*area[loaded,None]/3)
        edges=np.concatenate([faces[:,[0,1]],faces[:,[1,2]],faces[:,[2,0]]]);faceid=np.tile(np.arange(len(faces)),3)
        key=np.sort(edges,axis=1);_,idx,inv,cnt=np.unique(key,axis=0,return_index=True,return_inverse=True,return_counts=True)
        assert cnt.min()==cnt.max()==2
        order=np.argsort(inv);pairs=faceid[order].reshape(-1,2);sharp=np.einsum('ij,ij->i',normal[pairs[:,0]],normal[pairs[:,1]])<np.cos(np.deg2rad(40))
        edgepoints=p[key[idx[sharp]]].mean(1);fraction=.003 if what=='jaw_narrow' else .015;width=fraction*np.ptp(p,axis=0).max()
        dist=cKDTree(edgepoints).query(p[t].mean(1),workers=2)[0];nl=dist<=width
        meta={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'model':'Independent white-shark jaw proxy; source geometry assumes mm.',
          'E_Pa':150e6,'nu':.3,'reference_traction_Pa':[0,-1e4,0],'fixed_Y_below_m':lo,'loaded_centroid_Y_above_m':hi,
          'edge_zone':f'Within {100*fraction:g}% of full span of boundary-edge midpoints having dihedral angle above 40 degrees. Geometric sensitivity rule, not an identified tissue law.',
          'edge_band_width_mm':width*1000,'sharp_edge_count':int(sharp.sum()),'loaded_area_mm2':float(area[loaded].sum()*1e6),
          'constitutive':'Small-strain linear bulk; energy-consistent StVK edge band; dead traction; no contact.'}
        if what=='jaw_full':
            nl[:]=True;meta['constitutive']='Full objective StVK reference; linear small-strain tangent everywhere; dead traction; no contact.'
        E=150e6;nu=.3;run({'jaw_full':'jaw_full_stvk','jaw':'jaw','jaw_narrow':'jaw_edge_stvk'}[what],p,t,fixed,force,nl,E*nu/((1+nu)*(1-2*nu)),E/(2*(1+nu)),meta,[.25,.5,.75,1.])
    elif what in ['tooth','tooth_l1']:
        level='L1' if what=='tooth_l1' else 'L0'
        src=P/f'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/{level}/solution.npz';a=np.load(src);p=a['points_m'];t=a['tets'];faces=a['boundary_faces'];loaded=a['loaded_face_indices'];x=p[faces[loaded]]
        cross=np.cross(x[:,1]-x[:,0],x[:,2]-x[:,0]);force=np.zeros_like(p)
        for j in range(3):np.add.at(force,faces[loaded,j],-1e6*cross/6)
        run('tooth_stvk_l1' if level=='L1' else 'tooth_stvk',p,t,a['fixed_node_indices'],force,np.ones(len(t),bool),29e9,28.5e9,
          {'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'constitutive':'Full StVK; calibrated closed-solid proxy, baseline physical masks/supports; reference dead traction.','nominal_pressure_MPa':1.},[.25,.5,.75,1.])

if __name__=='__main__':main()
