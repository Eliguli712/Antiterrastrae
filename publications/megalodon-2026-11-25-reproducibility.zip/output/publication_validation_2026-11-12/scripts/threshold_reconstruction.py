#!/usr/bin/env python3
"""Three complete native-grid connected-component reconstructions, streamed."""
from pathlib import Path
import numpy as np,pydicom
from scipy import ndimage as ndi
import json,io,hashlib,csv,time,gc,zlib,shutil
R=Path(__file__).resolve().parents[1];P=R.parents[1];OUT=R/'data/thresholds';OUT.mkdir(exist_ok=True)
files=sorted((P/'DICOM_16um/exports/_unzipped_dicom_tmp').glob('*.DCM;1'));assert len(files)==3050
source=list(csv.DictReader((P/'output/ct_fea_2026-11-08/data/dicom_source_hashes.csv').open()))
shape=(3050,2028,1676);depth=32;spacing=.018;T=10361.669921875
cases=[dict(name=n,threshold=T*m,parent=[0],sizes=[0],blocks=[],last=None) for n,m in [('T095',.95),('T100',1.),('T105',1.05)]]
structure=ndi.generate_binary_structure(3,1);starttime=time.monotonic()
def find(parent,k):
 while parent[k]!=k:parent[k]=parent[parent[k]];k=parent[k]
 return k
for stage in [1,2]:
 if stage==2:
  for c in cases:
   c['roots']=np.array([find(c['parent'],k) for k in range(len(c['parent']))],np.uint32)
   totals=np.bincount(c['roots'],weights=c['sizes']).astype(np.int64);totals[0]=0;c['root']=int(totals.argmax());c['selected_count']=int(totals.max());c['global_components']=int((totals>0).sum())
   c['compressor']=zlib.compressobj(6);c['stream']=(OUT/(c['name']+'.zlib')).open('wb');c['areas']=[np.zeros(n,np.int64) for n in shape]
   c['coarse']=np.lib.format.open_memmap(OUT/(c['name']+'_occupancy64_72um.npy'),mode='w+',dtype='uint8',shape=(763,507,419))
 for block,start in enumerate(range(0,shape[0],depth)):
  stop=min(shape[0],start+depth);raw=np.empty((stop-start,*shape[1:]),np.int16)
  for j,k in enumerate(range(start,stop)):
   b=files[k].read_bytes();assert hashlib.sha256(b).hexdigest()==source[k]['sha256']
   ds=pydicom.dcmread(io.BytesIO(b),force=True);assert int(ds.InstanceNumber)==k and np.allclose(ds.PixelSpacing,[.018,.018]);raw[j]=ds.pixel_array
  for c in cases:
   labels,n=ndi.label(raw>c['threshold'],structure=structure)
   if stage==1:
    counts=np.bincount(labels.ravel(),minlength=n+1);offset=len(c['parent'])-1;c['parent'].extend(range(offset+1,offset+n+1));c['sizes'].extend(counts[1:].tolist())
    if c['last'] is not None:
     present=(c['last']>0)&(labels[0]>0);a=c['last'][present].astype(np.uint64);b=labels[0][present].astype(np.uint64)+offset
     for pair in np.unique((a<<np.uint64(32))|b):
      x=find(c['parent'],int(pair>>np.uint64(32)));y=find(c['parent'],int(pair&np.uint64(0xffffffff)))
      if x!=y:c['parent'][max(x,y)]=min(x,y)
    last=labels[-1].astype(np.uint32);last[last>0]+=offset;c['last']=last
    c['blocks'].append(dict(start=start,stop=stop,offset=offset,labels=n))
   else:
    cfg=c['blocks'][block];assert n==cfg['labels'];lut=c['roots'][cfg['offset']:cfg['offset']+n+1]==c['root'];lut[0]=False;selected=lut[labels].astype(np.uint8)
    c['stream'].write(c['compressor'].compress(selected.tobytes()))
    c['areas'][0][start:stop]=selected.sum((1,2));c['areas'][1]+=selected.sum((0,2));c['areas'][2]+=selected.sum((0,1))
    # Native 4x4x4 occupancy counts, rather than nearest-voxel sampling.
    pad=(-len(selected))%4
    if pad:selected=np.pad(selected,((0,pad),(0,0),(0,0)))
    co=selected.reshape(-1,4,507,4,419,4).sum((1,3,5),dtype=np.uint16).astype(np.uint8);c['coarse'][start//4:(stop+3)//4]=co
    del selected
   del labels
  del raw;gc.collect()
  if block%12==0:print('native pass',stage,stop,'/3050',round(time.monotonic()-starttime,1),'s',flush=True)
reports=[]
for c in cases:
 c['stream'].write(c['compressor'].flush());c['stream'].close();c['coarse'].flush()
 assert all(int(a.sum())==c['selected_count'] for a in c['areas'])
 if c['name']=='T100':assert c['selected_count']==967429317
 payload=OUT/(c['name']+'.zlib');path=OUT/(c['name']+'_native18um.mha')
 header=f'ObjectType = Image\nNDims = 3\nBinaryData = True\nBinaryDataByteOrderMSB = False\nCompressedData = True\nCompressedDataSize = {payload.stat().st_size}\nTransformMatrix = 1 0 0 0 1 0 0 0 1\nOffset = 4.176 0.198 16.818\nElementSpacing = 0.018 0.018 0.018\nDimSize = 1676 2028 3050\nElementType = MET_UCHAR\nElementDataFile = LOCAL\n'
 with path.open('wb') as f:
  f.write(header.encode())
  with payload.open('rb') as src:shutil.copyfileobj(src,f)
 payload.unlink()
 np.savez_compressed(OUT/(c['name']+'_component_and_areas.npz'),roots=c['roots'],areas_Z=c['areas'][0],areas_Y=c['areas'][1],areas_X=c['areas'][2])
 with path.open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 reports.append(dict(case=c['name'],threshold_raw=c['threshold'],selected_voxels=c['selected_count'],volume_mm3=c['selected_count']*spacing**3,global_material_components=c['global_components'],full_native_shape_zyx=shape,binary_closing=False,void_filling=False,native_downsampling=False,coarse_FE_reference='Separate 72 um block occupancy field; >=32 of 64 native voxels defines coarse material.',mask_file=path.name,sha256=digest,blocks=c['blocks']))
record=dict(status='passed',full_native_threshold_reconstructions=3,all_source_hashes_verified_both_passes=True,connectivity=6,selection='Largest global material component; two-pass slab union, no native hole filling.',cases=reports,runtime_seconds=time.monotonic()-starttime)
(R/'review/threshold_run_001/results.json').write_text(json.dumps(record,indent=2));(R/'review/threshold_reconstruction.json').write_text(json.dumps(record,indent=2));print(json.dumps({**record,'cases':[{k:v for k,v in x.items() if k!='blocks'} for x in reports]},indent=2))
