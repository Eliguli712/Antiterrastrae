#!/usr/bin/env python3
"""Extract complete cell-face boundaries of the supplied A3 geometric phases."""
from pathlib import Path
import argparse,json
import numpy as np
import pyvista as pv
R=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
assert not args.output.exists(),'Use a new output directory.'
args.output.mkdir(parents=True)
a=np.load(R/'data/bilayer_A3_0p5mm/fields.npz');p=a['points_m']*1000;t=a['tets'];shell=a['mu_Pa']>25e9
grid=pv.UnstructuredGrid(np.column_stack([np.full(len(t),4),t]).ravel(),np.full(len(t),10,np.uint8),p)
records=[]
for name,mask in [('Enameloid_candidate_crown_shell_A3',shell),('Dentine_candidate_core_A3',~shell)]:
    surface=grid.extract_cells(mask).extract_surface().triangulate();surface.save(args.output/(name+'.ply'));records.append(dict(model=name,cells=int(mask.sum()),surface_triangles=surface.n_cells))
(args.output/'scope.json').write_text(json.dumps(dict(models=records,scope='Cell-aligned geometric candidate phases with tied interfaces, not histologically identified fossil tissues; millimetre coordinates.'),indent=2))
