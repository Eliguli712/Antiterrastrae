#!/usr/bin/env python3
"""Extend the attachment stiffness range and test the bilayer on local A3."""
import json,numpy as np,pyvista as pv
import elastic_diagnostics as fe
R=fe.R;B=fe.B;rows=[]
a=np.load(B/'numerics/L1/solution.npz');p=a['points_m'];t=a['tets']
for exponent in [13,14,15]:rows.append(fe.solve('robin_L1_k'+str(exponent),p,t,foundation=10.**exponent))
a=np.load(R/'data/local_A3/fields.npz');p=a['points_m'];t=a['tets'];f=a['boundary_faces'];centers=p[t].mean(1);surf=pv.PolyData(p,np.column_stack([np.full(len(f),3),f]).ravel());idx,near=surf.find_closest_cell(centers,return_closest_point=True);distance=np.linalg.norm(near-centers,axis=1)
b=np.load(B/'numerics/L0/solution.npz');q=(centers-b['center_m'])@b['basis'];sq=(b['points_m'][np.unique(b['boundary_faces'])]-b['center_m'])@b['basis'];s,_,_=fe.core.geometric_coordinates(q,sq);tag=np.where((s<=.76)&(distance<=.0005),2,1).astype(np.uint8)
r=fe.solve('bilayer_A3_0p5mm',p,t,E=np.where(tag==2,100e9,30e9),nu=.25,tag=tag);r.update(shell_thickness_mm=.5,E_candidate_enameloid_GPa=100,E_candidate_dentine_GPa=30,nu=.25,interface_scope='Geometric candidate, not independent tissue identification.');(R/'data/bilayer_A3_0p5mm/results.json').write_text(json.dumps(r,indent=2));rows.append(r)
(R/'review/extended_material_run_001/results.json').write_text(json.dumps(dict(status='completed',cases=rows,scope='Finite assumption/reference tests; not an experimental attachment calibration or histologically validated bilayer.'),indent=2))
