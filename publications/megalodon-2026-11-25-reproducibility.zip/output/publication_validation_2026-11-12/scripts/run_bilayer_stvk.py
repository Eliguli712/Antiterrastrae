#!/usr/bin/env python3
from pathlib import Path
import sys,json,numpy as np
R=Path(__file__).resolve().parents[1];P=R.parents[1]
sys.path.insert(0,str(P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31/vendor'))
import finite_strain_bilayer as fe
checks=fe.selfcheck();rng=np.random.default_rng(20261119);F=np.eye(3)+rng.normal(0,.03,(8,3,3));la=np.linspace(2,4,8);mu=np.linspace(1,3,8);mask=np.ones(8,bool);direction=rng.normal(size=F.shape);pp,S,W,E=fe.tensor(F,la,mu,mask);A=fe.tangent(F,S,la,mu,mask);h=1e-6;FD=(fe.tensor(F+h*direction,la,mu,mask)[0]-fe.tensor(F-h*direction,la,mu,mask)[0])/(2*h);error=float(np.linalg.norm(FD-np.einsum('eijkl,ekl->eij',A,direction))/np.linalg.norm(FD));assert error<1e-8
source=R/'data/bilayer_L1_0p5mm/fields.npz';a=np.load(source);lam=a['lambda_Pa'];m=a['mu_Pa']
result=fe.run('bilayer_StVK_L1',a['points_m'],a['tets'],a['fixed_nodes'],a['force_N'],np.ones(len(a['tets']),bool),lam,m,dict(model='Geometric candidate bilayer: .5 mm crown shell, E100/30 GPa, nu=.25',source=str(source),pressure_Pa=1e6,material_scope='Assumed candidate partition, not identified fossil EDJ.',tangent_check=checks,heterogeneous_tangent_error=error),[.25,.5,.75,1.])
(R/'review/bilayer_stvk_run_001/results.json').write_text(json.dumps(result,indent=2))
