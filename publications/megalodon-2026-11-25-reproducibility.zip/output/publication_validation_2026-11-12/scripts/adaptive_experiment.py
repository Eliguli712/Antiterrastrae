#!/usr/bin/env python3
"""Fixed-domain, fixed-window local refinement at apex, root and proxy corners."""
from pathlib import Path
import sys,json,time,numpy as np
from scipy.spatial import cKDTree
import elastic_diagnostics as fe
from skfem import MeshTet
import trimesh
R=fe.R;B=fe.B
# Orthogonal element-stiffness check against engineering-strain B^T C B.
a=np.load(B/'numerics/L1/solution.npz');p=a['points_m'];t=a['tets'];sel=np.arange(128)
g,V=fe.basis_data(p,t[sel]);x=g
C=fe.core.constitutive(29e9,28.5e9);_,_,truth=fe.core.element_matrices(p,t[sel],C)
actual=(29e9*np.einsum('eai,ebk->eaibk',x,x)+28.5e9*np.einsum('eak,ebi->eaibk',x,x)+28.5e9*np.einsum('eab,ik->eaibk',np.einsum('eaj,ebj->eab',x,x),np.eye(3)))*V[:,None,None,None,None]
error=float(np.linalg.norm(actual.reshape(-1,12,12)-truth)/np.linalg.norm(truth));assert error<1e-10
r=fe.solve('L1_reference_engine_check',p,t)
for row in r['regions']:
 expected=json.loads((B/'numerics/L1/summary.json').read_text())['table9'];item=next(x for x in expected if x['region']==row['region']);assert abs(row['Q95_MPa']/item['Q95_MPa']-1)<2e-6
base=np.load(B/'numerics/L0/solution.npz');bp=base['points_m'];bt=base['tets'];data=fe.fixed_experiment(bp,bt);f=data['faces'];poly=trimesh.Trimesh(bp,f,process=False)
angle=poly.face_adjacency_angles;edge=poly.vertices[poly.face_adjacency_edges[angle>np.deg2rad(40)]].mean(1);q=(edge-data['center'])@data['basis'];s,rr,_=fe.core.geometric_coordinates(q,data['surface_q']);edge=edge[(s>.12)&(s<.64)&(abs(rr)>.7)];tree=cKDTree(edge) if len(edge) else None
start=np.load(B/'numerics/L2/solution.npz');p=start['points_m'];t=start['tets'];rows=[];last=json.loads((B/'numerics/L2/summary.json').read_text())['table9'];m=MeshTet(p.T,t.T,sort_t=False)
for level in range(1,5):
 pp=m.p.T;tt=m.t.T;dd=fe.fixed_experiment(pp,tt);ns,_,_=fe.core.geometric_coordinates((pp-dd['center'])@dd['basis'],dd['surface_q']);q=(pp-dd['center'])@dd['basis'];bq=(bp-dd['center'])@dd['basis'];length=np.ptp(dd['surface_q'][:,1]);ymin=dd['surface_q'][:,1].min();end=np.where(q[:,0]>=0,bq[bq[:,0]>=0,1].max(),bq[bq[:,0]<0,1].max());plane=np.maximum(.8,(end-ymin)/length-.04)
 cut=((ns-plane)[tt].min(1)<=0)&((ns-plane)[tt].max(1)>=0)
 near=tree.query(pp[tt].mean(1),workers=2)[0]<.0004 if tree is not None else np.zeros(len(tt),bool)
 marked=np.flatnonzero(dd['masks']['Rtip']|cut|near);candidate=m.refined(marked)
 if candidate.nelements>1800000:
  rows.append(dict(level=level,status='mesh_cap',proposed_tetrahedra=candidate.nelements,cap=1800000));break
 print('Local refinement',level,len(marked),'marked ->',candidate.nelements,'cells',flush=True)
 r=fe.solve(f'local_A{level}',candidate.p.T,candidate.t.T)
 changes=[]
 for item in r['regions']:
  prev=next(x for x in last if x['region']==item['region']);changes.append(dict(region=item['region'],Q90_percent=100*abs(item['Q90_MPa']-prev['Q90_MPa'])/item['Q90_MPa'],Q95_percent=100*abs(item['Q95_MPa']-prev['Q95_MPa'])/item['Q95_MPa'],Q99_percent=100*abs(item['Q99_MPa']-prev['Q99_MPa'])/item['Q99_MPa']))
 r['changes_from_previous']=changes;rows.append(r);last=r['regions'];m=candidate
 # Predeclared target applied to all 18 regional quantiles, not only one favourable value.
 if max(x[k] for x in changes for k in ['Q90_percent','Q95_percent','Q99_percent'])<.5:break
result=dict(status='completed',element_kernel_relative_error=error,local_selection='Frozen Rtip cell union; cells crossing fixed root-cap interfaces; within 0.4 mm of fixed L0 crown corner edges (>40 deg) on geometric sides.',target_all_18_percent=.5,reporting_threshold_percent=2,cell_cap=1800000,cases=rows,scope='Finite local refinement on one polyhedral proxy, not a proof of anatomical notch resolution or continuum convergence.')
(R/'review/adaptive_run_001/results.json').write_text(json.dumps(result,indent=2));(R/'review/adaptive_experiment.json').write_text(json.dumps(result,indent=2))
