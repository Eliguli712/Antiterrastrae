#!/usr/bin/env python3
"""Audit the new adjacent bilayer case and derive the printed finite comparisons."""
from pathlib import Path
import ast, json
import numpy as np
R=Path(__file__).resolve().parents[1]
source=R/'scripts/audit_publication_fields_v3.py'
tree=ast.parse(source.read_text())
nodes=[]
for node in tree.body:
    if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='start' for x in node.targets):break
    nodes.append(node)
scope={'__file__':str(source),'__name__':'independent_adjacent_readback'}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),scope)
readback=scope['one'](R/'data/bilayer_A2_0p5mm')
def case(name):return json.loads((R/'data'/name/'results.json').read_text())
def values(name):return np.array([[x[k] for k in ['Q90_MPa','Q95_MPa','Q99_MPa']] for x in case(name)['regions']])
primary=100*abs(values('local_A3')-values('local_A2'))/values('local_A3')
bilayer=100*abs(values('bilayer_A3_0p5mm')-values('bilayer_A2_0p5mm'))/values('bilayer_A3_0p5mm')
assert primary[:,1].max()<.233 and primary.max()<.60
assert bilayer.max()<.64
reference=values('grid_T100_h0p288')[:,1]
threshold=100*np.stack([values('grid_T095_h0p288')[:,1]/reference-1,values('grid_T105_h0p288')[:,1]/reference-1])
representation=100*(values('grid_T100_h0p576')[:,1]/reference-1)
assert abs(threshold).max()<.8
summary=dict(status='passed',adjacent_bilayer_independent_readback=readback,
  homogeneous_last_step_all_18_percent=primary.tolist(),bilayer_last_step_all_18_percent=bilayer.tolist(),
  threshold_Q95_signed_percent=threshold.tolist(),coarse_to_fine_Q95_signed_percent=representation.tolist(),
  homogeneous_A3_edge_to_centre=(values('local_A3')[[1,2],1]/values('local_A3')[0,1]).tolist(),
  scope='Finite adjacent-mesh differences, not certified continuum error bounds. Candidate layers and Robin springs are assumed model inputs, not histological or mechanical calibration.')
(R/'review/final_readback_001/results.json').write_text(json.dumps(summary,indent=2))
