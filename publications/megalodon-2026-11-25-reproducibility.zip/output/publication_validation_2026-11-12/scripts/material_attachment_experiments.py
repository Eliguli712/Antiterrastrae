#!/usr/bin/env python3
"""Geometric candidate bilayers and calibratable finite Robin references."""
from pathlib import Path
import json,numpy as np,pyvista as pv
import elastic_diagnostics as fe
R=fe.R;B=fe.B
rows=[];layers=[]
for level in [1,2]:
 a=np.load(B/f'numerics/L{level}/solution.npz');p=a['points_m'];t=a['tets'];f=a['boundary_faces'];surface=pv.PolyData(p,np.column_stack([np.full(len(f),3),f]).ravel());centroid=p[t].mean(1)
 closest_id,closest=surface.find_closest_cell(centroid,return_closest_point=True);distance=np.linalg.norm(closest-centroid,axis=1)
 reference=np.load(B/'numerics/L0/solution.npz');bp=reference['points_m'];bf=reference['boundary_faces'];q=(centroid-reference['center_m'])@reference['basis'];sq=(bp[np.unique(bf)]-reference['center_m'])@reference['basis'];s,_,_=fe.core.geometric_coordinates(q,sq)
 np.savez_compressed(R/'data'/f'L{level}_candidate_interface_distance.npz',distance_m=distance,reference_s=s,closest_boundary_face=closest_id)
 for width in ([.25,.5,1.] if level==1 else [.5]):
  tag=np.where((s<=.76)&(distance<=width*.001),2,1).astype(np.uint8)
  # Explicit assumptions: reduced indentation moduli are NOT substituted as Young moduli.
  young=np.where(tag==2,100e9,30e9)
  name=f'bilayer_L{level}_{str(width).replace(".","p")}mm'
  result=fe.solve(name,p,t,E=young,nu=.25,tag=tag);result.update(shell_thickness_mm=width,E_candidate_enameloid_GPa=100,E_candidate_dentine_GPa=30,nu=.25,interface_scope='Independently constructed geometric crown shell; centroid cell assignment, not histologically segmented enameloid/dentine or a conforming EDJ mesh.')
  (R/'data'/name/'results.json').write_text(json.dumps(result,indent=2));rows.append(result)
  if level==1 and width==.5:
   centers=p[t].mean(1);cell_mesh=pv.UnstructuredGrid(np.column_stack([np.full(len(t),4),t]).ravel(),np.full(len(t),10,np.uint8),p*1000);cell_mesh.cell_data['candidate_phase']=tag;cell_mesh.save(R/'data/candidate_bilayer_0p5mm.vtu')
  layers.append(dict(level=level,width_mm=width,cells2=int((tag==2).sum()),volume_fraction=result['material2_volume_fraction']))
 if level==1:
  for k in [1e10,1e11,1e12]:
   name='robin_L1_k'+str(int(np.log10(k)));result=fe.solve(name,p,t,foundation=k);rows.append(result)
record=dict(status='completed',bilayer_method='Separate crown shell distance and core in the calibrated proxy; labels stored independently of original appearance colours. No independent CT/SEM ground truth identifies this fossil EDJ.',material_scope='Chosen Young moduli 100/30 GPa and nu=.25; extant nanoindentation evidence motivates stiffness contrast but reports reduced moduli. Fossil stiffness, anisotropy and alteration remain unmeasured.',attachment_scope='3-direction external-root-face Robin springs with tributary areas. k is an explicit calibratable parameter; these runs are a sensitivity grid, not a fit to nonexistent attachment measurements.',interface_discretization=layers,cases=rows)
(R/'review/material_run_001/results.json').write_text(json.dumps(record,indent=2));(R/'review/material_attachment_experiments.json').write_text(json.dumps(record,indent=2))
