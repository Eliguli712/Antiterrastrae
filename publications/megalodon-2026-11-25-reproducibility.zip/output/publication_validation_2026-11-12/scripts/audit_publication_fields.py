#!/usr/bin/env python3
"""Independent local-gradient, CDF and equilibrium readback of every new solve."""
from pathlib import Path
import json,hashlib,time
import numpy as np
R=Path(__file__).resolve().parents[1];P=R.parents[1];B=P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics';base=np.load(B/'L0/solution.npz');mask0=np.load(B/'L0/region_masks.npz');I=np.eye(3)
bp=base['points_m'];center=base['center_m'];basis=base['basis'];surface=(bp[np.unique(base['boundary_faces'])]-center)@basis;ymin=surface[:,1].min();span=np.ptp(surface[:,1])

def coordinates(points):
 q=(points-center)@basis;s=(q[:,1]-ymin)/span;sy=(surface[:,1]-ymin)/span;centers=[];left=[];right=[]
 for lower in np.linspace(0,1,41)[:-1]:
  use=(sy>=lower)&(sy<=lower+.025)
  if use.sum()>=3:centers.append(lower+.0125);left.append(surface[use,0].min());right.append(surface[use,0].max())
 lo=np.interp(s,centers,left);hi=np.interp(s,centers,right);r=(2*q[:,0]-lo-hi)/np.maximum(hi-lo,1e-12);z=(q[:,2]-.5*(surface[:,2].min()+surface[:,2].max()))/(.5*np.ptp(surface[:,2]));return s,r,z

def one(folder):
 result=json.loads((folder/'results.json').read_text());a=np.load(folder/'fields.npz');p=a['points_m'];t=a['tets'];u=a['displacement_m'];vol=a['volumes_m3'];la=a['lambda_Pa'];mu=a['mu_Pa'];force=a['force_N'];spring=a['spring_N_per_m'];fixed=a['fixed_nodes'];fint=np.zeros_like(p);vm=np.empty(len(t));peak=np.empty((len(t),3));sumerr=0.;sumref=0.;maxG=0.;Jmin=np.inf;quality=[]
 for start in range(0,len(t),16000):
  sl=slice(start,min(start+16000,len(t)));tt=t[sl];edge=p[tt[:,1:]]-p[tt[:,:1]];inv=np.linalg.inv(edge);g=np.empty((len(tt),4,3));g[:,1:]=inv.transpose(0,2,1);g[:,0]=-g[:,1:].sum(1);v=np.abs(np.linalg.det(edge))/6;np.testing.assert_allclose(v,vol[sl],rtol=1e-12,atol=1e-24)
  G=(inv@(u[tt[:,1:]]-u[tt[:,:1]])).transpose(0,2,1);eps=(G+G.transpose(0,2,1))/2;sigma=la[sl,None,None]*np.trace(eps,axis1=1,axis2=2)[:,None,None]*I+2*mu[sl,None,None]*eps;error=sigma-a['stress_Pa'][sl];sumerr+=float(np.einsum('e,eij,eij->',v,error,error));sumref+=float(np.einsum('e,eij,eij->',v,sigma,sigma));dev=sigma-np.trace(sigma,axis1=1,axis2=2)[:,None,None]*I/3;vm[sl]=np.sqrt(1.5*np.sum(dev**2,(1,2)));peak[sl]=np.linalg.eigvalsh(sigma)
  local=np.einsum('eij,eaj,e->eai',sigma,g,v)
  for j in range(4):np.add.at(fint,tt[:,j],local[:,j])
  maxG=max(maxG,float(np.linalg.norm(G,axis=(1,2)).max()));Jmin=min(Jmin,float(np.linalg.det(I+G).min()));lengthsum=sum(np.sum((p[tt[:,j]]-p[tt[:,k]])**2,axis=1) for j in range(4) for k in range(j));quality.append(12*(3*v)**(2/3)/lengthsum)
 relative=float(np.sqrt(sumerr/sumref));assert relative<2e-6
 free=np.ones(len(p),bool);free[fixed]=False;res=fint+spring[:,None]*u-force;freeerror=float(np.linalg.norm(res[free])/np.linalg.norm(force[free]));assert freeerror<1e-5
 reconstructed=np.zeros_like(force);loaded=a['boundary_faces'][a['loaded_faces']];x=p[loaded];face_force=-1e6*np.cross(x[:,1]-x[:,0],x[:,2]-x[:,0])/6
 for j in range(3):np.add.at(reconstructed,loaded[:,j],face_force)
 np.testing.assert_allclose(reconstructed,force,rtol=1e-11,atol=1e-12)
 reaction=-spring[:,None]*u if len(fixed)==0 else np.where((~free)[:,None],res,0);balance=float(np.linalg.norm(reaction.sum(0)+force.sum(0))/np.linalg.norm(force.sum(0)));assert balance<1e-5
 current_moment=float(np.linalg.norm((np.cross(p+u,force+reaction)).sum(0))/(np.linalg.norm(force.sum(0))*np.ptp(p,axis=0).max()))
 parent=a['parent_L0'];centroid=p[t].mean(1)
 if np.all(parent>=0):
  masks={r['region']:np.isin(parent,mask0[r['region']]) for r in result['regions']}
  for start in range(0,len(t),32000):
   sl=slice(start,min(start+32000,len(t)));v=bp[base['tets'][parent[sl]]];local=np.linalg.solve((v[:,1:]-v[:,:1]).transpose(0,2,1),centroid[sl]-v[:,0]);assert local.min()>-1e-7 and local.sum(1).max()<1+1e-7
 else:
  s,r,z=coordinates(centroid);masks=dict(R0=(.25<=s)&(s<=.55)&(abs(r)<=.35)&(abs(z)<=.5),RA=(.12<s)&(s<.64)&(r<=-.78),RB=(.12<s)&(s<.64)&(r>=.78),Rtip=s<=.12,Rcr=(.64<=s)&(s<=.76),Rroot=(.78<=s)&(s<=.84))
 for row in result['regions']:
  use=masks[row['region']];assert use.sum()==row['cells'];np.testing.assert_allclose(vol[use].sum()*1e9,row['volume_mm3'],rtol=2e-12)
  for values,keys in [(vm,['Q90_MPa','Q95_MPa','Q99_MPa']),(np.maximum(peak[:,2],0),[None,'principal_tension_Q95_MPa',None]),(np.maximum(-peak[:,0],0),[None,'principal_compression_Q95_MPa',None])]:
   order=np.argsort(values[use]);v=values[use][order];w=vol[use][order];cdf=np.cumsum(w)/w.sum()
   for q,key in zip([.9,.95,.99],keys):
    if key:np.testing.assert_allclose(v[np.searchsorted(cdf,q)]/1e6,row[key],rtol=2e-6,atol=1e-8)
 idx=int(vm.argmax());support=bool((~free)[t[idx]].any());qcell=(centroid[idx]-center)@basis;speak,rpeak,zpeak=[float(v[0]) for v in coordinates(centroid[idx:idx+1])]
 quality=np.concatenate(quality)
 with (folder/'fields.npz').open('rb') as f:digest=hashlib.file_digest(f,'sha256').hexdigest()
 return dict(case=folder.name,elements=len(t),tensor_volume_L2_relative=relative,free_force_relative=freeerror,force_balance_relative=balance,current_frame_moment_defect=current_moment,max_displacement_gradient_Fro=maxG,minimum_det_I_plus_gradient=Jmin,quality_min_p01_median=np.quantile(quality,[0,.01,.5]).tolist(),peak_MPa=float(vm[idx]/1e6),peak_cell_intersects_essential_nodes=support,peak_reference_s_r_zeta=[speak,rpeak,zpeak],raw_fields_sha256=digest)

start=time.monotonic();rows=[]
for path in sorted((R/'data').glob('*/results.json')):
 if (path.parent/'fields.npz').exists():rows.append(one(path.parent));print('Independently read',path.parent.name,flush=True)
assert len(rows)==19,len(rows)
result=dict(status='passed',cases=rows,total_elements=sum(x['elements'] for x in rows),quantile_columns_checked_per_case=30,scope='Every saved cell, independently recovered tensors/forces/quantiles and frozen-region containment. Mesh-step changes are not certified continuum error bounds; material and attachment calibration remain separate obligations.',runtime_seconds=time.monotonic()-start)
(R/'review/publication_readback_001/results.json').write_text(json.dumps(result,indent=2));(R/'review/publication_readback.json').write_text(json.dumps(result,indent=2))
