"""Produce native-grid section views, microstructure media and uncertainty figures."""
from pathlib import Path
import argparse,json,hashlib,zipfile,shutil
import numpy as np
from scipy import ndimage
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties
from matplotlib.backends.backend_pdf import PdfPages
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[3];O=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();RUN=a.run.resolve();OUT=a.output.resolve();OUT.mkdir(exist_ok=True,parents=True)
F=OUT/'figures';F.mkdir(exist_ok=True);M=OUT/'media';M.mkdir(exist_ok=True);D=RUN/'data'
r=json.loads((RUN/'result.json').read_text());assert r['status']=='completed'
raw=np.memmap(ROOT/'output/ct_web_2026-11-19/cache/native_specimen_crop.i16',dtype='<i2',mode='r',shape=(2886,1903,746));mask=np.memmap(ROOT/'output/ct_web_2026-11-19/cache/selected_native_mask.u8',dtype='u1',mode='r',shape=raw.shape)
H=.018;origin=np.array([7.056,1.368,1.368]);center=np.array(r['voxel_volume_PCA']['center_scanner_mm']);axes=np.array(r['voxel_volume_PCA']['axes_columns'])
lo=np.array([7.083,1.395,1.395]);hi=np.array([20.439,35.577,53.271]);corners=np.array([[x,y,z]for x in [lo[0],hi[0]]for y in [lo[1],hi[1]]for z in [lo[2],hi[2]]])
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
def window(x):return np.uint8(np.rint(np.clip((x+3292)/(26623+3292),0,1)*255))
native_views=[]
for j,record in enumerate(r['principal_sections']):
 u=axes[:,1]if j!=1 else axes[:,2];v=-axes[:,0]if j!=0 else axes[:,2];n=axes[:,j]
 cu=(corners-center)@u;cv=(corners-center)@v;us=np.arange(cu.min()-.1,cu.max()+.1,H);vs=np.arange(cv.max()+.1,cv.min()-.1,-H)
 values=np.empty((len(vs),len(us)),dtype='<i2');seg=np.empty(values.shape,dtype='u1');s=record['plane_offset_from_centroid_mm']
 for row in range(0,len(vs),48):
  xyz=center+n*s+us[None,:,None]*u+vs[row:row+48,None,None]*v;coords=((xyz-origin)/H)[...,::-1].transpose(2,0,1)
  values[row:row+48]=ndimage.map_coordinates(raw,coords,order=0,prefilter=False,mode='constant',cval=-32768)
  seg[row:row+48]=ndimage.map_coordinates(mask,coords,order=0,prefilter=False,mode='constant',cval=0)
 gray=window(values);Image.fromarray(gray).save(M/f'principal_axis{j+1}_native18um.png');Image.fromarray(seg*255).save(M/f'principal_axis{j+1}_binary_native18um.png')
 Image.fromarray(gray).save(M/f'principal_axis{j+1}_native18um.gif',optimize=False)
 np.savez_compressed(M/f'principal_axis{j+1}_native_samples.npz',raw_signed16=values,mask=seg,normal=n,u=u,v=v,plane_origin_mm=center+n*s,grid_spacing_mm=H,u_coordinates_mm=us,v_coordinates_mm=vs)
 native_views.append({'axis':j+1,'image':f'principal_axis{j+1}_native18um.png','gif':f'principal_axis{j+1}_native18um.gif','binary':f'principal_axis{j+1}_binary_native18um.png','width':len(us),'height':len(vs),'native_sampling_um':18,'interpolation':'nearest native voxel; exact original grey value at the selected voxel, no claimed new resolution','plane_normal':n.tolist(),'plane_origin_scanner_mm':(center+n*s).tolist()})

# Paired resampling concerns algorithm-induced axis differences. The MPPCA
# model is fixed, so these are deliberately not model-refit confidence bounds.
s=np.load(D/'MPPCA_conditional_surface_sample.npz');x=s['original_points_mm'];y=s['bounded_display_points_mm']
ids=np.floor((x-lo)/.72).astype(int);_,ids=np.unique(ids,axis=0,return_inverse=True);K=int(ids.max()+1)
def moments(p):
 columns=[np.ones(len(p)),*p.T,*(p*p).T,p[:,0]*p[:,1],p[:,0]*p[:,2],p[:,1]*p[:,2]]
 return np.column_stack([np.bincount(ids,weights=c,minlength=K)for c in columns])
mx,my=moments(x),moments(y)
def frame(m):
 mu=m[...,1:4]/m[...,:1];C=np.zeros(m.shape[:-1]+(3,3));C[...,0,0]=m[...,4];C[...,1,1]=m[...,5];C[...,2,2]=m[...,6];C[...,0,1]=C[...,1,0]=m[...,7];C[...,0,2]=C[...,2,0]=m[...,8];C[...,1,2]=C[...,2,1]=m[...,9];C=C/m[...,0,None,None]-mu[...,:,None]*mu[...,None,:]
 return np.linalg.eigh(C)[1][...,::-1]
direct=np.rad2deg(np.arccos(np.clip(abs(np.sum(frame(mx.sum(0))*frame(my.sum(0)),axis=0)),0,1)))
rng=np.random.default_rng(20261125);delta=[]
for first in range(0,1500,24):
 w=rng.multinomial(K,np.full(K,1/K),size=min(24,1500-first));A=frame(w@mx);B=frame(w@my);delta.extend(np.rad2deg(np.arccos(np.clip(abs(np.einsum('bij,bij->bj',A,B)),0,1))).tolist())
delta=np.asarray(delta);displacement=50000*np.sin(np.deg2rad(delta))
paired={'method':'Paired .72 mm spatial-block bootstrap of the same area-uniform sample before/after bounded conditional MPPCA; fixed fitted model, not repeated acquisitions.','replicates':1500,'seed':20261125,'angle_deg_point_estimate':direct.tolist(),'angle_deg_Q025_Q50_Q975':np.quantile(delta,[.025,.5,.975],axis=0).tolist(),'direction_displacement_um_at_50mm_Q025_Q50_Q975':np.quantile(displacement,[.025,.5,.975],axis=0).tolist(),'empirical_fraction_algorithm_difference_le_1um':(displacement<=1).mean(0).tolist(),'bootstrap_refits_MPPCA':False,'accuracy_probability_claimed':False,'alpha5e_7_coverage_certified':False}

# Native grey-scale canal/void candidates, with original signed16 ROI values.
font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',18)
micro=[]
for source_z in [1500,1900,2100]:
 entry=next(q for q in r['internal_microstructure']['native_slice_diagnostics']if q['original_DICOM_slice_index']==source_z)
 region=entry['largest_regions'][0];cx,cy=map(lambda v:int(round(v)),region['centroid_xy_native_crop']);z=source_z-76;half=96
 x0=max(0,min(raw.shape[2]-2*half,cx-half));y0=max(0,min(raw.shape[1]-2*half,cy-half));roi=np.array(raw[z,y0:y0+2*half,x0:x0+2*half],dtype='f8')
 sigma=entry['background_MAD_raw_intensity'];mu=ndimage.uniform_filter(roi,size=3,mode='reflect');variance=np.maximum(ndimage.uniform_filter(roi*roi,size=3,mode='reflect')-mu*mu,0);gain=np.maximum(variance-sigma*sigma,0)/np.maximum(variance,1)
 preview=mu+gain*(roi-mu);raw_image=Image.fromarray(window(roi));filtered=Image.fromarray(window(preview));raw_image.save(M/f'micro_{source_z}_raw_native.png');filtered.save(M/f'micro_{source_z}_wiener_display.png')
 np.savez_compressed(M/f'micro_{source_z}_original_ROI.npz',raw_signed16=np.array(raw[z-50:z+51,y0:y0+2*half,x0:x0+2*half]),native_spacing_mm=H,origin_native_crop_zyx=[z-50,y0,x0])
 frames=[]
 for zz in range(z-50,z+51):
  image=Image.fromarray(window(raw[zz,y0:y0+2*half,x0:x0+2*half])).resize((768,768),Image.Resampling.NEAREST).convert('RGB')
  draw=ImageDraw.Draw(image);draw.rectangle((0,0,768,35),fill=(8,16,22));draw.text((12,8),f'18 um native sampling | 4x display | slice {zz+76}',font=font,fill=(238,242,245));bar=round(.5/H*4);draw.rectangle((22,725,22+bar,730),fill='white');draw.text((22,738),'500 um',font=font,fill='white');frames.append(image.convert('P',palette=Image.Palette.ADAPTIVE,colors=256,dither=Image.Dither.NONE))
 gif=M/f'micro_{source_z}_native18um_sweep.gif';frames[0].save(gif,save_all=True,append_images=frames[1:],duration=40,loop=0,optimize=False,disposal=2)
 thresholds=[]
 for factor in [.95,.975,1,1.025,1.05]:
  binary=roi>=10361.669921875*factor;holes=ndimage.binary_fill_holes(binary)&~binary;lab,n=ndimage.label(holes);sizes=np.bincount(lab.ravel())[1:];thresholds.append({'factor':factor,'enclosed_2D_regions':int(n),'enclosed_pixels':int(holes.sum()),'largest_region_pixels':int(sizes.max())if len(sizes)else 0})
 flips=float(np.mean((roi>=10361.669921875)!=(preview>=10361.669921875)))
 micro.append({'source_slice':source_z,'native_crop_ROI_yx':[y0,y0+192,x0,x0+192],'native_sampling_um':18,'sweep_frames':101,'sweep_duration_seconds':4.04,'sweep_z_step_um':18,'sweep_range_mm':1.8,'display_magnification':4,'GIF_dither':'none','gray_window_raw':[-3292,26623],'raw_image':f'micro_{source_z}_raw_native.png','display_preview':f'micro_{source_z}_wiener_display.png','GIF':gif.name,'threshold_sensitivity':thresholds,'wiener_display_threshold_classification_flip_fraction':flips,'denoised_image_used_for_quantitation':False,'anatomical_identification':'Candidate low-density morphology; neither vascular nor nutritive identity established.'})

plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':12,'text.color':'#dce9ed','axes.labelcolor':'#c7dbe2','xtick.color':'#b3c9d3','ytick.color':'#b3c9d3','axes.facecolor':'#11232d','figure.facecolor':'#09141b','savefig.facecolor':'#09141b','axes.edgecolor':'#526876','pdf.fonttype':42})
serif=FontProperties(fname=str(ROOT/'output/acrylic_baskerville_v4_2026-11-20/review/font_cache/Baskerville-Italic.ttf'))
figs=[]
def title(fig,sub):fig.text(.05,.955,'Astraeus Krystallisia',fontproperties=serif,fontsize=30,va='top');fig.text(.05,.887,sub,fontsize=15,va='top',color='#a3bdca')
def finish(fig,name):fig.savefig(F/(name+'.png'),dpi=220);figs.append(fig)
fig=plt.figure(figsize=(16,10));title(fig,'Native 18 um sampling | maximum sections in the volume-weighted principal frame')
gs=fig.add_gridspec(1,3,left=.04,right=.96,top=.80,bottom=.18,wspace=.08)
for j,q in enumerate(native_views):
 ax=fig.add_subplot(gs[0,j]);ax.imshow(Image.open(M/q['image']),cmap='gray',interpolation='nearest');ax.set_axis_off();ax.set_title(f'Axis {j+1} | {r["principal_sections"][j]["maximum_on_checked_grid_area_mm2"]:.3f} mm2',fontsize=14)
fig.text(.05,.105,'Every native triangle was intersected on an 18 um plane grid; inward-oriented void boundaries subtract from section area.',fontsize=11)
fig.text(.05,.06,'Native grey values are sampled without creating new measured detail. PNG/GIF and original signed16 sample arrays are downloadable.',fontsize=11,color='#9db7c4');finish(fig,'Native18_Principal_Maximum_Sections')
fig=plt.figure(figsize=(16,9));title(fig,'PCA weighting and cross-section profiles | full-data integration')
gs=fig.add_gridspec(1,3,left=.07,right=.95,top=.77,bottom=.29,wspace=.28)
for j in range(3):
 data=np.loadtxt(D/f'native-sections-axis{j+1}.csv',delimiter=',',skiprows=1);ax=fig.add_subplot(gs[0,j]);ax.plot(data[:,0],data[:,1],color='#8cd7d2');ax.set_xlabel('Plane offset (mm)');ax.set_ylabel('Section area (mm2)');ax.set_title('Principal axis '+str(j+1));ax.grid(alpha=.15)
fig.text(.07,.18,'Area-uniform surface PCA vs material-volume PCA: '+', '.join(f'{v:.4f} deg'for v in r['surface_vs_volume_axis_angles_deg']),fontsize=13)
fig.text(.07,.12,'Different weights estimate different geometric quantities; uniform voxels do not imply unbiased surface-curvature estimates.',fontsize=11,color='#9db7c4')
fig.text(.07,.07,'Isotropic-noise PPCA retains the PCA principal subspace. Its global residual includes real tooth thickness.',fontsize=11,color='#9db7c4');finish(fig,'Native18_PCA_Weights_and_Areas')
fig=plt.figure(figsize=(16,9));title(fig,'Spatial bootstrap | dependence on block size | conditional resampling stability')
gs=fig.add_gridspec(1,2,left=.07,right=.95,top=.77,bottom=.30,wspace=.25)
for col,key in enumerate(['volume','surface']):
 ax=fig.add_subplot(gs[0,col]);bs=r['bootstrap'][key]
 for j in range(3):ax.plot([v['block_edge_mm']for v in bs],[v['angle_deg_Q95'][j]for v in bs],'o-',label='Axis '+str(j+1))
 ax.set_xlabel('Spatial block edge (mm)');ax.set_ylabel('95th percentile angular change (deg)');ax.set_title(key.title()+' weighting');ax.legend();ax.grid(alpha=.15)
fig.text(.07,.18,'1,500 replicates per scale. These are spatial reweightings of one specimen, not independent repeated acquisitions.',fontsize=11)
fig.text(.07,.12,'Requested alpha = 5e-7; empirical tail resolution = 1/1501 = 6.66e-4. Requested extreme-tail coverage is not validated.',fontsize=11,color='#e1bd8c')
fig.text(.07,.07,'Larger spatial blocks produce wider variation here. More resampling does not remove scanner or segmentation bias.',fontsize=11,color='#9db7c4');finish(fig,'Native18_Spatial_Bootstrap_Stability')
fig=plt.figure(figsize=(16,9));title(fig,'Conditional sparse MPPCA | algorithm-induced directional differences')
gs=fig.add_gridspec(1,2,left=.07,right=.95,top=.77,bottom=.35,wspace=.25)
ax=fig.add_subplot(gs[0,0]);models=r['MPPCA']['models'];ax.plot([m['K']for m in models],[m['heldout_mean_log_likelihood']for m in models],'o-',color='#8cd7d2');ax.set_xlabel('Mixture components');ax.set_ylabel('Spatial holdout mean log likelihood');ax.grid(alpha=.15)
ax=fig.add_subplot(gs[0,1]);ax.boxplot([displacement[:,j]for j in range(3)],tick_labels=['Axis 1','Axis 2','Axis 3'],patch_artist=True,boxprops={'facecolor':'#316a7c'},medianprops={'color':'#d9d5a3'});ax.axhline(1,color='#e1bd8c',ls='--',label='1 um target');ax.set_ylabel('Algorithm difference at 50 mm lever arm (um)');ax.legend();ax.grid(alpha=.15)
notes=['MPPCA uses an area-uniform 65,000-point sample with held-out spatial cells; all native geometry is retained separately.','Top four mixture responsibilities are retained. The display hypothesis is capped at 9 um displacement.','These intervals keep the fitted model fixed. They describe algorithm changes, not reconstruction accuracy or biological truth.','The residual is not calibrated measurement noise. The 1 um / alpha=5e-7 target is not certified; no native surface is replaced.']
for j,t in enumerate(notes):fig.text(.07,.245-j*.046,t,fontsize=11,color='#9db7c4'if j<3 else'#e1bd8c')
finish(fig,'Native18_Conditional_MPPCA')
fig=plt.figure(figsize=(16,10));title(fig,'Internal microstructure | original native-grid low-density candidates')
gs=fig.add_gridspec(2,3,left=.05,right=.95,top=.79,bottom=.20,wspace=.08,hspace=.10)
for j,q in enumerate(micro):
 for row,key,label in [(0,'raw_image','Original'),(1,'display_preview','Wiener display only')]:
  ax=fig.add_subplot(gs[row,j]);ax.imshow(Image.open(M/q[key]),cmap='gray',interpolation='nearest');ax.set_axis_off();ax.set_title(f'{label} | slice {q["source_slice"]}',fontsize=12);ax.plot([14,14+.5/H],[175,175],color='white',lw=2);ax.text(14,185,'500 um',fontsize=9,color='white')
closed=r['internal_microstructure'];fig.text(.05,.12,f'803,442 retained closed void components | closed-void fraction of closed outer envelope {100*closed["closed_void_fraction_of_closed_outer_envelope"]:.4f}%.',fontsize=11)
fig.text(.05,.075,'Closed threshold-defined voids exclude open channels. Neither these regions nor their boundaries establish nutritive or vascular identity.',fontsize=11,color='#e1bd8c')
fig.text(.05,.035,'Only original data are used for quantitative counts. Denoised displays and threshold sensitivity remain separate.',fontsize=10,color='#9db7c4');finish(fig,'Native18_Microstructure_Candidates')
pdf=ROOT/'output/pdf/Native18_PCA_PPCA_MPPCA_and_Microstructure.pdf';pdf.parent.mkdir(exist_ok=True,parents=True)
with PdfPages(pdf,metadata={'Title':'Native 18 um PCA, conditional PPCA/MPPCA and internal microstructure','Author':'eliguli712'})as out:
 for fig in figs:out.savefig(fig,dpi=220);plt.close(fig)
shutil.copy2(pdf,OUT/pdf.name)
sources=[{'title':'Tipping and Bishop: Probabilistic Principal Component Analysis','url':'https://doi.org/10.1111/1467-9868.00196'},{'title':'Tipping and Bishop: Mixtures of Probabilistic Principal Component Analyzers','url':'https://www.microsoft.com/en-us/research/publication/mixtures-of-probabilistic-principal-component-analyzers/'},{'title':'Bouxsein et al.: Guidelines for assessment of bone microstructure using micro-CT','url':'https://doi.org/10.1002/jbmr.141'}]
summary={'status':'completed','raw_run':str(RUN),'raw_result_sha256':sha(RUN/'result.json'),'native_sections':native_views,'paired_conditional_difference':paired,'microstructure_ROIs':micro,'requested_precision_certified':False,'source_native_resolution_label':'18 um acquired voxel sampling; not a measured 1 um spatial resolution','native_FEM_status':'Deferred by user; no native volume solution claimed.','sources':sources}
(OUT/'interpretation.json').write_text(json.dumps(summary,indent=2)+'\n');(OUT/'result.json').write_text(json.dumps({'status':'completed','figures':5,'native_maximum_section_views':3,'microstructure_sweeps':3,'requested_alpha_coverage_certified':False},indent=2)+'\n')
print('NATIVE PRESENTATION COMPLETE',flush=True)
