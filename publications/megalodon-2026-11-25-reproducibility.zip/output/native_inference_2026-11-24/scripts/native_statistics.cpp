#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
constexpr uint64_t NV=37951699,NF=74293846;
struct Map{int fd;void*p;size_t bytes;Map(std::string path){fd=open(path.c_str(),O_RDONLY);if(fd<0)throw std::runtime_error("Missing input");struct stat s;fstat(fd,&s);bytes=s.st_size;p=mmap(nullptr,bytes,PROT_READ,MAP_PRIVATE,fd,0);if(p==MAP_FAILED)throw std::runtime_error("Cannot map input");}~Map(){munmap(p,bytes);close(fd);}};
struct V{double x,y,z;V operator+(V a)const{return{x+a.x,y+a.y,z+a.z};}V operator-(V a)const{return{x-a.x,y-a.y,z-a.z};}V operator*(double s)const{return{x*s,y*s,z*s};}double operator[](int i)const{return i==0?x:i==1?y:z;}};
V cross(V a,V b){return{a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
double dot(V a,V b){return a.x*b.x+a.y*b.y+a.z*b.z;}
void voxel(std::string path,std::string output){
 Map m(path);constexpr int X=746,Y=1903,Z=2886,B=40,NX=(X+B-1)/B,NY=(Y+B-1)/B,NZ=(Z+B-1)/B;
 if(m.bytes!=uint64_t(X)*Y*Z)throw std::runtime_error("Native mask size mismatch");
 std::vector<std::array<uint64_t,10>> cells(NX*NY*NZ);const uint8_t*mask=(uint8_t*)m.p;
 for(int z=0;z<Z;z++)for(int y=0;y<Y;y++)for(int bx=0;bx<NX;bx++){
  uint64_t n=0,sx=0,sxx=0;const auto*row=mask+(uint64_t(z)*Y+y)*X;
  for(int x=bx*B;x<std::min(X,(bx+1)*B);x++)if(row[x]){n++;sx+=x;sxx+=uint64_t(x)*x;}
  if(!n)continue;auto&q=cells[((z/B)*NY+y/B)*NX+bx];
  q[0]+=n;q[1]+=sx;q[2]+=n*y;q[3]+=n*z;q[4]+=sxx;q[5]+=n*y*y;q[6]+=n*z*z;q[7]+=sx*y;q[8]+=sx*z;q[9]+=n*y*z;
 }
 std::ofstream o(output,std::ios::binary);uint32_t h[4]={NX,NY,NZ,10};o.write((char*)h,sizeof(h));o.write((char*)cells.data(),cells.size()*sizeof(cells[0]));
 uint64_t n=0;for(auto&q:cells)n+=q[0];if(n!=967429317)throw std::runtime_error("Selected material count mismatch");std::cout<<"All native mask voxels visited; selected material "<<n<<"\n";
}
void surface(std::string vertices,std::string faces,std::string prefix){
 Map vm(vertices),fm(faces);if(vm.bytes!=NV*sizeof(V)||fm.bytes!=NF*12)throw std::runtime_error("Native mesh size mismatch");const V*v=(V*)vm.p;const uint32_t*f=(uint32_t*)fm.p;
 V lo={7.082999999999999,1.3949999999999998,1.3949999999999998},hi={20.439,35.577,53.270999999999994};constexpr double B=.72;
 uint32_t nx=uint32_t(std::ceil((hi.x-lo.x)/B))+1,ny=uint32_t(std::ceil((hi.y-lo.y)/B))+1,nz=uint32_t(std::ceil((hi.z-lo.z)/B))+1;
 std::vector<std::array<double,10>>cells(uint64_t(nx)*ny*nz);std::ofstream areas(prefix+"-face-area.f64",std::ios::binary);
 double total=0,volume=0;
 for(uint64_t i=0;i<NF;i++){
  uint32_t a=f[3*i],b=f[3*i+1],c=f[3*i+2];if(std::max({a,b,c})>=NV)throw std::runtime_error("Invalid face");V p=v[a],q=v[b],r=v[c],normal=cross(q-p,r-p);double A=.5*std::sqrt(dot(normal,normal));if(!(A>0))throw std::runtime_error("Invalid area");areas.write((char*)&A,8);total+=A;volume+=dot(p,cross(q,r))/6;
  V s=p+q+r,center=s*(1./3);int x=std::clamp(int((center.x-lo.x)/B),0,int(nx)-1),y=std::clamp(int((center.y-lo.y)/B),0,int(ny)-1),z=std::clamp(int((center.z-lo.z)/B),0,int(nz)-1);auto&cell=cells[(z*ny+y)*nx+x];
  cell[0]+=A;for(int j=0;j<3;j++)cell[1+j]+=A*s[j]/3;
  int at=4;for(auto pair:std::array<std::array<int,2>,6>{{{0,0},{1,1},{2,2},{0,1},{0,2},{1,2}}}){int j=pair[0],k=pair[1];cell[at++]+=A*(p[j]*p[k]+q[j]*q[k]+r[j]*r[k]+s[j]*s[k])/12;}
 }
 std::ofstream o(prefix+"-blocks.f64",std::ios::binary);uint32_t h[4]={nx,ny,nz,10};o.write((char*)h,16);o.write((char*)cells.data(),cells.size()*sizeof(cells[0]));
 std::ofstream record(prefix+"-totals.txt");record.precision(17);record<<NV<<" "<<NF<<" "<<total<<" "<<volume<<"\n";std::cout<<"All "<<NF<<" faces integrated; area "<<total<<" mm2\n";
}
void sections(std::string vertices,std::string faces,std::string config,std::string prefix){
 Map vm(vertices),fm(faces);const V*v=(V*)vm.p;const uint32_t*f=(uint32_t*)fm.p;std::ifstream in(config);V center;in>>center.x>>center.y>>center.z;struct Axis{V n;double start,step;int count;std::vector<double>area,error;};std::array<Axis,3>axes;
 for(auto&a:axes){in>>a.n.x>>a.n.y>>a.n.z>>a.start>>a.step>>a.count;a.area.resize(a.count);a.error.resize(a.count);}
 if(!in)throw std::runtime_error("Section config invalid");
 for(uint64_t i=0;i<NF;i++){
  V p[3]={v[f[3*i]]-center,v[f[3*i+1]]-center,v[f[3*i+2]]-center},N=cross(p[1]-p[0],p[2]-p[0]);
  for(auto&a:axes){double z[3]={dot(p[0],a.n),dot(p[1],a.n),dot(p[2],a.n)};int k0=std::max(0,int(std::ceil((std::min({z[0],z[1],z[2]})-a.start)/a.step))),k1=std::min(a.count-1,int(std::floor((std::max({z[0],z[1],z[2]})-a.start)/a.step)));V tangent=cross(a.n,N);
   for(int k=k0;k<=k1;k++){double s=a.start+k*a.step;V hits[3];int nh=0;for(int j=0;j<3;j++){int b=(j+1)%3;double d=z[j]-s,e=z[b]-s;if((d<0&&e>=0)||(e<0&&d>=0))hits[nh++]=p[j]+(p[b]-p[j])*(d/(d-e));}if(nh!=2)continue;double q=.5*dot(cross(hits[0],hits[1]),a.n);if(dot(hits[1]-hits[0],tangent)<0)q=-q;double y=q-a.error[k],t=a.area[k]+y;a.error[k]=(t-a.area[k])-y;a.area[k]=t;}
  }
 }
 for(int j=0;j<3;j++){auto&a=axes[j];std::ofstream out(prefix+"-axis"+std::to_string(j+1)+".csv");out.precision(17);out<<"position_mm,area_mm2\n";for(int k=0;k<a.count;k++)out<<a.start+k*a.step<<","<<a.area[k]<<"\n";}
 std::cout<<"Sectioned every "<<NF<<" native triangle along all three declared directions\n";
}
int main(int argc,char**argv){try{if(argc<2)return 2;std::string mode=argv[1];if(mode=="voxel"&&argc==4)voxel(argv[2],argv[3]);else if(mode=="surface"&&argc==5)surface(argv[2],argv[3],argv[4]);else if(mode=="sections"&&argc==6)sections(argv[2],argv[3],argv[4],argv[5]);else return 2;return 0;}catch(std::exception&e){std::cerr<<e.what()<<"\n";return 5;}}
