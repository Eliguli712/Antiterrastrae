"""Full-native geometric integration and conditional probabilistic diagnostics.

The raw 18 um data and all native triangles are immutable. Bootstrap describes
resampling stability, not acquisition accuracy. MPPCA outputs are separate,
bounded display hypotheses and never a replacement stress or anatomy field.
"""
from pathlib import Path
import argparse,csv,hashlib,json,subprocess,time
import numpy as np
from scipy.special import logsumexp
from scipy.cluster.vq import kmeans2
from scipy import ndimage
from scipy.stats import chi2
import scipy

ROOT=Path(__file__).resolve().parents[3]
O=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('--run-dir',type=Path,required=True);args=p.parse_args();RUN=args.run_dir.resolve();RUN.mkdir(exist_ok=True,parents=True)
DATA=RUN/'data';DATA.mkdir(exist_ok=True)
NV,NF=37951699,74293846;H=.018;SEED=20261124;ALPHA=5e-7
rng=np.random.default_rng(SEED)
MESH=ROOT/'output/current_native74_stress_2026-11-20/cache'
MASK=ROOT/'output/ct_web_2026-11-19/cache/selected_native_mask.u8'
RAW=ROOT/'output/ct_web_2026-11-19/cache/native_specimen_crop.i16'
def log(*x):print(time.strftime('%H:%M:%S'),*x,flush=True)
def save(p,d):p.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()

binary=RUN/'native_statistics'
subprocess.run(['c++','-O3','-std=c++17',str(O/'scripts/native_statistics.cpp'),'-o',str(binary)],check=True)
log('Integrating the entire 18 um selected-material grid')
subprocess.run([str(binary),'voxel',str(MASK),str(DATA/'voxel-blocks.u64')],check=True)
log('Integrating all 74,293,846 native surface triangles')
subprocess.run([str(binary),'surface',str(MESH/'vertices.f64'),str(MESH/'triangles.u32'),str(DATA/'surface')],check=True)

def blocks(path,dtype):
 dims=np.fromfile(path,dtype='<u4',count=4)
 assert dims[3]==10
 x=np.fromfile(path,dtype=dtype,offset=16).reshape(-1,10)
 assert len(x)==int(np.prod(dims[:3]))
 return x,dims[:3].astype(int)
voxel,vdims=blocks(DATA/'voxel-blocks.u64','<u8');vtotal=voxel.sum(0,dtype='u8');assert int(vtotal[0])==967429317
surface,sdims=blocks(DATA/'surface-blocks.f64','<f8')
total=surface.sum(0);area=float(total[0]);assert abs(area/8198.330225636142-1)<1e-6
def covariance(m):
 m=np.asarray(m,dtype='f8');s=m[...,1:4]/m[...,:1]
 q=np.zeros(m.shape[:-1]+(3,3));q[...,0,0]=m[...,4];q[...,1,1]=m[...,5];q[...,2,2]=m[...,6]
 q[...,0,1]=q[...,1,0]=m[...,7];q[...,0,2]=q[...,2,0]=m[...,8];q[...,1,2]=q[...,2,1]=m[...,9]
 return s,q/m[...,0,None,None]-s[...,:,None]*s[...,None,:]
def pca(m,voxel_grid=False):
 center,C=covariance(m)
 if voxel_grid:center=center*H+np.array([7.056,1.368,1.368]);C=C*H**2+np.eye(3)*H**2/12
 e,U=np.linalg.eigh(C);e=e[::-1];U=U[:,::-1]
 for j in range(3):
  if U[np.argmax(abs(U[:,j])),j]<0:U[:,j]*=-1
 if np.linalg.det(U)<0:U[:,2]*=-1
 return center,e,U,C
known=np.array([[0.,0.,0.],[1.,0.,0.],[0.,1.,0.],[0.,0.,1.]])
known_mom=np.array([4,1,1,1,1,1,1,0,0,0],dtype=float)
assert np.allclose(covariance(known_mom)[1],np.cov(known,rowvar=False,bias=True),atol=1e-15)
vc,ve,vaxes,vC=pca(vtotal,True);sc,se,saxes,sC=pca(total)
angles=np.rad2deg(np.arccos(np.clip(abs(np.sum(vaxes*saxes,axis=0)),0,1)))
sigma2=float(ve[-1]);W=vaxes[:,:2]*np.sqrt(np.maximum(ve[:2]-sigma2,0));ppcaC=W@W.T+sigma2*np.eye(3)
assert np.linalg.norm(ppcaC-vC)/np.linalg.norm(vC)<1e-12
log('Full-data PCA complete; surface/volume axis angles (deg)',angles.tolist())

def coarsen(b,dims,factor):
 z,y,x=np.indices(tuple(dims[::-1]));newdims=(dims+factor-1)//factor
 ids=(((z//factor)*newdims[1]+y//factor)*newdims[0]+x//factor).ravel()
 out=np.zeros((int(np.prod(newdims)),10))
 for j in range(10):out[:,j]=np.bincount(ids,weights=b[:,j],minlength=len(out))
 return out[out[:,0]>0]
def boot(b,dims,axis,grid=False,B=1500):
 rows=[]
 for factor in [1,2,4]:
  cells=coarsen(b,dims,factor);k=len(cells);prob=np.full(k,1/k)
  directions=[]
  for first in range(0,B,24):
   mult=rng.multinomial(k,prob,size=min(24,B-first));m=mult@cells
   _,C=covariance(m)
   if grid:C=C*H**2+np.eye(3)*H**2/12
   _,U=np.linalg.eigh(C);U=U[:,:,::-1]
   dot=np.abs(np.einsum('bij,ij->bj',U,axis));directions.extend(np.rad2deg(np.arccos(np.clip(dot,0,1))).tolist())
  a=np.asarray(directions);save(DATA/f'{"volume"if grid else"surface"}-bootstrap-{factor}.json',{'angles_deg':a.tolist()})
  rows.append({'block_edge_mm':.72*factor,'nonempty_blocks':k,'replicates':B,'angle_deg_Q50':np.quantile(a,.5,axis=0).tolist(),'angle_deg_Q95':np.quantile(a,.95,axis=0).tolist(),'angle_deg_Q99':np.quantile(a,.99,axis=0).tolist(),'direction_displacement_at_50mm_um_Q95':(50000*np.sin(np.deg2rad(np.quantile(a,.95,axis=0)))).tolist(),'empirical_fraction_within_1um_at_50mm':(50000*np.sin(np.deg2rad(a))<=1).mean(0).tolist(),'empirical_tail_probability_resolution':1/(B+1)})
  log('Spatial block bootstrap',('volume'if grid else'surface'),factor,'blocks',k)
 return rows
voxel_boot=boot(voxel.astype('f8'),vdims,vaxes,True)
surface_boot=boot(surface,sdims,saxes)

# Draw exact conditional area-uniform points from the complete face-area CDF.
areas=np.memmap(DATA/'surface-face-area.f64',dtype='<f8',mode='r',shape=(NF,))
cdf=np.memmap(DATA/'surface-area-cdf.f64',dtype='<f8',mode='w+',shape=(NF,));np.cumsum(areas,out=cdf);cdf.flush()
target=rng.uniform(0,float(cdf[-1]),65000);ids=np.searchsorted(cdf,target)
vertices=np.memmap(MESH/'vertices.f64',dtype='<f8',mode='r',shape=(NV,3));faces=np.memmap(MESH/'triangles.u32',dtype='<u4',mode='r',shape=(NF,3))
tri=vertices[faces[ids]];a=np.sqrt(rng.random(len(ids)));b=rng.random(len(ids));points=tri[:,0]*(1-a[:,None])+tri[:,1]*(a*(1-b))[:,None]+tri[:,2]*(a*b)[:,None]
# Whole spatial cells are held out, rather than random neighbouring vertices.
cell=np.floor((points-np.array([7.083,1.395,1.395]))/.72).astype(int);held=((cell[:,0]*73856093)^(cell[:,1]*19349663)^(cell[:,2]*83492791))%5==0
train=points[~held];test=points[held];assert len(test)>5000
def posterior(X,mu,C,pi):
 sign,ld=np.linalg.slogdet(C);assert np.all(sign>0)
 inv=np.linalg.inv(C);q=X[:,None,:]-mu[None,:,:]
 logp=np.log(pi)[None,:]-.5*(3*np.log(2*np.pi)+ld[None,:]+np.einsum('nki,kij,nkj->nk',q,inv,q))
 loglike=logsumexp(logp,axis=1);return np.exp(logp-loglike[:,None]),loglike
def fit(K):
 mu,_=kmeans2(train,K,iter=12,minit='++',rng=np.random.default_rng(SEED+K));C=np.repeat(np.eye(3)[None],K,axis=0)*np.var(train,axis=0).mean()/K**(2/3);pi=np.full(K,1/K);trace=[]
 for iteration in range(40):
  r,ll=posterior(train,mu,C,pi);trace.append(float(ll.sum()));n=r.sum(0)+1e-12;pi=n/n.sum();mu=r.T@train/n[:,None]
  for k in range(K):
   d=train-mu[k];S=(d.T*r[:,k])@d/n[k];e,U=np.linalg.eigh(S);e=np.maximum(e,H**2/12)
   # Exact q=2 PPCA maximum-likelihood covariance in three observed dimensions.
   noise=e[0];load=U[:,1:]*np.sqrt(np.maximum(e[1:]-noise,0));C[k]=load@load.T+noise*np.eye(3)
  if iteration>4 and trace[-1]-trace[-2]<max(1,abs(trace[-2]))*2e-6:break
 assert min(np.diff(trace))>-max(1,abs(trace[0]))*1e-7
 _,valid=posterior(test,mu,C,pi)
 return {'K':K,'mu':mu,'C':C,'pi':pi,'trace':trace,'heldout_mean_log_likelihood':float(valid.mean()),'training_BIC':float(-2*trace[-1]+(10*K-1)*np.log(len(train)))}
models=[]
for K in [8,16,32]:
 log('Fitting conditional MPPCA',K);models.append(fit(K))
best=max(models,key=lambda m:m['heldout_mean_log_likelihood']);r,ll=posterior(points,best['mu'],best['C'],best['pi'])
top=np.argpartition(r,-4,axis=1)[:,-4:];sparse=np.zeros_like(r);np.put_along_axis(sparse,top,np.take_along_axis(r,top,axis=1),axis=1);retained=sparse.sum(1);sparse/=retained[:,None]
estimate=np.zeros_like(points);modelcov=np.zeros((len(points),3,3))
noise=[]
for k in range(best['K']):
 e,U=np.linalg.eigh(best['C'][k]);sigma=e[0];u=U[:,1:];shrink=np.maximum(e[1:]-sigma,0)/e[1:];A=(u*shrink)@u.T
 estimate+=(best['mu'][k]+(points-best['mu'][k])@A.T)*sparse[:,k,None];noise.append(float(np.sqrt(sigma)*1000))
delta=estimate-points;length=np.linalg.norm(delta,axis=1)
# Keep a display-only displacement cap at half a native voxel. It is a declared
# regularizer, not a claim to recover the true surface at sub-voxel precision.
delta*=np.minimum(1,(H/2)/np.maximum(length,1e-30))[:,None];bounded=points+delta
np.savez_compressed(DATA/'MPPCA_conditional_surface_sample.npz',source_face_indices=ids,original_points_mm=points,posterior_mean_mm=estimate,bounded_display_points_mm=bounded,spatial_holdout=held,mixture_means_mm=best['mu'],mixture_covariances_mm2=best['C'],mixture_weights=best['pi'])
sample={'K_selected':best['K'],'latent_dimension':2,'training_points':len(train),'heldout_points':len(test),'surface_sampling':'Area-uniform points drawn from the CDF of all 74,293,846 triangle areas; exact uniform barycentric points within each selected triangle.','sparsity':'Top four posterior mixture responsibilities; not sparse coordinate loadings. Full-responsibility EM fit is retained.','models':[{'K':m['K'],'heldout_mean_log_likelihood':m['heldout_mean_log_likelihood'],'training_BIC':m['training_BIC'],'EM_log_likelihood':m['trace']}for m in models],'top4_retained_posterior_mass_mean':float(retained.mean()),'top4_retained_posterior_mass_min':float(retained.min()),'component_residual_sigma_um':noise,'bounded_displacement_um_Q50_Q95_Q99':np.quantile(np.linalg.norm(delta,axis=1)*1000,[.5,.95,.99]).tolist(),'display_displacement_cap_um':9.,'measurement_noise_identified':False,'physical_1um_accuracy_validated':False,'meaning':'Conditional piecewise-planar shape hypothesis; residual includes anatomy, curvature and segmentation error as well as possible noise. The sparse sample is not a new full-native acquisition or volume FEM.'}

# Direct oriented triangle/plane intersections include inward-oriented void
# boundaries. The maximum is over the explicitly checked 18 um plane grid.
mins=np.full(3,np.inf);maxs=-mins
for first in range(0,NV,1000000):
 q=(vertices[first:first+1000000]-vc)@vaxes;mins=np.minimum(mins,q.min(0));maxs=np.maximum(maxs,q.max(0))
config=DATA/'section_config.txt'
with config.open('w')as f:
 f.write(' '.join(format(x,'.17g')for x in vc)+'\n')
 for j in range(3):
  lo=np.floor(mins[j]/H)*H-H;count=int(np.ceil((maxs[j]-lo)/H))+2
  f.write(' '.join(format(float(x),'.17g')for x in [*vaxes[:,j],lo,H,count])+'\n')
log('Intersecting all native faces with the three principal plane sweeps')
subprocess.run([str(binary),'sections',str(MESH/'vertices.f64'),str(MESH/'triangles.u32'),str(config),str(DATA/'native-sections')],check=True)
sections=[]
mesh_volume=float((DATA/'surface-totals.txt').read_text().split()[3])
for j in range(3):
 table=np.loadtxt(DATA/f'native-sections-axis{j+1}.csv',delimiter=',',skiprows=1);assert table[:,1].min()>-1e-5
 integral=float(np.trapezoid(table[:,1],table[:,0]));assert abs(integral/mesh_volume-1)<.002
 maximum=table[np.argmax(table[:,1])]
 sections.append({'axis':j+1,'normal':vaxes[:,j].tolist(),'checked_planes':len(table),'plane_step_um':18,'maximum_on_checked_grid_area_mm2':float(maximum[1]),'plane_offset_from_centroid_mm':float(maximum[0]),'integrated_volume_mm3':integral,'mesh_volume_relative_difference':float(abs(integral/mesh_volume-1))})

# Exact acquired-grid 2D low-density diagnostics. They do not establish vascular
# identity or 3D through-connectivity of a candidate opening.
raw=np.memmap(RAW,dtype='<i2',mode='r',shape=(2886,1903,746));mask=np.memmap(MASK,dtype='u1',mode='r',shape=raw.shape)
micro=[]
for source_z in [900,1300,1500,1700,1900,2100,2300]:
 z=source_z-76;plane=np.asarray(mask[z],dtype=bool);holes=ndimage.binary_fill_holes(plane)&~plane
 labels,n=ndimage.label(holes);sizes=np.bincount(labels.ravel())[1:];objects=ndimage.find_objects(labels)
 order=np.argsort(sizes)[::-1];top=[]
 for at in order[:8]:
  box=objects[at];yy,xx=np.nonzero(labels[box]==at+1);xx=xx+box[1].start;yy=yy+box[0].start
  top.append({'pixels':int(sizes[at]),'area_mm2':float(sizes[at]*H**2),'equivalent_circle_diameter_um':float(2000*np.sqrt(sizes[at]*H**2/np.pi)),'centroid_xy_native_crop':[float(xx.mean()),float(yy.mean())],'bbox_yx':[box[0].start,box[0].stop,box[1].start,box[1].stop]})
 gray=np.asarray(raw[z],dtype='f8');air=gray[ndimage.binary_dilation(plane,iterations=6)==0]
 air=air[(air>-20000)&(air<10361.669921875)]
 mad=float(1.4826*np.median(abs(air-np.median(air)))) if len(air)else None
 micro.append({'original_DICOM_slice_index':source_z,'native_crop_index':z,'scanner_z_mm':source_z*H,'enclosed_2D_regions':int(n),'enclosed_low_density_pixels':int(holes.sum()),'regions_ge4_pixels':int((sizes>=4).sum()),'largest_regions':top,'background_MAD_raw_intensity':mad,'biological_interpretation':'Low-density candidates only; not identified as nutritive foramina or vessels.'})

native_report=json.loads((ROOT/'full_3D/ct_internal_reconstruction/native_topology_report.json').read_text())
closed_void_volume=native_report['negative_component_volume_sum_mm3'];solid_volume=native_report['signed_volume_mm3']
result={'status':'completed','assertion_tested':'Entire selected native voxel mask and every ordered native surface triangle integrated; spatial block-resampling stability measured; conditional sparse MPPCA fitted with spatial holdout; every native triangle intersected along three declared principal plane sweeps.','source_native_sampling_um':18,'native_triangles':NF,'native_vertices':NV,'material_voxels':int(vtotal[0]),'voxel_volume_mm3':float(vtotal[0]*H**3),'voxel_volume_PCA':{'center_scanner_mm':vc.tolist(),'eigenvalues_mm2':ve.tolist(),'axes_columns':vaxes.tolist(),'voxel_cell_variance_included':True},'area_uniform_surface_PCA':{'area_mm2':area,'center_scanner_mm':sc.tolist(),'eigenvalues_mm2':se.tolist(),'axes_columns':saxes.tolist(),'integration':'Exact first and second moments over each triangle, including every retained inward-oriented internal boundary.'},'surface_vs_volume_axis_angles_deg':angles.tolist(),'PPCA':{'latent_dimension':2,'isotropic_residual_variance_mm2':sigma2,'leading_principal_axes_equal_to_PCA':True,'covariance_relative_roundtrip_error':float(np.linalg.norm(ppcaC-vC)/np.linalg.norm(vC)),'residual_interpretation':'Global residual includes real tooth thickness; it cannot be identified as scan noise from these coordinates alone.'},'bootstrap':{'seed':SEED,'method':'Nonempty spatial blocks sampled with replacement, retaining each block mass/area and within-block moments; three block scales; no independent-acquisition confidence claim.','volume':voxel_boot,'surface':surface_boot},'MPPCA':sample,'principal_sections':sections,'internal_microstructure':{'retained_closed_void_components':native_report['negative_volume_components'],'mesh_closed_void_volume_mm3':closed_void_volume,'mesh_material_volume_mm3':solid_volume,'closed_void_fraction_of_closed_outer_envelope':closed_void_volume/(closed_void_volume+solid_volume),'scope':'Closed threshold-defined voids only; excludes open channels and does not establish biological composition.','native_slice_diagnostics':micro},'requested_precision':{'target_direction_displacement_um':1,'reference_lever_arm_mm':50,'target_alpha':ALPHA,'target_confidence':1-ALPHA,'achieved_or_certified':False,'empirical_bootstrap_tail_resolution':1/1501,'reason':'Bootstrap measures conditional resampling stability, not bias, scanner PSF, threshold/systematic error, or acquisition accuracy. A 1 um evaluation/output grid does not add measured information to 18 um sampling.','needed_for_validation':['PSF/MTF and geometric calibration with a traceable reference','Independent repeated or higher-resolution scans','Sensitivity to segmentation, spatial dependence and model misspecification','Explicit family-wise or simultaneous uncertainty definition']},'raw_data_overwritten':False,'stress_field_changed':False,'non_claims':['No new 1 um acquired detail or unconditional alpha=5e-7 accuracy claim.','No full native porous-volume FEM was solved by this statistical analysis.','Candidate dark regions are not histologically identified nutritive channels.','No anatomy is removed merely because a local linear model assigns a large residual.']}
save(RUN/'result.json',result)
log('NATIVE STATISTICAL COMPUTATION COMPLETE')
