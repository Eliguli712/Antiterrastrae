"""Create a fresh, immutable larger-step continuation from a verified checkpoint."""
from pathlib import Path
import json
import numpy as np

R = Path(__file__).resolve().parents[1]
src = R / 'scripts/solve_objective_10kpa_NH.py'
target = R / 'scripts/solve_objective_10kpa_NH_fast.py'
assert not target.exists()
original = R / 'data/L2_10kPa_NH'
a = np.load(original / 'checkpoint.npz')
lam, u = float(a['load_factor']), a['displacement_m']
history = json.loads((original / 'load_curve.json').read_text())
assert abs(history[-1]['load_factor'] - lam) < 1e-12
assert history[-1]['free_residual'] < 2e-7
np.savez_compressed(R / 'data/NH_fast_initial_checkpoint.npz',
                    load_factor=lam, displacement_m=u,
                    control_displacement_m=float(a['control_displacement_m']))
(R / 'data/NH_fast_initial_curve.json').write_text(json.dumps(history, indent=2))
text = src.read_text().replace("D=R/'data/L2_10kPa_NH'", "D=R/'data/L2_10kPa_NH_fast'")
text = text.replace("RUN=R/'review/run_NH_001'", "RUN=R/'review/run_NH_fast_001'")
begin = text.index('    # The StVK 1 kPa displacement')
end = text.index('    def augmented(K,M):', begin)
text = text[:begin] + '''    # Resume only displacement/load from the separately verified same-law state.
    restart=np.load(R/'data/NH_fast_initial_checkpoint.npz')
    u=restart['displacement_m'].copy();lam=float(restart['load_factor'])
    history=json.loads((R/'data/NH_fast_initial_curve.json').read_text())
    fi,W,J,_=assemble(u);initial=float(np.linalg.norm((fi-lam*f)[free])/(lam*fn))
    assert initial<2e-7 and J>.05
    total_force=float(np.linalg.norm(force.sum(0)));Lref=.1;b=f[free]/Lref
    d=float(f@u.ravel()/total_force);dstep=.012;attempts=0;accepted=0
    log({'stage':'verified_checkpoint','load_kPa':10*lam,'relative_residual':initial,'J_min':J,'control_m':d})

''' + text[end:]
text = text.replace('if peak>.020:', 'if peak>.060:').replace('factor=.019/peak', 'factor=.058/peak')
text = text.replace('if it<=6:dstep=min(.0075,dstep*1.35)', 'if it<=7:dstep=min(.020,dstep*1.4)')
text = text.replace('"""Full objective StVK at 10 kPa, unchanged fine jaw domain and dead loads.',
                    '"""Full objective logarithmic-volume neo-Hookean jaw at exact 10 kPa.')
target.write_text(text)
contract = json.loads((R / 'review/contract_NH.json').read_text())
for key in ['execution_artifacts']:
    contract[key] = [p.replace('solve_objective_10kpa_NH.py', 'solve_objective_10kpa_NH_fast.py')
                     for p in contract[key]]
for key in ['inputs']:
    contract['mathematics'][key] = [p.replace('solve_objective_10kpa_NH.py', 'solve_objective_10kpa_NH_fast.py')
                                   for p in contract['mathematics'][key]]
extra = ['output/jaw_full_stvk_2026-11-20/data/NH_fast_initial_checkpoint.npz',
         'output/jaw_full_stvk_2026-11-20/data/NH_fast_initial_curve.json']
contract['execution_artifacts'] += extra
contract['mathematics']['inputs'] += extra
contract['claim_id'] = 'OBJECTIVE_NH_10KPA_LARGER_STEP_CONTINUATION'
contract['mathematics']['conventions'] += ' Fresh run resumes a verified same-law state. Maximum work-control increment 20 mm and nodal predictor 60 mm; final exact-force residual unchanged.'
(R / 'review/contract_NH_fast.json').write_text(json.dumps(contract, indent=2))
print(json.dumps(dict(start_pressure_kPa=10*lam, max_displacement_mm=float(np.linalg.norm(u, axis=1).max()*1000))))
