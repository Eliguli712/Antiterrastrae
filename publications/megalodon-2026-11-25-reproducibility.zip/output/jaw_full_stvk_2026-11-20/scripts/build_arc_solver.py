"""Prepare a bordered work-conjugate displacement continuation, same physics."""
from pathlib import Path

R=Path(__file__).resolve().parents[1]
p=R/'scripts/solve_objective_10kpa_v4.py';s=p.read_text()
s=s.replace('minres,cg,gmres','minres,cg,gmres,LinearOperator')
s=s.replace("D=R/'data/L2_10kPa_v4'","D=R/'data/L2_10kPa_arc'").replace("RUN=R/'review/run_004'","RUN=R/'review/run_arc_001'")
s=s.replace("R/'data/L2_10kPa_v3/checkpoint.npz'","R/'data/arc_initial_checkpoint.npz'")
start=s.index('    fi,W,J,_=assemble(u);initial=');end=s.index('    # Orthogonal direct tensor/force readback',start)
block=r'''    fi,W,J,_=assemble(u);initial=np.linalg.norm((fi-start_lam*f)[free])/(start_lam*fn)
    assert initial<2e-7 and J>.05
    history=json.loads((R/'data/arc_initial_curve.json').read_text())
    lam=start_lam;total_force=float(np.linalg.norm(force.sum(0)));Lref=.1;b=f[free]/Lref
    d=float(f@u.ravel()/total_force);dstep=.0015;attempts=0;accepted=0
    log({'stage':'initial_equilibrium','load_kPa':10*lam,'relative_residual':initial,'J_min':J,'work_conjugate_displacement_m':d})

    def augmented(K,M):
        nf=len(free)
        def mv(z):return np.r_[K@z[:-1]-b*z[-1],-b@z[:-1]]
        schur=float(b@(M@b));assert schur>0
        def pm(z):return np.r_[M@z[:-1],z[-1]/schur]
        return LinearOperator((nf+1,nf+1),matvec=mv,dtype=float),LinearOperator((nf+1,nf+1),matvec=pm,dtype=float)

    while lam<1:
        attempts+=1;assert attempts<=140 and accepted<=80
        log({'stage':'displacement_trial','attempt':attempts,'starting_kPa':10*lam,'control_increment_mm':dstep*1000})
        ml=precondition(u);M=ml.aspreconditioner();_,_,_,K0=assemble(u,True);K0f=K0[free][:,free].tocsr();del K0
        A0,B0=augmented(K0f,M);rhs=np.zeros(len(free)+1);rhs[-1]=-total_force*dstep/Lref
        pred=lin(A0,rhs,B0,.01);del A0,B0,K0f
        up=np.zeros(n);up[free]=pred[:-1];up=up.reshape(-1,3);delta_lam=pred[-1]/Lref
        peak=float(np.linalg.norm(up,axis=1).max())
        if peak>.020:
            factor=.019/peak;up*=factor;delta_lam*=factor;dstep*=factor
        target_d=d+dstep;target_work=total_force*target_d
        trial=u+up;trial_lam=lam+delta_lam;converged=False
        for it in range(20):
            fi,W,J,K=assemble(trial,True);ru=(fi-trial_lam*f)[free];c=(float(f@trial.ravel())-target_work)/Lref
            residual=np.r_[ru,-c];rel=float(np.linalg.norm(ru)/(max(abs(trial_lam),.1)*fn));control_error=abs(c)*Lref/total_force
            log({'stage':'Newton_displacement','iteration':it,'load_kPa':10*trial_lam,'relative_force_residual':rel,'control_error_m':control_error,'J_min':J})
            if rel<2e-7 and control_error<1e-10 and J>.05 and trial_lam>0:
                converged=True;del K;break
            if J<=.05 or trial_lam<=0:del K;break
            Kf=K[free][:,free].tocsr();del K;Aa,Bb=augmented(Kf,M)
            forcing=min(.02,max(.0005,.05*np.sqrt(rel)))
            try:step=lin(Aa,-residual,Bb,forcing)
            except RuntimeError:del Aa,Bb,Kf;break
            del Aa,Bb,Kf
            du=np.zeros(n);du[free]=step[:-1];du=du.reshape(-1,3);dl=step[-1]/Lref
            alpha=1.;norm=float(np.linalg.norm(residual))
            for ls in range(16):
                candidate=trial+alpha*du;cl=trial_lam+alpha*dl;fc,wc,jc,_=assemble(candidate)
                rc=np.r_[(fc-cl*f)[free],-(float(f@candidate.ravel())-target_work)/Lref];nc=float(np.linalg.norm(rc))
                if jc>.05 and cl>0 and nc<=norm*(1-1e-4*alpha):break
                alpha*=.5
            else:break
            trial=candidate;trial_lam=cl
            log({'stage':'arc_line_search','alpha':alpha,'reduction':nc/norm,'load_kPa':10*cl,'J_min':jc})
            if it in [4,9,14]:
                del M,ml;gc.collect();ml=precondition(trial);M=ml.aspreconditioner()
        del M,ml;gc.collect()
        if not converged:
            dstep*=.5;log({'stage':'reject_displacement_trial','next_increment_mm':dstep*1000})
            assert dstep>=1e-6,'Work-control continuation cap reached'
            continue
        old_lam=lam;old_u=u.copy();lam=float(trial_lam);u=trial.copy();d=target_d;accepted+=1
        row=dict(load_factor=lam,traction_kPa=10*lam,method='work-conjugate displacement continuation',work_conjugate_displacement_m=d,newton_iterations=it,free_residual=rel,J_min=J,max_displacement_mm=float(np.linalg.norm(u,axis=1).max()*1000))
        history.append(row);(D/'load_curve.json').write_text(json.dumps(history,indent=2));np.savez_compressed(D/'checkpoint.npz',load_factor=lam,displacement_m=u,control_displacement_m=d)
        log({'stage':'accepted_displacement',**row})
        assert np.linalg.norm(u,axis=1).max()<.8 and d<.4,'Declared displacement extent cap'
        if it<=6:dstep=min(.0075,dstep*1.35)
        elif it>=13:dstep*=.7
        if lam>=1:
            w=(1-old_lam)/(lam-old_lam);u=(1-w)*old_u+w*u
            break

    # Return to the exact original 10 kPa dead-traction problem for final polish.
    lam=1.;ml=precondition(u);M=ml.aspreconditioner()
    for it in range(30):
        fi,W,J,K=assemble(u,True);res=(fi-f)[free];relative=float(np.linalg.norm(res)/fn)
        log({'stage':'force_polish_10kPa','iteration':it,'relative_residual':relative,'J_min':J})
        if relative<2e-7 and J>.05:del K;break
        Kf=K[free][:,free].tocsr();del K;step=lin(Kf,-res,M,min(.01,max(.0001,.05*np.sqrt(relative))));del Kf
        du=np.zeros(n);du[free]=step;du=du.reshape(-1,3);alpha=1.;norm=np.linalg.norm(res)
        for ls in range(17):
            candidate=u+alpha*du;fc,wc,jc,_=assemble(candidate)
            if jc>.05 and np.linalg.norm((fc-f)[free])<norm*(1-1e-4*alpha):break
            alpha*=.5
        else:raise RuntimeError('Final 10 kPa force polish line search failed')
        u=candidate
        if it in [4,9,14,19,24]:del M,ml;gc.collect();ml=precondition(u);M=ml.aspreconditioner()
    else:raise RuntimeError('Final exact 10 kPa force polish did not converge')
    del M,ml;gc.collect()
    history.append(dict(load_factor=1.,traction_kPa=10.,method='exact original dead-force polish',free_residual=relative,J_min=J,max_displacement_mm=float(np.linalg.norm(u,axis=1).max()*1000)))
    (D/'load_curve.json').write_text(json.dumps(history,indent=2))
    assert lam==1.
'''
s=s[:start]+block+s[end:]
(R/'scripts/solve_objective_10kpa_arc.py').write_text(s)
print('Prepared unchanged-physics work-conjugate continuation and exact-force polish.')
