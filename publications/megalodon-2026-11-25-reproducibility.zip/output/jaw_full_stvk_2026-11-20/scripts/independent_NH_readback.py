#!/usr/bin/env python3
"""Independent local readback of the log-volume neo-Hookean jaw control.

No solver/material-module imports. This is not an StVK constitutive check.
"""
from pathlib import Path
import argparse
import hashlib
import json
import time
import numpy as np


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--fields', type=Path, required=True)
    ap.add_argument('--pressure-pa', type=float, required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    start = time.monotonic()
    a = np.load(args.fields)
    p, t, u, force, fixed = [a[k] for k in
        ['points_m', 'tets', 'displacement_m', 'force_N', 'fixed_node_indices']]
    assert len(p) == 169396 and len(t) == 589700
    n = len(t)
    la, mu, eye = 150e6 * .3 / (1.3 * .4), 150e6 / 2.6, np.eye(3)
    fint = np.zeros_like(p)
    V, vm, tension, compression, jac, stretch, acoustic = [np.empty(n) for _ in range(7)]
    energy = stress_gap = stress_mass = objectivity = symmetry = 0.
    rng = np.random.default_rng(20261120)
    Q, _ = np.linalg.qr(rng.normal(size=(3, 3)))
    Q[:, 0] *= np.linalg.det(Q)
    for begin in range(0, n, 10000):
        sl = slice(begin, min(begin + 10000, n))
        cells = t[sl]
        X = p[cells[:, 1:]] - p[cells[:, :1]]
        du = u[cells[:, 1:]] - u[cells[:, :1]]
        F = eye + np.linalg.solve(X, du).transpose(0, 2, 1)
        J = np.linalg.det(F)
        assert J.min() > .05
        N = np.linalg.solve(F.transpose(0, 2, 1), np.broadcast_to(eye, F.shape))
        logJ = np.log(J)
        P = mu * F + (la * logJ - mu)[:, None, None] * N
        # Direct Cauchy form avoids calling the solver's F S F^T expression.
        sig = (mu * (F @ F.transpose(0, 2, 1) - eye)
               + la * logJ[:, None, None] * eye) / J[:, None, None]
        gradients = np.empty((len(cells), 4, 3))
        gradients[:, 1:] = np.linalg.solve(X, np.broadcast_to(eye, X.shape)).transpose(0, 2, 1)
        gradients[:, 0] = -gradients[:, 1:].sum(1)
        vol = abs(np.linalg.det(X)) / 6
        V[sl], jac[sl] = vol, J
        local = np.einsum('eij,eaj,e->eai', P, gradients, vol)
        for k in range(4):
            np.add.at(fint, cells[:, k], local[:, k])
        dev = sig - np.trace(sig, axis1=1, axis2=2)[:, None, None] * eye / 3
        vm[sl] = np.sqrt(1.5 * np.sum(dev * dev, (1, 2)))
        eigen = np.linalg.eigvalsh(sig)
        tension[sl], compression[sl] = np.maximum(eigen[:, -1], 0), np.maximum(-eigen[:, 0], 0)
        energy += float(vol @ (mu / 2 * (np.sum(F * F, (1, 2)) - 3)
                               - mu * logJ + la / 2 * logJ**2))
        singular = np.linalg.svd(F, compute_uv=False)
        stretch[sl] = singular[:, -1]
        # Q(N)=mu I+(lambda+mu-lambda log J) (F^-T N) (F^-T N)^T.
        # This lower bound is over all unit reference directions in each cell.
        coefficient = la + mu - la * logJ
        acoustic[sl] = mu + np.minimum(coefficient, 0) / singular[:, -1]**2
        stored = a['cauchy_stress_Pa'][sl]
        stress_gap += float(np.sum(vol[:, None, None] * (sig - stored)**2))
        stress_mass += float(np.sum(vol[:, None, None] * sig**2))
        symmetry = max(symmetry, float(np.max(abs(sig - sig.transpose(0, 2, 1)))))
        Fq, Nq = Q @ F, Q @ N
        Pq = mu * Fq + (la * logJ - mu)[:, None, None] * Nq
        sq = (Pq @ Fq.transpose(0, 2, 1)) / J[:, None, None]
        objectivity = max(objectivity, float(np.max(abs(Pq - Q @ P))),
                          float(np.max(abs(sq - Q @ sig @ Q.T))))
    free = np.setdiff1d(np.arange(3 * len(p)), (3 * fixed[:, None] + np.arange(3)).ravel())
    residual = fint - force
    reaction = np.zeros_like(p)
    reaction[fixed] = residual[fixed]
    free_error = float(np.linalg.norm(residual.ravel()[free]) / np.linalg.norm(force.ravel()[free]))
    net_force = float(np.linalg.norm(force.sum(0) + reaction.sum(0)) / np.linalg.norm(force.sum(0)))
    moment = float(np.linalg.norm(np.cross(p + u, force + reaction).sum(0))
                   / (np.linalg.norm(force.sum(0)) * np.ptp(p, axis=0).max()))
    ref = np.load(Path(__file__).resolve().parents[2]
                  / 'ct_fea_calibrated_2026-11-08/data/jaw_L2_full_1kPa/fields.npz')
    expected = ref['force_N'] * (args.pressure_pa / 1000)
    force_error = float(np.linalg.norm(force - expected) / np.linalg.norm(expected))
    tensor_error = float(np.sqrt(stress_gap / stress_mass))
    objective_error = objectivity / max(float(vm.max()), 1.)
    assert max(free_error, net_force, moment, force_error, tensor_error, objective_error) < 2e-6
    assert np.max(abs(u[fixed])) == 0
    def quantiles(v):
        order = np.argsort(v)
        weights = np.cumsum(V[order], dtype=np.longdouble)
        return (v[order[np.searchsorted(weights, np.array([.5, .95, .99]) * weights[-1])]] / 1e6).tolist()
    result = dict(status='passed', material='log-volume neo-Hookean, not StVK',
        fields=str(args.fields), fields_sha256=hashlib.file_digest(args.fields.open('rb'), 'sha256').hexdigest(),
        reference_pressure_Pa=args.pressure_pa, nodes=len(p), tetrahedra=n,
        independent_free_residual=free_error, force_balance=net_force,
        current_moment_balance=moment, force_assignment_relative_error=force_error,
        volume_weighted_tensor_relative_difference=tensor_error,
        rigid_superposition_relative_error=objective_error,
        cauchy_symmetry_absolute_Pa=symmetry, J_min=float(jac.min()), J_max=float(jac.max()),
        minimum_principal_stretch=float(stretch.min()),
        all_direction_sufficient_acoustic_lower_bound_Pa=float(acoustic.min()),
        cells_with_nonpositive_sufficient_bound=int((acoustic <= 0).sum()),
        local_material_interpretation='A positive bound certifies elementwise strong ellipticity at the recovered states, not global equilibrium stability or continuum convergence.',
        vm_Q50_Q95_Q99_MPa=quantiles(vm), tensile_Q50_Q95_Q99_MPa=quantiles(tension),
        compressive_Q50_Q95_Q99_MPa=quantiles(compression), peak_vm_MPa=float(vm.max() / 1e6),
        max_displacement_mm=float(np.linalg.norm(u, axis=1).max() * 1000),
        elastic_energy_J=energy, applied_force_N=force.sum(0).tolist(),
        volume_mm3=float(V.sum() * 1e9), runtime_seconds=time.monotonic() - start,
        non_claims=['No calibrated fossil jaw, impact, contact, fracture or true attachment model.',
                    'One fixed polyhedral mesh at the target pressure is not a full mesh-convergence study.'])
    args.output.write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
