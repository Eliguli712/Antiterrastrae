#!/usr/bin/env python3
"""Independent objective StVK readback with current-moment and acoustic checks."""
from pathlib import Path
import argparse,hashlib,json,time
import numpy as np

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--fields',type=Path,required=True);ap.add_argument('--pressure-pa',type=float,required=True);ap.add_argument('--output',type=Path,required=True);args=ap.parse_args()
 start=time.monotonic();a=np.load(args.fields);p=a['points_m'];t=a['tets'];u=a['displacement_m'];force=a['force_N'];fixed=a['fixed_node_indices'];n=len(t)
 assert len(p)==169396 and n==589700
 la=150e6*.3/(1.3*.4);mu=150e6/2.6;I=np.eye(3);fint=np.zeros_like(p);V=np.empty(n);vm=np.empty(n);tension=np.empty(n);compression=np.empty(n);jacs=np.empty(n);elliptic=np.empty(n);stretch_min=np.empty(n);principal_acoustic=np.empty(n)
 energy=0.;stress_gap=0.;stress_mass=0.;symmetry=0.;objectivity=[]
 rng=np.random.default_rng(20261120);Q,_=np.linalg.qr(rng.normal(size=(3,3)));Q[:,0]*=np.linalg.det(Q)
 for begin in range(0,n,10000):
  sl=slice(begin,min(begin+10000,n));cells=t[sl]
  X=p[cells[:,1:]]-p[cells[:,:1]];du=u[cells[:,1:]]-u[cells[:,:1]]
  G=np.linalg.solve(X,du).transpose(0,2,1);F=I+G;J=np.linalg.det(F);E=(F.transpose(0,2,1)@F-I)/2
  S=la*np.trace(E,axis1=1,axis2=2)[:,None,None]*I+2*mu*E;P=F@S;sig=(P@F.transpose(0,2,1))/J[:,None,None]
  gradients=np.empty((len(cells),4,3));gradients[:,1:]=np.linalg.solve(X,np.broadcast_to(I,X.shape)).transpose(0,2,1);gradients[:,0]=-gradients[:,1:].sum(1)
  vol=abs(np.linalg.det(X))/6;V[sl]=vol;jacs[sl]=J
  local=np.einsum('eij,eaj,e->eai',P,gradients,vol)
  for j in range(4):np.add.at(fint,cells[:,j],local[:,j])
  dev=sig-np.trace(sig,axis1=1,axis2=2)[:,None,None]*I/3;vm[sl]=np.sqrt(1.5*np.sum(dev*dev,(1,2)))
  eigen=np.linalg.eigvalsh(sig);tension[sl]=np.maximum(eigen[:,-1],0);compression[sl]=np.maximum(-eigen[:,0],0)
  energy+=float(vol@(.5*la*np.trace(E,axis1=1,axis2=2)**2+mu*np.sum(E*E,(1,2))))
  sv=np.linalg.svd(F,compute_uv=False);stretch_min[sl]=sv[:,-1]
  Se=np.linalg.eigvalsh(S);c=sv[:,::-1]**2
  elliptic[sl]=mu*c[:,0]+Se[:,0]
  acoustic=mu*c[:,:,None]+Se[:,None,:]+(la+mu)*np.eye(3)[None]*c[:,None,:]
  principal_acoustic[sl]=acoustic.min((1,2))
  stored=a['cauchy_stress_Pa'][sl];stress_gap+=float(np.sum(vol[:,None,None]*(sig-stored)**2));stress_mass+=float(np.sum(vol[:,None,None]*sig**2));symmetry=max(symmetry,float(np.max(abs(sig-sig.transpose(0,2,1)))))
  # One explicitly fixed rigid superposition on all recovered cells.
  Fq=Q@F;Eq=(Fq.transpose(0,2,1)@Fq-I)/2;Sq=la*np.trace(Eq,axis1=1,axis2=2)[:,None,None]*I+2*mu*Eq;Pq=Fq@Sq;sq=(Pq@Fq.transpose(0,2,1))/J[:,None,None]
  objectivity.append(float(np.max(abs(Pq-Q@P))));objectivity.append(float(np.max(abs(sq-Q@sig@Q.T))))
 free=np.setdiff1d(np.arange(3*len(p)),(3*fixed[:,None]+np.arange(3)).ravel());r=fint-force;reaction=np.zeros_like(p);reaction[fixed]=r[fixed]
 residual=float(np.linalg.norm(r.ravel()[free])/np.linalg.norm(force.ravel()[free]))
 balance=float(np.linalg.norm(force.sum(0)+reaction.sum(0))/np.linalg.norm(force.sum(0)))
 moment=float(np.linalg.norm(np.cross(p+u,force+reaction).sum(0))/(np.linalg.norm(force.sum(0))*np.ptp(p,axis=0).max()))
 q=lambda v:[float(v[np.argsort(v)[np.searchsorted(np.cumsum(V[np.argsort(v)]),x*V.sum())]])/1e6 for x in [.5,.95,.99]]
 ref=np.load(Path(__file__).resolve().parents[2]/'ct_fea_calibrated_2026-11-08/data/jaw_L2_full_1kPa/fields.npz')
 expected=ref['force_N']*(args.pressure_pa/1000);force_error=float(np.linalg.norm(force-expected)/np.linalg.norm(expected))
 max_scale=max(float(vm.max()),1.);stress_rel=float(np.sqrt(stress_gap/stress_mass));objective_rel=max(objectivity)/max_scale
 assert max(residual,balance,moment,stress_rel,force_error,objective_rel)<2e-6 and jacs.min()>.05
 assert np.max(abs(u[fixed]))==0
 result=dict(status='passed',fields=str(args.fields),fields_sha256=hashlib.file_digest(args.fields.open('rb'),'sha256').hexdigest(),reference_pressure_Pa=args.pressure_pa,nodes=len(p),tetrahedra=n,independent_free_residual=residual,force_balance=balance,current_moment_balance=moment,force_assignment_relative_error=force_error,volume_weighted_tensor_relative_difference=stress_rel,rigid_superposition_relative_error=objective_rel,cauchy_symmetry_absolute_Pa=symmetry,J_min=float(jacs.min()),J_max=float(jacs.max()),minimum_principal_stretch=float(stretch_min.min()),all_direction_sufficient_acoustic_lower_bound_Pa=float(elliptic.min()),cells_with_nonpositive_sufficient_bound=int((elliptic<=0).sum()),minimum_principal_direction_acoustic_eigenvalue_Pa=float(principal_acoustic.min()),cells_with_negative_principal_acoustic_eigenvalue=int((principal_acoustic<0).sum()),local_material_interpretation='For lambda+mu > 0, the acoustic tensor is bounded below by mu*sigma_min(F)^2+lambda_min(S). A positive value in every cell certifies elementwise strong ellipticity at this recovered state. A nonpositive sufficient bound is inconclusive, not proof of lost ellipticity. A negative principal-direction acoustic eigenvalue is a direct sampled-direction witness of loss of strong ellipticity; positive principal tests alone are insufficient. This is not a global buckling/stability test.',vm_Q50_Q95_Q99_MPa=q(vm),tensile_Q50_Q95_Q99_MPa=q(tension),compressive_Q50_Q95_Q99_MPa=q(compression),peak_vm_MPa=float(vm.max()/1e6),max_displacement_mm=float(np.linalg.norm(u,axis=1).max()*1000),elastic_energy_J=energy,applied_force_N=force.sum(0).tolist(),volume_mm3=float(V.sum()*1e9),runtime_seconds=time.monotonic()-start,non_claims=['No calibrated jaw anatomy, fossil material, time history, contact or fracture.','A stationary equilibrium and local material check do not certify global stability or continuum convergence.'])
 args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':main()
