#!/usr/bin/env python3
"""Full objective logarithmic-volume neo-Hookean jaw at exact 10 kPa.

Adaptive force continuation and residual line search. A material-tangent AMG
preconditioner changes the linear solver only, never the constitutive residual.
"""
from pathlib import Path
import gc,json,sys,time
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import minres,cg,gmres,LinearOperator

R=Path(__file__).resolve().parents[1];P=R.parents[1]
OLD=P/'output/ct_fea_calibrated_2026-11-08'
sys.path.insert(0,str(OLD/'scripts'));sys.path.insert(0,str(OLD/'runtime'))
import pyamg
import neo_hookean_material as law

D=R/'data/L2_10kPa_NH_energy';D.mkdir(parents=True,exist_ok=True)
RUN=R/'review/run_NH_energy_001'
I=np.eye(3);LA=150e6*.3/(1.3*.4);MU=150e6/2.6
started=time.monotonic();np.random.seed(20261120)

def log(row):
    row={'elapsed_seconds':round(time.monotonic()-started,3),**row}
    with (D/'progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
    print(json.dumps(row),flush=True)

def main():
    assert not (D/'results.json').exists(),'Preserve previous result; use a new immutable run name.'
    a=np.load(OLD/'data/jaw_L2_full_1kPa/fields.npz')
    p=a['points_m'];t=a['tets'];fixed=a['fixed_node_indices'];force=a['force_N']*10
    u=a['displacement_m'].copy();start_lam=.1;linear=a['linear_displacement_m']*10
    assert len(t)==589700 and len(p)==169396
    mesh=np.load(OLD/'review/mesh_run_001/jaw_L2.npz')
    np.testing.assert_allclose(p,mesh['points_mm']*.001,rtol=0,atol=0)
    np.testing.assert_array_equal(t,mesh['tets'])
    E=p[t[:,1:]]-p[t[:,:1]];inverse=np.linalg.inv(E);g=np.empty((len(t),4,3));g[:,1:]=inverse.transpose(0,2,1);g[:,0]=-g[:,1:].sum(1)
    V=abs(np.linalg.det(E))/6;assert V.min()>1e-24
    dof=(3*t[:,:,None]+np.arange(3)).reshape(-1,12).astype(np.int32)
    rr=np.repeat(dof,12,axis=1).ravel();cc=np.tile(dof,(1,12)).ravel()
    n=3*len(p);free=np.setdiff1d(np.arange(n),(3*fixed[:,None]+np.arange(3)).ravel());f=force.ravel();fn=np.linalg.norm(f[free])
    all_nl=np.ones(len(t),bool)
    checks=law.selfcheck();log({'stage':'law_selfcheck','checks':checks})

    def assemble(u,stiff=False,material=False):
        fi=np.zeros(n);values=np.empty(len(t)*144) if stiff else None;W=0.;Jmin=np.inf
        for start in range(0,len(t),5000):
            sl=slice(start,min(start+5000,len(t)));gg=g[sl]
            G=np.einsum('eai,eaj->eij',u[t[sl,1:]]-u[t[sl,:1]],gg[:,1:]);F=I+G
            PP,S,w,green=law.tensor(F,LA,MU,all_nl[sl],G=G)
            Jmin=min(Jmin,float(np.linalg.det(F).min()));W+=float(V[sl]@w)
            fint=np.einsum('eij,eaj,e->eai',PP,gg,V[sl]);np.add.at(fi,dof[sl].ravel(),fint.ravel())
            if stiff:
                A=law.tangent(F,S,LA,MU,all_nl[sl])
                if material:A-=np.einsum('ik,elj->eijkl',I,S)
                ke=np.einsum('eijkl,eaj,ebl,e->eaibk',A,gg,gg,V[sl],optimize=True).reshape(-1,12,12)
                values[start*144:sl.stop*144]=ke.ravel()
        K=coo_matrix((values,(rr,cc)),shape=(n,n)).tocsr() if stiff else None
        return fi,W,Jmin,K

    def precondition(u):
        _,_,_,Km=assemble(u,True,True)
        cur=p+u;cur=(cur-cur.mean(0))/np.ptp(cur,axis=0).max()
        modes=np.zeros((len(p),3,6));modes[:,:,:3]=I
        for j in range(3):modes[:,:,j+3]=np.cross(I[j],cur)
        Af=Km[free][:,free].tobsr(blocksize=(3,3));del Km
        ml=pyamg.smoothed_aggregation_solver(Af,B=modes.reshape(n,6)[free],symmetry='symmetric',presmoother=('block_gauss_seidel',{'sweep':'symmetric'}),postsmoother=('block_gauss_seidel',{'sweep':'symmetric'}),max_coarse=250,max_levels=12)
        log({'stage':'preconditioner','levels':len(ml.levels),'operator_complexity':float(ml.operator_complexity())})
        return ml

    def lin(K,rhs,M,tolerance):
        count=[0]
        def cb(_):count[0]+=1
        step,status=gmres(K,rhs,M=M,rtol=tolerance,atol=0,restart=80,maxiter=25,callback=cb,callback_type='pr_norm')
        true=float(np.linalg.norm(K@step-rhs)/np.linalg.norm(rhs))
        log({'stage':'linear_solve','iterations':count[0],'true_relative_residual':true,'requested':tolerance,'status':int(status)})
        if not np.isfinite(step).all() or true>max(.02,tolerance*1.1):raise RuntimeError('Unresolved Newton linear system')
        return step

    # A separate fixed-load route. Continuation is not physical time.
    checkpoint=np.load(R/'data/NH_energy_initial_checkpoint.npz')
    u=checkpoint['displacement_m'].copy();history=[]
    # Smooth initial-guess perturbation only; geometry, material and all loads stay fixed.
    y=(p[:,1]-p[:,1].min())/np.ptp(p[:,1]);xx=(p[:,0]-p[:,0].min())/np.ptp(p[:,0])
    u[:,2]+=1e-5*y*np.sin(np.pi*xx);u[fixed]=0
    ml0=precondition(np.zeros_like(u));M0=ml0.aspreconditioner()
    fi,W,J,_=assemble(u);gradient=(fi-f)[free];potential=W-f@u.ravel()
    pairs=[];total_force=float(np.linalg.norm(force.sum(0)))
    for iteration in range(650):
        rel=float(np.linalg.norm(gradient)/fn)
        log({'stage':'fixed_10kPa_energy_minimisation','iteration':iteration,'potential_J':potential,'relative_force_residual':rel,'J_min':J})
        if rel<.002:break
        z=gradient.copy();alphas=[]
        for ss,yy,rho in reversed(pairs):
            alpha=rho*float(ss@z);alphas.append(alpha);z-=alpha*yy
        direction=M0@z
        for (ss,yy,rho),alpha in zip(pairs,reversed(alphas)):
            beta=rho*float(yy@direction);direction+=ss*(alpha-beta)
        direction=-direction;descent=float(gradient@direction)
        if descent>=0 or not np.isfinite(direction).all():
            pairs=[];direction=-(M0@gradient);descent=float(gradient@direction)
        assert descent<0
        du=np.zeros(n);du[free]=direction;du=du.reshape(-1,3)
        peak=float(np.linalg.norm(du,axis=1).max());step=min(1.,.04/max(peak,1e-30))
        for ls in range(23):
            candidate=u+step*du;fc,wc,jc,_=assemble(candidate);pc=wc-f@candidate.ravel()
            if jc>.05 and np.isfinite(pc) and pc<=potential+1e-4*step*descent:break
            step*=.5
        else:raise RuntimeError('Fixed-load energy line search exhausted')
        gcnew=(fc-f)[free];ss=step*direction;yy=gcnew-gradient;curvature=float(ss@yy)
        if curvature>1e-10*np.linalg.norm(ss)*np.linalg.norm(yy):
            pairs.append((ss,yy,1/curvature));pairs=pairs[-14:]
        else:pairs=[]
        u=candidate;gradient=gcnew;potential=float(pc);W=wc;J=jc
        assert np.linalg.norm(u,axis=1).max()<.9,'Declared displacement extent cap'
        if iteration%20==0:
            np.savez_compressed(D/'energy_checkpoint.npz',displacement_m=u,relative_residual=float(np.linalg.norm(gradient)/fn),J_min=J,potential_J=potential)
    else:raise RuntimeError('Fixed-load energy iteration cap reached before Newton handoff')
    log({'stage':'energy_to_Newton_handoff','relative_residual':rel,'J_min':J,'potential_J':potential})
    del M0,ml0,pairs;gc.collect()

    # Return to the exact original 10 kPa dead-traction problem for final polish.
    lam=1.;ml=precondition(u);M=ml.aspreconditioner()
    for it in range(45):
        fi,W,J,K=assemble(u,True);res=(fi-f)[free];relative=float(np.linalg.norm(res)/fn)
        log({'stage':'force_polish_10kPa','iteration':it,'relative_residual':relative,'J_min':J})
        if relative<2e-7 and J>.05:del K;break
        Kf=K[free][:,free].tocsr();del K;step=lin(Kf,-res,M,min(.01,max(.0001,.05*np.sqrt(relative))));del Kf
        du=np.zeros(n);du[free]=step;du=du.reshape(-1,3);alpha=1.;norm=np.linalg.norm(res)
        for ls in range(17):
            candidate=u+alpha*du;fc,wc,jc,_=assemble(candidate)
            if jc>.05 and np.linalg.norm((fc-f)[free])<norm*(1-1e-4*alpha):break
            alpha*=.5
        else:raise RuntimeError('Final 10 kPa force polish line search failed')
        u=candidate
        if it in [4,9,14,19,24,29,34,39]:del M,ml;gc.collect();ml=precondition(u);M=ml.aspreconditioner()
    else:raise RuntimeError('Final exact 10 kPa force polish did not converge')
    del M,ml;gc.collect()
    history.append(dict(load_factor=1.,traction_kPa=10.,method='exact original dead-force polish',free_residual=relative,J_min=J,max_displacement_mm=float(np.linalg.norm(u,axis=1).max()*1000)))
    (D/'load_curve.json').write_text(json.dumps(history,indent=2))
    assert lam==1.
    # Orthogonal direct tensor/force readback, without calling constitutive helpers.
    G=np.einsum('eai,eaj->eij',u[t[:,1:]]-u[t[:,:1]],g[:,1:]);F=I+G
    green=(F.transpose(0,2,1)@F-I)/2
    J=np.linalg.det(F);N=np.linalg.inv(F).transpose(0,2,1);coef=LA*np.log(J)-MU
    PP=MU*F+coef[:,None,None]*N;sigma=(MU*(F@F.transpose(0,2,1)-I)+LA*np.log(J)[:,None,None]*I)/J[:,None,None]
    dev=sigma-np.trace(sigma,axis1=1,axis2=2)[:,None,None]*I/3;vm=np.sqrt(1.5*np.sum(dev*dev,(1,2)))
    strain_dev=green-np.trace(green,axis1=1,axis2=2)[:,None,None]*I/3;eq=np.sqrt(2/3*np.sum(strain_dev*strain_dev,(1,2)))
    fint=np.zeros_like(p)
    local=np.einsum('eij,eaj,e->eai',PP,g,V)
    for j in range(4):np.add.at(fint,t[:,j],local[:,j])
    residual=fint-force;readback=float(np.linalg.norm(residual.ravel()[free])/fn)
    reaction=np.zeros_like(p);reaction[fixed]=residual[fixed]
    balance=float(np.linalg.norm(reaction.sum(0)+force.sum(0))/np.linalg.norm(force.sum(0)))
    moment=float(np.linalg.norm(np.cross(p+u,force+reaction).sum(0))/(np.linalg.norm(force.sum(0))*np.ptp(p,axis=0).max()))
    symmetry=float(np.linalg.norm(sigma-sigma.transpose(0,2,1))/np.linalg.norm(sigma))
    W=.5*MU*(np.sum(F*F,(1,2))-3)-MU*np.log(J)+.5*LA*np.log(J)**2
    order=np.argsort(vm);q=vm[order[np.searchsorted(np.cumsum(V[order]),np.array([.5,.95,.99])*V.sum())]]/1e6
    assert max(readback,balance,moment,symmetry)<2e-6 and J.min()>.05
    np.savez_compressed(D/'fields.npz',points_m=p,tets=t,displacement_m=u,linear_displacement_m=linear,volumes_m3=V,von_mises_Pa=vm,cauchy_stress_Pa=sigma,green_strain=green,equivalent_strain=eq,J=J,fixed_node_indices=fixed,force_N=force)
    result=dict(status='verified_stationary_equilibrium',model='Full objective logarithmic-volume neo-Hookean on unchanged fine L2 white-shark reference; no contact',reference_traction_Pa=[0,-10000,0],E_Pa=150e6,nu=.3,nodes=len(p),tetrahedra=len(t),source_scale='Original model unit assumed mm; no anatomical calibration',all_material_cells_neo_Hookean=True,load_steps=history,independent_free_residual=readback,force_balance=balance,current_moment_balance=moment,cauchy_symmetry=symmetry,J_min=float(J.min()),J_max=float(J.max()),Q50_Q95_Q99_MPa=q.tolist(),peak_MPa=float(vm.max()/1e6),max_displacement_mm=float(np.linalg.norm(u,axis=1).max()*1000),elastic_energy_J=float(V@W),max_equivalent_strain=float(eq.max()),non_claims=['No calibrated fossil bite, contact impact or fracture law.','Stationary equilibrium alone does not establish stability, continuum convergence or constitutive calibration at large deformation.'],runtime_seconds=time.monotonic()-started,selfcheck=checks)
    (D/'results.json').write_text(json.dumps(result,indent=2));(RUN/'results.json').write_text(json.dumps(result,indent=2));log({'stage':'VERIFIED_10_KPA','summary':result})

if __name__=='__main__':main()
