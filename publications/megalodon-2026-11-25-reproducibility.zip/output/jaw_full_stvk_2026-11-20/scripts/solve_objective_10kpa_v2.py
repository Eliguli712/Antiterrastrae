#!/usr/bin/env python3
"""Full objective StVK at 10 kPa, unchanged fine jaw domain and dead loads.

Adaptive force continuation and residual line search. A material-tangent AMG
preconditioner changes the linear solver only, never the constitutive residual.
"""
from pathlib import Path
import gc,json,sys,time
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import minres,cg,gmres

R=Path(__file__).resolve().parents[1];P=R.parents[1]
OLD=P/'output/ct_fea_calibrated_2026-11-08'
sys.path.insert(0,str(OLD/'scripts'));sys.path.insert(0,str(OLD/'runtime'))
import pyamg
import finite_strain_material as law

D=R/'data/L2_10kPa_v2';D.mkdir(parents=True,exist_ok=True)
RUN=R/'review/run_002'
I=np.eye(3);LA=150e6*.3/(1.3*.4);MU=150e6/2.6
started=time.monotonic();np.random.seed(20261120)

def log(row):
    row={'elapsed_seconds':round(time.monotonic()-started,3),**row}
    with (D/'progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
    print(json.dumps(row),flush=True)

def main():
    assert not (D/'results.json').exists(),'Preserve previous result; use a new immutable run name.'
    a=np.load(OLD/'data/jaw_L2_full_1kPa/fields.npz')
    p=a['points_m'];t=a['tets'];fixed=a['fixed_node_indices'];force=a['force_N']*10
    u=a['displacement_m'].copy();linear=a['linear_displacement_m']*10
    assert len(t)==589700 and len(p)==169396
    mesh=np.load(OLD/'review/mesh_run_001/jaw_L2.npz')
    np.testing.assert_allclose(p,mesh['points_mm']*.001,rtol=0,atol=0)
    np.testing.assert_array_equal(t,mesh['tets'])
    E=p[t[:,1:]]-p[t[:,:1]];inverse=np.linalg.inv(E);g=np.empty((len(t),4,3));g[:,1:]=inverse.transpose(0,2,1);g[:,0]=-g[:,1:].sum(1)
    V=abs(np.linalg.det(E))/6;assert V.min()>1e-24
    dof=(3*t[:,:,None]+np.arange(3)).reshape(-1,12).astype(np.int32)
    rr=np.repeat(dof,12,axis=1).ravel();cc=np.tile(dof,(1,12)).ravel()
    n=3*len(p);free=np.setdiff1d(np.arange(n),(3*fixed[:,None]+np.arange(3)).ravel());f=force.ravel();fn=np.linalg.norm(f[free])
    all_nl=np.ones(len(t),bool)
    checks=law.selfcheck();log({'stage':'law_selfcheck','checks':checks})

    def assemble(u,stiff=False,material=False):
        fi=np.zeros(n);values=np.empty(len(t)*144) if stiff else None;W=0.;Jmin=np.inf
        for start in range(0,len(t),5000):
            sl=slice(start,min(start+5000,len(t)));gg=g[sl]
            G=np.einsum('eai,eaj->eij',u[t[sl,1:]]-u[t[sl,:1]],gg[:,1:]);F=I+G
            PP,S,w,green=law.tensor(F,LA,MU,all_nl[sl],G=G)
            Jmin=min(Jmin,float(np.linalg.det(F).min()));W+=float(V[sl]@w)
            fint=np.einsum('eij,eaj,e->eai',PP,gg,V[sl]);np.add.at(fi,dof[sl].ravel(),fint.ravel())
            if stiff:
                A=law.tangent(F,S,LA,MU,all_nl[sl])
                if material:A-=np.einsum('ik,elj->eijkl',I,S)
                ke=np.einsum('eijkl,eaj,ebl,e->eaibk',A,gg,gg,V[sl],optimize=True).reshape(-1,12,12)
                values[start*144:sl.stop*144]=ke.ravel()
        K=coo_matrix((values,(rr,cc)),shape=(n,n)).tocsr() if stiff else None
        return fi,W,Jmin,K

    def precondition(u):
        _,_,_,Km=assemble(u,True,True)
        cur=p+u;cur=(cur-cur.mean(0))/np.ptp(cur,axis=0).max()
        modes=np.zeros((len(p),3,6));modes[:,:,:3]=I
        for j in range(3):modes[:,:,j+3]=np.cross(I[j],cur)
        Af=Km[free][:,free].tobsr(blocksize=(3,3));del Km
        ml=pyamg.smoothed_aggregation_solver(Af,B=modes.reshape(n,6)[free],symmetry='symmetric',presmoother=('block_gauss_seidel',{'sweep':'symmetric'}),postsmoother=('block_gauss_seidel',{'sweep':'symmetric'}),max_coarse=250,max_levels=12)
        log({'stage':'preconditioner','levels':len(ml.levels),'operator_complexity':float(ml.operator_complexity())})
        return ml

    def lin(K,rhs,M,tolerance):
        count=[0]
        def cb(_):count[0]+=1
        step,status=gmres(K,rhs,M=M,rtol=tolerance,atol=0,restart=80,maxiter=25,callback=cb,callback_type='pr_norm')
        true=float(np.linalg.norm(K@step-rhs)/np.linalg.norm(rhs))
        log({'stage':'linear_solve','iterations':count[0],'true_relative_residual':true,'requested':tolerance,'status':int(status)})
        if not np.isfinite(step).all() or true>max(.02,tolerance*1.1):raise RuntimeError('Unresolved Newton linear system')
        return step

    fi,W,J,_=assemble(u);initial=np.linalg.norm((fi-.1*f)[free])/(.1*fn)
    assert initial<2e-7 and J>.05,(initial,J)
    log({'stage':'initial_equilibrium','load_kPa':1.,'relative_residual':initial,'J_min':J})
    lam=.1;previous_lam=0.;previous_u=np.zeros_like(u);increment=.01
    history=[dict(load_factor=lam,traction_kPa=1.,free_residual=initial,J_min=J,max_displacement_mm=float(np.linalg.norm(u,axis=1).max()*1000))]
    accepted=0;attempts=0
    while lam<1-1e-12:
        attempts+=1;assert attempts<=140,'Continuation attempt cap'
        target=min(1.,lam+increment)
        log({'stage':'load_trial','load_kPa':10*target,'increment_kPa':10*(target-lam),'attempt':attempts})
        ml=precondition(u);M=ml.aspreconditioner()
        _,_,_,Kbase=assemble(u,True)
        Kbasef=Kbase[free][:,free].tocsr();del Kbase
        predictor=lin(Kbasef,(target-lam)*f[free],M,.003);del Kbasef
        du_predict=np.zeros(n);du_predict[free]=predictor;du_predict=du_predict.reshape(-1,3)
        if np.linalg.norm(du_predict,axis=1).max()>.025:
            del M,ml;increment*=.5
            assert increment>=.0001,'Load control cannot resolve a limit point within declared cap'
            continue
        trial=u+du_predict;trial[fixed]=0
        converged=False
        for it in range(22):
            fi,W,J,K=assemble(trial,True);r=(fi-target*f)[free];relative=float(np.linalg.norm(r)/(target*fn))
            log({'stage':'Newton','load_kPa':target*10,'iteration':it,'relative_residual':relative,'J_min':J})
            if relative<2e-7 and J>.05:converged=True;del K;break
            if J<=.05 or not np.isfinite(relative):del K;break
            Kf=K[free][:,free].tocsr();del K;gc.collect()
            forcing=min(.03,max(1e-5,.1*np.sqrt(relative)))
            try:step=lin(Kf,-r,M,forcing)
            except RuntimeError:del Kf;break
            del Kf
            du=np.zeros(n);du[free]=step;du=du.reshape(-1,3)
            alpha=1.;norm=np.linalg.norm(r);potential=W-target*float(f@trial.ravel());slope=float(r@step)
            for ls in range(15):
                candidate=trial+alpha*du;fc,wc,jc,_=assemble(candidate)
                nc=np.linalg.norm((fc-target*f)[free])
                new_potential=wc-target*float(f@candidate.ravel())
                energy_descent=slope<0 and new_potential<=potential+1e-4*alpha*slope+64*np.finfo(float).eps*max(abs(potential),abs(wc),1e-20)
                if jc>.05 and (nc<=norm*(1-1e-4*alpha) or energy_descent):break
                alpha*=.5
            else:
                log({'stage':'residual_line_search_failed','load_kPa':target*10,'iteration':it});break
            trial=candidate
            log({'stage':'line_search','alpha':alpha,'trial_J_min':jc,'residual_reduction':float(nc/norm)})
            if it in [5,11,17] or alpha<.125:
                del M,ml;gc.collect();ml=precondition(trial);M=ml.aspreconditioner()
            last_rel=relative
        del ml,M;gc.collect()
        if not converged:
            increment*=.5
            log({'stage':'reject_load','last_accepted_kPa':lam*10,'next_increment_kPa':increment*10})
            if increment<.0001:
                np.save(D/'last_accepted_displacement.npy',u)
                raise RuntimeError('Force-control continuation reached its declared minimum step; no verified 10 kPa result')
            continue
        previous_lam,previous_u=lam,u.copy();lam=target;u=trial.copy();accepted+=1
        row=dict(load_factor=lam,traction_kPa=lam*10,newton_iterations=it,free_residual=relative,J_min=J,max_displacement_mm=float(np.linalg.norm(u,axis=1).max()*1000))
        history.append(row);(D/'load_curve.json').write_text(json.dumps(history,indent=2))
        np.savez_compressed(D/'checkpoint.npz',load_factor=lam,displacement_m=u,previous_load_factor=previous_lam,previous_displacement_m=previous_u)
        log({'stage':'accepted',**row})
        if it<=4:increment=min(.10,increment*1.5)
        elif it>=12:increment=max(.0001,increment*.65)
    assert lam==1.
    # Orthogonal direct tensor/force readback, without calling constitutive helpers.
    G=np.einsum('eai,eaj->eij',u[t[:,1:]]-u[t[:,:1]],g[:,1:]);F=I+G
    green=(F.transpose(0,2,1)@F-I)/2
    S=LA*np.trace(green,axis1=1,axis2=2)[:,None,None]*I+2*MU*green
    PP=F@S;J=np.linalg.det(F);sigma=(PP@F.transpose(0,2,1))/J[:,None,None]
    dev=sigma-np.trace(sigma,axis1=1,axis2=2)[:,None,None]*I/3;vm=np.sqrt(1.5*np.sum(dev*dev,(1,2)))
    strain_dev=green-np.trace(green,axis1=1,axis2=2)[:,None,None]*I/3;eq=np.sqrt(2/3*np.sum(strain_dev*strain_dev,(1,2)))
    fint=np.zeros_like(p)
    local=np.einsum('eij,eaj,e->eai',PP,g,V)
    for j in range(4):np.add.at(fint,t[:,j],local[:,j])
    residual=fint-force;readback=float(np.linalg.norm(residual.ravel()[free])/fn)
    reaction=np.zeros_like(p);reaction[fixed]=residual[fixed]
    balance=float(np.linalg.norm(reaction.sum(0)+force.sum(0))/np.linalg.norm(force.sum(0)))
    moment=float(np.linalg.norm(np.cross(p+u,force+reaction).sum(0))/(np.linalg.norm(force.sum(0))*np.ptp(p,axis=0).max()))
    symmetry=float(np.linalg.norm(sigma-sigma.transpose(0,2,1))/np.linalg.norm(sigma))
    W=.5*LA*np.trace(green,axis1=1,axis2=2)**2+MU*np.sum(green*green,(1,2))
    order=np.argsort(vm);q=vm[order[np.searchsorted(np.cumsum(V[order]),np.array([.5,.95,.99])*V.sum())]]/1e6
    assert max(readback,balance,moment,symmetry)<2e-6 and J.min()>.05
    np.savez_compressed(D/'fields.npz',points_m=p,tets=t,displacement_m=u,linear_displacement_m=linear,volumes_m3=V,von_mises_Pa=vm,cauchy_stress_Pa=sigma,green_strain=green,equivalent_strain=eq,J=J,fixed_node_indices=fixed,force_N=force)
    result=dict(status='verified_stationary_equilibrium',model='Full objective StVK on unchanged fine L2 white-shark reference; no contact',reference_traction_Pa=[0,-10000,0],E_Pa=150e6,nu=.3,nodes=len(p),tetrahedra=len(t),source_scale='Original model unit assumed mm; no anatomical calibration',all_material_cells_StVK=True,load_steps=history,independent_free_residual=readback,force_balance=balance,current_moment_balance=moment,cauchy_symmetry=symmetry,J_min=float(J.min()),J_max=float(J.max()),Q50_Q95_Q99_MPa=q.tolist(),peak_MPa=float(vm.max()/1e6),max_displacement_mm=float(np.linalg.norm(u,axis=1).max()*1000),elastic_energy_J=float(V@W),max_equivalent_strain=float(eq.max()),non_claims=['No calibrated fossil bite, contact impact or fracture law.','Stationary equilibrium alone does not establish stability, continuum convergence or validity of StVK at large compression.'],runtime_seconds=time.monotonic()-started,selfcheck=checks)
    (D/'results.json').write_text(json.dumps(result,indent=2));(RUN/'results.json').write_text(json.dumps(result,indent=2));log({'stage':'VERIFIED_10_KPA','summary':result})

if __name__=='__main__':main()
