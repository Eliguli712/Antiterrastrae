"""Objective logarithmic-volume neo-Hookean law with matched Lamé tangent.

W = mu/2*(tr(F^T F)-3) - mu*log J + lambda/2*(log J)^2.
The model is a separate constitutive control, never an StVK alias.
"""
import numpy as np
I=np.eye(3)

def inverse_transpose(F):
 J=np.linalg.det(F);valid=J>1e-12;N=np.full_like(F,np.nan)
 N[valid]=np.linalg.inv(F[valid]).transpose(0,2,1)
 logJ=np.full(len(F),np.nan);logJ[valid]=np.log(J[valid])
 return J,N,logJ

def tensor(F,lam,mu,nonlinear,G=None):
 assert np.all(nonlinear),'This comparison uses the nonlinear law in every cell.'
 J,N,l=inverse_transpose(F);coef=lam*l-mu
 P=mu*F+coef[:,None,None]*N
 S=mu*I+coef[:,None,None]*(N.transpose(0,2,1)@N)
 W=mu/2*(np.sum(F*F,(1,2))-3)-mu*l+lam/2*l*l
 E=(F.transpose(0,2,1)@F-I)/2
 return P,S,W,E

def tangent(F,S,lam,mu,nonlinear):
 assert np.all(nonlinear)
 J,N,l=inverse_transpose(F);coef=lam*l-mu
 return mu*np.einsum('ik,jl->ijkl',I,I)[None]+lam*np.einsum('eij,ekl->eijkl',N,N)-coef[:,None,None,None,None]*np.einsum('eil,ekj->eijkl',N,N)

def selfcheck():
 rng=np.random.default_rng(712);F=I+rng.normal(0,.04,(6,3,3));mask=np.ones(len(F),bool);la=2.;mu=3.;H=rng.normal(size=F.shape);h=1e-6
 p,s,w,e=tensor(F,la,mu,mask);A=tangent(F,s,la,mu,mask)
 pp=tensor(F+h*H,la,mu,mask);pm=tensor(F-h*H,la,mu,mask)
 numeric=(pp[0]-pm[0])/(2*h);analytic=np.einsum('eijkl,ekl->eij',A,H)
 relative=float(np.linalg.norm(numeric-analytic)/np.linalg.norm(numeric));assert relative<1e-8
 np.testing.assert_allclose((pp[2]-pm[2])/(2*h),np.einsum('eij,eij->e',p,H),rtol=1e-7,atol=1e-8)
 Q,_=np.linalg.qr(rng.normal(size=(3,3)));Q[:,0]*=np.linalg.det(Q)
 np.testing.assert_allclose(tensor(Q@F,la,mu,mask)[0],Q@p,rtol=1e-12,atol=1e-12)
 A0=tangent(I[None],np.zeros((1,3,3)),la,mu,np.ones(1,bool))[0]
 expected=la*np.einsum('ij,kl->ijkl',I,I)+mu*np.einsum('ik,jl->ijkl',I,I)+mu*np.einsum('il,jk->ijkl',I,I)
 np.testing.assert_allclose(A0,expected,rtol=0,atol=1e-14)
 return dict(model='Full logarithmic-volume neo-Hookean, separate from StVK',consistent_tangent_relative_error=relative,energy_gradient=True,rigid_superposition=True,matched_linear_Lame_tangent=True)
