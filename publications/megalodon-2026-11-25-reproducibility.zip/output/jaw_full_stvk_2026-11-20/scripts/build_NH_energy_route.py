"""Prepare a separate exact-load energy-minimisation route, without changing the BVP."""
from pathlib import Path
import json
import numpy as np

R = Path(__file__).resolve().parents[1]
target = R / 'scripts/solve_objective_10kpa_NH_energy.py'
assert not target.exists()
path = R / 'data/L2_10kPa_NH_fast'
a = np.load(path / 'checkpoint.npz')
h = json.loads((path / 'load_curve.json').read_text())
assert abs(float(a['load_factor']) - h[-1]['load_factor']) < 1e-12
assert h[-1]['free_residual'] < 2e-7
np.savez_compressed(R / 'data/NH_energy_initial_checkpoint.npz', **{k: a[k] for k in a.files})
(R / 'data/NH_energy_initial_curve.json').write_text(json.dumps(h, indent=2))
s = (R / 'scripts/solve_objective_10kpa_NH_fast.py').read_text()
s = s.replace("D=R/'data/L2_10kPa_NH_fast'", "D=R/'data/L2_10kPa_NH_energy'")
s = s.replace("RUN=R/'review/run_NH_fast_001'", "RUN=R/'review/run_NH_energy_001'")
begin = s.index('    # Resume only displacement/load')
end = s.index('    # Return to the exact original 10 kPa', begin)
s = s[:begin] + '''    # A separate fixed-load route. Continuation is not physical time.
    checkpoint=np.load(R/'data/NH_energy_initial_checkpoint.npz')
    u=checkpoint['displacement_m'].copy();history=[]
    # Smooth initial-guess perturbation only; geometry, material and all loads stay fixed.
    y=(p[:,1]-p[:,1].min())/np.ptp(p[:,1]);xx=(p[:,0]-p[:,0].min())/np.ptp(p[:,0])
    u[:,2]+=1e-5*y*np.sin(np.pi*xx);u[fixed]=0
    ml0=precondition(np.zeros_like(u));M0=ml0.aspreconditioner()
    fi,W,J,_=assemble(u);gradient=(fi-f)[free];potential=W-f@u.ravel()
    pairs=[];total_force=float(np.linalg.norm(force.sum(0)))
    for iteration in range(650):
        rel=float(np.linalg.norm(gradient)/fn)
        log({'stage':'fixed_10kPa_energy_minimisation','iteration':iteration,'potential_J':potential,'relative_force_residual':rel,'J_min':J})
        if rel<.002:break
        z=gradient.copy();alphas=[]
        for ss,yy,rho in reversed(pairs):
            alpha=rho*float(ss@z);alphas.append(alpha);z-=alpha*yy
        direction=M0@z
        for (ss,yy,rho),alpha in zip(pairs,reversed(alphas)):
            beta=rho*float(yy@direction);direction+=ss*(alpha-beta)
        direction=-direction;descent=float(gradient@direction)
        if descent>=0 or not np.isfinite(direction).all():
            pairs=[];direction=-(M0@gradient);descent=float(gradient@direction)
        assert descent<0
        du=np.zeros(n);du[free]=direction;du=du.reshape(-1,3)
        peak=float(np.linalg.norm(du,axis=1).max());step=min(1.,.04/max(peak,1e-30))
        for ls in range(23):
            candidate=u+step*du;fc,wc,jc,_=assemble(candidate);pc=wc-f@candidate.ravel()
            if jc>.05 and np.isfinite(pc) and pc<=potential+1e-4*step*descent:break
            step*=.5
        else:raise RuntimeError('Fixed-load energy line search exhausted')
        gcnew=(fc-f)[free];ss=step*direction;yy=gcnew-gradient;curvature=float(ss@yy)
        if curvature>1e-10*np.linalg.norm(ss)*np.linalg.norm(yy):
            pairs.append((ss,yy,1/curvature));pairs=pairs[-14:]
        else:pairs=[]
        u=candidate;gradient=gcnew;potential=float(pc);W=wc;J=jc
        assert np.linalg.norm(u,axis=1).max()<.9,'Declared displacement extent cap'
        if iteration%20==0:
            np.savez_compressed(D/'energy_checkpoint.npz',displacement_m=u,relative_residual=float(np.linalg.norm(gradient)/fn),J_min=J,potential_J=potential)
    else:raise RuntimeError('Fixed-load energy iteration cap reached before Newton handoff')
    log({'stage':'energy_to_Newton_handoff','relative_residual':rel,'J_min':J,'potential_J':potential})
    del M0,ml0,pairs;gc.collect()

''' + s[end:]
s = s.replace('for it in range(30):', 'for it in range(45):')
s = s.replace('if it in [4,9,14,19,24]:', 'if it in [4,9,14,19,24,29,34,39]:')
target.write_text(s)
c = json.loads((R / 'review/contract_NH_fast.json').read_text())
old = 'solve_objective_10kpa_NH_fast.py'
new = 'solve_objective_10kpa_NH_energy.py'
for rows in [c['execution_artifacts'], c['mathematics']['inputs']]:
    for i in range(len(rows)):
        rows[i] = rows[i].replace(old, new).replace('NH_fast_initial_', 'NH_energy_initial_')
c['claim_id'] = 'OBJECTIVE_NH_EXACT_10KPA_ENERGY_ROUTE'
c['mathematics']['conventions'] = 'Unchanged fine geometry, material, support and exact reference dead traction (0,-10000,0) Pa. Preconditioned limited-memory energy descent followed by analytic-tangent Newton; initial-guess perturbation is not geometric imperfection. Continuation/iterations are not time.'
c['mathematics']['bounds'].update(energy_iterations=650,Newton_polish_iterations=45,maximum_nodal_displacement_m=.9)
(R / 'review/contract_NH_energy.json').write_text(json.dumps(c, indent=2))
print(json.dumps(dict(start_pressure_kPa=10*float(a['load_factor']),route='exact-load energy minimisation and Newton, unchanged BVP')))
