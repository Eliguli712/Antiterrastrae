"""Freeze a fixed-load descent state and prepare an energy-globalised Newton run."""
from pathlib import Path
import json
import numpy as np

R=Path(__file__).resolve().parents[1]
target=R/'scripts/solve_objective_10kpa_NH_regularised.py'
assert not target.exists()
a=np.load(R/'data/L2_10kPa_NH_energy/energy_checkpoint.npz')
np.savez_compressed(R/'data/NH_regularised_initial_checkpoint.npz',**{k:a[k] for k in a.files})
s=(R/'scripts/solve_objective_10kpa_NH_energy.py').read_text()
s=s.replace("D=R/'data/L2_10kPa_NH_energy'","D=R/'data/L2_10kPa_NH_regularised'")
s=s.replace("RUN=R/'review/run_NH_energy_001'","RUN=R/'review/run_NH_regularised_001'")
begin=s.index('    # A separate fixed-load route.')
end=s.index('    # Return to the exact original 10 kPa',begin)
s=s[:begin]+'''    # Matrix regularisation is an iteration device, not material/force modification.
    checkpoint=np.load(R/'data/NH_regularised_initial_checkpoint.npz')
    u=checkpoint['displacement_m'].copy();history=[]
    ml0=precondition(np.zeros_like(u));M0=ml0.aspreconditioner()
    _,_,_,Kref=assemble(np.zeros_like(u),True);Kref=Kref[free][:,free].tocsr()
    beta=1.;total_force=float(np.linalg.norm(force.sum(0)))
    for iteration in range(160):
        fi,W,J,K=assemble(u,True);gradient=(fi-f)[free];potential=float(W-f@u.ravel())
        rel=float(np.linalg.norm(gradient)/fn)
        log({'stage':'regularised_energy_Newton','iteration':iteration,'potential_J':potential,'relative_force_residual':rel,'J_min':J,'regularisation':beta})
        if rel<.002:del K;break
        Kf=K[free][:,free].tocsr();del K;accepted=False
        for damping_trial in range(6):
            A=Kf+beta*Kref;count=[0]
            def cb(_):count[0]+=1
            direction,status=gmres(A,-gradient,M=M0,rtol=.015,atol=0,restart=80,maxiter=4,callback=cb,callback_type='pr_norm')
            true=float(np.linalg.norm(A@direction+gradient)/np.linalg.norm(gradient));del A
            slope=float(gradient@direction)
            if not np.isfinite(direction).all() or slope>=0 or true>.15:
                beta*=10;continue
            du=np.zeros(n);du[free]=direction;du=du.reshape(-1,3)
            peak=float(np.linalg.norm(du,axis=1).max());alpha=min(1.,.05/max(peak,1e-30))
            for ls in range(19):
                candidate=u+alpha*du;fc,wc,jc,_=assemble(candidate);pc=float(wc-f@candidate.ravel())
                if jc>.05 and np.isfinite(pc) and pc<=potential+1e-4*alpha*slope:break
                alpha*=.5
            else:
                beta*=10;continue
            accepted=True;u=candidate
            log({'stage':'regularised_Newton_step','alpha':alpha,'regularisation':beta,'linear_residual':true,'linear_iterations':count[0],'potential_J':pc,'J_min':jc})
            if alpha>.9:beta=max(1e-8,beta*.35)
            elif alpha<.05:beta=min(1e8,beta*3)
            np.savez_compressed(D/'energy_checkpoint.npz',displacement_m=u,relative_residual=float(np.linalg.norm((fc-f)[free])/fn),J_min=jc,potential_J=pc)
            assert np.linalg.norm(u,axis=1).max()<.9
            break
        del Kf;gc.collect()
        if not accepted:raise RuntimeError('Energy-globalised Newton step cap reached')
    else:raise RuntimeError('Regularised energy Newton iteration cap reached')
    del M0,ml0,Kref;gc.collect()

''' +s[end:]
target.write_text(s)
c=json.loads((R/'review/contract_NH_energy.json').read_text())
for rows in [c['execution_artifacts'],c['mathematics']['inputs']]:
 for i in range(len(rows)):
  rows[i]=rows[i].replace('solve_objective_10kpa_NH_energy.py','solve_objective_10kpa_NH_regularised.py').replace('NH_energy_initial_checkpoint.npz','NH_regularised_initial_checkpoint.npz')
c['claim_id']='OBJECTIVE_NH_10KPA_ENERGY_GLOBALISED_NEWTON'
c['mathematics']['conventions']='Exact unchanged 10 kPa dead-force residual, fine geometry, support and log-volume NH law. A reference-stiffness matrix shift provides descent directions only; final unmodified Newton/independent force readback must pass. The initial displacement need not be equilibrated.'
c['mathematics']['bounds'].update(energy_Newton_iterations=160,damping_trials_per_iteration=6,linear_GMRES_iterations_per_trial=320)
(R/'review/contract_NH_regularised.json').write_text(json.dumps(c,indent=2))
print(json.dumps({'initial_potential_J':float(a['potential_J']),'initial_force_residual':float(a['relative_residual'])}))
