#!/usr/bin/env python3
"""Full objective StVK at 10 kPa, unchanged fine jaw domain and dead loads.

Adaptive force continuation and residual line search. A material-tangent AMG
preconditioner changes the linear solver only, never the constitutive residual.
"""
from pathlib import Path
import gc,json,sys,time
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import minres,cg,gmres,LinearOperator

R=Path(__file__).resolve().parents[1];P=R.parents[1]
OLD=P/'output/ct_fea_calibrated_2026-11-08'
sys.path.insert(0,str(OLD/'scripts'));sys.path.insert(0,str(OLD/'runtime'))
import pyamg
import neo_hookean_material as law

D=R/'data/L2_10kPa_NH';D.mkdir(parents=True,exist_ok=True)
RUN=R/'review/run_NH_001'
I=np.eye(3);LA=150e6*.3/(1.3*.4);MU=150e6/2.6
started=time.monotonic();np.random.seed(20261120)

def log(row):
    row={'elapsed_seconds':round(time.monotonic()-started,3),**row}
    with (D/'progress.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
    print(json.dumps(row),flush=True)

def main():
    assert not (D/'results.json').exists(),'Preserve previous result; use a new immutable run name.'
    a=np.load(OLD/'data/jaw_L2_full_1kPa/fields.npz')
    p=a['points_m'];t=a['tets'];fixed=a['fixed_node_indices'];force=a['force_N']*10
    u=a['displacement_m'].copy();start_lam=.1;linear=a['linear_displacement_m']*10
    assert len(t)==589700 and len(p)==169396
    mesh=np.load(OLD/'review/mesh_run_001/jaw_L2.npz')
    np.testing.assert_allclose(p,mesh['points_mm']*.001,rtol=0,atol=0)
    np.testing.assert_array_equal(t,mesh['tets'])
    E=p[t[:,1:]]-p[t[:,:1]];inverse=np.linalg.inv(E);g=np.empty((len(t),4,3));g[:,1:]=inverse.transpose(0,2,1);g[:,0]=-g[:,1:].sum(1)
    V=abs(np.linalg.det(E))/6;assert V.min()>1e-24
    dof=(3*t[:,:,None]+np.arange(3)).reshape(-1,12).astype(np.int32)
    rr=np.repeat(dof,12,axis=1).ravel();cc=np.tile(dof,(1,12)).ravel()
    n=3*len(p);free=np.setdiff1d(np.arange(n),(3*fixed[:,None]+np.arange(3)).ravel());f=force.ravel();fn=np.linalg.norm(f[free])
    all_nl=np.ones(len(t),bool)
    checks=law.selfcheck();log({'stage':'law_selfcheck','checks':checks})

    def assemble(u,stiff=False,material=False):
        fi=np.zeros(n);values=np.empty(len(t)*144) if stiff else None;W=0.;Jmin=np.inf
        for start in range(0,len(t),5000):
            sl=slice(start,min(start+5000,len(t)));gg=g[sl]
            G=np.einsum('eai,eaj->eij',u[t[sl,1:]]-u[t[sl,:1]],gg[:,1:]);F=I+G
            PP,S,w,green=law.tensor(F,LA,MU,all_nl[sl],G=G)
            Jmin=min(Jmin,float(np.linalg.det(F).min()));W+=float(V[sl]@w)
            fint=np.einsum('eij,eaj,e->eai',PP,gg,V[sl]);np.add.at(fi,dof[sl].ravel(),fint.ravel())
            if stiff:
                A=law.tangent(F,S,LA,MU,all_nl[sl])
                if material:A-=np.einsum('ik,elj->eijkl',I,S)
                ke=np.einsum('eijkl,eaj,ebl,e->eaibk',A,gg,gg,V[sl],optimize=True).reshape(-1,12,12)
                values[start*144:sl.stop*144]=ke.ravel()
        K=coo_matrix((values,(rr,cc)),shape=(n,n)).tocsr() if stiff else None
        return fi,W,Jmin,K

    def precondition(u):
        _,_,_,Km=assemble(u,True,True)
        cur=p+u;cur=(cur-cur.mean(0))/np.ptp(cur,axis=0).max()
        modes=np.zeros((len(p),3,6));modes[:,:,:3]=I
        for j in range(3):modes[:,:,j+3]=np.cross(I[j],cur)
        Af=Km[free][:,free].tobsr(blocksize=(3,3));del Km
        ml=pyamg.smoothed_aggregation_solver(Af,B=modes.reshape(n,6)[free],symmetry='symmetric',presmoother=('block_gauss_seidel',{'sweep':'symmetric'}),postsmoother=('block_gauss_seidel',{'sweep':'symmetric'}),max_coarse=250,max_levels=12)
        log({'stage':'preconditioner','levels':len(ml.levels),'operator_complexity':float(ml.operator_complexity())})
        return ml

    def lin(K,rhs,M,tolerance):
        count=[0]
        def cb(_):count[0]+=1
        step,status=gmres(K,rhs,M=M,rtol=tolerance,atol=0,restart=80,maxiter=25,callback=cb,callback_type='pr_norm')
        true=float(np.linalg.norm(K@step-rhs)/np.linalg.norm(rhs))
        log({'stage':'linear_solve','iterations':count[0],'true_relative_residual':true,'requested':tolerance,'status':int(status)})
        if not np.isfinite(step).all() or true>max(.02,tolerance*1.1):raise RuntimeError('Unresolved Newton linear system')
        return step

    # The StVK 1 kPa displacement is only an initial guess: equilibrate the
    # distinct neo-Hookean residual first, without transferring a material state.
    ml=precondition(u);M=ml.aspreconditioner()
    for init in range(20):
        fi,W,J,K=assemble(u,True);res=(fi-.1*f)[free];initial=float(np.linalg.norm(res)/(.1*fn))
        log({'stage':'NH_1kPa_initial_equilibration','iteration':init,'residual':initial,'J_min':J})
        if initial<2e-7:del K;break
        Kf=K[free][:,free].tocsr();del K;step=lin(Kf,-res,M,.005);del Kf
        du=np.zeros(n);du[free]=step;du=du.reshape(-1,3);alpha=1.;norm=np.linalg.norm(res)
        for ls in range(17):
            trial=u+alpha*du;fc,wc,jc,_=assemble(trial)
            if jc>.05 and np.linalg.norm((fc-.1*f)[free])<norm*(1-1e-4*alpha):break
            alpha*=.5
        else:raise RuntimeError('NH initial 1 kPa line search failed')
        u=trial
    else:raise RuntimeError('NH initial 1 kPa failed to equilibrate')
    del M,ml
    lam=.1;total_force=float(np.linalg.norm(force.sum(0)));Lref=.1;b=f[free]/Lref
    d=float(f@u.ravel()/total_force);dstep=.0015;attempts=0;accepted=0
    history=[dict(load_factor=lam,traction_kPa=1.,model='full neo-Hookean',free_residual=initial,J_min=J,max_displacement_mm=float(np.linalg.norm(u,axis=1).max()*1000))]
    np.save(D/'initial_NH_1kPa.npy',u)
    log({'stage':'initial_equilibrium','load_kPa':10*lam,'relative_residual':initial,'J_min':J,'work_conjugate_displacement_m':d})

    def augmented(K,M):
        nf=len(free)
        def mv(z):return np.r_[K@z[:-1]-b*z[-1],-b@z[:-1]]
        schur=float(b@(M@b));assert schur>0
        def pm(z):return np.r_[M@z[:-1],z[-1]/schur]
        return LinearOperator((nf+1,nf+1),matvec=mv,dtype=float),LinearOperator((nf+1,nf+1),matvec=pm,dtype=float)

    while lam<1:
        attempts+=1;assert attempts<=140 and accepted<=80
        log({'stage':'displacement_trial','attempt':attempts,'starting_kPa':10*lam,'control_increment_mm':dstep*1000})
        ml=precondition(u);M=ml.aspreconditioner();_,_,_,K0=assemble(u,True);K0f=K0[free][:,free].tocsr();del K0
        A0,B0=augmented(K0f,M);rhs=np.zeros(len(free)+1);rhs[-1]=-total_force*dstep/Lref
        pred=lin(A0,rhs,B0,.01);del A0,B0,K0f
        up=np.zeros(n);up[free]=pred[:-1];up=up.reshape(-1,3);delta_lam=pred[-1]/Lref
        peak=float(np.linalg.norm(up,axis=1).max())
        if peak>.020:
            factor=.019/peak;up*=factor;delta_lam*=factor;dstep*=factor
        target_d=d+dstep;target_work=total_force*target_d
        trial=u+up;trial_lam=lam+delta_lam;converged=False
        for it in range(20):
            fi,W,J,K=assemble(trial,True);ru=(fi-trial_lam*f)[free];c=(float(f@trial.ravel())-target_work)/Lref
            residual=np.r_[ru,-c];rel=float(np.linalg.norm(ru)/(max(abs(trial_lam),.1)*fn));control_error=abs(c)*Lref/total_force
            log({'stage':'Newton_displacement','iteration':it,'load_kPa':10*trial_lam,'relative_force_residual':rel,'control_error_m':control_error,'J_min':J})
            if rel<2e-7 and control_error<1e-10 and J>.05 and trial_lam>0:
                converged=True;del K;break
            if J<=.05 or trial_lam<=0:del K;break
            Kf=K[free][:,free].tocsr();del K;Aa,Bb=augmented(Kf,M)
            forcing=min(.02,max(.0005,.05*np.sqrt(rel)))
            try:step=lin(Aa,-residual,Bb,forcing)
            except RuntimeError:del Aa,Bb,Kf;break
            del Aa,Bb,Kf
            du=np.zeros(n);du[free]=step[:-1];du=du.reshape(-1,3);dl=step[-1]/Lref
            alpha=1.;norm=float(np.linalg.norm(residual))
            for ls in range(16):
                candidate=trial+alpha*du;cl=trial_lam+alpha*dl;fc,wc,jc,_=assemble(candidate)
                rc=np.r_[(fc-cl*f)[free],-(float(f@candidate.ravel())-target_work)/Lref];nc=float(np.linalg.norm(rc))
                if jc>.05 and cl>0 and nc<=norm*(1-1e-4*alpha):break
                alpha*=.5
            else:break
            trial=candidate;trial_lam=cl
            log({'stage':'arc_line_search','alpha':alpha,'reduction':nc/norm,'load_kPa':10*cl,'J_min':jc})
            if it in [4,9,14]:
                del M,ml;gc.collect();ml=precondition(trial);M=ml.aspreconditioner()
        del M,ml;gc.collect()
        if not converged:
            dstep*=.5;log({'stage':'reject_displacement_trial','next_increment_mm':dstep*1000})
            assert dstep>=1e-6,'Work-control continuation cap reached'
            continue
        old_lam=lam;old_u=u.copy();lam=float(trial_lam);u=trial.copy();d=target_d;accepted+=1
        row=dict(load_factor=lam,traction_kPa=10*lam,method='work-conjugate displacement continuation',work_conjugate_displacement_m=d,newton_iterations=it,free_residual=rel,J_min=J,max_displacement_mm=float(np.linalg.norm(u,axis=1).max()*1000))
        history.append(row);(D/'load_curve.json').write_text(json.dumps(history,indent=2));np.savez_compressed(D/'checkpoint.npz',load_factor=lam,displacement_m=u,control_displacement_m=d)
        log({'stage':'accepted_displacement',**row})
        assert np.linalg.norm(u,axis=1).max()<.8 and d<.4,'Declared displacement extent cap'
        if it<=6:dstep=min(.0075,dstep*1.35)
        elif it>=13:dstep*=.7
        if lam>=1:
            w=(1-old_lam)/(lam-old_lam);u=(1-w)*old_u+w*u
            break

    # Return to the exact original 10 kPa dead-traction problem for final polish.
    lam=1.;ml=precondition(u);M=ml.aspreconditioner()
    for it in range(30):
        fi,W,J,K=assemble(u,True);res=(fi-f)[free];relative=float(np.linalg.norm(res)/fn)
        log({'stage':'force_polish_10kPa','iteration':it,'relative_residual':relative,'J_min':J})
        if relative<2e-7 and J>.05:del K;break
        Kf=K[free][:,free].tocsr();del K;step=lin(Kf,-res,M,min(.01,max(.0001,.05*np.sqrt(relative))));del Kf
        du=np.zeros(n);du[free]=step;du=du.reshape(-1,3);alpha=1.;norm=np.linalg.norm(res)
        for ls in range(17):
            candidate=u+alpha*du;fc,wc,jc,_=assemble(candidate)
            if jc>.05 and np.linalg.norm((fc-f)[free])<norm*(1-1e-4*alpha):break
            alpha*=.5
        else:raise RuntimeError('Final 10 kPa force polish line search failed')
        u=candidate
        if it in [4,9,14,19,24]:del M,ml;gc.collect();ml=precondition(u);M=ml.aspreconditioner()
    else:raise RuntimeError('Final exact 10 kPa force polish did not converge')
    del M,ml;gc.collect()
    history.append(dict(load_factor=1.,traction_kPa=10.,method='exact original dead-force polish',free_residual=relative,J_min=J,max_displacement_mm=float(np.linalg.norm(u,axis=1).max()*1000)))
    (D/'load_curve.json').write_text(json.dumps(history,indent=2))
    assert lam==1.
    # Orthogonal direct tensor/force readback, without calling constitutive helpers.
    G=np.einsum('eai,eaj->eij',u[t[:,1:]]-u[t[:,:1]],g[:,1:]);F=I+G
    green=(F.transpose(0,2,1)@F-I)/2
    J=np.linalg.det(F);N=np.linalg.inv(F).transpose(0,2,1);coef=LA*np.log(J)-MU
    PP=MU*F+coef[:,None,None]*N;sigma=(MU*(F@F.transpose(0,2,1)-I)+LA*np.log(J)[:,None,None]*I)/J[:,None,None]
    dev=sigma-np.trace(sigma,axis1=1,axis2=2)[:,None,None]*I/3;vm=np.sqrt(1.5*np.sum(dev*dev,(1,2)))
    strain_dev=green-np.trace(green,axis1=1,axis2=2)[:,None,None]*I/3;eq=np.sqrt(2/3*np.sum(strain_dev*strain_dev,(1,2)))
    fint=np.zeros_like(p)
    local=np.einsum('eij,eaj,e->eai',PP,g,V)
    for j in range(4):np.add.at(fint,t[:,j],local[:,j])
    residual=fint-force;readback=float(np.linalg.norm(residual.ravel()[free])/fn)
    reaction=np.zeros_like(p);reaction[fixed]=residual[fixed]
    balance=float(np.linalg.norm(reaction.sum(0)+force.sum(0))/np.linalg.norm(force.sum(0)))
    moment=float(np.linalg.norm(np.cross(p+u,force+reaction).sum(0))/(np.linalg.norm(force.sum(0))*np.ptp(p,axis=0).max()))
    symmetry=float(np.linalg.norm(sigma-sigma.transpose(0,2,1))/np.linalg.norm(sigma))
    W=.5*MU*(np.sum(F*F,(1,2))-3)-MU*np.log(J)+.5*LA*np.log(J)**2
    order=np.argsort(vm);q=vm[order[np.searchsorted(np.cumsum(V[order]),np.array([.5,.95,.99])*V.sum())]]/1e6
    assert max(readback,balance,moment,symmetry)<2e-6 and J.min()>.05
    np.savez_compressed(D/'fields.npz',points_m=p,tets=t,displacement_m=u,linear_displacement_m=linear,volumes_m3=V,von_mises_Pa=vm,cauchy_stress_Pa=sigma,green_strain=green,equivalent_strain=eq,J=J,fixed_node_indices=fixed,force_N=force)
    result=dict(status='verified_stationary_equilibrium',model='Full objective logarithmic-volume neo-Hookean on unchanged fine L2 white-shark reference; no contact',reference_traction_Pa=[0,-10000,0],E_Pa=150e6,nu=.3,nodes=len(p),tetrahedra=len(t),source_scale='Original model unit assumed mm; no anatomical calibration',all_material_cells_neo_Hookean=True,load_steps=history,independent_free_residual=readback,force_balance=balance,current_moment_balance=moment,cauchy_symmetry=symmetry,J_min=float(J.min()),J_max=float(J.max()),Q50_Q95_Q99_MPa=q.tolist(),peak_MPa=float(vm.max()/1e6),max_displacement_mm=float(np.linalg.norm(u,axis=1).max()*1000),elastic_energy_J=float(V@W),max_equivalent_strain=float(eq.max()),non_claims=['No calibrated fossil bite, contact impact or fracture law.','Stationary equilibrium alone does not establish stability, continuum convergence or constitutive calibration at large deformation.'],runtime_seconds=time.monotonic()-started,selfcheck=checks)
    (D/'results.json').write_text(json.dumps(result,indent=2));(RUN/'results.json').write_text(json.dumps(result,indent=2));log({'stage':'VERIFIED_10_KPA','summary':result})

if __name__=='__main__':main()
