"""Independent equilibrium and rank-one material check of a saved path state."""
from pathlib import Path
import json
import numpy as np

R = Path(__file__).resolve().parents[1]
P = R.parents[1]
a = np.load(P / 'output/ct_fea_calibrated_2026-11-08/data/jaw_L2_full_1kPa/fields.npz')
c = np.load(R / 'data/StVK_path_snapshot.npz')
p, t, fixed = a['points_m'], a['tets'], a['fixed_node_indices']
u, factor = c['displacement_m'], float(c['load_factor'])
force = a['force_N'] * 10 * factor
la, mu, I = 150e6 * .3 / (1.3 * .4), 150e6 / 2.6, np.eye(3)
internal = np.zeros_like(p)
min_acoustic, Jmin, Wsum = float('inf'), float('inf'), 0.
witness = None
for start in range(0, len(t), 10000):
    sl = slice(start, min(start + 10000, len(t)))
    cells = t[sl]
    X = p[cells[:, 1:]] - p[cells[:, :1]]
    G = np.linalg.solve(X, u[cells[:, 1:]] - u[cells[:, :1]]).transpose(0, 2, 1)
    F = I + G
    E = (F.transpose(0, 2, 1) @ F - I) / 2
    S = la * np.trace(E, axis1=1, axis2=2)[:, None, None] * I + 2 * mu * E
    PP = F @ S
    vol = abs(np.linalg.det(X)) / 6
    Wsum += float(vol @ (la / 2 * np.trace(E, axis1=1, axis2=2)**2 + mu * np.sum(E * E, (1, 2))))
    g = np.empty((len(cells), 4, 3))
    g[:, 1:] = np.linalg.inv(X).transpose(0, 2, 1)
    g[:, 0] = -g[:, 1:].sum(1)
    local = np.einsum('eij,eaj,e->eai', PP, g, vol)
    for k in range(4):
        np.add.at(internal, cells[:, k], local[:, k])
    Jmin = min(Jmin, float(np.linalg.det(F).min()))
    U, sv, Vh = np.linalg.svd(F)
    cc = sv**2
    # S is coaxial with C. Match eigenvalues to each SVD reference direction.
    se = la / 2 * (cc.sum(1) - 3)[:, None] + mu * (cc - 1)
    acoustic = mu * cc[:, :, None] + se[:, None, :] + (la + mu) * I[None] * cc[:, None, :]
    e, i, j = np.unravel_index(np.argmin(acoustic), acoustic.shape)
    if acoustic[e, i, j] < min_acoustic:
        min_acoustic = float(acoustic[e, i, j])
        witness = (start + e, F[e].copy(), U[e, :, i].copy(), Vh[e, j].copy())
free = np.ones(len(p), bool)
free[fixed] = False
residual = internal - force
reaction = np.zeros_like(p)
reaction[fixed] = residual[fixed]
error = float(np.linalg.norm(residual[free]) / np.linalg.norm(force[free]))
balance = float(np.linalg.norm(force.sum(0) + reaction.sum(0)) / np.linalg.norm(force.sum(0)))
moment = float(np.linalg.norm(np.cross(p + u, force + reaction).sum(0))
               / (np.linalg.norm(force.sum(0)) * np.ptp(p, axis=0).max()))
assert max(error, balance, moment) < 2e-6 and Jmin > .05
cell, F, spatial, reference = witness
direction = spatial[:, None] * reference[None, :]


def energy(matrix):
    strain = (matrix.T @ matrix - I) / 2
    return la / 2 * np.trace(strain)**2 + mu * np.sum(strain * strain)


h = 1e-5
finite = (energy(F + h * direction) - 2 * energy(F) + energy(F - h * direction)) / h**2
relative = abs(finite - min_acoustic) / max(abs(min_acoustic), 1.)
assert relative < 2e-4
result = dict(status='passed', reference_pressure_kPa=10 * factor,
              control_displacement_mm=float(c['control_displacement_m']) * 1000,
              maximum_displacement_mm=float(np.linalg.norm(u, axis=1).max() * 1000),
              free_residual=error, force_balance=balance, current_moment_balance=moment,
              J_min=Jmin, elastic_energy_J=Wsum,
              minimum_principal_direction_acoustic_eigenvalue_Pa=min_acoustic,
              witness_cell=int(cell), spatial_direction=spatial.tolist(),
              reference_direction=reference.tolist(), deformation_gradient=F.tolist(),
              rank_one_energy_second_difference_Pa=float(finite),
              second_difference_relative_error=relative,
              interpretation=('A negative rank-one second variation witnesses loss of elementwise strong ellipticity at this saved state.'
                              if min_acoustic < 0 else 'Positive principal-direction tests alone do not certify all-direction strong ellipticity.'),
              non_claims=['No exact 10 kPa StVK equilibrium, critical-load bound or global stability proof.'])
(R / 'review/audit_path_snapshot_001/results.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
