"""Prepare tangent-projected descent while retaining exact NH forces and energy."""
from pathlib import Path
import json
import numpy as np

R=Path(__file__).resolve().parents[1];target=R/'scripts/solve_objective_10kpa_NH_projected.py'
assert not target.exists()
a=np.load(R/'data/L2_10kPa_NH_regularised/energy_checkpoint.npz')
np.savez_compressed(R/'data/NH_projected_initial_checkpoint.npz',**{k:a[k] for k in a.files})
s=(R/'scripts/solve_objective_10kpa_NH_regularised.py').read_text()
s=s.replace("D=R/'data/L2_10kPa_NH_regularised'","D=R/'data/L2_10kPa_NH_projected'")
s=s.replace("RUN=R/'review/run_NH_regularised_001'","RUN=R/'review/run_NH_projected_001'")
s=s.replace('def assemble(u,stiff=False,material=False):','def assemble(u,stiff=False,material=False,projected=False):')
needle="                if material:A-=np.einsum('ik,elj->eijkl',I,S)"
replacement=needle+'''
                if projected:
                    AA=A.reshape(-1,9,9);AA=(AA+AA.transpose(0,2,1))/2
                    ew,ev=np.linalg.eigh(AA)
                    AA=(ev*np.maximum(ew,MU*1e-6)[:,None,:])@ev.transpose(0,2,1)
                    A=AA.reshape(-1,3,3,3,3)
'''
assert needle in s;s=s.replace(needle,replacement)
begin=s.index('    # Matrix regularisation is an iteration device')
end=s.index('    # Return to the exact original 10 kPa',begin)
s=s[:begin]+'''    # Project only the iteration Hessian. The physical NH energy/force is exact.
    checkpoint=np.load(R/'data/NH_projected_initial_checkpoint.npz')
    u=checkpoint['displacement_m'].copy();history=[];Mstep=None;mlstep=None
    for iteration in range(120):
        fi,W,J,K=assemble(u,True,projected=True);gradient=(fi-f)[free];potential=float(W-f@u.ravel())
        rel=float(np.linalg.norm(gradient)/fn)
        log({'stage':'projected_tangent_descent','iteration':iteration,'potential_J':potential,'relative_force_residual':rel,'J_min':J})
        if rel<.002:del K;break
        Af=K[free][:,free].tocsr();del K
        if Mstep is None or iteration%4==0:
            if Mstep is not None:del Mstep,mlstep;gc.collect()
            cur=p+u;cur=(cur-cur.mean(0))/np.ptp(cur,axis=0).max()
            rigid=np.zeros((len(p),3,6));rigid[:,:,:3]=I
            for k in range(3):rigid[:,:,k+3]=np.cross(I[k],cur)
            mlstep=pyamg.smoothed_aggregation_solver(Af.tobsr(blocksize=(3,3)),B=rigid.reshape(n,6)[free],symmetry='symmetric',presmoother=('block_gauss_seidel',{'sweep':'symmetric'}),postsmoother=('block_gauss_seidel',{'sweep':'symmetric'}),max_coarse=250,max_levels=12)
            Mstep=mlstep.aspreconditioner()
        count=[0]
        def callback(_):count[0]+=1
        direction,status=cg(Af,-gradient,M=Mstep,rtol=.01,atol=0,maxiter=1500,callback=callback)
        true=float(np.linalg.norm(Af@direction+gradient)/np.linalg.norm(gradient))
        for polish in range(2):
            if true<.03:break
            delta,istat=cg(Af,-gradient-Af@direction,M=Mstep,rtol=.01,atol=0,maxiter=800)
            direction+=delta;true=float(np.linalg.norm(Af@direction+gradient)/np.linalg.norm(gradient))
        del Af
        slope=float(gradient@direction);assert np.isfinite(direction).all() and slope<0 and true<.1
        du=np.zeros(n);du[free]=direction;du=du.reshape(-1,3)
        peak=float(np.linalg.norm(du,axis=1).max());alpha=min(1.,.1/max(peak,1e-30))
        for ls in range(22):
            candidate=u+alpha*du;fc,wc,jc,_=assemble(candidate);pc=float(wc-f@candidate.ravel())
            if jc>.05 and np.isfinite(pc) and pc<=potential+1e-4*alpha*slope:break
            alpha*=.5
        else:raise RuntimeError('Projected-tangent exact-energy line search exhausted')
        u=candidate;np.savez_compressed(D/'energy_checkpoint.npz',displacement_m=u,relative_residual=float(np.linalg.norm((fc-f)[free])/fn),J_min=jc,potential_J=pc)
        log({'stage':'projected_tangent_step','alpha':alpha,'linear_iterations':count[0],'linear_residual':true,'potential_J':pc,'J_min':jc})
        assert np.linalg.norm(u,axis=1).max()<.9
    else:raise RuntimeError('Projected tangent descent iteration cap reached')
    if Mstep is not None:del Mstep,mlstep
    gc.collect()

''' +s[end:]
target.write_text(s)
c=json.loads((R/'review/contract_NH_regularised.json').read_text())
for rows in [c['execution_artifacts'],c['mathematics']['inputs']]:
 for i in range(len(rows)):
  rows[i]=rows[i].replace('solve_objective_10kpa_NH_regularised.py','solve_objective_10kpa_NH_projected.py').replace('NH_regularised_initial_checkpoint.npz','NH_projected_initial_checkpoint.npz')
c['claim_id']='OBJECTIVE_NH_10KPA_PROJECTED_TANGENT_DESCENT'
c['mathematics']['conventions']='Exact unchanged NH forces/energy and10kPa dead traction. Local9x9 energy Hessian eigenvalues are floored at mu*1e-6 only to produce descent directions; neither constitutive energy nor force/stress is projected. Final unmodified analytic-tangent Newton and independent readback must pass.'
c['mathematics']['bounds'].update(projected_descent_iterations=120,local_eigenvalue_floor_Pa=150e6/2.6*1e-6,CG_iterations=1500,residual_corrections_max=2)
(R/'review/contract_NH_projected.json').write_text(json.dumps(c,indent=2))
print(json.dumps({'initial_potential_J':float(a['potential_J']),'initial_relative_residual':float(a['relative_residual'])}))
