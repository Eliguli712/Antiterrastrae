"""Paired Q1 plane-strain FEM and first-kink estimates on a native CT section."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy import ndimage
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve

SPACING_MM = .018
NX, NY = 60, 48
CAVITY_X, CAVITY_Y = 41, 28
TIP_X, CRACK_Y = 34, 24
OPENING_STRAIN = 1e-4
YOUNG_MPA, POISSON = 20_000., .28
EXPECTED = '8a68259cc4c079eaef5ec604e60bea2de6bf8bf4ebb7d9499347651676e19bce'


def crop_from_mha(path, traces_path):
    """Read the needed slices from the zlib MHA stream without a second 4 GB copy."""
    import zlib
    with path.open('rb') as source:
        assert hashlib.file_digest(source, 'sha256').hexdigest() == EXPECTED
        source.seek(0)
        header = {}
        for line in source:
            key, value = line.decode().strip().split(' = ', 1)
            header[key] = value
            if key == 'ElementDataFile':
                break
        shape = tuple(map(int, header['DimSize'].split()))[::-1]
        assert shape == (2886, 1903, 746)
        assert header['ElementType'] == 'MET_UCHAR' and header['CompressedData'] == 'True'
        record = json.loads(traces_path.read_text())
        origin = np.array(record['registered_web_mesh_origin_xyz_mm'])
        points = {}
        for trace in record['traces']:
            coords = np.rint((np.array(trace['points_registered_native_xyz_mm'])-origin)/SPACING_MM).astype(int)
            for x, y, z in coords[::3]:
                points.setdefault(z, []).append((trace['id'], x, y))
        plane_size = shape[1]*shape[2]
        bytes_pending, iz = bytearray(), 0
        unpack = zlib.decompressobj()
        structure = ndimage.generate_binary_structure(2, 1)
        candidates = []
        last_z = max(points)
        while iz <= last_z and (chunk := source.read(65536)):
            bytes_pending.extend(unpack.decompress(chunk))
            planes = len(bytes_pending)//plane_size
            for local in range(planes):
                z = iz+local
                if z not in points:
                    continue
                start = local*plane_size
                plane = np.frombuffer(bytes_pending[start:start+plane_size], dtype='u1').reshape(shape[1:])
                for trace_id, x, y in points[z]:
                    x0, y0 = int(x)-CAVITY_X, int(y)-CAVITY_Y
                    mask = plane[y0:y0+NY, x0:x0+NX] == 1
                    if mask.shape != (NY, NX) or mask[CAVITY_Y,CAVITY_X]:
                        continue
                    components, _ = ndimage.label(~mask, structure)
                    label = components[CAVITY_Y,CAVITY_X]
                    component = components == label
                    if not 12 <= component.sum() <= 100:
                        continue
                    # Use the first traced candidate with a sealed in-plane
                    # section and a continuous 4-voxel strip around the notch.
                    if not all(np.all(line) for line in (mask[0], mask[-1], mask[:,0], mask[:,-1])):
                        continue
                    if not mask[CRACK_Y-2:CRACK_Y+2,:TIP_X+3].all():
                        continue
                    if int(mask.sum()) < .94*NX*NY:
                        continue
                    candidates.append((trace_id, z, y0, x0, mask, component))
            del bytes_pending[:planes*plane_size]
            iz += planes
    _, z, y0, x0, mask, component = best = min(candidates,key=lambda row:row[:4])
    location = {'trace_id':int(best[0]), 'source_z_index':int(z),
                'crop_start_yx':[int(y0),int(x0)], 'candidate_section_voxels':int(component.sum()),
                'all_ct_void_pixels':int((~mask).sum()), 'shape_yx':[NY,NX]}
    return mask, component, location


def operators(poisson, spacing):
    young = YOUNG_MPA
    shear = young/(2*(1+poisson))
    lame = young*poisson/((1+poisson)*(1-2*poisson))
    c = np.array([[lame+2*shear, lame, 0],[lame,lame+2*shear,0],[0,0,shear]])
    signs_x = np.array([-1.,1.,1.,-1.])
    signs_y = np.array([-1.,-1.,1.,1.])
    def strains(xi, eta):
        b = np.zeros((3,8))
        b[0,::2] = b[2,1::2] = signs_x*(1+signs_y*eta)/(2*spacing)
        b[1,1::2] = b[2,::2] = signs_y*(1+signs_x*xi)/(2*spacing)
        return b
    gauss = [-1/np.sqrt(3), 1/np.sqrt(3)]
    matrices = [strains(xi,eta) for xi in gauss for eta in gauss]
    stiffness = sum(b.T@c@b for b in matrices)*(spacing**2/4)
    return stiffness, strains(0.,0.), c, lame, shear


def solve(mask, factor, cracked):
    active = mask.repeat(factor,axis=0).repeat(factor,axis=1)
    ny, nx = active.shape
    nodes = np.arange((ny+1)*(nx+1)).reshape(ny+1,nx+1)
    rows, cols = np.nonzero(active)
    cells = np.column_stack([nodes[rows,cols], nodes[rows,cols+1],
                             nodes[rows+1,cols+1],nodes[rows+1,cols]])
    tip, seam = TIP_X*factor, CRACK_Y*factor
    lower = upper = np.array([],dtype=int)
    if cracked:
        lower = nodes[seam,:tip]
        upper = np.arange(nodes.size,nodes.size+tip)
        at_seam = (rows==seam)[:,None] & (cells>=lower[0]) & (cells<=lower[-1])
        cells[at_seam] += upper[0]-lower[0]
    dofs = (2*cells[:,:,None]+np.arange(2)).reshape(-1,8)
    unique = np.unique(dofs)
    lookup = np.full(unique[-1]+1,-1,dtype=int)
    lookup[unique] = np.arange(unique.size)
    dofs = lookup[dofs]
    h = SPACING_MM/factor
    k_local, b, c, lame, shear = operators(POISSON,h)
    stiff = coo_matrix((np.tile(k_local.ravel(),dofs.shape[0]),
                       (dofs.repeat(8,axis=1).ravel(),np.tile(dofs,(1,8)).ravel())),
                      shape=(len(unique),len(unique))).tocsc()
    bottom, top = lookup[2*nodes[0]+1], lookup[2*nodes[-1]+1]
    fixed = np.r_[bottom,top,lookup[0]]
    u = np.zeros(unique.size)
    u[bottom] = -OPENING_STRAIN*ny*h/2
    u[top] = OPENING_STRAIN*ny*h/2
    free = np.setdiff1d(np.arange(len(u)),fixed)
    u[free] = spsolve(stiff[free][:,free], -(stiff[free][:,fixed]@u[fixed]))
    force = stiff@u
    scale = np.linalg.norm(force[fixed])
    assert np.linalg.norm(force[free]) <= scale*1e-8
    assert abs(force[top].sum()+force[bottom].sum()) <= abs(force[top].sum())*1e-7
    eps = u[dofs]@b.T
    sx, sy, shear_xy = (eps@c.T).T
    sz = lame*(eps[:,0]+eps[:,1])
    vm = np.sqrt(((sx-sy)**2+(sy-sz)**2+(sz-sx)**2)/2+3*shear_xy**2)
    stress = np.full(active.shape,np.nan)
    stress[rows,cols] = vm
    result = {'elements':int(len(cells)), 'dofs':int(len(unique)),
              'top_reaction_N_per_mm':float(force[top].sum()),
              'relative_equilibrium_residual':float(np.linalg.norm(force[free])/scale)}
    if cracked:
        r = np.arange(tip,0,-1)*h
        locs = np.arange(2)
        jump = u[lookup[2*upper[:,None]+locs]]-u[lookup[2*lower[:,None]+locs]]
        # Williams leading displacement jump (mode II tangential, mode I normal).
        # The r^(3/2) term absorbs the first regular face-jump correction.
        factor_sif = np.sqrt(2*np.pi)*shear/(4*(1-POISSON))
        window_results = []
        for outer_mm in (.054,.072,.09):
            use = (r>=max(2*h,.009)-1e-9)&(r<=outer_mm+1e-9)
            a = np.column_stack([np.sqrt(r[use]),r[use]**1.5])
            kii, ki = np.linalg.lstsq(a,jump[use],rcond=None)[0][0]*factor_sif
            angle = np.degrees(2*np.arctan(-2*kii/(ki+np.sqrt(ki*ki+8*kii*kii))))
            assert ki > 0
            window_results.append({'outer_mm':outer_mm, 'fit_nodes':int(use.sum()),
                                   'KI_MPa_sqrt_mm':float(ki),'KII_MPa_sqrt_mm':float(kii),
                                   'first_kink_deg':float(angle)})
        result['face_jump_fit'] = window_results
    return stress, result


def run(mask, component):
    records, plots = [], {}
    nominal = YOUNG_MPA/(1-POISSON**2)*OPENING_STRAIN
    for f in (1,2,4,8):
        local = {'element_pitch_mm':SPACING_MM/f}
        collar = ndimage.distance_transform_edt(~component.repeat(f,axis=0).repeat(f,axis=1),
                                               sampling=SPACING_MM/f) <= .036+1e-9
        for tag, material in [('ct_pores',mask),('filled',np.ones_like(mask))]:
            vm, intact = solve(material,f,False)
            near = collar & np.isfinite(vm) & ~component.repeat(f,axis=0).repeat(f,axis=1)
            intact['collar_q95_over_nominal']=float(np.quantile(vm[near],.95)/nominal)
            intact['collar_mean_over_nominal']=float(vm[near].mean()/nominal)
            cracked_vm, cracked=solve(material,f,True)
            local[tag]={'intact':intact,'seeded_crack':cracked}
            if f==8:
                plots[tag]=(vm/nominal,cracked_vm/nominal)
        records.append(local)
    assert all(abs(row['filled']['seeded_crack']['face_jump_fit'][1]['first_kink_deg'])<1e-6 for row in records)
    return records, plots


def plot(plots, location, result, out):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import FancyArrowPatch
    plt.rcParams.update({'font.family':'DejaVu Serif','font.size':9})
    extent = (0,NX*SPACING_MM,0,NY*SPACING_MM)
    fig, axes=plt.subplots(2,2,figsize=(9.4,7.6),layout='constrained')
    positions = ('ct_pores','filled')
    for row, kind in enumerate(('intact','seeded_crack')):
        for col,key in enumerate(positions):
            ax=axes[row,col]
            data=plots[key][row]
            ax.set_facecolor('#e5e9ea')
            im=ax.imshow(data,origin='lower',extent=extent,interpolation='nearest',cmap='turbo',vmin=0,vmax=3)
            ax.set(title=('CT voids retained' if col==0 else 'Void-filled control')+' · '+('Uncracked' if row==0 else 'Seeded edge crack'),
                   xlabel='Scanner x within crop (mm)',ylabel='Scanner y within crop (mm)')
            if row==1:
                x,y=TIP_X*SPACING_MM,CRACK_Y*SPACING_MM
                angle=result[-1][key][kind]['face_jump_fit'][1]['first_kink_deg']
                ax.plot([0,x],[y,y],color='white',linewidth=2)
                dx,dy=.14*np.cos(np.radians(angle)),.14*np.sin(np.radians(angle))
                ax.add_patch(FancyArrowPatch((x,y),(x+dx,y+dy),color='white',arrowstyle='-|>',mutation_scale=12))
                ax.text(.03,.06,f'First-kink estimate {angle:+.1f}°',transform=ax.transAxes,
                        color='white',bbox={'facecolor':'#141922','edgecolor':'none','alpha':.8})
    fig.colorbar(im,ax=axes,orientation='horizontal',extend='both',fraction=.045,pad=.08,
                 label='Von Mises stress / nominal tensile stress')
    fig.suptitle(f'Micro-CT cross-section {location["source_z_index"]} · local plane-strain model',fontsize=13)
    fig.savefig(out,dpi=260)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--mha',type=Path)
    cli.add_argument('--traces',type=Path)
    cli.add_argument('--roi',type=Path,help='Bundled exact extracted CT crop (NPZ).')
    cli.add_argument('--output',type=Path,default=Path('.'))
    args = cli.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    if args.roi:
        with np.load(args.roi) as roi:
            mask, component, location = roi['mask'],roi['component'],json.loads(str(roi['record']))
    else:
        mask,component,location = crop_from_mha(args.mha,args.traces)
        np.savez_compressed(args.output/'ct-cavity-crop.npz',mask=mask,component=component,record=json.dumps(location))
    result, plots=run(mask,component)
    report={'source_mha_sha256':EXPECTED, 'native_voxel_pitch_mm':SPACING_MM,
            'geometry':location,'material':{'E_MPa':YOUNG_MPA,'nu':POISSON},
            'nominal_tensile_strain':OPENING_STRAIN, 'plane_strain':True,
            'precrack':{'tip_xy_mm':[TIP_X*SPACING_MM,CRACK_Y*SPACING_MM],
                        'extends_from_left_edge':True},
            'boundary':'Uniform opposite vertical displacements on horizontal edges. Horizontal slip free except one bottom corner. Remaining boundaries and crack faces traction-free.',
            'collar':'Material cell centres within 36 µm of the chosen cavity, identical spatial selection in paired control.',
            'crack_metric':'Initial kink direction from a near-tip displacement-jump fit and the maximum circumferential stress criterion; not a simulated crack path or measured fracture.',
            'results':result}
    (args.output/'ct-cavity-mechanics.json').write_text(json.dumps(report,indent=2)+'\n')
    plot(plots,location,result,args.output/'ct-cavity-mechanics.png')


if __name__=='__main__':
    main()
