"""Explicit small-strain P1 kernel; coordinates and tractions are SI."""
import numpy as np

def kinematics(points, tets):
    X=points[tets[:,1:]]-points[tets[:,:1]]
    determinant=np.linalg.det(X)
    if np.any(abs(determinant)<1e-30):raise ValueError('Degenerate tetrahedron')
    gradients=np.empty((len(tets),4,3));gradients[:,1:]=np.linalg.inv(X).transpose(0,2,1)
    gradients[:,0]=-gradients[:,1:].sum(1)
    return gradients,abs(determinant)/6

def stiffness(g,volume,E,nu):
    if not(E>0 and -1<nu<.5):raise ValueError('Invalid isotropic tangent')
    mu=E/(2*(1+nu));la=E*nu/((1+nu)*(1-2*nu))
    return (la*np.einsum('eai,ebk->eaibk',g,g)
            +mu*np.einsum('ik,eab->eaibk',np.eye(3),g@g.transpose(0,2,1))
            +mu*np.einsum('eak,ebi->eaibk',g,g))*volume[:,None,None,None,None]

def tensors(g,local_u,E,nu):
    G=np.einsum('eai,eaj->eij',local_u,g)
    strain=(G+G.transpose(0,2,1))/2
    stress=E/(1+nu)*strain+E*nu/((1+nu)*(1-2*nu))*np.trace(strain,axis1=1,axis2=2)[:,None,None]*np.eye(3)
    dev=stress-np.trace(stress,axis1=1,axis2=2)[:,None,None]*np.eye(3)/3
    return stress,strain,np.sqrt(1.5*np.sum(dev*dev,(1,2)))

def boundary(tets):
    # Audit/demo helper. Native production extraction must run with sufficient RAM.
    faces=tets[:,[[1,2,3],[0,3,2],[0,1,3],[0,2,1]]].reshape(-1,3)
    canonical=np.sort(faces,axis=1);_,first,counts=np.unique(canonical,axis=0,return_index=True,return_counts=True)
    if np.any(counts>2):raise ValueError('Nonmanifold volume faces')
    return faces[first[counts==1]],(first[counts==1]//4)
