"""Exact boundary-array audit; no hash-only geometric equality claim."""
from pathlib import Path
import argparse,json
import numpy as np

def canonical(f):
    a=np.ascontiguousarray(np.sort(f,axis=1),dtype='<u8')
    return np.sort(a.view([('a','<u8'),('b','<u8'),('c','<u8')]).reshape(-1),order=['a','b','c'])

def main():
    p=argparse.ArgumentParser();p.add_argument('--source-vertices',type=Path,required=True);p.add_argument('--source-faces',type=Path,required=True);p.add_argument('--tet-vertices',type=Path,required=True);p.add_argument('--extracted-tet-boundary',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
    sv=np.load(a.source_vertices,mmap_mode='r');sf=np.load(a.source_faces,mmap_mode='r');tv=np.load(a.tet_vertices,mmap_mode='r');tf=np.load(a.extracted_tet_boundary,mmap_mode='r')
    if len(tv)<len(sv) or len(sf)!=len(tf):raise ValueError('Boundary count changed')
    # The mesher contract keeps the input vertices first; changed numbering needs
    # a separately audited bijection, rather than a nearest-neighbour substitute.
    for begin in range(0,len(sv),100000):
        if not np.array_equal(sv[begin:begin+100000],tv[begin:begin+100000]):raise ValueError('An original boundary vertex moved or was renumbered')
    if np.max(tf)>=len(sv):raise ValueError('Unrecorded boundary Steiner vertex')
    if not np.array_equal(canonical(sf),canonical(tf)):raise ValueError('Boundary facets differ')
    result=dict(status='exact_array_boundary_match',vertices=len(sv),triangles=len(sf),scope='Checks exact supplied boundary arrays. Extraction from the full volume, embeddedness, nesting and material occupancy require their own independent audit.')
    a.output.write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':main()
