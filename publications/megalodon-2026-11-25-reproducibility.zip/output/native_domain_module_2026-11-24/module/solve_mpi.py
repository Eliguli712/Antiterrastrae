"""Distributed PETSc assembly on a prevalidated conforming native tetrahedral mesh.

Run under mpiexec in an MPI-enabled PETSc environment. This is not a browser
solver and does not convert a surface projection into a native-volume result.
"""
from pathlib import Path
import argparse,json,sys,hashlib,time
import numpy as np
from elasticity import kinematics,stiffness,tensors

def verify_contract(c,root):
    a=c['geometry_audit'];mode=c['domain']
    if mode not in ['preserve','filled']:raise ValueError('Boundary-adjacent cells are a visibility selection, not a separate material problem')
    for k in ['positive_tet_volumes','embedded_shells','boundary_matches_input','no_overlapping_tets','occupancy_checked']:
        if a.get(k) is not True:raise ValueError('Missing geometry certification: '+k)
    if mode=='preserve':
        if a.get('retained_native_faces')!=74293846 or a.get('retained_native_vertices')!=37951699 or a.get('excluded_void_components')!=803442:raise ValueError('Incomplete native boundary/void domain')
    elif a.get('separate_filled_mesh') is not True:raise ValueError('Filled geometry must be independently meshed and labelled')
    required={c[k] for k in ['points','tets','loaded_faces','fixed_nodes','boundary_nodes']}
    if not required.issubset(c['input_sha256']):raise ValueError('Every geometry/load/support array requires a pinned SHA-256')
    for name,digest in c['input_sha256'].items():
        p=root/name
        if hashlib.file_digest(p.open('rb'),'sha256').hexdigest()!=digest:raise ValueError('Input checksum mismatch: '+name)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('contract',type=Path);ap.add_argument('--output',type=Path,required=True)
    args,extra=ap.parse_known_args()
    from mpi4py import MPI
    import petsc4py
    petsc4py.init([sys.argv[0],*extra])
    from petsc4py import PETSc
    comm=MPI.COMM_WORLD;rank=comm.rank;start=time.monotonic();root=args.contract.resolve().parent
    c=json.loads(args.contract.read_text());error=None
    if rank==0:
        try:verify_contract(c,root)
        except Exception as e:error=str(e)
    error=comm.bcast(error)
    if error:raise ValueError(error)
    if c['units']!='m' or c['nominal_height_mm'] not in [50,100]:raise ValueError('Explicit SI geometry and one independent size are required')
    points=np.load(root/c['points'],mmap_mode='r');all_t=np.load(root/c['tets'],mmap_mode='r')
    n=len(points)
    if points.shape[1]!=3 or all_t.shape[1]!=4:raise ValueError('Expected XYZ points and four-node tetrahedra')
    if c['domain']=='preserve' and (n<37951699 or len(all_t)<37951696):raise ValueError('Actual mesh is too small to retain the native boundary')
    begin=len(all_t)*rank//comm.size;end=len(all_t)*(rank+1)//comm.size;t=np.asarray(all_t[begin:end],dtype=np.int64)
    own0=n*rank//comm.size;own1=n*(rank+1)//comm.size
    E=float(c['E_Pa']);nu=float(c['nu']);out=args.output
    if rank==0:out.mkdir(parents=True,exist_ok=False)
    comm.Barrier()
    # Block row ownership is aligned to complete three-component vertex blocks.
    A=PETSc.Mat().createAIJ(size=((3*(own1-own0),3*n),(3*(own1-own0),3*n)),nnz=90,comm=comm)
    A.setBlockSize(3)
    A.setOption(PETSc.Mat.Option.NEW_NONZERO_ALLOCATION_ERR,False)
    chunk=2048
    for i in range(0,len(t),chunk):
        cells=t[i:i+chunk];g,V=kinematics(points,cells);K=stiffness(g,V,E,nu).reshape(-1,12,12)
        for ids,ke in zip(cells,K):A.setValuesBlocked(ids,ids,ke,addv=PETSc.InsertMode.ADD_VALUES)
    A.assemble();b=A.createVecRight();b.set(0)
    faces=np.load(root/c['loaded_faces'],mmap_mode='r');traction=np.asarray(c['reference_traction_Pa'],float)
    for i in range(len(faces)*rank//comm.size,len(faces)*(rank+1)//comm.size,chunk):
        tri=np.asarray(faces[i:min(i+chunk,len(faces)*(rank+1)//comm.size)]);q=points[tri]
        area=np.linalg.norm(np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]),axis=1)/2
        values=area[:,None,None]*np.broadcast_to(traction/3,(len(tri),3,3))
        b.setValues((3*tri[:,:,None]+np.arange(3)).ravel(),values.ravel(),addv=PETSc.InsertMode.ADD_VALUES)
    b.assemble();force=b.copy()
    fixed=np.load(root/c['fixed_nodes'],mmap_mode='r');fixed=np.asarray(fixed[(fixed>=own0)&(fixed<own1)],dtype=PETSc.IntType)
    constrained=(3*fixed[:,None]+np.arange(3)).ravel().astype(PETSc.IntType)
    A.zeroRowsColumns(constrained,diag=1)
    b.setValues(constrained,np.zeros(len(constrained)));b.assemble()
    # Six genuine translation/rotation near-nullspace vectors, no replicated global vectors.
    modes=[];coords=np.asarray(points[own0:own1]);centre=np.asarray(c['rotation_origin_m'])
    for j in range(6):
        v=A.createVecRight();local=v.getArray().reshape(-1,3);local[:]=0
        if j<3:local[:,j]=1
        else:local[:]=np.cross(np.eye(3)[j-3],coords-centre)
        v.setValues(constrained,np.zeros(len(constrained)));v.assemble();modes.append(v)
    for j,v in enumerate(modes):
        for q in modes[:j]:v.axpy(-q.dot(v),q)
        v.normalize()
    ns=PETSc.NullSpace().create(vectors=modes,comm=comm);A.setNearNullSpace(ns)
    u=A.createVecRight();ksp=PETSc.KSP().create(comm);ksp.setOperators(A);ksp.setType('cg');ksp.getPC().setType('gamg');ksp.setTolerances(rtol=1e-8,atol=0,max_it=5000);ksp.setFromOptions();ksp.solve(b,u)
    if ksp.getConvergedReason()<=0:raise RuntimeError('KSP did not converge; do not publish a solved native status')
    residual=b.duplicate();A.mult(u,residual);residual.axpy(-1,b);relative=residual.norm()/max(b.norm(),1e-300)
    needed=np.unique(t);ids=(3*needed[:,None]+np.arange(3)).ravel().astype(PETSc.IntType)
    local_u=PETSc.Vec().createSeq(len(ids),comm=PETSc.COMM_SELF)
    scatter=PETSc.Scatter().create(u,PETSc.IS().createGeneral(ids,comm=PETSc.COMM_SELF),local_u,PETSc.IS().createStride(len(ids),comm=PETSc.COMM_SELF))
    scatter.scatter(u,local_u,addv=PETSc.InsertMode.INSERT,mode=PETSc.ScatterMode.FORWARD)
    values=local_u.getArray(readonly=True).reshape(-1,3);cell_values=values[np.searchsorted(needed,t)]
    g,V=kinematics(points,t);stress,strain,vm=tensors(g,cell_values,E,nu)
    internal=force.duplicate();internal.set(0);local_f=np.einsum('eij,eaj,e->eai',stress,g,V)
    internal.setValues((3*t[:,:,None]+np.arange(3)).ravel(),local_f.ravel(),addv=PETSc.InsertMode.ADD_VALUES);internal.assemble();internal.axpy(-1,force)
    owned=internal.getArray(readonly=True).reshape(-1,3);free=np.ones(own1-own0,bool);free[fixed-own0]=False
    free_norm=np.sqrt(comm.allreduce(float(np.sum(owned[free]**2)),op=MPI.SUM))/max(force.norm(),1e-300)
    reaction=owned[~free].sum(0);applied=force.getArray(readonly=True).reshape(-1,3).sum(0)
    net=comm.allreduce(reaction+applied,op=MPI.SUM);total_force=comm.allreduce(applied,op=MPI.SUM)
    balance=np.linalg.norm(net)/max(np.linalg.norm(total_force),1e-300)
    energy=comm.allreduce(float(.5*np.sum(V[:,None,None]*stress*strain)),op=MPI.SUM)
    work=.5*force.dot(u);energy_error=abs(energy-work)/max(abs(energy),1e-300)
    wrench=force.getArray(readonly=True).reshape(-1,3).copy();wrench[~free]+=owned[~free]
    moment=comm.allreduce(np.cross(coords,wrench).sum(0),op=MPI.SUM)
    span=max(comm.allreduce(float(coords[:,j].max()),op=MPI.MAX)-comm.allreduce(float(coords[:,j].min()),op=MPI.MIN) for j in range(3))
    moment_error=np.linalg.norm(moment)/max(np.linalg.norm(total_force)*span,1e-300)
    boundary_nodes=np.load(root/c['boundary_nodes'],mmap_mode='r') if c.get('boundary_nodes') else None
    if boundary_nodes is not None:
        ix=np.searchsorted(boundary_nodes,t);adjacent=np.any((ix<len(boundary_nodes))&(boundary_nodes[np.minimum(ix,len(boundary_nodes)-1)]==t),axis=1)
    else:adjacent=np.zeros(len(t),bool)
    np.savez(out/f'cells-rank-{rank:05d}.npz',global_cell_begin=begin,tets=t,volume_m3=V,cauchy_stress_Pa=stress,strain=strain,von_mises_Pa=vm,boundary_adjacent=adjacent)
    viewer=PETSc.Viewer().createBinary(str(out/'displacement.petsc'),mode='w',comm=comm);u.view(viewer);viewer.destroy()
    if max(relative,free_norm,balance,moment_error,energy_error)>1e-6:raise RuntimeError('Independent element-force readback failed')
    result=dict(status='verified_discrete_linear_equilibrium',domain=c['domain'],nominal_height_mm=c['nominal_height_mm'],ranks=comm.size,nodes=n,tetrahedra=len(all_t),free_residual=free_norm,KSP_true_residual=relative,force_balance=balance,moment_balance=moment_error,energy_work_relative_error=energy_error,energy_J=energy,iterations=ksp.getIterationNumber(),runtime_seconds=time.monotonic()-start,native_geometry_audit=c['geometry_audit'],scope='Actual certified input mesh; not a contact, fracture, shock or continuum-convergence result')
    if rank==0:(out/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':main()
