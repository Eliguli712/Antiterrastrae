"""Actual 3D cavity and filled-domain solves, never labelled native CT results."""
from pathlib import Path
import json,itertools
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve
from elasticity import kinematics,stiffness,tensors,boundary

def mesh(filled):
    n=8;pts=np.array(list(itertools.product(range(n+1),repeat=3)),float)/n
    def idx(p):return (p[0]*(n+1)+p[1])*(n+1)+p[2]
    cells=[]
    for base in itertools.product(range(n),repeat=3):
        if not filled and all(3<=x<5 for x in base):continue
        for order in itertools.permutations(range(3)):
            q=np.array(base);c=[idx(q)]
            for k in order:q=q.copy();q[k]+=1;c.append(idx(q))
            cells.append(c)
    t=np.array(cells);used=np.unique(t);return pts[used],np.searchsorted(used,t)

def solve(filled,size):
    pts,t=mesh(filled);pts*=size/1000;g,V=kinematics(pts,t);K=stiffness(g,V,3e9,.3).reshape(-1,12,12);dof=(3*t[:,:,None]+np.arange(3)).reshape(-1,12)
    A=coo_matrix((K.ravel(),(np.repeat(dof,12,1).ravel(),np.tile(dof,(1,12)).ravel())),shape=(3*len(pts),)*2).tocsr()
    faces,owners=boundary(t);fixed=np.flatnonzero(pts[:,0]==0);loaded=faces[np.all(pts[faces,0]==size/1000,axis=1)]
    q=pts[loaded];area=np.linalg.norm(np.cross(q[:,1]-q[:,0],q[:,2]-q[:,0]),axis=1)/2;force=np.zeros_like(pts)
    for i in range(3):np.add.at(force,loaded[:,i],area[:,None]*np.array([1e6/3,0,0]))
    free=np.setdiff1d(np.arange(3*len(pts)),(3*fixed[:,None]+np.arange(3)).ravel());u=np.zeros(3*len(pts));u[free]=spsolve(A[free][:,free],force.ravel()[free]);r=A@u-force.ravel();res=np.linalg.norm(r[free])/np.linalg.norm(force);reaction=r.reshape(-1,3)[fixed].sum(0)
    stress,strain,vm=tensors(g,u.reshape(-1,3)[t],3e9,.3);internal=np.zeros_like(pts);local=np.einsum('eij,eaj,e->eai',stress,g,V)
    for j in range(4):np.add.at(internal,t[:,j],local[:,j])
    tensor_gap=np.linalg.norm(internal.ravel()-A@u)/np.linalg.norm(A@u);balance=np.linalg.norm(reaction+force.sum(0))/np.linalg.norm(force.sum(0));energy=.5*u@(A@u)
    assert max(res,balance,tensor_gap)<1e-10
    assert abs(V.sum()/(size/1000)**3-(1 if filled else 504/512))<1e-13
    # The shared kernel must annihilate arbitrary infinitesimal rigid motions.
    rigid=np.cross(np.array([.1,-.2,.3]),pts)+[.03,.02,-.01]
    assert np.linalg.norm(A@rigid.ravel())/np.linalg.norm(A.data)<1e-14
    return dict(domain='filled' if filled else 'preserved_cavity',height_mm=size,nodes=len(pts),tetrahedra=len(t),boundary_triangles=len(faces),boundary_adjacent_tetrahedra=len(np.unique(owners)),material_volume_m3=float(V.sum()),residual=res,independent_kernel_relative_gap=tensor_gap,force_balance=balance,energy_J=energy,max_displacement_m=float(np.linalg.norm(u.reshape(-1,3),axis=1).max()),stress_max_Pa=float(vm.max()))

def main():
    rows=[solve(filled,size) for filled in [False,True] for size in [50,100]]
    for i in [0,2]:
        assert abs(rows[i+1]['stress_max_Pa']/rows[i]['stress_max_Pa']-1)<1e-10
        assert abs(rows[i+1]['max_displacement_m']/rows[i]['max_displacement_m']-2)<1e-10
    report=dict(status='passed',cases=rows,scope='Four independently assembled synthetic 3D solves only; no native tetrahedra generated, no MPI execution or scalability claim',native_completed_tetrahedra=0)
    out=Path(__file__).resolve().parents[1]/'review/synthetic_kernel_validation.json';out.parent.mkdir(exist_ok=True);out.write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

if __name__=='__main__':main()
