"""Write the unchanged native PLC for a large-memory constrained mesher.

This stage deliberately requires independently checked embedding and cavity seeds.
Watertightness alone is insufficient for an embedded cavity complex.
"""
from pathlib import Path
import argparse,hashlib,json
import numpy as np

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--vertices',type=Path,required=True);ap.add_argument('--faces',type=Path,required=True);ap.add_argument('--void-seeds',type=Path,required=True);ap.add_argument('--audit',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--domain',choices=['preserve','filled'],required=True)
    a=ap.parse_args();v=np.load(a.vertices,mmap_mode='r');f=np.load(a.faces,mmap_mode='r');seeds=np.load(a.void_seeds,mmap_mode='r');record=json.loads(a.audit.read_text())
    for key in ['embedded_shells','shell_containment','seeds_strictly_inside_voids','source_hashes_verified']:
        if record.get(key) is not True:raise ValueError('Geometry gate pending: '+key)
    if a.domain=='preserve' and (len(v)!=37951699 or len(f)!=74293846 or len(seeds)!=803442):raise ValueError('Native boundary/cavity count differs')
    if a.domain=='filled' and len(seeds):raise ValueError('Distinct filled-domain PLC has no excluded cavity seeds')
    a.output.mkdir(parents=True,exist_ok=False)
    with (a.output/'domain.node').open('w') as out:
        out.write(f'{len(v)} 3 0 1\n')
        for begin in range(0,len(v),50000):
            for i,p in enumerate(v[begin:begin+50000],begin):out.write(f'{i} {p[0]:.17g} {p[1]:.17g} {p[2]:.17g} 1\n')
    with (a.output/'domain.poly').open('w') as out:
        out.write('0 3 0 1\n'+str(len(f))+' 1\n')
        for begin in range(0,len(f),50000):
            for tri in f[begin:begin+50000]:out.write(f'1 0 1\n3 {tri[0]} {tri[1]} {tri[2]}\n')
        out.write(str(len(seeds))+'\n')
        for i,p in enumerate(seeds):out.write(f'{i} {p[0]:.17g} {p[1]:.17g} {p[2]:.17g}\n')
        out.write('0\n')
    report=dict(status='PLC_written_not_meshed',domain=a.domain,vertices=len(v),faces=len(f),excluded_voids=len(seeds),no_vertex_movement=True,no_smoothing=True,no_decimation=True,mesher_command='tetgen -pYzMJC domain.poly',scope='TetGen is a large-memory meshing stage, not an MPI mesher. Do not promise a tetrahedron count or valid-quality mesh before execution.',inputs={str(p):hashlib.file_digest(p.open('rb'),'sha256').hexdigest() for p in [a.vertices,a.faces,a.void_seeds,a.audit]})
    (a.output/'preparation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))

if __name__=='__main__':main()
