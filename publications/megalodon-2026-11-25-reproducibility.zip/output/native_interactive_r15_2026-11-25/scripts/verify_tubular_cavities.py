"""Check every display trace directly against its source CT and mesh envelope."""
from pathlib import Path
import csv
import json
import hashlib
import time
import zlib
import numpy as np
from scipy import ndimage as ndi
from scipy.spatial import cKDTree

root=Path(__file__).resolve().parents[3]
out=root/'output/native_interactive_r15_2026-11-25'
data=out/'source-owned/design/megalodon/assets/native-microtubes.json'
report_dir=out/'review/microtubes'
mask_file=root/'output/ct_web_2026-11-19/cache/selected_native_mask.u8'
record=json.loads(data.read_text())
s=record['native_voxel_spacing_mm']
origin=np.array(record['registered_web_mesh_origin_xyz_mm'])
shape=tuple(record['native_voxel_source_shape_zyx'])
source=np.memmap(mask_file,dtype='u1',mode='r',shape=shape)
envelopes={int(r['mesh_component']):r for r in csv.DictReader((report_dir/'inner-shells.csv').open())}
total=0
max_step_residual=0.0
diameter_agreement=0.0
started=time.monotonic()
for t in record['traces']:
    envelope=envelopes[t['mesh_component']]
    low_xyz=np.array([float(envelope[f'min_{d}']) for d in 'xyz'])
    high_xyz=np.array([float(envelope[f'max_{d}']) for d in 'xyz'])
    xyz=np.array(t['points_registered_native_xyz_mm'])
    native=np.rint((xyz-origin)/s).astype(int)
    native_zyx=native[:,::-1]
    assert np.allclose(xyz,native*s+origin,rtol=0,atol=3e-6)
    assert np.all(source[tuple(native_zyx.T)]==0)
    assert np.all(np.abs(np.diff(native_zyx,axis=0))<=1)
    measured_length=np.linalg.norm(np.diff(xyz,axis=0),axis=1).sum()
    max_step_residual=max(max_step_residual,abs(measured_length-t['trace_length_mm']))
    # Propagate from a single trace node using only six face-neighbours.
    # This independently checks both common component membership and seal.
    lo=np.maximum(0,np.floor((low_xyz-origin)[::-1]/s).astype(int)-4)
    hi=np.minimum(shape,np.ceil((high_xyz-origin)[::-1]/s).astype(int)+5)
    native_box=tuple(slice(a,b) for a,b in zip(lo,hi))
    box_void=(source[native_box]==0)
    seed=np.zeros_like(box_void)
    local_points=native_zyx-lo
    seed[tuple(local_points[0])]=True
    region=ndi.binary_propagation(seed,mask=box_void,structure=ndi.generate_binary_structure(3,1))
    assert all(not np.any(np.take(region,[0,region.shape[axis]-1],axis=axis)) for axis in range(3))
    assert np.all(region[tuple(local_points.T)])
    assert int(region.sum())==t['mask_component_voxels']
    # A kd-tree nearest-neighbour query against actual material centres checks
    # radius independently of the EDT used by the trace generator.
    points=cKDTree(np.argwhere(~box_void))
    radius=points.query(local_points)[0]
    diameter_agreement=max(diameter_agreement,abs(2*np.median(radius)*s-t['median_native_diameter_mm']))
    total+=len(native)
with mask_file.open('rb') as f:
    actual_hash=hashlib.file_digest(f,'sha256').hexdigest()
assert actual_hash==record['native_raw_u8_sha256']
# Independently decompress the original MHA and compare complete mask bytes.
mha=root/'full_3D'/record['original_mha_filename']
with mha.open('rb') as f:
    archive_hash=hashlib.file_digest(f,'sha256').hexdigest()
assert archive_hash==record['original_mha_sha256']
uncompressed=hashlib.sha256()
with mha.open('rb') as f:
    header={}
    while line:=f.readline():
        k,v=line.strip().decode('ascii').split(' = ',1)
        header[k]=v
        if k=='ElementDataFile':
            break
    assert header['ElementDataFile']=='LOCAL'
    assert np.allclose(np.fromstring(header['Offset'],sep=' '),record['original_mha_patient_offset_xyz_mm'])
    assert tuple(np.fromstring(header['DimSize'],sep=' ',dtype=int)[::-1])==shape
    decompress=zlib.decompressobj()
    while chunk:=f.read(65536):
        uncompressed.update(decompress.decompress(chunk))
    uncompressed.update(decompress.flush())
assert uncompressed.hexdigest()==actual_hash
assert max_step_residual<6e-6 and diameter_agreement<6e-6
audit={
    'candidate_paths_checked':len(record['traces']),
    'original_mask_points_checked':total,
    'closed_six_neighbour_membership':'independently confirmed by seeded propagation from each path',
    'checked_source_mask_sha256':actual_hash,
    'checked_original_mha_sha256':archive_hash,
    'mha_payload_matches_registered_web_mask':True,
    'max_length_residual_mm':max_step_residual,
    'max_material_diameter_residual_mm':diameter_agreement,
    'duration_seconds':round(time.monotonic()-started,3),
    'status':'verified'
}
(report_dir/'coordinate-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
print(json.dumps(audit),flush=True)
