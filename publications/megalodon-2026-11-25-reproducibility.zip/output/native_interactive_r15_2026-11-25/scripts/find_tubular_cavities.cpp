#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <fcntl.h>
#include <limits>
#include <numeric>
#include <stdexcept>
#include <string>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <vector>

// Vertices are already unique in the exact native surface export. Sign is
// measured independently of topology with the oriented tetrahedron sum.
constexpr uint32_t vertices = 37951699;
constexpr uint32_t faces = 74293846;
constexpr uint32_t none = std::numeric_limits<uint32_t>::max();
template<class T> struct Map {
    const T* data;
    size_t bytes;
    explicit Map(const char* path, size_t count) : bytes(count * sizeof(T)) {
        int fd = open(path, O_RDONLY);
        struct stat st;
        if (fd < 0 || fstat(fd, &st) || size_t(st.st_size) != bytes)
            throw std::runtime_error(std::string("Wrong input size: ") + path);
        data = static_cast<const T*>(mmap(nullptr, bytes, PROT_READ, MAP_PRIVATE, fd, 0));
        close(fd);
        if (data == MAP_FAILED) throw std::runtime_error("mmap failed");
    }
    ~Map() { munmap(const_cast<T*>(data), bytes); }
};
struct Bounds {
    std::array<float, 3> low, high;
    uint32_t size = 0;
    uint32_t triangles = 0;
    double volume6 = 0.;
    explicit Bounds(const float* point) {
        std::copy(point, point+3, low.begin());
        high = low;
    }
    void add(const float* point) {
        for (int j=0;j<3;++j) {
            low[j] = std::min(low[j], point[j]);
            high[j] = std::max(high[j], point[j]);
        }
        ++size;
    }
};
int main(int argc, char** argv) {
    if (argc != 3) { fprintf(stderr, "usage: find_tubular_cavities vertices.f32 triangles.u32\n"); return 2; }
    Map<float> v(argv[1], size_t(vertices)*3);
    Map<uint32_t> f(argv[2], size_t(faces)*3);
    std::vector<uint32_t> parent(vertices);
    std::iota(parent.begin(), parent.end(), 0u);
    std::vector<uint8_t> rank(vertices);
    auto root = [&](uint32_t x) {
        while (parent[x] != x) {
            parent[x] = parent[parent[x]];
            x = parent[x];
        }
        return x;
    };
    auto join = [&](uint32_t a,uint32_t b) {
        a = root(a);
        b = root(b);
        if (a==b) return;
        if (rank[a]<rank[b]) std::swap(a,b);
        parent[b]=a;
        if (rank[a]==rank[b]) ++rank[a];
    };
    for (size_t i=0;i<size_t(faces)*3;i+=3) {
        const uint32_t a=f.data[i], b=f.data[i+1], c=f.data[i+2];
        if (std::max({a,b,c})>=vertices) throw std::runtime_error("Out-of-range face index");
        join(a,b); join(a,c);
    }
    fprintf(stderr, "Face connectivity complete.\n");
    std::vector<uint8_t>().swap(rank);
    std::vector<uint32_t> lookup(vertices, none);
    std::vector<Bounds> bounds;
    bounds.reserve(810000);
    for (uint32_t i=0;i<vertices;++i) {
        const auto r=root(i);
        parent[i]=r;
        const auto p=v.data+size_t(i)*3;
        if (lookup[r]==none) {
            lookup[r]=uint32_t(bounds.size());
            bounds.emplace_back(p);
        }
        bounds[lookup[r]].add(p);
    }
    for (auto& x : parent) x=lookup[x];
    std::vector<uint32_t>().swap(lookup);
    for (size_t i=0;i<size_t(faces)*3;i+=3) {
        auto& b=bounds[parent[f.data[i]]];
        const float* p=v.data+size_t(f.data[i])*3;
        const float* q=v.data+size_t(f.data[i+1])*3;
        const float* r=v.data+size_t(f.data[i+2])*3;
        double a[3], u[3], w[3];
        for (int j=0;j<3;++j) {
            a[j]=double(p[j])-b.low[j];
            u[j]=double(q[j])-b.low[j];
            w[j]=double(r[j])-b.low[j];
        }
        b.volume6 += a[0]*(u[1]*w[2]-u[2]*w[1])-a[1]*(u[0]*w[2]-u[2]*w[0])+a[2]*(u[0]*w[1]-u[1]*w[0]);
        ++b.triangles;
    }
    size_t negative=0,positive=0;
    for (auto& b:bounds) if (b.volume6<0.) ++negative; else if (b.volume6>0.) ++positive;
    fprintf(stderr,"Surface components %zu, inward %zu, outward %zu\n",bounds.size(),negative,positive);
    puts("mesh_component,vertices,triangles,signed_volume_mm3,min_x,min_y,min_z,max_x,max_y,max_z");
    for (size_t i=0;i<bounds.size();++i) {
        const auto& b=bounds[i];
        const double dx=b.high[0]-b.low[0],dy=b.high[1]-b.low[1],dz=b.high[2]-b.low[2];
        const double diagonal=std::sqrt(dx*dx+dy*dy+dz*dz);
        if (b.volume6>=0.||diagonal<.20||b.size<32) continue;
        printf("%zu,%u,%u,%.10g,%.8f,%.8f,%.8f,%.8f,%.8f,%.8f\n",
          i,b.size,b.triangles,b.volume6/6.,b.low[0],b.low[1],b.low[2],b.high[0],b.high[1],b.high[2]);
    }
}
