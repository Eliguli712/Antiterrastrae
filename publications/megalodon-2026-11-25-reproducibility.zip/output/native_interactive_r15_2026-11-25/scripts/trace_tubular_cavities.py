"""Centrelines of elongated, closed, six-connected cavities in the original CT mask.

Inward mesh shells are a search index. ROI flood labels, skeletons, and centreline
membership come from the untouched native binary mask. The output is a bounded
set of image-derived candidates, not a histological annotation.
"""
from __future__ import annotations

import argparse
import collections
import csv
import json
from pathlib import Path

import numpy as np
from scipy import ndimage as ndi
from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import connected_components, dijkstra
from scipy.spatial import cKDTree
from skimage.morphology import skeletonize

SPACING = 0.018
ORIGIN = np.array([7.056, 1.368, 1.368])
SHAPE = (2886, 1903, 746)
PAD = 3
MIN_BBOX_DIAGONAL = .30
MAX_ROI = 31_000_000
MIN_TUBE_SPAN = .24
MIN_EIGENVALUE_RATIO = 2.0
MIN_ASPECT = 3.0
DISPLAY_LIMIT = 64


def fit_component(mask, row):
    lows = np.asarray([float(row[f"min_{axis}"]) for axis in "xyz"])
    highs = np.asarray([float(row[f"max_{axis}"]) for axis in "xyz"])
    first = np.maximum(0, np.floor((lows-ORIGIN)/SPACING).astype(int)[::-1]-PAD)
    last = np.minimum(SHAPE, np.ceil((highs-ORIGIN)/SPACING).astype(int)[::-1]+PAD+1)
    if np.prod(last-first) > MAX_ROI:
        return None, "oversize mesh envelope"
    if np.any(last <= first):
        return None, "invalid mesh envelope"
    binary = mask[tuple(slice(a, b) for a, b in zip(first,last))] == 0
    labels, count = ndi.label(binary, structure=ndi.generate_binary_structure(3,1))
    exterior = np.zeros(count+1,dtype=bool)
    for axis in range(3):
        exterior[np.unique(np.take(labels, [0, labels.shape[axis]-1], axis=axis))] = True
    exterior[0] = True
    boxes = ndi.find_objects(labels)
    expected = np.r_[lows, highs]
    best = None
    for label, box in enumerate(boxes, 1):
        if exterior[label] or box is None:
            continue
        xyz_low = ORIGIN+(first+np.array([x.start for x in box]))[::-1]*SPACING-SPACING*.5
        xyz_high = ORIGIN+(first+np.array([x.stop-1 for x in box]))[::-1]*SPACING+SPACING*.5
        error = np.abs(np.r_[xyz_low, xyz_high]-expected)
        if max(error) > SPACING*2.00 + 1e-5:
            continue
        score = float(error.sum())
        if best is None or score < best[0]:
            best = (score,label,box)
    if best is None:
        return None, "no matching sealed mask component"
    score, label, box = best
    tight = labels[box] == label
    base = first + np.array([axis.start for axis in box]) - 1
    cavity = np.pad(tight, 1)
    return (cavity,base,score), None


def principal_trace(cavity):
    points = np.argwhere(cavity)
    if len(points)<12:
        return None,"small mask cavity"
    covariance=np.cov(points.T)
    values=np.linalg.eigvalsh(covariance)
    eigen_ratio=float(values[2]/max(values[1],.01))
    if eigen_ratio<MIN_EIGENVALUE_RATIO:
        return None,"not elongated by covariance"
    skeleton = np.argwhere(skeletonize(cavity,method="lee")).astype(np.int32)
    if len(skeleton)<4:
        return None,"no stable centreline"
    pairs=cKDTree(skeleton).query_pairs(np.sqrt(3.0)+1e-9,output_type="ndarray")
    if len(pairs)==0:
        return None,"no connected centreline"
    a,b=pairs.T
    steps=np.linalg.norm(skeleton[a]-skeleton[b],axis=1)*SPACING
    graph=csr_matrix((np.r_[steps,steps],(np.r_[a,b],np.r_[b,a])),
                     shape=(len(skeleton),len(skeleton)))
    _, component = connected_components(graph, directed=False)
    biggest = int(np.argmax(np.bincount(component)))
    selected = np.flatnonzero(component == biggest)
    # Use the longest of sweeps from the extremal coordinates, rather than
    # claim a general graph diameter from a single double sweep.
    seeds=np.unique(np.r_[selected[0],selected[np.argmax(skeleton[selected],axis=0)],
                          selected[np.argmin(skeleton[selected],axis=0)]])
    distances = dijkstra(graph,directed=False,indices=seeds)
    best_seed,best_end=np.unravel_index(np.argmax(np.where(np.isfinite(distances),distances,-1)),distances.shape)
    d, predecessor = dijkstra(graph,directed=False,indices=int(seeds[best_seed]),return_predecessors=True)
    chain=[int(best_end)]
    while chain[-1]!=seeds[best_seed]:
        chain.append(int(predecessor[chain[-1]]))
    chain=np.asarray(chain[::-1],dtype=np.int32)
    trace=skeleton[chain]
    length=float(d[best_end])
    chord=float(np.linalg.norm(trace[-1]-trace[0])*SPACING)
    diameter=2*float(np.median(ndi.distance_transform_edt(cavity)[tuple(trace.T)]))*SPACING
    # Exclude non-elongate meanders with a nearly coincident start and finish.
    if chord < MIN_TUBE_SPAN or length / diameter < MIN_ASPECT or chord / length < .32:
        return None,"short or compact trace"
    assert np.all(cavity[tuple(trace.T)])
    assert np.all(np.max(np.abs(np.diff(trace,axis=0)),axis=1) <= 1)
    return (trace,length,chord,diameter,eigen_ratio,len(points),len(selected)),None


def run(args):
    mask=np.memmap(args.mask,dtype="u1",mode="r",shape=SHAPE)
    rows=list(csv.DictReader(args.shells.open()))
    selected=sorted(rows,key=lambda r:-sum(
        (float(r[f"max_{a}"])-float(r[f"min_{a}"]))**2 for a in "xyz"))
    accepted=[]
    rejected=collections.Counter()
    buckets=set()
    considered = 0
    for row in selected:
        diagonal=np.linalg.norm([float(row[f"max_{a}"])-float(row[f"min_{a}"]) for a in "xyz"])
        if diagonal < MIN_BBOX_DIAGONAL:
            break
        considered += 1
        match,reason=fit_component(mask,row)
        if match is None:
            rejected[reason]+=1
            continue
        cavity,base,edge_deviation=match
        line,reason=principal_trace(cavity)
        if line is None:
            rejected[reason]+=1
            continue
        trace,length,chord,diameter,ratio,voxel_count,connected_points=line
        locations=(trace+base)[:,::-1]
        # Guard against different mesh shells selecting the same mask component.
        key=(tuple(locations.min(axis=0)),tuple(locations.max(axis=0)),voxel_count)
        if key in buckets:
            rejected["duplicate mask trace"]+=1
            continue
        buckets.add(key)
        assert not np.any(mask[tuple((trace+base).T)])
        xyz = np.round(ORIGIN+locations*SPACING,5)
        accepted.append({
            "mesh_component":int(row["mesh_component"]),
            "mask_component_voxels":voxel_count,
            "trace_length_mm":round(length,5),
            "trace_chord_mm":round(chord,5),
            "median_native_diameter_mm":round(diameter,5),
            "variance_ratio_first_to_second":round(ratio,5),
            "bounding_fit_sum_abs_mm":round(edge_deviation,5),
            "selected_skeleton_component_voxels":connected_points,
            "points_registered_native_xyz_mm": xyz.tolist()
        })
        if considered%100==0:
            print(f"Checked {considered}, traced {len(accepted)}",flush=True)

    accepted.sort(key=lambda t:-t["trace_length_mm"])
    display=accepted[:DISPLAY_LIMIT]
    assert len(display)>=8 and all(x["mask_component_voxels"]>=len(x["points_registered_native_xyz_mm"]) for x in display)
    for i,t in enumerate(display,1):
        t["id"]=i
    record={
        "schema":"native-ct-tubular-cavity-traces-v1",
        "name":"Tubular CT cavity candidates",
        "native_voxel_spacing_mm":SPACING,
        "native_voxel_source_shape_zyx":list(SHAPE),
        "registered_web_mesh_origin_xyz_mm":ORIGIN.tolist(),
        "original_mha_patient_offset_xyz_mm":[11.232,1.566,18.186],
        "registration":"The same native lattice is translated from the MHA patient origin to the registered web mesh origin. The viewer then applies its documented display affine.",
        "original_mha_filename":"Megalodon_FullCT_SpecimenMask_18um.mha",
        "original_mha_sha256":"8a68259cc4c079eaef5ec604e60bea2de6bf8bf4ebb7d9499347651676e19bce",
        "native_raw_u8_sha256":"d8b630b35c365f861ccc46d625a28cad21395055271f9cc937d9a9211c02a543",
        "native_mesh_source_3mf_sha256":"69928fc1d776a0cb2cd3da389802e0b08d226395005bbf4a2094180e90622b73",
        "mask_semantics":"Selected mineralized material is 1; background or CT void is 0.",
        "survey":{
            "source_faces":74293846,
            "source_vertices":37951699,
            "inward_mesh_components":803442,
            "mesh_envelopes_after_size_filter":len(rows),
            "mesh_envelopes_checked":considered,
            "traces_qualified":len(accepted),
            "traces_displayed":len(display),
            "display_selection":"Longest sampled principal centrelines among the qualified candidates.",
            "filters":{"minimum_bbox_diagonal_mm":MIN_BBOX_DIAGONAL,
                       "maximum_roi_voxels":MAX_ROI,
                       "minimum_chord_mm":MIN_TUBE_SPAN,
                       "minimum_first_to_second_variance_ratio":MIN_EIGENVALUE_RATIO,
                       "minimum_trace_to_median_diameter_ratio":MIN_ASPECT,
                       "display_limit":DISPLAY_LIMIT},
            "rejections":rejected
        },
        "method":"Inward signed-volume mesh components propose local envelopes. Face-connected voids touching the padded crop boundary are rejected. The closest sealed component within two native samples of each envelope face is thinned with the Lee algorithm. Connected skeleton paths are sampled between extremal coordinates; the longest measured path is retained. Every trace node is independently checked against the original zero-valued mask.",
        "native_diameter_estimator":"Twice the median Euclidean distance from traced voxel centres to the nearest selected-material voxel centre. A discrete geometric estimate on the 18 µm sampling grid.",
        "display":"Interactive X-ray tube sweep along voxel centres. A visible minimum diameter of 0.16 mm in native CT coordinates can exaggerate thin candidates. Measured diameters remain unmodified in this record.",
        "interpretation":"These are candidate tubular CT voids. The chosen subset excludes surface-connected channels, structures outside the tested bounds, and cavities with ambiguous paths. It does not identify vasculature, dentinal tubules, material composition, or a complete biological network.",
        "literature_context":[
            {"doi":"10.1038/s41598-019-46081-3","title":"Micro-computed tomography imaging reveals the development of a unique tooth mineralization pattern in mackerel sharks"},
            {"doi":"10.7717/peerj.12775","title":"Dental pathologies in lamniform and carcharhiniform sharks"}
        ],
        "traces":display
    }
    args.output.write_text(json.dumps(record,separators=(",",":"),ensure_ascii=False)+"\n")
    print(json.dumps(record["survey"],indent=2),flush=True)


if __name__ == "__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("--mask",type=Path,required=True)
    ap.add_argument("--shells",type=Path,required=True)
    ap.add_argument("--output",type=Path,required=True)
    run(ap.parse_args())
