from pathlib import Path
import re

N=Path(__file__).resolve().parents[1]
SITE=N.parents[2]/'output/antiterrastrae_publish'
D=SITE/'design/megalodon'
html=(D/'index.html').read_text()
boundary=re.search(r'<label class="check-label"><input[^>]*id="showBoundary".*?</label>',html).group()
controls='''<details class="fixation-controls"><summary data-t="supportDisplay">Support &amp; contact display</summary><label class="check-label"><input id="showSupport" type="checkbox" checked/><span data-t="showSupport">Show the root support</span></label>'''+boundary+'''<p id="supportVisibilityStatus" role="status" aria-live="polite"></p></details>'''
assert 'id="showSupport"' not in html
html=html.replace(boundary,controls)
panel='''<div class="ct-movie-grid">
<article class="ct-movie-card"><h3 data-t="broadfaceTitle">Along the natural tooth plane</h3><p data-t="broadfaceIntro">A longitudinal plane stays parallel to the crown–root face and moves through the tooth’s thickness. The apex points upward; both roots remain below.</p><video id="ctBroadface" controls playsinline preload="metadata" poster="assets/ct-r10/CT_broadface_poster.jpg"><source src="assets/ct-r10/CT_broadface_longitudinal_3050.mp4" type="video/mp4"/><a href="assets/ct-r10/CT_broadface_longitudinal_3050.mp4">Play or download MP4</a></video><div class="ct-downloads"><a href="assets/ct-r10/CT_broadface_longitudinal_3050.mp4" download>MP4 · 1920 × 1080</a><a href="assets/ct-r10/CT_broadface_longitudinal_3050.gif" download>Animated GIF</a><a href="assets/ct-r10/broadface_frame_coordinates.csv" download data-t="framePositions">Frame positions &amp; line data</a></div></article>
<article class="ct-movie-card"><h3 data-t="threeAxesTitle">Three calibrated directions</h3><p data-t="threeAxesIntro">Axial, coronal and sagittal scans show the selected specimen, with moving area and mean-intensity lines in the measured scanner coordinate frame.</p><video id="ctThreeAxes" controls playsinline preload="metadata" poster="assets/ct-r10/CT_three_axes_poster.jpg"><source src="assets/ct-r10/CT_specimen_three_axes_3050.mp4" type="video/mp4"/><a href="assets/ct-r10/CT_specimen_three_axes_3050.mp4">Play or download MP4</a></video><div class="ct-downloads"><a href="assets/ct-r10/CT_specimen_three_axes_3050.mp4" download>MP4 · 1920 × 1080</a><a href="assets/ct-r10/CT_specimen_three_axes_3050.gif" download>Animated GIF</a><a href="assets/ct-r10/three_axes_frame_coordinates.csv" download data-t="framePositions">Frame positions &amp; line data</a></div></article>
</div><p class="caption" data-t="movieClock">Each movie contains 3,050 frames at 25 fps (122 seconds). Playback time is separate from scan acquisition, growth and mechanical time.</p><details class="ct-method-note"><summary data-t="scanDisplay">How these scans are displayed</summary><p data-t="scanDisplayNote">The original 18 µm specimen mask excludes surrounding scanner background; internal low-density spaces remain visible. This isolates the display and does not correct beam hardening or identify preserved soft tissue. The longitudinal movie reslices a documented 36 µm display cache on a 72 µm grid. It adds no acquired resolution and does not force the outline into a triangle. Area–intensity correlations describe spatially dependent sections, without biological significance tests.</p><a href="assets/ct-r10/media_manifest.json" data-t="scanRecord">Source, sampling and checksum record</a></details>'''
start=html.index('<section class="native-domain-section" id="internal">')
point=html.index('<div class="domain-grid">',start)
html=html[:point]+panel+html[point:]
html=html.replace('exhibition.js?v=r10-1','exhibition.js?v=r11-1')
html=html.replace('</head>','<link href="exhibition-ct-r11.css" rel="stylesheet"/></head>')
(D/'index.html').write_text(html)

js=(D/'exhibition.js').read_text()
js=js.replace("'./exhibition-i18n.js?v=r10-1'","'./exhibition-i18n.js?v=r11-1'")
js=js.replace("if(!$('showBoundary').checked){","if(!$('showBoundary').checked||!$('showSupport').checked||state.appearance==='art'){")
old="$('topSupportStress').onchange=()=>state.viewer?.setLayers?.({beam:$('topSupportStress').checked,sphere:$('topSupportStress').checked,resin:!$('topSupportStress').checked});"
assert old in js
js=js.replace(old,"$('topSupportStress').onchange=syncSupportVisibility;")
old="v.setLayers?.({beam:$('topSupportStress').checked,sphere:$('topSupportStress').checked,resin:!$('topSupportStress').checked});"
assert old in js
js=js.replace(old,"syncSupportVisibility();")
js=js.replace("v.showFixed($('showBoundary').checked);","v.showFixed(state.appearance!=='art'&&$('showSupport').checked&&$('showBoundary').checked);")
js=js.replace("state.appearance!=='art'&&$('showBoundary').checked","state.appearance!=='art'&&$('showSupport').checked&&$('showBoundary').checked")
js=js.replace("mode!=='art'&&$('showBoundary').checked","mode!=='art'&&$('showSupport').checked&&$('showBoundary').checked")
js=js.replace("state.viewer.setAppearance?.(state.appearance);$('nativeCanvas').hidden=false;","state.viewer.setAppearance?.(state.appearance);syncSupportVisibility();$('nativeCanvas').hidden=false;")
js=js.replace("quality();}\n$('artAppearance')","quality();leaders();}\n$('artAppearance')")
anchor="$('showBoundary').onchange="
idx=js.index(anchor)
js=js[:idx]+'''function syncSupportVisibility(){
 const visible=$('showSupport').checked,stress=$('topSupportStress').checked,v=state.viewer;
 v?.setLayers?.({beam:visible&&stress,sphere:visible&&stress,resin:visible&&!stress});
 v?.showFixed(state.appearance!=='art'&&visible&&$('showBoundary').checked);
 if(v?.ready){$('nativeCanvas').hidden=false;$('stageImageWrap').hidden=true;v.resize();}
 $('nativeStage').dataset.support=visible?'shown':'hidden';
 $('supportVisibilityStatus').textContent=t(visible?'supportShown':'supportHidden');
 leaders();
}
$('showSupport').onchange=syncSupportVisibility;
'''+js[idx:]
# Static plates contain the support; keeping it hidden requires the separable 3D view.
js=js.replace("$('completePlate').onclick=()=>{","$('completePlate').onclick=()=>{if(!$('showSupport').checked){syncSupportVisibility();return;}")
js=js.replace("$('showSupport').checked&&$('showSupport').checked", "$('showSupport').checked")
(D/'exhibition.js').write_text(js)

words={
 'supportDisplay':['Support & contact display','Stütze und Kontakt','Στήριξη και επαφή'],
 'showSupport':['Show the root support','Wurzelstütze anzeigen','Εμφάνιση στήριξης ρίζας'],
 'supportShown':['Root support visible.','Wurzelstütze sichtbar.','Η στήριξη ρίζας είναι ορατή.'],
 'supportHidden':['Tooth alone; support and fixed-region labels hidden.','Nur Zahn; Stütze und Fixierungsmarkierungen ausgeblendet.','Μόνο το δόντι· στήριξη και ενδείξεις πάκτωσης κρυμμένες.'],
 'broadfaceTitle':['Along the natural tooth plane','Entlang der natürlichen Zahnebene','Στο φυσικό επίπεδο του δοντιού'],
 'broadfaceIntro':['A longitudinal plane stays parallel to the crown–root face and moves through the tooth’s thickness. The apex points upward; both roots remain below.','Eine Längsebene bleibt parallel zur Kronen-Wurzel-Fläche und wandert durch die Zahndicke. Die Spitze zeigt nach oben, beide Wurzeln nach unten.','Ένα διαμήκες επίπεδο παραμένει παράλληλο στην όψη μύλης–ρίζας και διασχίζει το πάχος. Η κορυφή δείχνει επάνω και οι ρίζες κάτω.'],
 'threeAxesTitle':['Three calibrated directions','Drei kalibrierte Richtungen','Τρεις βαθμονομημένες διευθύνσεις'],
 'threeAxesIntro':['Axial, coronal and sagittal scans show the selected specimen, with moving area and mean-intensity lines in the measured scanner coordinate frame.','Axiale, koronale und sagittale Schnitte zeigen das ausgewählte Exemplar mit bewegten Flächen- und Intensitätskurven in gemessenen Scannerkoordinaten.','Αξονικές, στεφανιαίες και οβελιαίες τομές δείχνουν το δείγμα, με κινούμενες καμπύλες εμβαδού και μέσης έντασης στις συντεταγμένες του σαρωτή.'],
 'framePositions':['Frame positions & line data','Bildpositionen und Kurvendaten','Θέσεις καρέ και δεδομένα καμπυλών'],
 'movieClock':['Each movie contains 3,050 frames at 25 fps (122 seconds). Playback time is separate from scan acquisition, growth and mechanical time.','Jeder Film enthält 3.050 Bilder mit 25 fps (122 Sekunden). Wiedergabezeit ist unabhängig von Aufnahme-, Wachstums- und mechanischer Zeit.','Κάθε βίντεο περιέχει 3.050 καρέ στα 25 fps (122 δευτερόλεπτα). Ο χρόνος αναπαραγωγής διαφέρει από τον χρόνο σάρωσης, ανάπτυξης και μηχανικής.'],
 'scanDisplay':['How these scans are displayed','Darstellung dieser Schnitte','Πώς προβάλλονται οι τομές'],
 'scanDisplayNote':['The original 18 µm specimen mask excludes surrounding scanner background; internal low-density spaces remain visible. This isolates the display and does not correct beam hardening or identify preserved soft tissue. The longitudinal movie reslices a documented 36 µm display cache on a 72 µm grid. It adds no acquired resolution and does not force the outline into a triangle. Area–intensity correlations describe spatially dependent sections, without biological significance tests.','Die originale 18-µm-Maske blendet den Scannerhintergrund aus; innere Bereiche geringer Dichte bleiben sichtbar. Dies korrigiert keine Strahlaufhärtung und identifiziert kein erhaltenes Weichgewebe. Der Längsfilm nutzt dokumentierte 36-µm-Anzeigedaten auf einem 72-µm-Schnittgitter, ohne neue Aufnahmeauflösung oder erzwungene Dreiecksform. Korrelationen beschreiben räumlich abhängige Schnitte ohne biologische Signifikanztests.','Η αρχική μάσκα 18 µm αποκλείει το περιβάλλον του σαρωτή, διατηρώντας τους εσωτερικούς χώρους χαμηλής πυκνότητας. Δεν διορθώνει σκλήρυνση δέσμης ούτε αναγνωρίζει μαλακό ιστό. Το διαμήκες βίντεο χρησιμοποιεί τεκμηριωμένα δεδομένα προβολής 36 µm σε πλέγμα 72 µm, χωρίς νέα ανάλυση ή επιβολή τριγωνικού σχήματος. Οι συσχετίσεις περιγράφουν χωρικά εξαρτώμενες τομές χωρίς βιολογικούς ελέγχους σημαντικότητας.'],
 'scanRecord':['Source, sampling and checksum record','Quellen-, Abtastungs- und Prüfsummennachweis','Πηγές, δειγματοληψία και αθροίσματα ελέγχου'],
}
import json
with (D/'exhibition-i18n.js').open('a') as f:f.write('\nObject.assign(words,'+json.dumps(words,ensure_ascii=False)+');\n')
(D/'exhibition-ct-r11.css').write_text('''
.fixation-controls{border:1px solid #36535b;padding:.65rem .9rem;min-width:14rem;max-width:100%;text-align:left}
.fixation-controls summary{cursor:pointer;color:#b5d7cd;font-size:.88rem}
.fixation-controls .check-label{margin:.8rem 0}.fixation-controls p{font-size:.78rem;max-width:26rem;margin:.4rem 0 0;color:#9dbab4}
.stage-bottom{flex-wrap:wrap;align-items:flex-start}
.ct-movie-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:2rem;margin:2rem 0 1rem}
.ct-movie-card{min-width:0;border:1px solid #36535b;padding:1.2rem}
.ct-movie-card h3{font-family:Georgia,serif;font-size:1.65rem;margin:.2rem 0 .8rem;font-weight:400}
.ct-movie-card p{font-size:.95rem;line-height:1.65;color:#9dbab4;min-height:5rem}
.ct-movie-card video{display:block;width:100%;height:auto;aspect-ratio:16/9;background:#fff;object-fit:contain}
.ct-downloads{display:flex;gap:.8rem 1.2rem;flex-wrap:wrap;margin-top:1rem;font-size:.82rem}
.ct-downloads a{padding:.4rem 0;text-decoration:underline;text-underline-offset:4px}
.ct-method-note{border-bottom:1px solid #36535b;padding:1rem 0 1.5rem;margin-bottom:2rem}
.ct-method-note summary{cursor:pointer;color:#b5d7cd}.ct-method-note p{font-size:.9rem;line-height:1.7;color:#9dbab4;max-width:90ch}
@media(max-width:760px){.ct-movie-grid{grid-template-columns:1fr;gap:1.2rem}.ct-movie-card{padding:1rem}.ct-movie-card p{min-height:0}.fixation-controls{width:100%}.stage-bottom .gesture-help{width:100%}}
''')
print('Added CT playback/downloads and independent support visibility controls.')
