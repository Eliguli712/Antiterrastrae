#!/usr/bin/env python3
"""Independent displacement-to-stress reconstruction and final numeric readback.

This does not call the original assembly/recovery or quantile routines.
"""
from pathlib import Path
import csv,hashlib,json,time,argparse
import numpy as np
from scipy.stats import t
R=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--allow-missing-originals',action='store_true',help='For a portable copy: record unavailable original absolute paths without claiming to have verified them.')
args=parser.parse_args()
B=R.parent/'debunk_myth_full_reconstruction_2026-10-31'
if not B.exists():B=R/'supporting_baseline'
def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for x in iter(lambda:f.read(2**20),b''):h.update(x)
    return h.hexdigest()
started=time.monotonic();checks=[];sources={};cdf=[];last={}
for lev in range(3):
    path=B/f'numerics/L{lev}/solution.npz';sources[str(path)]=sha(path)
    a=np.load(path);p=a['points_m'];cells=a['tets'];u=a['displacement_m'];saved=a['element_von_mises_Pa'];vol=a['volumes_m3'];energy=0.;sse=0.;den=0.;peak=0.;vmax=0.
    for begin in range(0,len(cells),50000):
        c=cells[begin:begin+50000];x=p[c];du=u[c];D=x[:,1:]-x[:,:1];G=np.linalg.solve(D,du[:,1:]-du[:,:1]);strain=(G+G.transpose(0,2,1))/2
        stress=57e9*strain;stress[:,range(3),range(3)]+=29e9*np.trace(strain,axis1=1,axis2=2)[:,None]
        vm=np.sqrt(((stress[:,0,0]-stress[:,1,1])**2+(stress[:,1,1]-stress[:,2,2])**2+(stress[:,2,2]-stress[:,0,0])**2)/2+3*(stress[:,0,1]**2+stress[:,1,2]**2+stress[:,2,0]**2))
        vv=np.abs(np.linalg.det(D))/6;np.testing.assert_allclose(vv,vol[begin:begin+len(c)],rtol=1e-10,atol=1e-20)
        error=vm-saved[begin:begin+len(c)];sse+=float(error@error);den+=float(vm@vm);peak=max(peak,float(np.max(np.abs(error))))
        energy+=float(.5*np.sum(vv*np.einsum('nij,nij->n',stress,strain)))
    rel=(sse/den)**.5;assert rel<1e-9
    summary=json.load(open(B/f'numerics/L{lev}/summary.json'));np.testing.assert_allclose(energy,summary['strain_energy_J'],rtol=1e-9)
    assert np.max(np.abs(u[a['fixed_node_indices']]))==0
    masks=np.load(B/f'numerics/L{lev}/region_masks.npz')
    for row in summary['table9']:
        mask=masks[row['region']];x=saved[mask]/1e6;w=vol[mask];total=w.sum()
        np.testing.assert_allclose(total*1e9,row['volume_mm3'],rtol=1e-11)
        for prob,col in [(.9,'Q90_MPa'),(.95,'Q95_MPa'),(.99,'Q99_MPa')]:
            q=row[col];below=float(w[x<q*(1-2e-15)].sum()/total);at=float(w[x<=q*(1+2e-15)].sum()/total)
            assert below<prob+1e-12 and at>=prob-1e-12
            cdf.append(dict(level=lev,region=row['region'],q=prob,value_MPa=q,CDF_below=below,CDF_at=at))
        if lev==2:last[row['region']]=row
    checks.append(dict(level=lev,elements=len(cells),stress_recovery_relative_L2=rel,stress_recovery_max_abs_Pa=peak,recovered_energy_J=energy,all_support_displacements_zero=True))

rows=list(csv.DictReader(open(R/'numerics/curvature_study/simultaneous_statistics.csv')));ref=np.load(R/'numerics/curvature_study/reference_samples.npz')['curvature_reference'];eta=np.sqrt(np.log(2*51/.05)/(2*len(ref)));errmax=0.
for row in rows:
    j=['H','K','Habs'].index(row['field']);x=ref[:,j];y=np.load(R/f'numerics/curvature_study/{row["run"]}_pairs.npz')['curvature'][:,j];e=y-x
    mse=float(e@e/len(e));np.testing.assert_allclose(mse,float(row['MSE']),rtol=1e-13)
    corr=float(np.corrcoef(x,y)[0,1]);np.testing.assert_allclose(corr,float(row['r']),atol=1e-13)
    batch=np.array([np.mean(z*z) for z in np.array_split(e,8)]);se=float(batch.std(ddof=1)/np.sqrt(8));np.testing.assert_allclose(se,float(row['MSE_SE_MC']),rtol=1e-11)
    bands=np.quantile(y,[.025-eta,.025+eta,.975-eta,.975+eta],method='inverted_cdf')
    np.testing.assert_allclose(bands,[float(row[k]) for k in ['Q025_DKW_low','Q025_DKW_high','Q975_DKW_low','Q975_DKW_high']])
    assert np.mean(abs(e)>float(row['epsilon_measure']))<=min(1,mse/float(row['epsilon_measure'])**2)+1e-12
    errmax=max(errmax,abs(mse-float(row['MSE'])))

old=json.load(open(R/'review/original_hashes.json'));originals={};missing=[]
for p,h in old.items():
    if Path(p).is_file():originals[p]=sha(p)==h
    else:missing.append(p)
assert all(originals.values())
if missing and not args.allow_missing_originals:
    raise FileNotFoundError('Original absolute paths unavailable; use --allow-missing-originals for a portable numerical readback. Missing: '+repr(missing))
report=dict(status='passed',duration_seconds=time.monotonic()-started,method='Independent batched affine displacement gradient; isotropic stress from tensor entries; direct CDF inequalities without the solver recovery or quantile functions.',stress_meshes=checks,weighted_quantiles_checked=len(cdf),curvature_comparisons_checked=len(rows),curvature_MSE_max_readback_difference=errmax,DKW_method='inverse empirical CDF; 51-field simultaneous rank band',original_versions_unchanged=originals,original_absolute_paths_unavailable=missing,field_input_sha256=sources,limitations='Numerical verification only; not a new COMSOL solve, CFD solution, segmentation repeatability study or physical validation.')
(R/'review/final_numeric_validation.json').write_text(json.dumps(report,indent=2))
with (R/'review/table9_cdf_readback.csv').open('w',newline='') as f:w=csv.DictWriter(f,list(cdf[0]));w.writeheader();w.writerows(cdf)
print(json.dumps({k:v for k,v in report.items() if k not in ['original_versions_unchanged','field_input_sha256']},indent=2))
