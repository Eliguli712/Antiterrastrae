#!/usr/bin/env python3
"""Render only executed finer jaw fields; append their scale-free checks to Fig 4."""
from pathlib import Path
import argparse,json,re,xml.etree.ElementTree as ET
import numpy as np
import pyvista as pv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
from PIL import Image
import fitz
import revise_figures as old
import update_ct_assets as earlier

R=Path(__file__).resolve().parents[1];P=R.parents[2];D=P/'output/ct_fea_calibrated_2026-11-08'
F=R/'figures';old.R=R;old.F=F;old.V=R/'svg';old.REVIEW=R/'review'


def record(level,law):
    if law=='linear':
        name='jaw_L0_linear_block' if level==0 else f'jaw_L{level}_narrow_local'
    elif law=='full':name=f'jaw_L{level}_full_material'
    elif law=='wide' and level==1:name='jaw_L1_wide_admissible'
    else:name=f'jaw_L{level}_{law}_local'
    directory=D/'data'/name
    result=json.loads((directory/'results.json').read_text())
    assert json.loads((directory/'manifest.json').read_text())['run']['status']=='completed'
    return directory,result


def render_fields(third):
    title={'full':'Full StVK','wide':'Linear bulk / wide StVK','neo_hookean':'Full neo-Hookean'}[third]
    modes=[('linear','Linear elasticity'),('narrow','Linear bulk / narrow StVK'),(third,title)]
    for law,_ in modes:
        folder,r=record(2,law);a=np.load(folder/'fields.npz')
        points=a['points_m']*1000;points-=points.mean(0);f=a['boundary_faces'];owner=a['boundary_owner']
        poly=pv.PolyData(points,np.column_stack([np.full(len(f),3),f]).ravel())
        for key,tag in [('von_mises_Pa','vm'),('equivalent_strain','strain')]:
            if law=='linear':key='linear_'+key
            values=a[key][owner]/1e6 if tag=='vm' else a[key][owner]
            earlier.render(poly,values,f'jaw_fine_{law}_{tag}',(700,-750,900),
                           clim=(.001,100) if tag=='vm' else (1e-5,1),log=True)
    # Stable filename used by Figure 1; provenance records which actual law it is.
    image=Image.open(F/f'jaw_fine_{third}_vm.png');image.save(F/'jaw_fine_full_vm.png')
    (R/'review/finer_jaw_display.json').write_text(json.dumps(dict(third_law=third,
        layout='3 columns by 2 rows; common undeformed orientation',
        stress_limits_MPa=[.001,100],strain_limits=[1e-5,1],
        reference_geometry='1.8 mm reconstructed source domain; 589700 tetrahedra',
        fields='Unsmoothed owner-element stress/strain; linear convention identified separately.'),indent=2))
    fig=old.canvas(183,98)
    for i in range(6):
        col=i%3;law,title=modes[col];tag='vm' if i<3 else 'strain';x=61*col;y=52 if i<3 else 4
        old.picture(old.axmm(fig,x+1,y,53,39),F/f'jaw_fine_{law}_{tag}.png')
        old.panel(fig,x+1,y+44,'abcdef'[i])
        old.txt(fig,x+28,y+44,title if i<3 else ['Linear equivalent strain','Mixed-model equivalent strain',
                    'Green–Lagrange equivalent strain' if third in ['full','neo_hookean'] else 'Mixed-model equivalent strain'][col],6,ha='center',va='top')
        norm=LogNorm(.001,100) if i<3 else LogNorm(1e-5,1)
        cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap='turbo'),cax=old.axmm(fig,x+55,y+5,1.4,29))
        cb.set_ticks([.001,.1,10,100] if i<3 else [1e-5,1e-3,.1,1])
        cb.ax.tick_params(labelsize=5,pad=1)
        old.txt(fig,x+55,y+36,'MPa' if i<3 else 'strain',5.3,ha='center')
    fig.set_size_inches(183/25.4,90/25.4);old.save(fig,'jaw_comsol_3x2')


def calibration(third):
    fig=old.canvas(121,37)
    folder,meta=record(2,'narrow');data=np.load(folder/'fields.npz')
    xyz=data['points_m']*1000;faces=data['boundary_faces'];fixed=np.zeros(len(xyz),bool);fixed[data['fixed_node_indices']]=True
    categories=np.zeros(len(faces),np.int32);categories[(xyz[faces,1].mean(1)*.001)>=meta['loaded_centroid_Y_above_m']]=1;categories[fixed[faces].all(1)]=2
    poly=pv.PolyData(xyz-xyz.mean(0),np.column_stack([np.full(len(faces),3),faces]).ravel())
    earlier.render(poly,categories,'jaw_fine_constraints',(700,-750,900),clim=(0,2),cmap=plt.matplotlib.colors.ListedColormap(['#d1d6da','#2879bb','#c92f40']))
    old.picture(old.axmm(fig,1,6,29,25),F/'jaw_fine_constraints.png')
    old.panel(fig,.5,35.8,'e');old.txt(fig,16,35.5,'Jaw load / support',5.8,ha='center',va='top')
    old.txt(fig,16,3.5,'Blue: 10 kPa  |  red: fixed',5.1,ha='center')
    ax1=old.axmm(fig,42,8,31,22);ax2=old.axmm(fig,88,8,31,22)
    styles={'linear':('#555555','Linear'),'narrow':('#287eab','Narrow band'),
            'wide':('#c27629','Wide band'),'full':('#ba433c','Full StVK'),
            'neo_hookean':('#ba433c','Neo-Hookean, L2')}
    numbers=[]
    for law in ['linear','narrow',third]:
        levels=[0,1,2] if law=='linear' else [1,2]
        valid=[]
        for level in levels:
            try:folder,r=record(level,law)
            except FileNotFoundError:continue
            q=r['linear_Q50_Q95_Q99_MPa'][1] if law=='linear' else r['nonlinear_Q50_Q95_Q99_MPa'][1]
            u=r['linear_max_displacement_mm'] if law=='linear' else r['max_displacement_mm']
            valid.append([level,r['tetrahedra'],q/.01,u/r['reference_span_mm']])
        values=np.asarray(valid);assert len(values)>0
        color,title=styles[law]
        for ax,index in [(ax1,2),(ax2,3)]:
            ax.plot(values[:,1]/1e5,values[:,index],'-o',c=color,label=title,ms=2.4,lw=.7)
        numbers.append(dict(law=law,rows=valid,
                            last_step_percent=(100*abs(values[-1,2:]-values[-2,2:])/abs(values[-1,2:])).tolist() if len(values)>1 else None))
    for ax in [ax1,ax2]:
        ax.set_xlabel(r'Tetrahedra ($\times10^5$)',labelpad=1,fontsize=5.8)
        ax.tick_params(labelsize=5.5,pad=1);ax.grid(alpha=.16,lw=.4)
    ax1.set_ylabel(r'Jaw $Q_{0.95}/p$',labelpad=1,fontsize=6)
    ax2.set_ylabel(r'Jaw $u_{\max}/L$',labelpad=1,fontsize=6)
    ax1.legend(fontsize=5,loc='best',frameon=False,handlelength=1)
    old.panel(fig,33,35.8,'f');old.panel(fig,79,35.8,'g')
    old.txt(fig,57,35.6,'Stress / pressure',6,ha='center',va='top')
    old.txt(fig,103,35.6,'Displacement / span',6,ha='center',va='top')
    old.txt(fig,61,.5,'Scale-free response; L = 505.856 source units; no anatomical size anchor',5.2,ha='center')
    old.save(fig,'jaw_calibration_strip')
    base=fitz.open(F/'field_fullresolution_qf.pdf');strip=fitz.open(F/'jaw_calibration_strip.pdf')
    output=fitz.open();page=output.new_page(width=base[0].rect.width,height=base[0].rect.height+strip[0].rect.height)
    page.show_pdf_page(fitz.Rect(0,0,base[0].rect.width,base[0].rect.height),base,0)
    page.show_pdf_page(fitz.Rect(0,base[0].rect.height,base[0].rect.width,page.rect.height),strip,0)
    output.save(F/'field_qf_jaw_calibration.pdf');output.close()
    # Preserve vector/raster objects and editable text in the SVG combination.
    top=(R/'svg/field_fullresolution_qf.svg').read_text();bottom=(R/'svg/jaw_calibration_strip.svg').read_text()
    for identifier in re.findall(r'\bid="([^"]+)"',bottom):
        bottom=bottom.replace('id="'+identifier+'"','id="jaw_'+identifier+'"').replace('#'+identifier+'"','#jaw_'+identifier+'"').replace('#'+identifier+')','#jaw_'+identifier+')')
    ns='http://www.w3.org/2000/svg';ET.register_namespace('',ns)
    first=ET.fromstring(top);second=ET.fromstring(bottom)
    w=base[0].rect.width;h=base[0].rect.height;hh=strip[0].rect.height
    root=ET.Element('{'+ns+'}svg',dict(width=f'{w}pt',height=f'{h+hh}pt',viewBox=f'0 0 {w} {h+hh}',version='1.1'))
    first.set('x','0');first.set('y','0');second.set('x','0');second.set('y',str(h));root.append(first);root.append(second)
    ET.ElementTree(root).write(R/'svg/field_qf_jaw_calibration.svg',encoding='utf-8',xml_declaration=True)
    preview=fitz.open(F/'field_qf_jaw_calibration.pdf');preview[0].get_pixmap(matrix=fitz.Matrix(3,3),alpha=False).save(F/'field_qf_jaw_calibration.png');preview.close()
    base.close();strip.close()
    (R/'review/jaw_calibration_curves.json').write_text(json.dumps(dict(series=numbers,definition='Whole-domain, volume-weighted Q95 / 0.01 MPa and maximum displacement / fixed source span.'),indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--third-law',choices=['full','wide'],default='full');args=parser.parse_args()
    render_fields(args.third_law);calibration(args.third_law)
