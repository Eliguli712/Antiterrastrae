"""Compare registered stress fields over the full A3 reference boundary.

The projections in a–c use every A3 boundary face. Independent common-area
draws calibrate each normalizer and estimate the axial means. The fixed fields,
closest-point registration and pressure cases are kept distinct.
"""
import csv
import json
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
import pyvista as pv
from scipy.spatial import cKDTree
from scipy.stats import pearsonr, spearmanr
from matplotlib import pyplot as plt
from matplotlib.colors import LogNorm, TwoSlopeNorm

import revise_figures as plot
from render_full_surface_stress import (
    HEIGHT, WIDTH, finish_render, make_rasterizer, read_render, send_triangles,
)

PAPER = Path(__file__).resolve().parents[1]
PROJECT = PAPER.parents[2]
OUT = PAPER / 'numerics/archive_axis_dense'
N_CALIBRATION, N_PROFILE = 320_000, 1_280_000
BINS = 80
DISTANCE_LIMIT = 0.5
SEED = 2026112502


def closest_and_interpolate(query, archive_mesh, xyz, faces, vertex_stress):
    face_index, closest = archive_mesh.find_closest_cell(query, return_closest_point=True)
    tri = xyz[faces[face_index]]
    e0, e1, ep = tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0], closest - tri[:, 0]
    dot = lambda a, b: np.einsum('ij,ij->i', a, b)
    a, b, d = dot(e0, e0), dot(e0, e1), dot(e1, e1)
    det = a * d - b * b
    assert np.all(det > 0)
    u = (d * dot(e0, ep) - b * dot(e1, ep)) / det
    v = (a * dot(e1, ep) - b * dot(e0, ep)) / det
    bary = np.column_stack((1 - u - v, u, v))
    assert bary.min() >= -1e-5
    projected = np.einsum('ij,ij->i', bary, vertex_stress[faces[face_index]])
    return projected, np.linalg.norm(query - closest, axis=1)


def normalised_axes(coordinates, center, basis, lo, hi):
    q = (coordinates - center) @ basis
    x = 2 * (q[:, 0] - lo[0]) / (hi[0] - lo[0]) - 1
    s = (q[:, 1] - lo[1]) / (hi[1] - lo[1])
    return np.column_stack((x, s, q[:, 2]))


def render_plate(q, faces, archive, current_display, valid, q95, bins):
    maps = [LogNorm(.01, 3, clip=True), LogNorm(.01, 3, clip=True),
            TwoSlopeNorm(vmin=-2, vcenter=0, vmax=2)]
    cmaps = ['turbo', 'turbo', 'RdBu_r']
    ext = [-1.15, 1.15, 1.03, -.03]
    screen = np.column_stack(((q[:, 0] - ext[0]) / (ext[1] - ext[0]) * WIDTH,
                             (q[:, 1] - ext[3]) / (ext[2] - ext[3]) * HEIGHT, -q[:, 2]))
    # Double entries at the projection cutoff preserve the common-domain mask.
    # The continuous vertex data agree across triangles within that domain.
    points = screen[faces].reshape(-1, 3)
    triangles = np.arange(len(points), dtype=np.uint32).reshape(-1, 3)
    a = archive[faces].reshape(-1) / q95[0]
    c = current_display[faces].reshape(-1) / q95[1]
    common = np.repeat(valid[faces].all(1), 3)
    fig = plot.canvas(183, 57)
    with TemporaryDirectory(prefix='meg-axis-') as tmp:
        tmp = Path(tmp)
        process = make_rasterizer(tmp)
        for i, data in enumerate((a, c, c-a)):
            colors = plt.colormaps[cmaps[i]](maps[i](data))[:, :3].copy()
            colors[~common] = np.array([.91,.82,.95])
            send_triangles(process, i, points, colors, triangles)
        log = finish_render(process, len(faces))
        for i, title in enumerate(('Archive / own Q95', 'A3 / own Q95', 'A3 − archive')):
            x = 7 + 34 * i
            ax = plot.axmm(fig, x, 13, 23, 35)
            ax.imshow(read_render(tmp, i), extent=ext, aspect='auto', interpolation='none')
            ax.set(xlim=ext[:2], ylim=ext[2:], xticks=[-1, 0, 1], yticks=[0, .5, 1],
                   xlabel=r'$\xi$', ylabel=r'$s$' if i == 0 else '')
            ax.tick_params(labelsize=5, pad=1)
            if i > 0:
                ax.tick_params(labelleft=False)
            cb = fig.colorbar(plt.cm.ScalarMappable(norm=maps[i], cmap=cmaps[i]),
                              cax=plot.axmm(fig, x+24, 17, 1, 27), extend='both')
            cb.set_ticks([.01, .1, 1, 3] if i < 2 else [-2, 0, 2])
            cb.ax.tick_params(labelsize=4.4, pad=1)
            plot.panel(fig, x-6, 55, 'abc'[i])
            plot.txt(fig, x+10, 54, title, 5.7, ha='center', va='top')
    mid, arch_mean, a3_mean, delta, se = [
        np.array([row[k] for row in bins])
        for k in ('s_mid', 'archive_normalised_mean', 'A3_normalised_mean', 'difference_mean', 'difference_MC_SE')
    ]
    ax = plot.axmm(fig, 115, 13, 27, 35)
    ax.plot(mid, arch_mean, color=plot.BLUE, label='Archive')
    ax.plot(mid, a3_mean, color=plot.ORANGE, label='A3')
    ax.set(xlabel=r'Rootward $s$', ylabel='Mean / own Q95', xlim=(0, 1), xticks=[0, .5, 1])
    ax.tick_params(labelsize=5, pad=1)
    ax.legend(fontsize=4.8, frameon=False)
    ax.grid(alpha=.15)
    plot.panel(fig, 107, 55, 'd')
    plot.txt(fig, 129, 54, '80 axial bins', 5.8, ha='center', va='top')
    ax = plot.axmm(fig, 154, 13, 27, 35)
    ax.axhline(0, color='#5d7280', lw=.5)
    ax.fill_between(mid, delta-1.96*se, delta+1.96*se, color=plot.RED, alpha=.24)
    ax.plot(mid, delta, color=plot.RED)
    ax.set(xlabel=r'Rootward $s$', ylabel='Mean shape difference', xlim=(0, 1), xticks=[0, .5, 1])
    ax.tick_params(labelsize=5, pad=1)
    ax.grid(alpha=.15)
    plot.panel(fig, 145, 55, 'e')
    plot.txt(fig, 166, 54, r'$\pm$1.96 MC standard errors', 5.5, ha='center', va='top')
    plot.txt(fig, 91.5, 1.7, 'Apex 0 → 1 root  |  Lavender: projection beyond 0.5 mm  |  Descriptive comparison of distinct load cases', 5.3, ha='center')
    plot.save(fig, 'archive_axis_comparison_dense_recovered')
    return log


def main():
    OUT.mkdir(exist_ok=True)
    cache = PROJECT / 'output/tooth_continuous_surfaces/cache'
    raw = np.loadtxt(PROJECT / 'DICOM_16um/exports/von_mises_data_smoothed.txt', comments='%')
    v = np.load(cache / 'fe_v.npy')
    archive_faces = np.load(cache / 'fe_f.npy', mmap_mode='r')
    assert raw.shape == (191031, 4) and archive_faces.shape == (5554286, 3)
    _, nearest = cKDTree(raw[:, :3]).query(v, workers=4)
    archive_stress = raw[nearest, 3] / 1e6
    v[:, 2] *= 18 / 16
    archive_mesh = pv.PolyData.from_regular_faces(v, archive_faces)
    with np.load(PROJECT / 'output/publication_validation_2026-11-12/data/local_A3/fields.npz') as a:
        p, faces, tets, vm = a['points_m'] * 1000, a['boundary_faces'], a['tets'], a['von_mises_Pa'] / 1e6
        volume = a['volumes_m3']
    with np.load(PROJECT / 'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0/solution.npz') as ref:
        center, basis = ref['center_m'] * 1000, ref['basis']
        ref_q = (ref['points_m'][np.unique(ref['boundary_faces'])] * 1000 - center) @ basis
    lo, hi = ref_q.min(0), ref_q.max(0)
    local = np.array([[1, 2, 3], [0, 3, 2], [0, 1, 3], [0, 2, 1]])
    all_faces = tets[:, local].reshape(-1, 3)
    _, ix, count = np.unique(np.sort(all_faces, axis=1), axis=0, return_index=True, return_counts=True)
    ix = ix[count == 1]
    np.testing.assert_array_equal(np.sort(all_faces[ix], axis=1), np.sort(faces, axis=1))
    del all_faces
    current_stress = vm[ix // 4]
    ids, inverse = np.unique(faces, return_inverse=True)
    sum_vol = np.zeros(len(p))
    sum_vm = np.zeros(len(p))
    for nodes in tets.T:
        np.add.at(sum_vol, nodes, volume)
        np.add.at(sum_vm, nodes, volume*vm)
    current_display = sum_vm[ids]/sum_vol[ids]
    faces = inverse.reshape(-1, 3)
    p = p[ids]
    tri = p[faces]
    areas = np.linalg.norm(np.cross(tri[:, 1]-tri[:, 0], tri[:, 2]-tri[:, 0]), axis=1) / 2
    assert (areas > 0).all()
    rng = np.random.default_rng(SEED)
    n = N_CALIBRATION + N_PROFILE
    face_ids = rng.choice(len(faces), n, p=areas/areas.sum())
    r = np.sqrt(rng.random(n))
    t = rng.random(n)
    weights = np.column_stack((1-r, r*(1-t), r*t))
    query = np.einsum('ij,ijk->ik', weights, tri[face_ids])
    # One locator construction for the full independent samples and all boundary vertices.
    source, distance = closest_and_interpolate(np.vstack((query, p)), archive_mesh, v, archive_faces, archive_stress)
    s = normalised_axes(query, center, basis, lo, hi)[:, 1]
    assert s.min() > -1e-6 and s.max() < 1+1e-6
    values = np.column_stack((source[:n], current_stress[face_ids]))
    accepted = distance[:n] <= DISTANCE_LIMIT
    calibration = values[:N_CALIBRATION][accepted[:N_CALIBRATION]]
    q95 = np.quantile(calibration, .95, axis=0)
    assert np.all(q95 > 0)
    s = s[N_CALIBRATION:][accepted[N_CALIBRATION:]]
    values = values[N_CALIBRATION:][accepted[N_CALIBRATION:]]
    shape = values / q95
    delta = shape[:, 1]-shape[:, 0]
    indices = np.clip((s * BINS).astype(np.int64), 0, BINS-1)
    summaries = []
    for k in range(BINS):
        m = indices == k
        assert m.sum() >= 100
        summaries.append(dict(s_mid=(k+.5)/BINS, n=int(m.sum()),
                              archive_normalised_mean=float(shape[m, 0].mean()),
                              A3_normalised_mean=float(shape[m, 1].mean()),
                              difference_mean=float(delta[m].mean()),
                              difference_MC_SE=float(delta[m].std(ddof=1) / np.sqrt(m.sum()))))
    with (OUT / 'axial_profiles.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summaries[0]))
        writer.writeheader()
        writer.writerows(summaries)
    np.savez_compressed(OUT / 'samples.npz', s=s, archive_MPa=values[:, 0], A3_MPa=values[:, 1],
                        distance_mm=distance[N_CALIBRATION:n][accepted[N_CALIBRATION:]], normalizers_MPa=q95)
    log = render_plate(normalised_axes(p, center, basis, lo, hi), faces, source[n:], current_display,
                       distance[n:] <= DISTANCE_LIMIT, q95, summaries)
    raw_delta = values[:, 1]-values[:, 0]
    # DKW is a simultaneous CDF bound per field for the calibration sample.
    eps = np.sqrt(np.log(4/.05) / (2*len(calibration)))
    intervals = np.quantile(calibration, [.95-eps, .95+eps], axis=0, method='inverted_cdf').T
    record = dict(status='passed', seed=SEED, map_faces=len(faces), map_vertices=len(p),
                  archive_export_nodes=len(raw), archive_interpolation_faces=len(archive_faces),
                  supported_map_vertices=int((distance[n:] <= DISTANCE_LIMIT).sum()),
                  calibration_draws=N_CALIBRATION, calibration_accepted=len(calibration),
                  profile_draws=N_PROFILE, profile_accepted=len(values),
                  bins=BINS, samples_per_bin_min=min(row['n'] for row in summaries),
                  samples_per_bin_max=max(row['n'] for row in summaries),
                  paired_surface_Q95_MPa=q95.tolist(),
                  joint_DKW_Q95_intervals_MPa=intervals.tolist(),
                  DKW_epsilon=float(eps), mean_difference_MPa=float(raw_delta.mean()),
                  absolute_difference_Q95_MPa=float(np.quantile(abs(raw_delta), .95)),
                  Pearson_r=float(pearsonr(*values.T).statistic), Spearman_rho=float(spearmanr(*values.T).statistic),
                  registration_max_distance_mm=float(distance[:n].max()),
                  widest_bin_pointwise_conditional_CI_half_width=1.96*max(row['difference_MC_SE'] for row in summaries),
                  raster=log.splitlines(),
                  display='A3 volume-weighted incident-cell scalar recovery at boundary vertices; triangular interpolation renders a continuous display. Profiles retain original unsmoothed A3 owner stress.',
                  scope='Conditional surface means, separate common-area Q95 normalization sample. The bands omit normalizer and model uncertainty. The two loads are not identified as matched.')
    (OUT / 'summary.json').write_text(json.dumps(record, indent=2))
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
