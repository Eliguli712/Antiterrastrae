"""Render a geometric jaw attachment overlay and bounded tooth display continuation.

The offset samples come from the archived jaw fit. Pink marks their projected
jaw-side locations, with footprint size inferred from the matched root face.
The scalar continuation keeps the earlier supported projection and fills only
its out-of-range vertices. It is not a second FE solution.
"""

import json
from pathlib import Path
import struct
import subprocess
import tempfile

import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import gaussian_filter
from scipy.spatial import cKDTree

import revise_figures as layout


WIDTH, HEIGHT = 1800, 1600
N_VERTICES, N_TRIANGLES = 37_951_699, 74_293_846
SUPPORT_MM = 1.5
KNN_RADIUS_MM = 2.5
ATTACHMENT_MM = 1.5
PROJECT = layout.P
TRANSFER = PROJECT / 'output/jaw_tooth_transfer_2026-11-22'
BASE = PROJECT / 'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0/solution.npz'
CACHE = PROJECT / 'output/current_native74_stress_2026-11-20/cache'


def native_arrays():
    vertices = np.memmap(CACHE / 'vertices.f64', '<f8', mode='r', shape=(N_VERTICES, 3))
    faces = np.memmap(CACHE / 'triangles.u32', '<u4', mode='r', shape=(N_TRIANGLES, 3))
    return vertices, faces


def registered_attachment(vertices):
    with np.load(TRANSFER / 'data_v3/registration.npz') as fit:
        points = fit['projected_points_m'] * 1000
        footprints = np.sqrt(fit['root_face_area_m2'] / np.pi) * 1000
        gaps = fit['bridge_distances_m'] * 1000
        lobes = fit['root_face_side']
        placed = (vertices[::100] * .001 - fit['tooth_root_centre_m']) @ fit['reference_rotation'].T
        target = (placed.mean(axis=0) + fit['reference_location_m']) * 1000
    # Exact common orthographic camera from render_native_figure8_natural.py.
    center = json.loads((layout.REVIEW / 'figure8_native_counts.json').read_text())
    direction = np.array([-700., 795., -900.])
    direction /= np.linalg.norm(direction)
    transverse = np.cross(direction, [0, 0, 1])
    transverse /= np.linalg.norm(transverse)
    vertical = np.cross(transverse, direction)
    screen = (points-target) @ np.stack((transverse, -vertical), axis=1)
    chosen = gaps <= ATTACHMENT_MM
    samples_per_lobe = np.bincount(lobes[chosen], minlength=2)
    assert np.all(samples_per_lobe > 10)
    png_touched = {}
    for panel, scale, origin in ((0, 2.5, center['overview_window_center_px']), (1, 24, [900, 800])):
        projected = screen*scale + np.asarray(origin)
        assert np.all((projected[chosen] > 0) & (projected[chosen] < [WIDTH, HEIGHT]))
        footprint = Image.new('L', (WIDTH, HEIGHT))
        draw = ImageDraw.Draw(footprint)
        for (x, y), radius in zip(projected[chosen], footprints[chosen]*scale):
            draw.ellipse((x-radius, y-radius, x+radius, y+radius), fill=255)
        mask = gaussian_filter(np.asarray(footprint, dtype=np.float32), sigma=.65)
        mask = np.minimum(mask * 1.3, 219).astype(np.uint8)
        with Image.open(layout.F / f'native_figure8_{panel}.png') as source:
            image = source.convert('RGBA')
        # Where the locator is visible, overlay a rose ink wash on the existing image.
        mask[np.asarray(image)[..., 3] == 0] = 0
        paint = Image.new('RGBA', image.size, '#ed446f')
        paint.putalpha(Image.fromarray(mask))
        Image.alpha_composite(image, paint).save(layout.F / f'native_figure8_contact_{panel}.png')
        png_touched[str(panel)] = int(np.count_nonzero(mask))
    return dict(gap_threshold_mm=ATTACHMENT_MM, sample_count_per_lobe=samples_per_lobe.tolist(),
                counts_before_cutoff=np.bincount(lobes, minlength=2).tolist(), pixels_changed=png_touched,
                description='Pink shows matched geometric jaw-side locations within the display fit-distance cutoff. Marker footprint scales with source root-face area. The two roots are retained as separate selections. No anatomical socket or solved contact pressure is implied.')


def owner_recovery():
    with np.load(BASE) as base:
        points, tetrahedra, boundary_faces, volumes = (
            base[k] for k in ('points_m', 'tets', 'boundary_faces', 'volumes_m3'))
        center, basis = base['center_m']*1000, base['basis']
    with np.load(TRANSFER / 'edge_data/RA_pose0_oblique30_tied.npz') as state:
        tension = np.maximum(state['principal_stresses_Pa'][:, -1], 0) / 1e6
    assert len(tension) == len(tetrahedra) == 55_852
    mass = np.zeros(len(points))
    weighted = np.zeros(len(points))
    for corner in tetrahedra.T:
        np.add.at(mass, corner, volumes)
        np.add.at(weighted, corner, volumes*tension)
    boundary = np.unique(boundary_faces)
    return cKDTree(points[boundary]*1000), weighted[boundary]/mass[boundary], center, basis


def vertex_colours(vertices, tree, nodal):
    palette = np.array(json.loads((layout.R / 'numerics/reference_palette_512.json').read_text())['RGBA_8bit'],
                       dtype=np.uint8)[:, :3]
    color = np.empty((len(vertices), 3), dtype=np.uint8)
    within_support = np.empty(len(vertices), dtype=bool)
    max_distance = 0.
    for start in range(0, len(vertices), 250_000):
        batch = slice(start, start + 250_000)
        distance, nearest = tree.query(vertices[batch], k=8, workers=3)
        inverse_weights = 1 / np.maximum(distance, 1e-10)**2
        nearest_distance = distance[:, 0]
        within_support[batch] = nearest_distance <= SUPPORT_MM
        max_distance = max(max_distance, float(nearest_distance.max()))
        blend = np.clip((nearest_distance-SUPPORT_MM)/(KNN_RADIUS_MM-SUPPORT_MM), 0, 1)
        blend = blend*blend*(3 - 2*blend)
        influence = inverse_weights * np.where(distance <= KNN_RADIUS_MM, 1, blend[:, None])
        local = nodal[nearest]
        recovered = np.sum(influence*local, axis=1) / np.sum(influence, axis=1)
        assert np.all(recovered >= local.min(axis=1)-1e-12)
        assert np.all(recovered <= local.max(axis=1)+1e-12)
        # Match the archived ListedColormap sampling and LogNorm limits.
        unit = np.clip((np.log10(np.maximum(recovered, 1e-12))+4)/3, 0, 1)
        color[batch] = palette[np.minimum((unit*len(palette)).astype(np.int32), len(palette)-1)]
    return color, within_support, max_distance


def render_stress(vertices, faces):
    tree, nodal, center, basis = owner_recovery()
    color, supported, max_distance = vertex_colours(vertices, tree, nodal)
    section_min = ((vertices[::100]-center) @ basis)[:, 1].min()
    with tempfile.TemporaryDirectory() as tmp:
        tmp = Path(tmp)
        rasterizer = tmp / 'rasterizer'
        subprocess.run(['clang++', '-O3', '-std=c++17', str(Path(__file__).with_name('native_figure8_raster.cpp')),
                        '-o', str(rasterizer)], check=True)
        process = subprocess.Popen([str(rasterizer), str(tmp)], stdin=subprocess.PIPE, stderr=subprocess.PIPE)
        assert process.stdin is not None and process.stderr is not None
        with process:
            for start in range(0, len(faces), 850_000):
                part = faces[start:start+850_000]
                ids, indices = np.unique(part, return_inverse=True)
                q = (vertices[ids]-center) @ basis
                position = np.c_[900+q[:, 0]*26, 95+(q[:, 1]-section_min)*27, -q[:, 2]]
                rgb = color[ids] / 255
                payload = np.column_stack((position, rgb)).astype('<f4').tobytes()
                indices = indices.astype('<u4').tobytes()
                process.stdin.write(struct.pack('<III', 2, len(ids), len(part)))
                process.stdin.write(payload)
                process.stdin.write(indices)
                # A second raster keeps coverage separate at identical depth.
                coverage = np.broadcast_to(supported[ids, None], position.shape)
                payload = np.column_stack((position, coverage)).astype('<f4').tobytes()
                process.stdin.write(struct.pack('<III', 1, len(ids), len(part)))
                process.stdin.write(payload)
                process.stdin.write(indices)
            process.stdin.close()
            log = process.stderr.read().decode()
            assert process.wait() == 0, log
        assert log.count(str(N_TRIANGLES)) == 2
        raster = Image.frombytes('RGBA', (WIDTH, HEIGHT), (tmp / 'native_figure8_2.rgba').read_bytes())
        mask = Image.frombytes('RGBA', (WIDTH, HEIGHT), (tmp / 'native_figure8_1.rgba').read_bytes())
    color = np.asarray(raster).copy()
    support_im = np.asarray(mask)
    inside = color[..., 3] > 0
    with Image.open(layout.F / 'native_figure8_2.png') as source:
        earlier = np.asarray(source.convert('RGBA'))
    assert np.array_equal(inside, earlier[..., 3] > 0)
    # C++ barycentric summation can round an all-white support pixel down by one.
    just_supported = inside & (support_im[..., 0] >= 254)
    rgb_error = np.max(np.abs(color[just_supported, :3].astype(int)-earlier[just_supported, :3]))
    assert rgb_error <= 2, rgb_error
    color[just_supported] = earlier[just_supported]
    Image.fromarray(color).save(layout.F / 'native_figure8_continued_2.png')
    mask.save(layout.F / 'native_figure8_continuation_support.png')
    return dict(native_faces_per_raster=len(faces), unsupported_vertices=int(np.count_nonzero(~supported)),
                visible_pixels_with_continuation=int(np.count_nonzero(inside & ~just_supported)),
                visible_original_pixels=int(np.count_nonzero(just_supported)),
                max_nearest_FE_node_mm=max_distance, max_rgb_check=int(rgb_error),
                description='Original volume-weighted nodal principal tension and inverse-square mapping retained where nearest FE boundary node is within 1.5 mm. Between 1.5 and 2.5 mm nearest distance, a cubic ramp admits additional neighbours. Beyond 2.5 mm the eight nearest boundary nodes contribute with inverse-square weights. This convex weighted continuation is display-only. The saved companion raster records original support.')


def main():
    vertices, faces = native_arrays()
    attachment = registered_attachment(vertices)
    print('Attachment coverage', attachment, flush=True)
    stress = render_stress(vertices, faces)
    print('Display continuation', stress, flush=True)
    record = {'contact_locator': attachment, 'scalar_display': stress}
    (layout.REVIEW / 'figure8_contact_continuation.json').write_text(json.dumps(record, indent=2) + '\n')


if __name__ == '__main__':
    main()
