"""Render the complete native surface with continuous FE display recovery."""
import argparse
import json
from pathlib import Path
from tempfile import TemporaryDirectory

import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import numpy as np
from scipy.spatial import cKDTree

import revise_figures as layout
from render_full_surface_stress import (
    FIGURES, HEIGHT, WIDTH, PAPER, PROJECT, TRIANGLES, VERTICES, make_rasterizer,
    read_render, send_triangles,
)
from render_native_field_plates import BASELINE, MAP_NORM, NUMERICS, p2_at_corners, volume_average


CACHE = PROJECT / 'output/current_native74_stress_2026-11-20/cache'
BILAYER = PROJECT / 'output/publication_validation_2026-11-12/data/bilayer_StVK_L1/fields.npz'
SUPPORT_MM = 1.5
PALETTE = plt.colormaps['turbo'](np.linspace(0, 1, 256))[:, :3]
FRACTIONS = np.linspace(0, 1, len(PALETTE))


def continuous_projection(tree, nodal, coordinates):
    """The ninth distance defines a vanishing-weight envelope for eight neighbours."""
    distances, indices = tree.query(coordinates, k=9, workers=3)
    closest, outer = distances[:, 0], distances[:, -1]
    # A tied, equidistant query still needs finite, positive total weight.
    radius = np.maximum(outer, closest + 1e-12)
    distance = distances[:, :8]
    weights = np.square(np.maximum(1 - distance/radius[:, None], 0) /
                        np.maximum(distance, 1e-10))
    local = nodal[indices[:, :8]]
    value = np.einsum('nk,nkf->nf', weights, local) / weights.sum(1)[:, None]
    assert np.isfinite(value).all()
    assert (value >= local.min(1) - 1e-10).all()
    assert (value <= local.max(1) + 1e-10).all()
    return value, closest


def colour_table(values, norm):
    projected = np.asarray(norm(np.maximum(values, norm.vmin)))
    scaled = np.column_stack([np.interp(projected, FRACTIONS, row) for row in PALETTE.T])
    return np.round(scaled*255).astype(np.uint8)


def colour_vertices(vertices, tree, nodal, norm, frames):
    colours = np.empty((nodal.shape[1], len(vertices), 3), dtype=np.uint8)
    supported = 0
    nearest_max = 0.
    bounds = [(np.full(2, np.inf), np.full(2, -np.inf)) for _ in frames]
    for start in range(0, len(vertices), 200_000):
        batch = slice(start, start+200_000)
        points = vertices[batch]
        recovered, closest = continuous_projection(tree, nodal, points)
        supported += int((closest <= SUPPORT_MM).sum())
        nearest_max = max(nearest_max, float(closest.max()))
        for i, value in enumerate(recovered.T):
            colours[i, batch] = colour_table(value, norm)
        for j, (center, transform) in enumerate(frames):
            plane = points @ transform[:, :2] - center @ transform[:, :2]
            lo, hi = bounds[j]
            np.minimum(lo, plane.min(0), out=lo)
            np.maximum(hi, plane.max(0), out=hi)
        if start % 5_000_000 == 0:
            print(f'Projection {start:,}/{len(vertices):,}', flush=True)
    return colours, supported, nearest_max, bounds


def rasterize(vertices, faces, colours, panels, stem):
    """Submit all original faces. No owner-face constant colour or subset is used."""
    with TemporaryDirectory(prefix='meg-continuous-native-') as tmp:
        tmp = Path(tmp)
        with make_rasterizer(tmp) as process:
            for start in range(0, len(faces), 800_000):
                block = faces[start:start+800_000]
                ids, local = np.unique(block, return_inverse=True)
                points = vertices[ids]
                indexed = local.reshape(-1, 3)
                for i, (projection, colour_index) in enumerate(panels):
                    send_triangles(process, i, projection(points), colours[colour_index, ids]/255, indexed)
            process.stdin.close()
            log = process.stderr.read().decode().strip()
            assert process.wait() == 0, log
        expected = [TRIANGLES if i < len(panels) else 0 for i in range(3)]
        counts = [int(line.split()[-1]) for line in log.splitlines()]
        assert counts == expected, log
        for i, _ in enumerate(panels):
            image = read_render(tmp, i)
            crop = image.getbbox()
            assert crop is not None, (stem, i)
            image.crop(crop).save(FIGURES/f'{stem}_{i}.png')
    return counts[:len(panels)]


def save_record(name, record):
    record.update(
        status='passed', mesh_faces=TRIANGLES, mesh_vertices=VERTICES,
        support_threshold_mm=SUPPORT_MM,
        projection='Volume-weighted incident-element nodal stress; eight-neighbour inverse-square weights multiplied by (1 - d/d9)^2. This taper vanishes at the ninth-neighbour radius. Positive normalized weights bound the values even outside the old support threshold.',
        scope='Display projection only. Element stresses, quantiles, and geometry were not changed.',
    )
    (PAPER/'review'/f'{name}.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record, indent=2), flush=True)


def compose_order_check(stem):
    fig = layout.canvas(58, 36)
    for i, name in enumerate(['P1', 'P2']):
        axis = layout.axmm(fig, 1.5+28.5*i, 8, 26, 22)
        layout.picture(axis, FIGURES/f'{stem}_{i}.png')
        layout.panel(fig, 2+28.5*i, 34.5, 'cd'[i])
        layout.txt(fig, 15+28.5*i, 34.4, name+' · native projection', 5.7,
                   ha='center', va='top')
    bar = fig.colorbar(plt.cm.ScalarMappable(norm=MAP_NORM, cmap='turbo'),
                       cax=layout.axmm(fig, 15, 4.2, 32, 1.3),
                       orientation='horizontal', extend='both')
    bar.set_ticks([1, 10, 100])
    bar.ax.tick_params(labelsize=4.6, pad=.6)
    layout.txt(fig, 13.5, 4.9, 'MPa', 4.8, ha='right')
    layout.save(fig, stem)


def order_check(vertices, triangles):
    with np.load(BASELINE/'L0/solution.npz') as result:
        center, basis = result['center_m']*1000, result['basis']
        points, tets, volumes = result['points_m'], result['tets'], result['volumes_m3']
        p1 = volume_average(tets, points, volumes, result['element_von_mises_Pa']/1e6)
        p2 = volume_average(tets, points, volumes, p2_at_corners(points, tets))
        ids = np.unique(result['boundary_faces'])
    nodal = np.column_stack((p1[ids], p2[ids]))
    colours, supported, nearest_max, _ = colour_vertices(
        vertices, cKDTree(points[ids]*1000), nodal, MAP_NORM, ())

    def front(position):
        local = (position-center) @ basis
        return np.column_stack((900+29*local[:, 0], 748-29*local[:, 1], -local[:, 2]))

    stem = 'P1_P2_native_surface_continuous'
    counts = rasterize(vertices, triangles, colours, [(front, 0), (front, 1)], stem)
    compose_order_check(stem)
    save_record(stem, dict(
        source_p1=str((BASELINE/'L0/solution.npz').relative_to(PROJECT)),
        source_p2=str((NUMERICS/'p1_p2_common_domain/solution_P2.npz').relative_to(PROJECT)),
        finite_elements_per_case=len(tets), supported_native_vertices=supported,
        continued_native_vertices=VERTICES-supported, nearest_max_mm=nearest_max,
        raster_faces_by_panel=counts, visual_range_MPa=[.5, 500],
    ))


def bilayer_check(vertices, triangles):
    with np.load(BILAYER) as result, np.load(BASELINE/'L1/solution.npz') as frame:
        points, tets, volumes = result['points_m'], result['tets'], result['volumes_m3']
        ids = np.unique(result['boundary_faces'])
        sigma = result['cauchy_stress_Pa']
        deviator = sigma - np.trace(sigma, axis1=1, axis2=2)[:, None, None]*np.eye(3)/3
        vm = np.sqrt(1.5*np.einsum('eij,eij->e', deviator, deviator))
        np.testing.assert_allclose(vm, result['von_mises_Pa'], rtol=1e-12, atol=1e-6)
        maximum_error = np.max(np.abs(vm - result['von_mises_Pa']))
        center, basis = frame['center_m']*1000, frame['basis']
    nodal = volume_average(tets, points, volumes, vm/1e6)[ids, None]
    frames = []
    for direction in np.array([(0, 0, 150), (100, 20, 140), (0, 0, -150)], dtype=float):
        inward = -direction / np.linalg.norm(direction)
        right = np.cross(inward, [0., 1., 0.])
        right /= np.linalg.norm(right)
        rotation = np.column_stack((right, np.cross(right, inward), inward))
        frames.append((center, basis @ np.diag([-1, -1, 1]) @ rotation))
    norm = LogNorm(.1, 300, clip=True)
    colours, supported, nearest_max, bounds = colour_vertices(
        vertices, cKDTree(points[ids]*1000), nodal, norm, frames)
    scale = float(np.min((np.array([WIDTH, HEIGHT]) - 40) /
                         np.array([hi-lo for lo, hi in bounds])))

    def orthographic(transform, middle):
        def project(position):
            q = (position-center) @ transform
            q[:, :2] -= middle
            q[:, 0] = WIDTH/2 + q[:, 0]*scale
            q[:, 1] = HEIGHT/2 - q[:, 1]*scale
            return q
        return project

    panels = [(orthographic(transform, (lo+hi)/2), 0)
              for (_, transform), (lo, hi) in zip(frames, bounds)]
    stem = 'bilayer_stvk_native_continuous'
    counts = rasterize(vertices, triangles, colours, panels, stem)
    save_record(stem, dict(
        source=str(BILAYER.relative_to(PROJECT)), finite_elements=len(tets),
        max_invariant_error_Pa=float(maximum_error), supported_native_vertices=supported,
        continued_native_vertices=VERTICES-supported, nearest_max_mm=nearest_max,
        raster_faces_by_panel=counts, visual_range_MPa=[.1, 300],
    ))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('figure', choices=('6', '9', 'both'), nargs='?', default='both')
    selected = parser.parse_args().figure
    vertices = np.memmap(CACHE/'vertices.f64', '<f8', 'r', shape=(VERTICES, 3))
    faces = np.memmap(CACHE/'triangles.u32', '<u4', 'r', shape=(TRIANGLES, 3))
    if selected in ('6', 'both'):
        order_check(vertices, faces)
    if selected in ('9', 'both'):
        bilayer_check(vertices, faces)


if __name__ == '__main__':
    main()
