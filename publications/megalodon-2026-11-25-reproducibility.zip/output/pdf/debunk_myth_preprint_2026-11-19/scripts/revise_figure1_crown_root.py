"""Change only d2 contours, e2 finite-deformation display, and colourbar ends.
All other Figure 1 assets, cameras, stress limits and ticks are retained.
"""
from pathlib import Path
import inspect,json,hashlib
import numpy as np
from scipy import ndimage as ndi
import matplotlib.pyplot as plt
import matplotlib.patheffects as pe
import pyvista as pv
from PIL import Image
import figure1_palette_matte_root as previous
import profile_figures as original
N=Path(__file__).resolve().parents[1];P=N.parents[2];F=N/'figures'
REPORT={}
# Original quantitative CT crop; contour extraction changes annotations only.
a=np.load(P/'output/ct_profiles_2026-11-09/data/native_profiles_and_maximum_sections.npz');raw=a['sagittal_raw_maximum'];origin=np.array([4.176,.198,16.818]);dx=.018
x0=int((13-origin[1])/dx);x1=int((28-origin[1])/dx);y0=int((45-origin[2])/dx);y1=int((56-origin[2])/dx);patch=raw[y0:y1,x0:x1]
limits=np.quantile(patch[patch>10361.669921875],[.01,.99]);ex=[origin[1]+x0*dx,origin[1]+x1*dx,origin[2]+y0*dx,origin[2]+y1*dx]
# A modest 1-voxel Gaussian is used ONLY to select contours. Displayed voxels
# remain completely unchanged. Long low-attenuation components are isolated
# with a declared local-intensity threshold and minimum connected area.
smooth=ndi.gaussian_filter(patch.astype(float),1)
low=smooth<np.quantile(smooth,.12);lab,num=ndi.label(low);sizes=np.bincount(lab.ravel());keep=sizes>=80;keep[0]=False;low=keep[lab]
high=smooth>np.quantile(smooth,.88);lab,num=ndi.label(high);sizes=np.bincount(lab.ravel());keep=sizes>=120;keep[0]=False;high=keep[lab]

def draw(ax,large=False):
 fs=9 if large else 5.2
 ax.imshow(patch,cmap='gray_r',origin='lower',vmin=limits[0],vmax=limits[1],extent=ex,interpolation='none')
 Y=ex[0]+(np.arange(patch.shape[1])+.5)*.018;Z=ex[2]+(np.arange(patch.shape[0])+.5)*.018;yy,zz=np.meshgrid(Y,Z)
 for mask,color,window in [(high,'#bf2337',(yy>15)&(yy<20.5)&(zz>51.5)&(zz<55.5)),(low,'#126db1',(yy>22.5)&(yy<26.5)&(zz<50.5))]:
  if mask.any():ax.contour(np.ma.array(mask,mask=~window),levels=[.5],colors=[color],linewidths=.65 if large else .28,extent=ex,origin='lower')
 for label,point,text,color in [('1',(18.6,53.8),(15.4,55.),'#bf2337'),('2',(25.25,47.8),(23.4,45.6),'#126db1')]:
  ax.annotate(label,point,xytext=text,color=color,fontsize=fs,weight='bold',arrowprops={'arrowstyle':'-','color':color,'lw':.65},path_effects=[pe.withStroke(linewidth=1.4,foreground='white')])
 ax.set_xlabel('Y (mm)',fontsize=fs,labelpad=1);ax.set_ylabel('Z (mm)',fontsize=fs,labelpad=1);ax.tick_params(labelsize=fs-.3,pad=1);ax.set_xlim(ex[:2]);ax.set_ylim(ex[2:])
fig=original.old.canvas(30,29);ax=original.old.axmm(fig,7,5,22,23);draw(ax);original.old.save(fig,'junction_CT_root_contours');fig.savefig(F/'junction_CT_root_contours.png',dpi=1200);plt.close(fig)
fig,ax=plt.subplots(figsize=(6.6,5));draw(ax,True);ax.set_title('Native root-side CT | X = 17.658 mm',fontsize=11);ax.text(.01,-.16,'Red: higher attenuation     Blue: lower-attenuation tracks\nDisplay contour classes, not histology or preserved soft tissue.',transform=ax.transAxes,fontsize=8.5);fig.subplots_adjust(bottom=.2);fig.savefig(F/'Figure1_d2_root_CT_contours.pdf');fig.savefig(F/'Figure1_d2_root_CT_contours.png',dpi=600);plt.close(fig)
REPORT['CT']={'unchanged_YZ_limits_mm':ex,'unchanged_contrast_limits':limits.tolist(),'raw_patch_sha256':hashlib.sha256(patch.tobytes()).hexdigest(),'contour_only_gaussian_sigma_voxels':1,'low_high_intensity_quantiles':[.12,.88],'min_component_pixels':[80,120],'annotation_windows_YZ_mm':{'higher':[[15,20.5],[51.5,55.5]],'lower':[[22.5,26.5],[45,50.5]]},'low_high_thresholds_raw':np.quantile(smooth,[.12,.88]).tolist(),'contents':'Attenuation classes only; no tissue identity, histological EDJ, or preserved soft-tissue claim.'}
# The same converged L1 StVK field, at 100 mm under exact pressure-only
# similarity; displacement magnification is two, not ten. No scalar rescaling.
a=np.load(P/'output/ct_fea_2026-11-08/data/tooth_stvk_l1/fields.npz');ref=np.load(P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L1/solution.npz')
q=(a['points_m']-ref['center_m'])@ref['basis']*1000;q[:,:2]*=-1;fac=100/np.ptp(q[:,1]);q*=fac
u=a['displacement_m']@ref['basis']*1000*fac;u[:,:2]*=-1
f=a['boundary_faces'];owner=a['boundary_owner'];faces=np.column_stack([np.full(len(f),3),f]).ravel();poly=pv.PolyData(q,faces);deformed=pv.PolyData(q+2*u,faces)
e=ref['basis'][:,1];stress=np.einsum('i,eij,j->e',e,a['cauchy_stress_Pa'],e)[owner]/1e6
r=json.loads((N/'review/current_field_display.json').read_text());limit=r['tooth_signed_limit_MPa'];tau=r['tooth_signed_asinh_scale_MPa'];deformed.cell_data['signed']=np.arcsinh(stress/tau)
viewer=pv.Plotter(off_screen=True,window_size=(1800,1650));viewer.set_background('white');viewer.add_mesh(poly,color='#cbd1d6',opacity=.2,show_scalar_bar=False);viewer.add_mesh(deformed,scalars='signed',cmap='RdBu_r',clim=(-np.arcsinh(limit/tau),np.arcsinh(limit/tau)),lighting=False,show_scalar_bar=False)
viewer.camera_position=[(100,5,150),(0,0,0),(0,1,0)];viewer.enable_parallel_projection();viewer.reset_camera();im=viewer.screenshot(return_img=True);viewer.close();yy,xx=np.where(np.any(im[:,:,:3]<247,axis=2));Image.fromarray(im[max(0,yy.min()-10):yy.max()+11,max(0,xx.min()-10):xx.max()+11]).save(F/'stvk_tooth_signed_deformed_x2_100mm.png')
REPORT['e2']={'source':'ct_fea_2026-11-08/data/tooth_stvk_l1/fields.npz','nominal_height_mm':100,'pressure_similarity_factor':fac,'display_u_multiplier':2,'signed_stress_limits_MPa':[-limit,limit],'asinh_scale_MPa':tau,'stress_values_unchanged':True,'scope':'100 mm geometrically similar fixed-cap homogeneous StVK, same nominal pressure and material, no intrinsic length scale. Not the MR5 body-force case.'}
# Keep previous palette, photograph derivatives and all original panel positions.
source=inspect.getsource(original.figure1).split(' provenance=[]')[0]
source=source.replace("f'stvk_tooth_view_{j}.png'","f'archive_reference_palette_view_{j}.png'").replace("'StVK σvM\\n(MPa), log'","'Archive σvM\\n(MPa), linear'")
source=source.replace("norm=LogNorm(.1,300),cmap='turbo'","norm=plt.Normalize(.05676644283690944,.32688821709539363),cmap=reference_cmap")
source=source.replace("cb.set_ticks([.1,1,10,100,300],labels=['0.1','1','10','100','300'])","cb.set_ticks([.06,.1,.2,.3],labels=['0.06','0.10','0.20','0.30'])")
source=source.replace('specimen_photo_a_bordercrop.png','specimen_photo_a_matte.png').replace('specimen_photo_b_bordercrop.png','specimen_photo_b_matte.png').replace("f'photograph_junction_{key}.png'","f'photograph_junction_matte_{key}.png'")
source=source.replace("F/'junction_CT_detail.png'","F/'junction_CT_root_contours.png'").replace("'Original pixels; unscaled'","'Glare-compressed display'")
source=source.replace('stvk_tooth_signed_deformed.png','stvk_tooth_signed_deformed_x2_100mm.png').replace("'u ×10 display'","'100 mm; u ×2 display'")
source=source.replace("orientation='horizontal'","orientation='horizontal',extend='both',extendfrac=.025")
source=source.replace("cax=old.axmm(fig,139,12,1.3,19))","cax=old.axmm(fig,139,12,1.3,19),extend='both',extendfrac=.035)")
original.reference_cmap=previous.palette();exec(compile(source,__file__,'exec'),original.__dict__);original.figure1()
(N/'review/figure1_crown_root_revision.json').write_text(json.dumps(REPORT,indent=2));print('Figure 1 selective revision saved.')
