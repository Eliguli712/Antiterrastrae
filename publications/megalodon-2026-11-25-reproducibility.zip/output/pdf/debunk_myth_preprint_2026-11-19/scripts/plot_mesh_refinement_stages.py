"""Show global refinement and magnified local refinement on separate axes."""
import json

import matplotlib.pyplot as plt
import numpy as np

import revise_figures as layout


def main():
    data = json.loads((layout.REVIEW/'mesh_convergence_relative.json').read_text())
    quadrature = np.array(data['signed_Relative_Q95_percent'])
    levels = data['levels']
    counts = data['tetrahedra']
    last_step = np.abs(quadrature[-2])
    np.testing.assert_allclose(last_step, data['A2_relative_absolute_Q95_percent'])
    assert last_step.max() < .233

    figure = layout.canvas(58, 91)
    layout.panel(figure, 1, 89, 'a')
    layout.txt(figure, 31.5, 88, r'$Q_{0.95}$ deviation from A3 (%)', 6.3,
               ha='center', va='top')
    global_axis = layout.axmm(figure, 7, 49.6, 21, 23.5)
    local_axis = layout.axmm(figure, 35.1, 49.6, 21, 23.5)
    layout.txt(figure, 17.5, 76.1, 'Global', 5.7, ha='center')
    layout.txt(figure, 45.6, 76.1, 'Local', 5.7, ha='center')
    for stage, axis, tag, limits, ticks in [
        (slice(0, 3), global_axis, 'o', (-8.2, 10.7), [-8, 0, 8]),
        (slice(2, 6), local_axis, 'x', (-.65, 1.54), [-.5, 0, .5, 1., 1.5]),
    ]:
        x = np.arange(len(levels[stage]))
        for colour, differences in zip(layout.COLORS, quadrature[stage].T):
            axis.plot(x, differences, '-', marker=tag, c=colour, ms=2.4, lw=.65, mew=.65)
        axis.set(ylim=limits, xlim=(-.13, len(x)-.87))
        axis.set_yticks(ticks)
        axis.set_xticks(x, levels[stage])
        axis.tick_params(pad=1., labelsize=5.15)
        axis.grid(axis='y', alpha=.2, lw=.45)
    legend = [plt.Line2D([], [], c=colour, lw=1, label=label)
              for label, colour in zip(layout.LABELS, layout.COLORS)]
    figure.legend(handles=legend, ncol=6, loc='center', bbox_to_anchor=(.515, .906),
                  frameon=False, fontsize=4.65, handlelength=.8,
                  columnspacing=.68, handletextpad=.28, borderaxespad=0)
    layout.txt(figure, 31.5, 44.9, 'Mesh stages in execution order', 5.15, ha='center')

    axis = layout.axmm(figure, 11, 9, 44, 25)
    axis.bar(range(6), last_step, color=layout.COLORS, width=.7)
    axis.axhline(.5, ls='--', c='#333333', lw=.65)
    axis.set_xticks(range(6), layout.LABELS, fontsize=5.1)
    axis.set_ylabel('A2–A3 change (%)', labelpad=1)
    axis.set(ylim=(0, .56))
    axis.tick_params(pad=1, labelsize=5.5)
    for i, value in enumerate(last_step):
        axis.text(i, value+.012, f'{value:.3f}', ha='center', fontsize=5.1)
    layout.panel(figure, 1, 39, 'b')
    layout.txt(figure, 31, 38.3, 'All six below 0.233%', 6.5, ha='center', va='top')
    all_max = data['max_A2_relative_absolute_all_quantiles_percent']
    assert all_max < .60
    layout.txt(figure, 31, 1.6, 'Dashed: 0.5%; 18-quantile maximum <0.60%', 5.1, ha='center')
    layout.save(figure, 'mesh_convergence_stages')

    data['horizontal_axes'] = 'Ordered categorical stage positions, with actual tetrahedron counts retained.'
    data['zoom'] = {'global_stages': levels[:3], 'local_stages': levels[2:6],
                    'tetrahedral_elements': dict(zip(levels, counts))}
    (layout.REVIEW/'mesh_convergence_stages.json').write_text(json.dumps(data, indent=2)+'\n')


if __name__ == '__main__':
    main()
