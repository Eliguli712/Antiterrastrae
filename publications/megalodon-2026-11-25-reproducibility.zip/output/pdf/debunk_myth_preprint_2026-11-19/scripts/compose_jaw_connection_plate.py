"""Combine the tested global load-transfer view and the local connection solve."""
from pathlib import Path

import fitz


def main():
    figures = Path(__file__).resolve().parents[1] / 'figures'
    with fitz.open(figures / 'boundary_edge_transfer_top.pdf') as top, \
         fitz.open(figures / 'jaw_root_connection_FEA.pdf') as bottom, fitz.open() as combined:
        a, b = top[0].rect, bottom[0].rect
        assert abs(a.width-b.width) < .2
        height = a.height + b.height
        page = combined.new_page(width=a.width, height=height)
        page.show_pdf_page(a, top, 0)
        page.show_pdf_page(fitz.Rect(0, a.height, a.width, height), bottom, 0)
        combined.save(figures / 'boundary_edge_transmission_distributed.pdf', garbage=4, deflate=True)
        page.get_pixmap(dpi=220, alpha=False).save(figures / 'boundary_edge_transmission_distributed.png')


if __name__ == '__main__':
    main()
