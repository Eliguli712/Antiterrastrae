"""Anonymous readback of the deployed paper, source and preserved legacy PDF."""
from pathlib import Path
import hashlib
import json
import requests

N = Path(__file__).resolve().parents[1]
S = N.parents[2] / 'output/antiterrastrae_publish'
BASE = 'https://eliguli712.github.io/Antiterrastrae/'
session = requests.Session()  # No authentication, cookies or Git credential.
catalog = session.get(BASE + 'publications/catalog.json', params={'edition': '20261125'}, timeout=45)
catalog.raise_for_status()
paper = catalog.json()['documents'][0]
assert paper['date'] == '25 November 2026' and paper['pages'] == 12
local = json.loads((S / 'publications/catalog.json').read_text())['documents'][0]
assert paper == local
checks = []
for name in ['megalodon-current-preprint.pdf', 'megalodon-current-preprint-source.zip',
             'megalodon-9page-report.pdf', 'megalodon-2026-11-23-development.pdf']:
    expected = S / 'publications' / name
    request = session.get(BASE + 'publications/' + name, params={'edition': '20261125'},
                          stream=True, timeout=(30, 90))
    request.raise_for_status()
    h, size = hashlib.sha256(), 0
    for chunk in request.iter_content(1024 * 1024):
        h.update(chunk)
        size += len(chunk)
    request.close()
    assert size == expected.stat().st_size
    assert h.hexdigest() == hashlib.file_digest(expected.open('rb'), 'sha256').hexdigest()
    checks.append(dict(file=name, status=200, bytes=size, sha256=h.hexdigest(),
                       method='complete anonymous streamed download'))
for name in ['megalodon-P1-P2-validation.zip', 'megalodon-interface-validation.zip',
             'megalodon-threshold-validation.zip']:
    request = session.get(BASE + 'publications/' + name, headers={'Range': 'bytes=0-1023'},
                          stream=True, timeout=(30, 60))
    request.raise_for_status()
    prefix = next(request.iter_content(1024))
    assert prefix.startswith(b'PK')
    checks.append(dict(file=name, status=request.status_code,
                       content_range=request.headers.get('Content-Range'),
                       method='anonymous ZIP-signature byte-range check'))
    request.close()
cv = session.get(BASE + 'cv.html', params={'edition': '20261125'}, timeout=45)
cv.raise_for_status()
assert 'In development · 12 pages · 25 November 2026' in cv.text
assert 'DebunkMeg_Jaw_Tooth_Edge_Transfer_2026-11-23.zip' in cv.text
assert 'DebunkMeg_Jaw_Objective_10kPa_NH_2026-11-23.zip' in cv.text
result = dict(status='passed', paper_pages=12, edition='25 November 2026',
              catalog_matches_local=True, CV_current_and_legacy_links=True,
              files=checks, authentication='none',
              legacy_preserved=checks[2]['sha256'] ==
              '2f0e465c25db57de7080e338ed655d10fe16f7fb9f5d84df2797b9714c33fe6c')
assert result['legacy_preserved']
(N / 'review/development_public_access_2026-11-25.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
