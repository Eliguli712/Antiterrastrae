#!/usr/bin/env python3
"""Display-only Figure 1 changes, preserving stress values and all stress axes."""
from pathlib import Path
import hashlib, inspect, json, re, zipfile
import numpy as np
from scipy.ndimage import gaussian_filter
from scipy.spatial import cKDTree
from PIL import Image,ImageDraw,ImageFont
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import matplotlib.patheffects as pe
import pyvista as pv
import profile_figures as original

N=Path(__file__).resolve().parents[1];P=N.parents[2];F=N/'figures'
REPORT={}


def sha(p):
    with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def palette():
    source=P/'full_3D/Megalodon_FullCT_StressColors_PBR.3mf'
    with zipfile.ZipFile(source) as z:
        with z.open('3D/3dmodel.model') as stream:prefix=stream.read(520000).decode()
    group=re.search(r'<m:colorgroup id="100"[^>]*>(.*?)</m:colorgroup>',prefix,re.S)[1]
    colors=re.findall(r'<m:color color="(#[0-9A-Fa-f]{8})"',group)
    assert len(colors)==512
    rgba=np.array([[int(c[k:k+2],16) for k in [1,3,5,7]] for c in colors],np.uint8)
    (N/'numerics/reference_palette_512.json').write_text(json.dumps({'source':str(source.relative_to(P)),'group_id':100,'RGBA_8bit':rgba.tolist(),'axis_unchanged':True},indent=2))
    REPORT['palette']={'source':str(source.relative_to(P)),'entries':512,'RGBA_sha256':hashlib.sha256(rgba.tobytes()).hexdigest(),'meaning':'Appearance palette only; original numerical scalar field, linear normalisation and limits are unchanged.'}
    return ListedColormap(rgba/255,name='archived_reference_512')


def render(cmap):
    rawfile=P/'DICOM_16um/exports/von_mises_data_smoothed.txt'
    raw=np.loadtxt(rawfile,comments='%');v=np.load(P/'output/tooth_continuous_surfaces/cache/fe_v.npy',mmap_mode='r');faces=np.load(P/'output/tooth_continuous_surfaces/cache/fe_f.npy',mmap_mode='r')
    _,near=cKDTree(raw[:,:3]).query(v,workers=2);vm=raw[near,3]/1e6
    record=json.loads((N/'numerics/archive_axis_comparison/summary.json').read_text());limits=np.array(record['original_display_limits_MPa'])
    meta=json.loads((P/'output/tooth_continuous_surfaces/source_report.json').read_text())['fe']
    q=(v-np.array(meta['orientation_center_mm']))@np.array(meta['orientation_basis']);q[:,:2]*=-1
    poly=pv.PolyData(q,np.column_stack([np.full(len(faces),3,np.int32),faces]).ravel());poly['vm_MPa']=vm
    for j,camera in enumerate([(0,0,150),(100,20,140),(0,0,-150)]):
        viewer=pv.Plotter(off_screen=True,window_size=(1400,1250));viewer.set_background('white')
        viewer.add_mesh(poly,scalars='vm_MPa',cmap=cmap,n_colors=512,clim=limits,lighting=False,show_scalar_bar=False)
        viewer.camera_position=[camera,(0,0,0),(0,1,0)];viewer.enable_parallel_projection();viewer.reset_camera();im=viewer.screenshot(return_img=True);viewer.close()
        yy,xx=np.where(np.any(im[:,:,:3]<245,axis=2));Image.fromarray(im).crop((max(0,int(xx.min())-10),max(0,int(yy.min())-10),min(im.shape[1],int(xx.max())+11),min(im.shape[0],int(yy.max())+11))).save(F/f'archive_reference_palette_view_{j}.png')
    REPORT['stress']={'source':str(rawfile.relative_to(P)),'source_sha256':sha(rawfile),'vertices':len(v),'triangles':len(faces),'assigned_vertex_values_sha256':hashlib.sha256(vm.tobytes()).hexdigest(),'units':'MPa','limits':limits.tolist(),'scale':'linear','ticks':[.06,.1,.2,.3],'field_and_camera_unchanged':True,'lighting':False,'render_window_pixels':[1400,1250]}


def matte():
    REPORT['photographs']={};font=ImageFont.truetype('/System/Library/Fonts/Supplemental/Arial.ttf',43)
    for key in ['a','b']:
        src=F/f'specimen_photo_{key}_bordercrop.png';im=Image.open(src).convert('RGB');rgb=np.asarray(im).astype(float)/255
        blue=(rgb[:,:,2]>1.4*rgb[:,:,0])&(rgb[:,:,2]>1.05*rgb[:,:,1])&(rgb[:,:,2]>110/255)
        luminance=rgb@np.array([.2126,.7152,.0722]);base=gaussian_filter(luminance,18);sat=rgb.max(2)-rgb.min(2)
        mask=np.clip((luminance-.28)/.32,0,1)*np.clip((.24-sat)/.2,0,1)*np.clip((luminance-base-.025)/.16,0,1)
        corrected=luminance-.70*mask*np.maximum(luminance-base,0)
        ratio=np.divide(corrected,luminance,out=np.ones_like(corrected),where=luminance>0)
        result=np.uint8(np.round(255*np.clip(rgb*ratio[:,:,None],0,1)));source=np.asarray(im)
        result[blue]=source[blue];assert np.array_equal(result[blue],source[blue])
        out=Image.fromarray(result);draw=ImageDraw.Draw(out);colour=(23,100,219)
        if key=='a':pos=(105,277)
        else:
            # Existing archive image-coordinate landmark, transformed only by its crop.
            path=[(293-79,600-191),(269-79,622-191),(257-79,661-191),(246-79,693-191)]
            draw.line(path,fill=colour,width=4);pos=(242,435)
        draw.text(pos,'†',font=font,fill=colour,stroke_width=1)
        out.save(F/f'specimen_photo_{key}_matte.png')
        box=(int(.13*out.width),int(.42*out.height),int(.91*out.width),int(.73*out.height))
        out.crop(box).save(F/f'photograph_junction_matte_{key}.png')
        REPORT['photographs'][key]={'source':src.name,'source_sha256':sha(src),'derivative':f'specimen_photo_{key}_matte.png','method':'Local luminance highlight compression; no inpainting, geometry change or recovered texture. Original pixels remain in the source file.','blue_source_pixels_preserved':int(blue.sum()),'added_marker':'Blue dagger; observed edge defect, not a diagnosed fracture mechanism.','clipped_white_pixels_in_source':int((source.min(2)>=250).sum())}


def root_ct():
    a=np.load(P/'output/ct_profiles_2026-11-09/data/native_profiles_and_maximum_sections.npz');raw=a['sagittal_raw_maximum']
    origin=np.array([4.176,.198,16.818]);x0=int((13-origin[1])/.018);x1=int((28-origin[1])/.018);y0=int((45-origin[2])/.018);y1=int((56-origin[2])/.018);patch=raw[y0:y1,x0:x1]
    limits=np.quantile(patch[patch>10361.669921875],[.01,.99]);ex=[origin[1]+x0*.018,origin[1]+x1*.018,origin[2]+y0*.018,origin[2]+y1*.018]
    def draw(ax,large=False):
        ax.imshow(patch,cmap='gray_r',origin='lower',vmin=limits[0],vmax=limits[1],extent=ex,interpolation='none')
        size=9 if large else 5.4
        for label,point,text,colour in [('1',(18.6,53.8),(15.4,55.0),'#1178ad'),('2',(26.0,47.6),(23.4,45.6),'#b64d0b')]:
            ax.annotate(label,point,xytext=text,color=colour,fontsize=size,weight='bold',arrowprops={'arrowstyle':'-','color':colour,'lw':.6},path_effects=[pe.withStroke(linewidth=1.4,foreground='white')])
        ax.set_xlabel('Y (mm)',fontsize=size,labelpad=1);ax.set_ylabel('Z (mm)',fontsize=size,labelpad=1);ax.tick_params(labelsize=size-.3,pad=1)
        ax.set_xlim(ex[:2]);ax.set_ylim(ex[2:])
    fig=original.old.canvas(30,29);ax=original.old.axmm(fig,7,5,22,23);draw(ax);original.old.save(fig,'junction_CT_root_annotated');fig.savefig(F/'junction_CT_root_annotated.png',dpi=1200)
    fig,ax=plt.subplots(figsize=(6.6,5));draw(ax,True);ax.set_title('Native CT root-side structure | X = 17.658 mm',fontsize=11)
    ax.text(.01,-.16,'1  Root-side mineralised matrix     2  Low-attenuation track\n18 µm native voxels; no tissue identity or preserved soft tissue inferred.',transform=ax.transAxes,fontsize=8.5)
    fig.subplots_adjust(bottom=.2);fig.savefig(F/'Figure1_d2_root_CT_detail.pdf');fig.savefig(F/'Figure1_d2_root_CT_detail.png',dpi=600);plt.close(fig)
    REPORT['CT']={'source':'native_profiles_and_maximum_sections.npz / sagittal_raw_maximum','native_X_index':749,'plane_X_LPS_mm':17.658,'crop_zyx':[y0,y1,x0,x1],'unchanged_YZ_axes_mm':ex,'unchanged_local_contrast_limits':limits.tolist(),'voxel_spacing_mm':.018,'labels':{'1':'Root-side mineralised matrix','2':'Low-attenuation track; composition/contents undetermined'},'non_claim':'No preserved soft tissue, independently identified enameloid–dentine junction, or histologically verified root-canal network.'}


def assemble(cmap):
    src=inspect.getsource(original.figure1).split(' provenance=[]')[0]
    src=src.replace("f'stvk_tooth_view_{j}.png'","f'archive_reference_palette_view_{j}.png'")
    src=src.replace("'StVK σvM\\n(MPa), log'","'Archive σvM\\n(MPa), linear'")
    src=src.replace("norm=LogNorm(.1,300),cmap='turbo'","norm=plt.Normalize(.05676644283690944,.32688821709539363),cmap=reference_cmap")
    src=src.replace("cb.set_ticks([.1,1,10,100,300],labels=['0.1','1','10','100','300'])","cb.set_ticks([.06,.1,.2,.3],labels=['0.06','0.10','0.20','0.30'])")
    src=src.replace('specimen_photo_a_bordercrop.png','specimen_photo_a_matte.png').replace('specimen_photo_b_bordercrop.png','specimen_photo_b_matte.png')
    src=src.replace("f'photograph_junction_{key}.png'","f'photograph_junction_matte_{key}.png'").replace("F/'junction_CT_detail.png'","F/'junction_CT_root_annotated.png'")
    src=src.replace("'Original pixels; unscaled'","'Glare-compressed display'")
    original.reference_cmap=cmap
    exec(compile(src,__file__,'exec'),original.__dict__);original.figure1()


if __name__=='__main__':
    cmap=palette();render(cmap);matte();root_ct();assemble(cmap)
    (N/'review/figure1_palette_matte_root.json').write_text(json.dumps(REPORT,indent=2))
    print('Figure 1: original 512-colour palette mapped; all stress axes preserved; matte derivatives and CT labels saved.')
