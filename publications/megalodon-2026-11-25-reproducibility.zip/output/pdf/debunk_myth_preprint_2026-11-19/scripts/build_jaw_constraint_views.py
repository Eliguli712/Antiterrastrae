#!/usr/bin/env python3
"""Build the original jaw model in the shared 3-by-2 reference orientation."""
from build_jaw_reference_constraints import main

if __name__ == "__main__":
    main()
