"""Insert only independently verified10kPa full-neo-Hookean jaw fields in Fig.5."""
from pathlib import Path
import hashlib,json,shutil
import numpy as np
import finer_jaw_figures as plate

N=Path(__file__).resolve().parents[1];P=N.parents[2]
J=P/'output/jaw_full_stvk_2026-11-20';case=J/'data/L2_10kPa_NH_polish'
run=json.loads((J/'review/run_NH_polish_001/manifest.json').read_text())
assert run['run']['status']=='completed','Do not render an incomplete equilibrium as a result.'
r=json.loads((case/'results.json').read_text())
audit=json.loads((J/'review/audit_NH_10kPa_001/results.json').read_text())
assert r['status']=='verified_stationary_equilibrium' and audit['status']=='passed'
assert r['reference_traction_Pa']==[0,-10000,0] and r['all_material_cells_neo_Hookean']
assert hashlib.file_digest((case/'fields.npz').open('rb'),'sha256').hexdigest()==audit['fields_sha256']
derived=N/'numerics/jaw_objective_plot';derived.mkdir(exist_ok=True)
a=np.load(case/'fields.npz')
# Unchanged, audited fine-mesh boundary and owners from the verified 1 kPa field.
old=np.load(P/'output/ct_fea_calibrated_2026-11-08/data/jaw_L2_full_1kPa/fields.npz')
np.testing.assert_array_equal(a['tets'],old['tets']);np.testing.assert_array_equal(a['points_m'],old['points_m'])
np.savez_compressed(derived/'fields.npz',points_m=a['points_m'],tets=a['tets'],boundary_faces=old['boundary_faces'],boundary_owner=old['boundary_owner'],von_mises_Pa=a['von_mises_Pa'],equivalent_strain=a['equivalent_strain'])
base_record=plate.record
meta=dict(r,nonlinear_Q50_Q95_Q99_MPa=r['Q50_Q95_Q99_MPa'],reference_span_mm=505.8559875485156)
def actual(level,law):
 if law=='neo_hookean':
  if level!=2:raise FileNotFoundError('Full objective NH10kPa is verified only on L2.')
  return derived,meta
 return base_record(level,law)
plate.record=actual
backup=N/'original_versions/before_objective_jaw_10kPa'
backup.mkdir(parents=True,exist_ok=True)
for rel in ['figures/jaw_comsol_3x2.pdf','figures/jaw_comsol_3x2.png','svg/jaw_comsol_3x2.svg','figures/field_qf_jaw_calibration.pdf','figures/jaw_calibration_strip.pdf','figures/jaw_fine_full_vm.png','review/finer_jaw_display.json','review/jaw_calibration_curves.json']:
 p=N/rel;target=backup/rel;target.parent.mkdir(parents=True,exist_ok=True)
 if p.exists() and not target.exists():shutil.copy2(p,target)
plate.render_fields('neo_hookean')
plate.calibration('neo_hookean')
# Figure 1 retains its explicitly labelled wide-band image and its own provenance.
shutil.copy2(backup/'figures/jaw_fine_full_vm.png',N/'figures/jaw_fine_full_vm.png')
shutil.copy2(N/'review/finer_jaw_display.json',N/'review/Figure5_objective_jaw_provenance.json')
shutil.copy2(backup/'review/finer_jaw_display.json',N/'review/finer_jaw_display.json')
(derived/'source_record.json').write_text(json.dumps(dict(source_fields=str(case/'fields.npz'),source_sha256=audit['fields_sha256'],source_audit=str(J/'review/audit_NH_10kPa_001/results.json'),reference_traction_Pa=[0,-10000,0],rendering='Common undeformed camera; raw owner-element fields; original logarithmic colour ranges retained.',scope='Single fine-mesh full objective case, not a full-neo-Hookean mesh-convergence sequence.'),indent=2))
print('Rendered verified full objective jaw comparison and scale-free L2 reference.')
