"""Render the full 18 µm curvature field in two opposite views."""
import json
from pathlib import Path
import struct
import subprocess
import tempfile

import fitz
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
import trimesh

from curvature_core import curvature

PAPER = Path(__file__).resolve().parents[1]
PROJECT = PAPER.parents[2]
FIGURES = PAPER / 'figures'
CACHE = PROJECT / 'output/current_native74_stress_2026-11-20/cache'
V, F = 37_951_699, 74_293_846
LABELS = ('$K$', '$|H|$', '$H$')
UNITS = ('mm⁻²', 'mm⁻¹', 'mm⁻¹')
COVER = 0.99
LINEAR_WIDTH = 0.06
COLOURMAPS = [mpl.colormaps[name] for name in ('RdBu_r', 'viridis', 'RdBu_r')]


def render(vertices, faces, center, basis, fields, limits):
    """Each raster receives every original face. The reverse camera flips x and depth."""
    norms = [mpl.colors.AsinhNorm(linear_width=LINEAR_WIDTH * lim,
                                  vmin=0 if i == 1 else -lim, vmax=lim)
             for i, lim in enumerate(limits)]
    raster_checks = {}
    with tempfile.TemporaryDirectory() as tmp:
        executable = Path(tmp) / 'raster'
        subprocess.run(['clang++', '-O3', '-std=c++17',
                        str(PAPER / 'scripts/native_figure8_raster.cpp'),
                        '-o', str(executable)], check=True)
        for side, sign in (('front', 1), ('reverse', -1)):
            with subprocess.Popen([str(executable), tmp], stdin=subprocess.PIPE,
                                  stderr=subprocess.PIPE) as process:
                for start in range(0, F, 600_000):
                    part = faces[start:start + 600_000]
                    ids, indices = np.unique(part, return_inverse=True)
                    coordinates = (vertices[ids] - center) @ basis
                    px = 900 + sign * coordinates[:, 0] * 30
                    py = 745 - coordinates[:, 1] * 30
                    pz = -sign * coordinates[:, 2]
                    triangles = indices.astype('<u4').tobytes()
                    for i, (field, norm, cmap) in enumerate(zip(fields, norms, COLOURMAPS)):
                        rgb = cmap(norm(field[ids]))[:, :3]
                        xyz_rgb = np.column_stack((px, py, pz, rgb)).astype('<f4')
                        process.stdin.write(struct.pack('<III', i, len(ids), len(part)))
                        process.stdin.write(xyz_rgb.tobytes())
                        process.stdin.write(triangles)
                process.stdin.close()
                counts = process.stderr.read().decode()
                assert process.wait() == 0 and counts.count(str(F)) == 3, counts
            for i in range(3):
                raster = (Path(tmp) / f'native_figure8_{i}.rgba').read_bytes()
                rgba = Image.frombytes('RGBA', (1800, 1600), raster)
                crop = rgba.getbbox()
                assert crop and crop[0] > 1 and crop[1] > 1 and crop[2] < 1799 and crop[3] < 1599
                rgba.crop(crop).save(FIGURES / f'native18_curvature_{side}_{i}.png')
            raster_checks[side] = counts
            print(side, counts, flush=True)
    return raster_checks, norms


def compose(norms, limits, full_resolution=False, edge_aligned=False):
    reference = fitz.open(FIGURES / 'geometry_pack_3_curvature.pdf')
    rect = reference[0].rect
    split = 270
    right_clip = fitz.Rect(split, 0, rect.width, rect.height)
    page_width, page_height = rect.width, rect.height
    left_width = split
    if edge_aligned:
        page_width, page_height = 183*72/25.4, 77*72/25.4
        right_width = right_clip.width * page_height / right_clip.height
        left_width = page_width - right_width - 3
    left = plt.figure(figsize=(left_width / 72, page_height / 72))
    left.text(.5, .952, 'Curvature on the native 18 µm surface',
              ha='center', va='top', fontsize=8.5, weight='bold')
    for i, (norm, lim, cmap) in enumerate(zip(norms, limits, COLOURMAPS)):
        x = .064 + .309 * i
        left.text(x + .137, .857, LABELS[i], ha='center', fontsize=8)
        for side, y in [('front', .535), ('reverse', .244)]:
            axis = left.add_axes([x, y, .274, .305])
            raster = Image.open(FIGURES / f'native18_curvature_{side}_{i}.png')
            if not full_resolution:
                raster.thumbnail((335, 320), Image.Resampling.LANCZOS)
            axis.imshow(raster, interpolation='none')
            axis.set_axis_off()
        bar = left.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap),
                            cax=left.add_axes([x + .016, .205, .242, .013]),
                            orientation='horizontal', extend='max' if i == 1 else 'both')
        ticks = [0, lim / 2, lim] if i == 1 else [-lim, 0, lim]
        bar.set_ticks(ticks, labels=[f'{tick:.3g}' for tick in ticks])
        bar.ax.tick_params(labelsize=4.4, pad=1, length=1.5)
        bar.set_label(UNITS[i], fontsize=6, labelpad=2)
    left.text(.044, .685, 'Front', ha='center', va='center', rotation=90, fontsize=6)
    left.text(.044, .385, 'Reverse', ha='center', va='center', rotation=90, fontsize=6)
    left.text(.50, .064, '74,293,846 native faces submitted per map',
              ha='center', fontsize=6.5)
    with tempfile.TemporaryDirectory() as tmp:
        left.savefig(Path(tmp) / 'curvature.pdf', dpi=600)
        plt.close(left)
        with fitz.open(Path(tmp) / 'curvature.pdf') as rendered, fitz.open() as output:
            page = output.new_page(width=page_width, height=page_height)
            page.show_pdf_page(fitz.Rect(0, 0, left_width, page_height), rendered, 0)
            right_x = left_width + 3 if edge_aligned else split
            page.show_pdf_page(fitz.Rect(right_x, 0, page_width, page_height), reference, 0, clip=right_clip)
            stem = 'geometry_pack_3_native_six'
            if edge_aligned:
                stem += '_wide'
            if full_resolution:
                stem += '_full'
            output.save(FIGURES / f'{stem}.pdf', garbage=4, deflate=True)
            page.get_pixmap(matrix=fitz.Matrix(2.5, 2.5)).save(FIGURES / f'{stem}.png')


def main():
    sphere = trimesh.creation.icosphere(subdivisions=4, radius=10)
    k, h, _, area = curvature(sphere.vertices, sphere.faces)
    assert abs(k @ area - 4 * np.pi) < 1e-8 and abs(np.median(h) - .1) < .001
    vertices = np.memmap(CACHE / 'vertices.f64', '<f8', 'r', shape=(V, 3))
    faces = np.memmap(CACHE / 'triangles.u32', '<u4', 'r', shape=(F, 3))
    with np.load(PROJECT / 'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0/solution.npz') as reference:
        center, basis = reference['center_m'] * 1000, reference['basis']
    print('Computing full 18 µm curvature', flush=True)
    fields = curvature(vertices, faces)[:3]
    assert all(np.isfinite(field).all() for field in fields)
    limits = [float(np.quantile(np.abs(field), COVER)) for field in fields]
    print('P99 colour limits', limits, flush=True)
    checks, norms = render(vertices, faces, center, basis, fields, limits)
    compose(norms, limits)
    compose(norms, limits, full_resolution=True)
    record = dict(native_vertices=V, native_faces_per_map=F, native_sampling_um=18,
                  views=['front', 'reverse'], raster_checks=checks,
                  antialiasing='Lanczos image layout only, no geometry or field smoothing',
                  colour_lims=list(zip(LABELS, limits)), asinh_linear_width_fraction=LINEAR_WIDTH,
                  sphere_integral_K=float(k @ area), sphere_median_H=float(np.median(h)))
    (PAPER / 'review/native18_curvature_six.json').write_text(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
