#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>

constexpr std::size_t vertex_count = 37'951'699;
constexpr std::size_t face_count = 74'293'846;

struct MappedFile {
    void* address;
    std::size_t size;
    explicit MappedFile(const std::filesystem::path& path, std::size_t expected_size)
        : size(std::filesystem::file_size(path)) {
        if (size != expected_size) throw std::runtime_error("Wrong source length");
        int fd = open(path.c_str(), O_RDONLY);
        if (fd < 0) throw std::runtime_error("Unable to open source");
        address = mmap(nullptr, size, PROT_READ, MAP_PRIVATE, fd, 0);
        close(fd);
        if (address == MAP_FAILED) throw std::runtime_error("Unable to map source");
    }
    ~MappedFile() { munmap(address, size); }
    MappedFile(const MappedFile&) = delete;
    MappedFile& operator=(const MappedFile&) = delete;
};

struct Vec {
    double x, y, z;
    Vec operator-(Vec other) const { return {x - other.x, y - other.y, z - other.z}; }
    Vec operator+(Vec other) const { return {x + other.x, y + other.y, z + other.z}; }
    Vec operator*(double factor) const { return {x * factor, y * factor, z * factor}; }
};

double dot(Vec a, Vec b) { return a.x * b.x + a.y * b.y + a.z * b.z; }

Vec cross(Vec a, Vec b) {
    return {a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
}

struct Hit {
    uint64_t edge;
    Vec point;
};

bool intersect(const std::array<Vec, 3>& points, const std::array<uint32_t, 3>& ids,
               const std::array<double, 3>& projection, Vec tangent, double offset,
               std::array<Hit, 2>& hits) {
    int count = 0;
    for (int a = 0; a < 3; ++a) {
        int b = (a + 1) % 3;
        const double d = projection[a] - offset;
        const double e = projection[b] - offset;
        if ((d < 0) != (e < 0)) {
            uint64_t key = uint64_t(std::min(ids[a], ids[b])) << 32 | std::max(ids[a], ids[b]);
            hits[count++] = {key, points[a] + (points[b] - points[a]) * (d / (d - e))};
        }
    }
    if (count != 2) return false;
    if (dot(hits[1].point - hits[0].point, tangent) < 0) std::swap(hits[0], hits[1]);
    return true;
}

struct Sweep {
    Vec normal, u, v;
    double first, step;
    int count;
    std::vector<double> area, compensation;
    double maximum_offset;
    double minimum_vertex_gap = std::numeric_limits<double>::infinity();
};

int main(int argc, char** argv) {
    try {
        if (argc != 5) throw std::runtime_error("Use: executable vertex-file face-file config output-dir");
        const MappedFile vertex_file(argv[1], vertex_count * sizeof(Vec));
        const MappedFile face_file(argv[2], face_count * sizeof(std::array<uint32_t, 3>));
        const Vec* vertices = static_cast<const Vec*>(vertex_file.address);
        const auto* faces = static_cast<const std::array<uint32_t, 3>*>(face_file.address);
        std::ifstream config(argv[3]);
        Vec center;
        config >> center.x >> center.y >> center.z;
        std::array<Sweep, 3> sweeps;
        for (auto& sweep : sweeps) {
            config >> sweep.normal.x >> sweep.normal.y >> sweep.normal.z
                   >> sweep.u.x >> sweep.u.y >> sweep.u.z >> sweep.v.x >> sweep.v.y >> sweep.v.z
                   >> sweep.first >> sweep.step >> sweep.count;
            if (!config || sweep.count <= 0 || sweep.step <= 0) throw std::runtime_error("Invalid sweep");
            sweep.area.resize(sweep.count);
            sweep.compensation.resize(sweep.count);
        }
        const std::filesystem::path output(argv[4]);
        for (std::size_t i = 0; i < face_count; ++i) {
            const auto& ids = faces[i];
            if (*std::max_element(ids.begin(), ids.end()) >= vertex_count) {
                throw std::runtime_error("Invalid face index");
            }
            const std::array<Vec, 3> points{
                vertices[ids[0]] - center, vertices[ids[1]] - center, vertices[ids[2]] - center};
            const Vec face_normal = cross(points[1] - points[0], points[2] - points[0]);
            for (auto& sweep : sweeps) {
                const std::array<double, 3> projection{
                    dot(points[0], sweep.normal), dot(points[1], sweep.normal), dot(points[2], sweep.normal)};
                const Vec tangent = cross(sweep.normal, face_normal);
                const int start = std::max(0, int(std::ceil((*std::min_element(
                    projection.begin(), projection.end()) - sweep.first) / sweep.step)));
                const int end = std::min(sweep.count - 1, int(std::floor((*std::max_element(
                    projection.begin(), projection.end()) - sweep.first) / sweep.step)));
                for (int k = start; k <= end; ++k) {
                    std::array<Hit, 2> hits;
                    if (!intersect(points, ids, projection, tangent, sweep.first + k * sweep.step, hits)) continue;
                    const double area = .5 * dot(cross(hits[0].point, hits[1].point), sweep.normal);
                    const double corrected = area - sweep.compensation[k];
                    const double sum = sweep.area[k] + corrected;
                    sweep.compensation[k] = (sum - sweep.area[k]) - corrected;
                    sweep.area[k] = sum;
                }
            }
        }
        for (int j = 0; j < 3; ++j) {
            auto& sweep = sweeps[j];
            const int peak = int(std::max_element(sweep.area.begin(), sweep.area.end()) - sweep.area.begin());
            sweep.maximum_offset = sweep.first + peak * sweep.step;
            std::ofstream path(output / ("area-axis" + std::to_string(j + 1) + ".csv"));
            path.precision(17);
            path << "offset_mm,area_mm2\n";
            for (int k = 0; k < sweep.count; ++k) {
                path << sweep.first + k * sweep.step << ',' << sweep.area[k] << '\n';
            }
            if (!path) throw std::runtime_error("Area write failed");
        }
        std::array<std::ofstream, 3> contours;
        for (int j = 0; j < 3; ++j) {
            contours[j].open(output / ("edges-axis" + std::to_string(j + 1) + ".csv"));
            contours[j].precision(17);
            contours[j] << "start_edge,end_edge,u_start_mm,v_start_mm,u_end_mm,v_end_mm\n";
        }
        for (std::size_t i = 0; i < face_count; ++i) {
            const auto& ids = faces[i];
            const std::array<Vec, 3> points{
                vertices[ids[0]] - center, vertices[ids[1]] - center, vertices[ids[2]] - center};
            const Vec face_normal = cross(points[1] - points[0], points[2] - points[0]);
            for (int j = 0; j < 3; ++j) {
                auto& sweep = sweeps[j];
                const std::array<double, 3> projection{
                    dot(points[0], sweep.normal), dot(points[1], sweep.normal), dot(points[2], sweep.normal)};
                for (double p : projection) {
                    sweep.minimum_vertex_gap = std::min(sweep.minimum_vertex_gap, std::abs(p - sweep.maximum_offset));
                }
                std::array<Hit, 2> hits;
                if (!intersect(points, ids, projection, cross(sweep.normal, face_normal), sweep.maximum_offset, hits)) continue;
                contours[j] << hits[0].edge << ',' << hits[1].edge << ','
                            << dot(hits[0].point, sweep.u) << ',' << dot(hits[0].point, sweep.v) << ','
                            << dot(hits[1].point, sweep.u) << ',' << dot(hits[1].point, sweep.v) << '\n';
            }
        }
        for (const auto& contour : contours) if (!contour) throw std::runtime_error("Contour write failed");
        std::ofstream meta(output / "minimum-vertex-plane-gap-mm.txt");
        meta.precision(17);
        for (const auto& sweep : sweeps) meta << sweep.minimum_vertex_gap << '\n';
        if (!meta) throw std::runtime_error("Plane gap write failed");
        std::cout << "Intersected " << face_count << " faces in each principal sweep\n";
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n';
        return 1;
    }
    return 0;
}
