"""Plot executed refinement levels against the finest tested mesh."""
import json

import matplotlib.pyplot as plt
import numpy as np

import revise_figures as layout

DATA = layout.P / 'output/publication_validation_2026-11-12/data'
BASELINE = layout.B / 'numerics'
GLOBAL = [json.loads((BASELINE / f'L{i}/summary.json').read_text()) for i in range(3)]
LOCAL = [json.loads((DATA / f'local_A{i}/results.json').read_text()) for i in range(1,4)]
LEVELS = ['L0', 'L1', 'L2', 'A1', 'A2', 'A3']
N = [case['tetrahedra'] for case in GLOBAL + LOCAL]
QUANTILES = np.array([[region[key] for region in results] for results in
                      [case['table9'] for case in GLOBAL] + [case['regions'] for case in LOCAL]
                      for key in ['Q90_MPa', 'Q95_MPa', 'Q99_MPa']]).reshape(6, 3, 6)
ERROR = (QUANTILES[:, 1] / QUANTILES[-1, 1] - 1) * 100
CHANGE = np.abs(ERROR[-2])
assert np.max(CHANGE) < .233

fig = layout.canvas(58, 91)
ax = layout.axmm(fig, 11, 49, 44, 31)
ax.axhline(0, c='#53616d', ls='--', lw=.55)
ax.axvspan(N[2], N[-1], color='#dce9f2', alpha=.55)
ax.set(xscale='log', xlim=(N[0]*.79, N[-1]*1.17), ylim=(-8, 10.8))
for label, colour, differences in zip(layout.LABELS, layout.COLORS, ERROR.T):
    ax.plot(N[:3], differences[:3], '-o', c=colour, ms=2.15, lw=.7, label=label)
    ax.plot(N[2:], differences[2:], '-x', c=colour, ms=2.35, lw=.7, mew=.55)
ax.set_xticks([1e5, 1e6])
ax.set_yticks([-8,-4,0,4,8])
ax.set_xlabel('Tetrahedral elements', labelpad=1)
ax.set_ylabel(r'$Q_{0.95}$ vs A3 (%)', labelpad=1)
ax.grid(axis='y', alpha=.20, lw=.45)
ax.legend(ncol=3, fontsize=4.9, loc='lower center', bbox_to_anchor=(.57, .02),
          columnspacing=.7, handlelength=1.05)
ax.tick_params(pad=1, labelsize=5.5)
layout.panel(fig, 1, 89, 'a')
layout.txt(fig, 31.5, 88.7, 'Global and local refinement', 6.3, ha='center', va='top')
layout.txt(fig, 31.5, 84.8, 'Circle: global  |  Cross: local', 5.15, ha='center', va='top')

ax = layout.axmm(fig, 11, 9, 44, 25)
ax.bar(range(6), CHANGE, color=layout.COLORS, width=.7)
ax.axhline(.5, ls='--', c='#333333', lw=.65)
ax.set_xticks(range(6), layout.LABELS, fontsize=5.1)
ax.set_ylabel('A2–A3 change (%)', labelpad=1)
ax.set(ylim=(0, .56))
ax.tick_params(pad=1, labelsize=5.5)
for i, value in enumerate(CHANGE):
    ax.text(i, value+.012, f'{value:.3f}', ha='center', fontsize=5.1)
layout.panel(fig, 1, 39, 'b')
layout.txt(fig, 31, 38.3, 'All six below 0.233%', 6.5, ha='center', va='top')
all_max = float(np.abs(100 * (QUANTILES[-2] / QUANTILES[-1] - 1)).max())
assert all_max < .60
layout.txt(fig, 31, 1.6, 'Dashed: 0.5%; 18-quantile maximum <0.60%', 5.1, ha='center')
layout.save(fig, 'mesh_convergence_relative')

(layout.REVIEW / 'mesh_convergence_relative.json').write_text(json.dumps({
    'levels': LEVELS, 'tetrahedra': N, 'regions': layout.REGIONS,
    'signed_Relative_Q95_percent': ERROR.tolist(),
    'A2_relative_absolute_Q95_percent': CHANGE.tolist(),
    'max_A2_relative_absolute_all_quantiles_percent': all_max,
    'scope': 'A3 is a finite-grid reference; the plotted differences are not error bounds. Measured points only.'}, indent=2))
