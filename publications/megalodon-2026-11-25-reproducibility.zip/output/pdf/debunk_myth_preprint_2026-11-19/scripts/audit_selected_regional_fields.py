"""Replay the independent field audit on the four downloadable A2/A3 fields."""
from pathlib import Path
import ast
import json
import time

N=Path(__file__).resolve().parents[1]
P=N.parents[2]
D=P/'output/publication_validation_2026-11-12'
source=D/'scripts/audit_publication_fields_v3.py'
tree=ast.parse(source.read_text());nodes=[]
for node in tree.body:
    if isinstance(node,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='start' for x in node.targets):break
    nodes.append(node)
scope={'__file__':str(source),'__name__':'selected_independent_readback'}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(source),'exec'),scope)
start=time.monotonic();rows=[]
for case in ['local_A2','local_A3','bilayer_A2_0p5mm','bilayer_A3_0p5mm']:
    rows.append(scope['one'](D/'data'/case));print('Read every cell:',case,flush=True)
result=dict(status='passed',cases=rows,total_elements=sum(r['elements'] for r in rows),
            runtime_seconds=time.monotonic()-start,
            scope='Independent tensors, forces, frozen regions, principal values and CDF inequalities on exactly the supplied four raw FE fields; no continuum error bound.')
(N/'review/regional_archive_audit_001/results.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
