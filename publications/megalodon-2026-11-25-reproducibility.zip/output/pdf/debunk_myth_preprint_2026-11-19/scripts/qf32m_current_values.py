#!/usr/bin/env python3
"""Retain the frozen regional classification; display the audited A3 values."""
from pathlib import Path
import json,gc
import numpy as np
from scipy.spatial import cKDTree
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import pyvista as pv
from PIL import Image
R=Path(__file__).resolve().parents[1];P=R.parents[2]
B=P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31'
C=P/'output/pdf/debunk_myth_geometry_statistics_2026-10-31/numerics/cache/3mf'
D=P/'output/publication_validation_2026-11-12'
v=np.load(C/'optimised32_v.npy',mmap_mode='r');f=np.load(C/'optimised32_f.npy',mmap_mode='r');assert len(f)==31999434
a=np.load(B/'numerics/L2/solution.npz');centres=a['points_m'][a['tets']].mean(1)*1000;tree=cKDTree(centres)
masks=np.load(B/'numerics/L2/region_masks.npz');lab=np.full(len(centres),-1,np.int8)
for j,key in enumerate(['R0','RA','RB','Rtip','Rcr','Rroot']):lab[masks[key]]=j
result=json.loads((D/'data/local_A3/results.json').read_text());q95=np.array([r['Q95_MPa'] for r in result['regions']]);pal=(plt.colormaps['turbo'](LogNorm(.4,300)(q95))*255).astype(np.uint8)
rgba=np.full((len(v),4),[200,203,208,255],np.uint8);assigned=np.zeros(6,np.int64)
for start in range(0,len(v),400000):
    _,ids=tree.query(v[start:start+400000]);labels=lab[ids];hit=labels>=0;part=rgba[start:start+len(ids)];part[hit]=pal[labels[hit]]
    assigned+=np.bincount(labels[hit],minlength=6)
local=(np.asarray(v)-a['center_m']*1000)@a['basis']
del centres,tree;gc.collect()
poly=pv.PolyData(local,np.column_stack([np.full(len(f),3,np.int32),f]).ravel());assert poly.n_cells==31999434;poly.point_data['Q95_RGBA']=rgba
for name,pos in [('front',(0,0,150)),('oblique',(95,25,130))]:
    view=pv.Plotter(off_screen=True,window_size=(1500,1700));view.set_background('white');view.add_mesh(poly,scalars='Q95_RGBA',rgba=True,lighting=False,show_scalar_bar=False);view.camera_position=[pos,(0,0,0),(0,1,0)];view.enable_parallel_projection();view.camera.parallel_scale=29;view.render();image=view.screenshot(return_img=True);view.close();yy,xx=np.where(np.any(image[:,:,:3]<245,axis=2));Image.fromarray(image).crop((max(0,int(xx.min())-10),max(0,int(yy.min())-10),min(image.shape[1],int(xx.max())+11),min(image.shape[0],int(yy.max())+11))).save(R/'figures'/f'qf_full32m_{name}.png');print('Rendered',name,poly.n_cells,'triangles',flush=True)
(R/'review/qf32m_A3_mapping.json').write_text(json.dumps(dict(status='passed',source_faces=len(f),source_vertices=len(v),rendered_faces=poly.n_cells,decimation=False,region_classification='Frozen nearest-L2-element-centroid categories from the preceding full-surface view; grey is unassigned.',displayed_quantile_source='Audited A3 frozen-region volume quantiles',A3_Q95_MPa=q95.tolist(),assigned_vertices_by_region=assigned.tolist(),stress_map='turbo; log .4--300 MPa for regional summary only',scope='Regional reference overlay, not a native-pore/32M-element FE solve or pointwise fracture criterion.'),indent=2))
