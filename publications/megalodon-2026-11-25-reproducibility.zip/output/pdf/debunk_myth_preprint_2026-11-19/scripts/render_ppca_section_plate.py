"""Render PPCA-oriented sections of the unmodified native mesh.

The axes are the principal axes of a two-latent-dimensional isotropic PPCA
fit to the entire segmented material volume. The rank-two loading matrix
chooses the plane frame; section geometry is not a posterior-mean shape.
"""
import argparse
import csv
import hashlib
import importlib.metadata
import json
from pathlib import Path
import subprocess
import tempfile

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.path import Path as PlotPath
from matplotlib.patches import PathPatch
import numpy as np


PAPER = Path(__file__).resolve().parents[1]
PROJECT = PAPER.parents[2]
STUDY = PROJECT / "output/native_inference_2026-11-24/review/run001"
MESH = PROJECT / "output/current_native74_stress_2026-11-20/cache"
NATIVE_TRIANGLES = 74_293_846
NATIVE_VERTICES = 37_951_699
STEP = 0.009


def sha256(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def configure(source, limits, destination):
    axes = np.asarray(source["voxel_volume_PCA"]["axes_columns"])
    eigenvalues = np.asarray(source["voxel_volume_PCA"]["eigenvalues_mm2"])
    residual = source["PPCA"]["isotropic_residual_variance_mm2"]
    center = source["voxel_volume_PCA"]["center_scanner_mm"]
    loading = axes[:, :2] * np.sqrt(eigenvalues[:2] - residual)
    np.testing.assert_allclose(axes.T @ axes, np.eye(3), rtol=0, atol=1e-14)
    np.testing.assert_allclose(
        loading @ loading.T + residual * np.eye(3),
        (axes * eigenvalues) @ axes.T,
        rtol=1e-13, atol=1e-13,
    )
    u = (axes[:, 1], -axes[:, 2], axes[:, 1])
    v = (axes[:, 2], -axes[:, 0], -axes[:, 0])
    rows = [center]
    for j in range(3):
        normal = axes[:, j]
        np.testing.assert_allclose(np.cross(u[j], v[j]), normal, atol=1e-14)
        start, step, count = limits[j, 3:]
        assert step == STEP * 2
        rows.append([*normal, *u[j], *v[j], start, STEP, 2 * int(count) - 1])
    with destination.open("w") as file:
        for row in rows:
            print(*(format(value, ".17g") for value in row), file=file)
    return loading, u, v


def closed_paths(path):
    outgoing = {}
    incoming = set()
    with path.open() as file:
        for record in csv.DictReader(file):
            start, end = (int(record[key]) for key in ("start_edge", "end_edge"))
            assert start not in outgoing and end not in incoming
            here = np.array([float(record["u_start_mm"]), float(record["v_start_mm"])])
            there = np.array([float(record["u_end_mm"]), float(record["v_end_mm"])])
            outgoing[start] = end, here, there
            incoming.add(end)
    assert outgoing.keys() == incoming
    edge_count = len(outgoing)
    areas = []
    paths = []
    while outgoing:
        first = cursor = next(iter(outgoing))
        points = []
        while True:
            cursor, here, there = outgoing.pop(cursor)
            points.append(here)
            next_point = points[0] if cursor == first else outgoing[cursor][1]
            np.testing.assert_allclose(there, next_point, atol=2e-12, rtol=0)
            if cursor == first:
                break
        polygon = np.array([*points, points[0]])
        signed_area = 0.5 * np.sum(
            polygon[:-1, 0] * polygon[1:, 1] - polygon[1:, 0] * polygon[:-1, 1]
        )
        areas.append(float(signed_area))
        codes = np.full(len(polygon), PlotPath.LINETO, dtype=np.uint8)
        codes[0], codes[-1] = PlotPath.MOVETO, PlotPath.CLOSEPOLY
        paths.append(PlotPath(polygon, codes))
    return PlotPath.make_compound_path(*paths), np.asarray(areas), edge_count


def render(data, paths, destination):
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.size": 7,
        "axes.spines.top": False, "axes.spines.right": False, "pdf.fonttype": 42,
        "path.simplify": False, "lines.solid_capstyle": "round",
    })
    figure = plt.figure(figsize=(183 / 25.4, 105 / 25.4))
    grid = figure.add_gridspec(2, 3, left=.079, right=.97, top=.886, bottom=.120,
                               wspace=.42, hspace=.48, height_ratios=(1.6, 1))
    for j, (curve, path) in enumerate(zip(data, paths, strict=True)):
        offset, area = curve.T
        peak = area.argmax()
        section = figure.add_subplot(grid[0, j], facecolor="#07121c")
        section.add_patch(PathPatch(path, facecolor="#86d5e3", edgecolor="none"))
        min_xy = path.vertices.min(axis=0) - .9
        max_xy = path.vertices.max(axis=0) + .9
        section.set(xlim=(min_xy[0], max_xy[0]), ylim=(min_xy[1], max_xy[1]),
                    aspect="equal", xlabel="$u$ (mm)", ylabel="$v$ (mm)")
        column = grid[0, j].get_position(figure)
        figure.text((column.x0 + column.x1) / 2, .977,
                    f"PPCA axis {j + 1} maximum", fontsize=7.1, ha="center", va="top")
        figure.text((column.x0 + column.x1) / 2, .938,
                    f"{area[peak]:.3f} mm²  |  {offset[peak]:+.3f} mm",
                    fontsize=7, ha="center", va="top")
        figure.text(column.x0 - .045, .978, "abc"[j], fontsize=9, weight="bold", va="top")
        section.tick_params(labelsize=6, length=2.5, pad=1.5)

        profile = figure.add_subplot(grid[1, j], facecolor="white")
        profile.plot(offset, area, color="#126688", linewidth=1.05)
        profile.axvline(offset[peak], color="#bc4536", lw=.8, ls=":")
        profile.plot(offset[peak], area[peak], marker="+", color="#bc4536",
                     markersize=6, markeredgewidth=.95)
        profile.set(xlabel="Centroid offset (mm)", ylabel="Section area (mm²)", ylim=(0, area[peak]*1.09))
        profile.grid(alpha=.16, lw=.45)
        profile.tick_params(labelsize=6, length=2.5, pad=1.5)
        profile.text(-.20, 1.05, "def"[j], transform=profile.transAxes,
                     fontsize=9, weight="bold", ha="right")
        profile.text(.02, 1.048, f"{len(curve):,} planes", transform=profile.transAxes,
                     fontsize=6.5, color="#526779")
    figure.text(.52, .019, "Native surface intersections • 0.009 mm computation grid • no attenuation resampling",
                fontsize=6.3, color="#405665", ha="center")
    figure.savefig(destination)
    figure.savefig(destination.with_suffix(".png"), dpi=550)
    plt.close(figure)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--recompute", action="store_true", help="Re-intersect the immutable full native mesh.")
    arguments = parser.parse_args()
    product = PAPER / "numerics/figure2_ppca_sections"
    product.mkdir(parents=True, exist_ok=True)
    result_source = STUDY / "result.json"
    result = json.loads(result_source.read_text())
    assert result["native_triangles"] == NATIVE_TRIANGLES
    assert result["native_vertices"] == NATIVE_VERTICES
    original_config = STUDY / "data/section_config.txt"
    configuration = product / "section_config.txt"
    loading, u, v = configure(result, np.loadtxt(original_config, skiprows=1), configuration)
    code = Path(__file__).with_name("native_ppca_sections.cpp")
    sources = [MESH / "vertices.f64", MESH / "triangles.u32"]
    if arguments.recompute:
        with tempfile.TemporaryDirectory() as temp:
            program = Path(temp) / "native-ppca-sections"
            subprocess.run(["c++", "-O3", "-std=c++17", str(code), "-o", str(program)], check=True)
            subprocess.run([str(program), *map(str, sources), str(configuration), str(product)], check=True)
    curves = []
    paths = []
    audit = []
    volume = float((STUDY / "data/surface-totals.txt").read_text().split()[3])
    gaps = np.loadtxt(product / "minimum-vertex-plane-gap-mm.txt")
    assert np.all(gaps > 1e-12), "A selected plane reaches a vertex within numerical tolerance"
    for j in range(3):
        curve = np.loadtxt(product / f"area-axis{j+1}.csv", delimiter=",", skiprows=1)
        original = np.loadtxt(STUDY / "data" / f"native-sections-axis{j+1}.csv",
                              delimiter=",", skiprows=1)
        np.testing.assert_allclose(curve[::2], original, rtol=0, atol=3e-8)
        peak = curve[curve[:, 1].argmax()]
        path, signed_areas, count = closed_paths(product / f"edges-axis{j+1}.csv")
        np.testing.assert_allclose(signed_areas.sum(), peak[1], rtol=0, atol=3e-8)
        integrated = float(np.trapezoid(curve[:, 1], curve[:, 0]))
        relative_error = abs(integrated / volume - 1)
        assert relative_error < 1e-6
        audit.append({
            "axis": j + 1,
            "plane_count": len(curve),
            "maximum_offset_mm": float(peak[0]),
            "maximum_area_mm2": float(peak[1]),
            "maximum_18um_area_mm2": float(original[:, 1].max()),
            "max_absolute_difference_at_aligned_18um_points_mm2": float(np.max(abs(curve[::2, 1] - original[:, 1]))),
            "integrated_volume_relative_error": relative_error,
            "minimum_vertex_to_peak_plane_distance_mm": float(gaps[j]),
            "signed_loop_area_mm2": float(signed_areas.sum()),
            "oriented_edges": count,
            "positive_loops": int((signed_areas > 0).sum()),
            "negative_loops": int((signed_areas < 0).sum()),
            "in_plane_u": u[j].tolist(),
            "in_plane_v": v[j].tolist(),
        })
        curves.append(curve)
        paths.append(path)

    destination = PAPER / "figures/geometry_pack_2_ppca.pdf"
    render(curves, paths, destination)
    record = {
        "status": "completed",
        "assertion_tested": "All original oriented triangles are intersected in the verified PPCA frame. "
                            "All shared sections match the previous sweep. Closed oriented loops reproduce the peak areas.",
        "native_faces": NATIVE_TRIANGLES,
        "native_vertices": NATIVE_VERTICES,
        "native_CT_spacing_mm": 0.018,
        "computational_plane_spacing_mm": STEP,
        "PPCA": {**result["PPCA"], "loading_matrix_mm": loading.tolist()},
        "sections": audit,
        "reported_material_volume_mm3": volume,
        "sources_sha256": {str(path.relative_to(PROJECT)): sha256(path) for path in (
            *sources, result_source, original_config, configuration, code,
        )},
        "products_sha256": {str(path.relative_to(PAPER)): sha256(path) for path in
                            (destination, destination.with_suffix(".png"), *sorted(product.glob("*.csv")))},
        "numerical_environment": {name: importlib.metadata.version(name) for name in ("numpy", "matplotlib")},
        "interpretation": "Maxima apply to the declared plane grid. The PPCA residual includes real thickness. "
                          "The denser computational plane grid cannot improve the CT acquisition resolution.",
    }
    (PAPER / "review/figure2_ppca_sections.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
