"""Remove repeated imaging explanations, keeping all recorded values."""
from pathlib import Path
import re
import shutil

N = Path(__file__).resolve().parents[1]
p = N / 'DebunkMeg_complete_2026-11-19.tex'
backup = N / 'original_versions/before_imaging_prose_2026-11-21.tex'
assert not backup.exists()
shutil.copy2(p, backup)
s = p.read_text()
old = []


def replace(prefix, new):
    global s
    matches = list(re.finditer('(?m)^' + re.escape(prefix), s))
    assert len(matches) == 1
    start = matches[0].start()
    end = s.find('\n\n', start)
    if end < 0:
        end = len(s)
    old.append(s[start:end])
    s = s[:start] + new + s[end:]


replace('All 3,050 archived header records', r'''All 3,050 archived headers record 0.018~mm pixel spacing, slice thickness and successive slice positions. Fresh first/middle/last original headers agree, supporting isotropic 18~$\mu$m sampling.''')
replace('DICOM patient coordinates are evaluated', r'''Voxel-centre LPS coordinates add index times 0.018~mm spacing to origin $(4.176,0.198,16.818)$~mm under the identity direction matrix. Cropping at source index $(392,76,76)$ changes the origin to $(11.232,1.566,18.186)$~mm, preserving spacing. Figure~\ref{fig:sections} limits extend half a voxel beyond outermost centres.''')
replace('A slope/intercept pair alone', r'''Slope/intercept alone do not establish Hounsfield calibration; threshold and intensities remain scanner-native. Selected material comprises 967,429,317 voxels (99.87593\% of thresholded foreground). The component rule excludes 345,466 disconnected specks, largest 931 voxels, without determining whether they are anatomical structures, noise or partial-volume effects.''')
replace('The native segmentation is saved', r'''Lossless native reconstruction uses no voxel downsampling, binary closing, interior filling or smoothing filter. Extraction/seam processing cancels opposing zero-thickness triangle pairs without synthetic cavity caps. Thresholds $0.95T_0,T_0,1.05T_0$ share the component rule (Section~\ref{sec:materialgeometry}); independent operator repeatability is unmeasured.''')
replace('The three directional sweeps each contain', r'''Each directional sweep contains 3,050 frames at 25~fps (122~s); frame $f$ begins at $f/25$~s, with last onset 121.96~s. For $(Z,Y,X)$, native plane counts are $(3050,2028,1676)$, maximal-area indices $(1849,1368,749)$ and anchor frames $(1849,2058,1363)$. Plane index increases linearly first-to-anchor and anchor-to-last, including each maximal acquired plane exactly. Axial frames are integer planes; other fractional positions explicitly interpolate adjacent planes without in-plane stride reduction. Exact frame coordinates accompany the media. A separate bottom-to-top $Z$ sweep overlays its moving plane on the maximal-$X$ silhouette. These are playback times, not acquisition, growth or mechanical time. Maximal thresholded areas are 234.879/283.081/778.117~mm$^2$; area--mean-intensity Pearson correlations are $-0.840/0.305/0.141$ and Spearman correlations $-0.852/0.313/0.029$. These descriptive associations calibrate neither density nor strength. CT and FE sample volumes retain separate registered-grid metadata \citep{ITKResample}.''')
replace('Point peaks in A1/A2/A3 are', r'''A1/A2/A3 point peaks are 1804.316/2794.228/2914.649~MPa, each independently located in a cell touching essential support nodes. This support-adjacent sensitivity is separate from regional stability; it proves neither a continuum singularity nor physical notch rounding. Corner behaviour depends on angle/boundary conditions \citep{Williams1952}, without a universal serration exponent or fossil strength.''')
replace('The imposed 1~MPa is a reference pressure,', r'''The 1~MPa reference lacks matching fossil bite calibration. A measured resultant could fit nonnegative pressure by projection onto the unit-pressure force direction, with a directional residual check. Attachment calibration also needs displacement/contact observations under known loads; neither pressure nor stiffness is biologically fitted here.''')
replace('Dynamic cutting tests, structural models', r'''Dynamic cutting, structural modelling and extant tissue measurements supply complementary evidence \citep{Corn2016,Whitenack2011,Enax2012}. Dental orientation, matched loads, damage surveys and material/attachment observations remain necessary for fossil inference. Conditional regional localisation does not identify whole-animal bite force, ecology or adaptation from damage.''')
s = s.replace('\\date{Preprint\\\\20 November 2026}', '\\date{Preprint\\\\21 November 2026}')
p.write_text(s)
(N / 'Supplementary_unabridged_imaging_2026-11-21.tex').write_text(
    '% Preserved unabridged prose; reference fragment, not a second main paper.\n\n' + '\n\n'.join(old) + '\n')
print('Whitespace words saved:', len(backup.read_text().split()) - len(s.split()))
