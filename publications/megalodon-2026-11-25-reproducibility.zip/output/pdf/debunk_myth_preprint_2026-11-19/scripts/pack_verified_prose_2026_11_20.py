"""Condense explanation while retaining numerical results in the open paper."""
from pathlib import Path
import shutil
import re

N = Path(__file__).resolve().parents[1]
path = N / 'DebunkMeg_complete_2026-11-19.tex'
backup = N / 'original_versions/before_verified_prose_2026-11-20.tex'
if backup.exists():
    assert path.read_bytes() == backup.read_bytes(), 'Do not rerun an already applied prose edit.'
else:
    shutil.copy2(path, backup)
text = path.read_text()
changes = []


def paragraph(prefix, replacement):
    global text
    matches = list(re.finditer('(?m)^' + re.escape(prefix), text))
    assert len(matches) == 1, (prefix, len(matches))
    start = matches[0].start()
    end = text.find('\n\n', start)
    if end < 0:
        end = len(text)
    changes.append(text[start:end])
    text = text[:start] + replacement + text[end:]


paragraph('For each tetrahedron $e$,', r'''Affine P1 displacement gives constant element strain and stress. Consistent face traction is shared among its three nodes. The reduced free-node system recovers element stress without nodal averaging. Distortional stress is summarised by
\begin{equation}
\vm=\sqrt{\tfrac32\dev\boldsymbol\sigma:\dev\boldsymbol\sigma},\qquad
\dev\boldsymbol\sigma=\boldsymbol\sigma-\tfrac13\tr(\boldsymbol\sigma)\mathbf I.
\end{equation}
It is not a validated fossil-tooth failure criterion.''')

paragraph('The independent jaw reference is', r'''The white-shark reference \texttt{MBIE White Shark HQ.obj}, associated with \texttt{great\_white\_jaw.mph}, has 1,009,016 triangles. Source bounds are $X=[-184.852,192.751]$, $Y=[-249.526,256.330]$, $Z=[-91.969,98.2953]$, with units assumed mm by the import record. The prescribed lower/upper 12\% Y bands fix $Y\le-188.8233$ and load $Y\ge195.6273$ with $(0,-10^4,0)$~Pa. The report's 60 fixed/109 loaded boundary entities are not recovered by illustrative triangle-centroid masks. A separate volume preprocessing record contains 18,548 boundary triangles/153,389 tetrahedra; the imported full-surface report lists no volume tetrahedra. These records are not interchangeable or a megalodon jaw reconstruction.''')

paragraph('Six archived COMSOL jaw exports', r'''Six archived COMSOL exports retain their legends/cameras. Component~1 contains six savepoints, two surface meshes (1,620 vertices; 2,752/2,761 triangles), differing selections and an NH alias; their names do not identify six calibrated laws. Five fragments lack tetrahedral adjacency. Neither these masks nor fragments recover historical stresses or fossil force transfer. The juvenile white-shark asset is Auckland Museum's \citep{AucklandJaw2016}; no volumetric jaw CT is identified.''')

paragraph('The independent white-shark jaw asset has', r'''Before FEA, the 1,009,016-triangle jaw undergoes 1.8~mm voxelisation, enclosed-cell fill and 0.5-isosurface extraction without smoothing: 281,280 boundary triangles, 4.015 times finer grid pitch than the 7.227~mm comparison. Source-to-reference RMS distance on 10,000 area-uniform samples improves from 5.181 to 1.203~mm; reverse RMS improves from 5.117 to 1.260~mm. These are sampled representation errors, not anatomical calibration or Hausdorff bounds. Three audited meshes share this boundary and $1.287989\times10^6$~mm$^3$ volume: 503,546/520,151/589,700 tetrahedra. First-percentile quality rises from 0.325 to 0.389; minimum quality is $2.47\times10^{-4}$.''')

paragraph('Source units are assumed mm;', r'''The original Y span is $L=505.856$ source units, without an independent anatomical scale anchor. Figure~\ref{fig:field} reports scale-free $Q_{0.95}/p$ and $u_{\max}/L$: uniform scaling preserves deformation gradient and stress under unchanged material/reference traction, scales displacement with length and force with area. It does not calibrate jaw dimensions or material.''')

paragraph(r'Table~\ref{tab:procedures} records', r'''Table~\ref{tab:procedures} separates performed numerical checks from unresolved continuum, empirical and biological validation.''')
paragraph('These checks support conditional regional comparisons;', r'''The evidence supports conditional regional comparisons.''')

paragraph('The assumed Young moduli are', r'''The candidate uses assumed Young moduli of 100/30~GPa (shell/core), both $\nu=0.25$. Extant reduced indentation moduli motivate a contrast \citep{Enax2012}, without determining these fossil Young moduli. L1 shell widths 0.25/0.5/1.0~mm assign 8.258/18.067/35.190\% volume. The 0.5~mm candidate spans L1/L2/A2/A3, with A3 shell fraction 18.321\%. Centroid labels explicitly make this geometric interface mesh-dependent.''')

paragraph('A separate interface comparison uses', r'''Three L0 cases separate original centroid labels, fitted subdivision with unchanged labels, and fitted phase labels on that same subdivision. Its 59,164 nodes/258,969 tetrahedra preserve exterior, load, support and frozen region unions. Nodal values of the piecewise-affine 0.5~mm candidate level set within 20~$\mu$m of zero are snapped to zero; this is a declared numerical tolerance, not interface-location accuracy. Same-material subdivision gives a 4.28\% discrete energy-norm gap, not a continuum upper bound. On the identical refined space, fitted labels change regional von Mises Q95 by $+1.928,-0.036,+0.430,-0.901,-0.930,-0.347$\% in table order; principal-tensile Q95 changes reach $-5.44$\% centrally and $+5.01$\% apically. Shell fraction changes from 17.410 to 18.853\%. This finite representation contrast identifies neither an EDJ nor A3 interface convergence \citep{InterfaceData}.''')

paragraph('Each new linear field is independently recovered', r'''Independent local-gradient recovery checks 20 linear cases/15,036,632 tetrahedra, including principal eigenvalues, tensors, forces, physical regions and volume quantiles. Tensor discrepancies are below $2\times10^{-6}$ relative and free-force diagnostics below $10^{-5}$. Long-double cumulative sums and the positive-sum rounding bound enclose floating inverse-CDF mass jumps; these are numerical, not physical uncertainty.''')

paragraph('Contact impact requires inertia,', r'''Contact impact needs inertia, approach velocity or force--time history, and calibrated attachment/contact laws. Reference-frame balance is
\begin{equation}
\rho_0\,\ddot{\mathbf u}=\operatorname{Div}P+\rho_0\mathbf b,
\qquad P=FS\quad\text{for StVK}.
\end{equation}
Here $\rho_0$ is density, $P$ first Piola stress and $\mathbf b$ body acceleration. Frictionless unilateral contact prevents interpenetration and releases traction on separation. Normal compliance, closing-rate damping and impact duration need calibration \citep{Laursen1997,COMSOLDynamic}; the Robin grid is a separate static sensitivity.''')

paragraph('When load rise time approaches', r'''Rise times near an elastic-wave transit time require dynamic amplification and support reflections; wave speed depends on density and tangent stiffness. Contact can launch wavefronts, while a nonlinear shock also requires jump compatibility, energy admissibility and a hyperbolic material regime \citep{PerezRozga2016}. A static stress peak proves none of these. Verification must refine time step/contact mesh and check impulse, energy and damping. Without measured history, density or contact calibration, shock amplitude and impact fracture load are not inferred.''')

paragraph('For an elementary rectangular beam,', r'''Elementary rectangular-beam capacity scales with allowable tensile stress, width and squared thickness, divided by six times the lever arm. If thickness is a fixed fraction of crown height and lever arm approximates that height, capacity scales with width, height and the squared fraction. This matched-dimension/material/loading argument establishes no universal performance deficit or prey-size ceiling.''')

paragraph('Bibliography groups A/B provide', r'''Bibliography A/B provides anonymous optimised/native surface, lossless CT mask and exact 200M exterior downloads, with decoding instructions and checksums \citep{Exterior200M}. Numerical records retain meshes, tensors, frozen regions, threshold masks/occupancies, geometry pairs, candidate phases, statistical bounds and image provenance. The original whole-body OBJ retains its human object; the derivative removes only that object. CT movies retain 3,050 frames at 25~fps with LPS coordinates and area/intensity profiles. P1/P2 exact inputs, quadratic fields, local sizes and quadrature checks are supplied separately \citep{P1P2Data}. Full mathematical methods, prior manuscripts and source material are preserved; temporary caches are excluded.''')

text = text.replace('0.804\\% at 0.576~mm and 0.791\\% at 0.288~mm',
                    '0.804\\% at 0.576~mm and 0.790\\% at 0.288~mm')
path.write_text(text)
(N / 'Supplementary_unabridged_prose_2026-11-20.tex').write_text(
    '% Unabridged paragraphs preserved before main-paper prose condensation.\n'
    '% Reference fragment, not a second main paper.\n\n' + '\n\n'.join(changes) + '\n')
print('Preserved', len(changes), 'original paragraphs;',
      len(backup.read_text().split()) - len(text.split()), 'whitespace words removed.')
