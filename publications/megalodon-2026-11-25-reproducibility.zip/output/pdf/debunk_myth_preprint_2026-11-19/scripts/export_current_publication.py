#!/usr/bin/env python3
"""Export the open paper and update its CV entry, preserving earlier editions."""
from pathlib import Path
import hashlib
import html
import importlib.util
import json
import re
import shutil
import zipfile
import fitz

R = Path(__file__).resolve().parents[1]
P = R.parents[2]
SITE = P / 'output/antiterrastrae_publish'
SOURCE = R / 'DebunkMeg_complete_2026-11-19.tex'
PDF = SOURCE.with_suffix('.pdf')
LEGACY_HASH = '2f0e465c25db57de7080e338ed655d10fe16f7fb9f5d84df2797b9714c33fe6c'


def sha(path):
    return hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()


def record(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def main():
    legacy = SITE / 'publications/megalodon-9page-report.pdf'
    assert sha(legacy) == LEGACY_HASH, 'The preserved nine-page PDF changed'
    doc = fitz.open(PDF)
    assert len(doc) == 12
    jaw = json.loads((R / 'review/objective_jaw_summary.json').read_text())
    assert jaw['status'] == 'independently_verified_10kPa_NH', 'Publish only the independently verified target case.'
    access = {key: json.loads((R / ('review/' + name)).read_text()) for key, name in [('jaw', 'objective_jaw_public_access.json'), ('transfer', 'boundary_edge_public_access.json'), ('regional', 'regional_fields_public_access.json')]}
    assert all(v['status']=='uploaded_and_anonymously_accessible' for v in access.values())
    assert access['jaw']['public_archive_url']==jaw['public_archive_url']
    text = SOURCE.read_text()
    used_figures = sorted(set(re.findall(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]+)\}', text)))
    assert used_figures and all((R / name).is_file() for name in used_figures)
    source_zip = R / 'DebunkMeg_source_2026-11-25_figure-review.zip'
    with zipfile.ZipFile(source_zip, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        z.write(SOURCE, SOURCE.name)
        for name in used_figures:
            z.write(R / name, name)
        for name in used_figures:
            svg = R / 'svg' / (Path(name).stem + '.svg')
            if svg.is_file():
                z.write(svg, str(svg.relative_to(R)))
        for extra in ['Supplementary_mathematical_methods.tex', 'Supplementary_extended_methods_and_provenance.tex', 'Supplementary_unabridged_prose_2026-11-20.tex', 'Supplementary_unabridged_imaging_2026-11-21.tex', 'Supplementary_jaw_objective_2026-11-23.tex', 'Supplementary_jaw_tooth_transfer_2026-11-23.tex', 'review/objective_jaw_public_access.json', 'review/boundary_edge_public_access.json', 'review/regional_fields_public_access.json', 'review/objective_jaw_summary.json', 'review/figure1_palette_matte_root.json', 'review/reference_model_credits.json', 'numerics/reference_palette_512.json', 'Supplementary_crown_root_100mm_2026-11-25.tex', 'Supplementary_unabridged_2026-11-25.tex', 'review/crown_root_scale_public_access.json', 'review/crown_root_viewer_r2_public_access.json', 'review/crown_root_paper_validation.json', 'review/figure1_crown_root_revision.json', 'review/figure8_native_counts.json', 'numerics/crown_root_100mm/MR5_readback.json', 'numerics/crown_root_100mm/candidate_material_checks.json', 'figures/candidate_tension_interface_checks.pdf']:
            z.write(R / extra, extra)
        for viewer in ['native-resident-workbench.js','native-workbench-r13.js','native-workbench-r13.css','native-resident-workbench-worker.js','native-source-cache-r13.js']:
            z.write(SITE/'design/megalodon'/viewer, 'web/'+viewer)
        for pipeline in ['render_black_ct_profiles.py', 'render_native_curvature.py', 'curvature_core.py',
                         'render_adaptive_crown_root.py', 'publication_figures.py', 'render_anchored_jaw_plate.py',
                         'render_native_figure8_natural.py', 'native_figure8_raster.cpp', 'assemble_figure8_fit_detail.py',
                         'compose_native_curvature_and_ppca.py', 'revise_figures.py', 'profile_figures.py',
                         'update_ct_assets.py', 'calibrated_figures.py', 'plot_boundary_edge_transmission.py']:
            z.write(R/'scripts'/pipeline, 'scripts/'+pipeline)
        for path in sorted((R/'figures').glob('*.png')):
            if path.name.startswith(('figure2_', 'native18_curvature_', 'figure4_adaptive_', 'jaw_anchored_', 'native_figure8_')):
                if not path.stem.endswith(('_450dpi',)):
                    z.write(path, str(path.relative_to(R)))
        for path in ['review/figure2_black_CT.json', 'review/native18_curvature_display.json',
                     'review/figure4_CT_partition.json', 'review/jaw_anchored_readback.json',
                     'review/figure_review_validation.json', 'numerics/figure4_adaptive_CT_masks.npz',
                     'figures/field_fullresolution_qf.pdf', 'Native18_PCA_PPCA_Black_CT_2026-11-25.pdf']:
            z.write(R/path, path)
        z.writestr('README_SOURCE.txt',
            'Author manuscript in progress, 25 November 2026. Main file: ' + SOURCE.name + '\n'
            'Compile twice with XeLaTeX (TeX Live with TeX Gyre and Latin Modern fonts).\n'
            'All referenced figure PDFs and the inline bibliography are included.\n'
            'Supplementary .tex files are reference fragments, not additional main documents.\n'
            'The separately linked P1/P2 ZIP supplies exact inputs, fields, source and audit.\n'
            'This TeX file is an exact copy of the open document, not a separate editorial version.\n'
            'HAL/arXiv deposit, metadata verification and acceptance have not been performed.\n'
            'Figure 1 archive colours have their own linear MPa scale; current StVK fields are identified separately.\nOriginal native-resolution numerical renders, revision scripts and the black-background PPCA companion are included. The manuscript embeds print-scale copies to keep the PDF portable. Current native crown/root viewer source is in web/; the separate immutable MR5 archive freezes an earlier viewer snapshot. Numerical results are unchanged.\n')
    axis_zip = R / 'DebunkMeg_archive_axis_data_2026-11-19.zip'
    members = [
        'scripts/archive_axis_comparison.py', 'scripts/compact_axis_plate.py',
        'review/axis_comparison_contract.json',
        'numerics/archive_axis_comparison/paired_surface_values.npz',
        'numerics/archive_axis_comparison/axial_profiles.csv',
        'numerics/archive_axis_comparison/summary.json',
        'figures/archive_axis_comparison.pdf', 'svg/archive_axis_comparison.svg',
    ]
    members += [str(p.relative_to(R)) for p in (R / 'review/axis_comparison_run_001').rglob('*') if p.is_file()]
    with zipfile.ZipFile(axis_zip, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for name in sorted(set(members)):
            z.write(R / name, name)
        for name in ['DICOM_16um/build_frontal_von_mises.py', 'DICOM_16um/exports/von_mises_data_smoothed.txt']:
            z.write(P / name, name)
        z.writestr('README_AXIS_DATA.txt',
            'Saved registered archive/current comparison and audit, 25 November 2026.\n'
            'paired_surface_values.npz contains all 32,000 pairs, coordinates, distances and differences.\n'
            'axial_profiles.csv contains the 20-bin means and Monte Carlo standard errors.\n'
            'The authentic 191,031-row COMSOL export and original display script are included.\n'
            'The primary replay also needs the archived BDF geometry cache, L0 frame and current A3 field.\n'
            'Those larger inputs are identified by path and SHA-256 in the run manifest; they are not duplicated here.\n'
            'This archive alone can recompute saved-pair statistics but is not the complete FE input archive.\n'
            'Unmatched archive/current load cases: differences are descriptive, not calibrated stress errors.\n')
    for zpath in [source_zip, axis_zip]:
        with zipfile.ZipFile(zpath) as z:
            assert z.testzip() is None
    publications = SITE / 'publications'
    shutil.copy2(PDF, publications / 'megalodon-current-preprint.pdf')
    shutil.copy2(source_zip, publications / 'megalodon-current-preprint-source.zip')
    shutil.copy2(axis_zip, publications / 'megalodon-archive-axis-data.zip')
    catalog = json.loads((publications / 'catalog.json').read_text())
    catalog['documents'] = [p for p in catalog['documents'] if p['id'] != 'megalodon-current-preprint']
    old = next(p for p in catalog['documents'] if p['id'] == 'megalodon-9page-report')
    old.update(category='Research archive', status='Legacy 9-page edition',
               description='The unchanged nine-page edition, retained alongside the current preprint and earlier reports.')
    current = dict(id='megalodon-current-preprint', file='megalodon-current-preprint.pdf',
        title='Tooth-scale Stress Localisation in a µCT-derived Otodus megalodon Model',
        category='Computational biomechanics', status='In progress', date='25 November 2026',
        description='Calibrated CT geometry, regional stress quantiles, targeted mesh refinement, material and attachment sensitivity, same-domain P1/P2 verification, paired interface/threshold checks, an independently verified full-objective 10 kPa neo-Hookean jaw control, conservative jaw-to-root transfer and unit-margin tensile responses, the native-domain module with synthetic verification, registered axial field comparisons, full native crown–root views, native curvature and CT-guided partition figures, the independently checked 100 mm MR5 control, and anisotropic/cohesive coupons. Includes public native, optimised and 200M exterior data links.',
        pages=len(doc), bytes=PDF.stat().st_size, sha256=sha(PDF),
        source_file='megalodon-current-preprint-source.zip', axis_data_file='megalodon-archive-axis-data.zip', p1_p2_data_file='megalodon-P1-P2-validation.zip', interface_data_file='megalodon-interface-validation.zip', threshold_data_file='megalodon-threshold-validation.zip', jaw_data_url=jaw['public_archive_url'], transfer_data_url=access['transfer']['public_archive_url'], regional_data_url=access['regional']['public_archive_url'])
    catalog['documents'].insert(0, current)
    (publications / 'catalog.json').write_text(json.dumps(catalog, ensure_ascii=False, indent=2) + '\n')
    spec = importlib.util.spec_from_file_location('publications_builder', SITE / 'scripts/build-publications.py')
    builder = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(builder)
    cv = (SITE / 'cv.html').read_text()
    article = f'''<article class="entry report-entry"><p class="report-citation"><strong>Han, E. (2026).</strong> <a href="publications/reader.html?paper=megalodon-current-preprint" rel="noopener noreferrer"><i>Tooth-scale Stress Localisation in a μCT-derived Otodus megalodon Model: Calibrated Geometry, Numerical Verification and Regional Sensitivity.</i></a></p><p class="subline">In progress · 12 pages · 25 November 2026 · Revised figures</p><p class="report-method">Calibrated CT geometry, verified regional stress quantiles, material and attachment sensitivity, same-domain P1/P2 verification, paired interface/threshold checks, an independently verified full-objective 10 kPa neo-Hookean jaw control, conservative jaw-to-root transfer and unit-margin tensile responses, the native-domain module with synthetic verification, registered axial field comparisons, full native crown–root views, an independently checked 100 mm MR5 control, and anisotropic/cohesive coupons. Direct data links include the complete 32M and native 74M surfaces, 18 μm mask and exact 200M exterior with projected StVK fields.</p><a class="report-fulltext" href="publications/reader.html?paper=megalodon-current-preprint" rel="noopener noreferrer">Read current paper <small>PDF · 12 pages · {current['bytes']/1e6:.1f} MB</small></a><p class="report-method"><a href="publications/megalodon-current-preprint-source.zip" download>LaTeX source package</a> · <a href="publications/megalodon-native-ppca-black-ct.pdf">Native CT / PCA–PPCA companion</a> · <a href="publications/megalodon-archive-axis-data.zip" download>Registered axial comparison data</a> · <a href="publications/megalodon-P1-P2-validation.zip" download>P1/P2 verification data</a> · <a href="publications/megalodon-interface-validation.zip" download>Interface and support data</a> · <a href="publications/megalodon-threshold-validation.zip" download>Threshold contrast data</a> · <a href="{jaw['public_archive_url']}" download>10 kPa objective jaw data</a> · <a href="{access['transfer']['public_archive_url']}" download>Jaw–tooth edge-transfer data</a> · <a href="{access['regional']['public_archive_url']}" download>Raw A2/A3 regional fields</a> · <a href="https://github.com/Eliguli712/Antiterrastrae/releases/download/megalodon-ct-18um/DebunkMeg_Native74_100mm_MR5_CrownRoot_2026-11-25.zip" download>100 mm MR5, native views and candidate material records</a> · <a href="https://github.com/Eliguli712/Antiterrastrae/releases/download/megalodon-ct-18um/DebunkMeg_Native74_CrownRoot_Viewer_2026-11-25_r2.zip" download>Current native crown/root viewer source</a></p><p class="report-method">Earlier paper versions: <a href="publications/reader.html?paper=megalodon-2026-11-25-crown-root" rel="noopener">Crown–root and 100 mm edition</a> · <a href="publications/reader.html?paper=megalodon-2026-11-25-development" rel="noopener">25 November development snapshot</a> · <a href="publications/reader.html?paper=megalodon-9page-report" rel="noopener">Preserved 9-page edition</a> · <a href="publications/reader.html?paper=megalodon-20page-revised" rel="noopener">20-page revised report</a> · <a href="publications/reader.html?paper=megalodon-26page-recalculated" rel="noopener">26-page pressure-case revision</a> · <a href="publications/reader.html?paper=megalodon-durf-report" rel="noopener">Original 26-page technical report</a></p></article>'''
    cv, n = re.subn(r'<article class="entry report-entry">.*?</article>', lambda _: article, cv, flags=re.S)
    assert n == 1
    cv, n = re.subn(r'(<details class="paper-entry report-primary">.*?<span class="paper-meta">).*?(</span>)',
        lambda m: m[1] + 'In progress · 12 pages · 25 November 2026 · Revised figures' + m[2], cv, flags=re.S)
    assert n == 1
    shelf = '<ol class="paper-catalog">' + ''.join('<li>' + builder.disclosure(p) + '</li>' for p in catalog['documents']) + '</ol>'
    cv, n = re.subn(r'<ol class="paper-catalog">.*?</ol>', lambda _: shelf, cv, flags=re.S)
    assert n == 1
    cv, n = re.subn(r'(<span class="manuscripts-count">)\d+( <small>HOSTED PDFS</small>)', lambda m: m[1] + str(len(catalog['documents'])) + m[2], cv)
    assert n == 1
    (SITE / 'cv.html').write_text(cv)
    project = SITE / 'fea_research/high_res_meg_teeth/index.html'
    p = project.read_text()
    section = '''<section class="section paper-versions" id="paper-versions"><h2>Paper &amp; versions.</h2><p><a href="../../publications/reader.html?paper=megalodon-current-preprint"><strong>Current Otodus megalodon manuscript · In progress · 12 pages</strong></a></p><p class="note">The 25 November 2026 manuscript in development includes calibrated geometry, verified regional quantiles, material and attachment sensitivity, same-domain P1/P2 verification, paired interface/threshold checks, an independently verified full-objective 10 kPa neo-Hookean jaw control, conservative jaw-to-root transfer and unit-margin tensile responses, the native-domain module with synthetic verification, registered axial field comparisons, full native crown–root views, native curvature and CT-guided partition figures, the independently checked 100 mm MR5 control, and anisotropic/cohesive coupons. Its bibliography links the complete optimised and native surfaces, lossless mask and exact 200M exterior with projected fields.</p><p class="note"><a href="../../publications/megalodon-current-preprint.pdf" download>Download PDF</a> · <a href="../../publications/megalodon-current-preprint-source.zip" download>LaTeX source</a> · <a href="../../publications/megalodon-archive-axis-data.zip" download>Axial comparison data</a></p><p class="note">Earlier versions: <a href="../../publications/reader.html?paper=megalodon-9page-report">Preserved 9-page edition</a> · <a href="../../publications/megalodon-20page-revised.pdf" target="_blank" rel="noopener">20-page revised report</a> · <a href="../../publications/megalodon-26page-recalculated.pdf" target="_blank" rel="noopener">26-page pressure-case revision</a> · <a href="../../publications/megalodon-durf-report.pdf" target="_blank" rel="noopener">Original 26-page technical report</a></p></section>'''
    p, n = re.subn(r'<section class="section paper-versions" id="paper-versions">.*?</section>', lambda _: section, p, flags=re.S)
    assert n == 1
    project.write_text(p)
    assert sha(legacy) == LEGACY_HASH
    outputs = [record(x) for x in [SOURCE, PDF, source_zip, axis_zip]]
    manifest = dict(date='2026-11-25', paper_pages=12, status='prepared', outputs=outputs,
        preserves='Earlier delivery_manifest.json describes the pre-HAL revision; all earlier PDF/ZIP editions are retained. The open TeX file has been intentionally revised in place.',
        compile={'local_same_source':'passed, 12 pages', 'desktop_editor':'success'},
        objective_jaw=jaw, public_data_archives=access,
        validation_archives=[record(publications / name) for name in ['megalodon-P1-P2-validation.zip', 'megalodon-interface-validation.zip', 'megalodon-threshold-validation.zip']],
        axial_scope=json.loads((R / 'numerics/archive_axis_comparison/summary.json').read_text()),
        legacy_9page_sha256=LEGACY_HASH,
        public_pdf='https://eliguli712.github.io/Antiterrastrae/publications/megalodon-current-preprint.pdf',
        cv='https://eliguli712.github.io/Antiterrastrae/cv.html',
        submission_status='Author preprint prepared; no HAL/arXiv submission or acceptance implied.')
    (R / 'HAL_revision_manifest_2026-11-19.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'pages':12, 'figures_in_source':len(used_figures), 'source_zip_bytes':source_zip.stat().st_size,
        'axis_zip_bytes':axis_zip.stat().st_size, 'hosted_documents':len(catalog['documents']),
        'legacy_preserved':sha(legacy)==LEGACY_HASH, 'pdf_sha256':sha(PDF)}, indent=2))


if __name__ == '__main__':
    main()
