#!/usr/bin/env python3
"""Build the final prose and vector tables from audited numerical records."""
from pathlib import Path
import json,shutil
import numpy as np
R=Path(__file__).resolve().parents[1];P=R.parents[2];D=P/'output/publication_validation_2026-11-12';W=P/'output/pdf/debunk_myth_profiles_2026-11-09';S=R/'sections'
def read(name):return json.loads((D/'data'/name/'results.json').read_text())
def edit(path,old,new):
    text=path.read_text();assert old in text,(path.name,old[:70]);path.write_text(text.replace(old,new))
def between(path,start,end,replacement):
    text=path.read_text();a=text.index(start);b=text.index(end,a);path.write_text(text[:a]+replacement+text[b:])
def write(path,text):path.write_text(text.strip()+'\n')
ref=read('local_A3');prev=read('local_A2');bilayer=read('bilayer_A3_0p5mm');final=json.loads((D/'review/final_readback_001/results.json').read_text())
labels=[r'$R_0$',r'$R_A$',r'$R_B$',r'$R_{\rm tip}$',r'$R_{\rm cr}$',r'$R_{\rm root}$']
# Refresh source-faithful native-resolution panels after their final crop review.
for folder,names in [('figures',['geometry_pack_1_specimen.pdf','geometry_pack_1_specimen.png','geometry_pack_2_reconstruction.pdf','geometry_pack_2_reconstruction.png','junction_CT_detail.pdf','junction_CT_detail.png','photograph_junction_a.png','photograph_junction_b.png']),('svg',['geometry_pack_1_specimen.svg','geometry_pack_2_reconstruction.svg','junction_CT_detail.svg']),('review',['junction_crop_records.json','StVK_unchanged_image_mapping.json'])]:
    for name in names:shutil.copy2(W/folder/name,R/folder/name)

table9=r'''\begin{table}[htbp]
\centering\fontsize{7.4}{8.1}\selectfont
\caption{Region-wise percentile stress and stress-amplification factors under a standardised crown-face pressure $\sigma_0=1$ MPa. Values are region summaries of $\sigma_{\rm vM}$ (MPa), not pointwise fracture criteria.}\label{tab:table9}
\setlength{\tabcolsep}{2.4pt}\begin{tabular}{lrrrrr}\toprule
Region & $Q_{0.90}$ & $Q_{0.95}$ & $Q_{0.99}$ & SAF$_{0.95}$ & \shortstack{A2--A3\\change (\%)}\\\midrule
'''
for j,(label,row) in enumerate(zip(labels,ref['regions'])):
    change=final['homogeneous_last_step_all_18_percent'][j][1]
    table9+=label+' & '+' & '.join(f'{row[k]:.3f}' for k in ['Q90_MPa','Q95_MPa','Q99_MPa','Q95_MPa'])+f' & {change:.3f}'+r' \\'+'\n'
table9+=r'''\bottomrule\end{tabular}
\par\smallskip\begin{minipage}{.97\linewidth}\footnotesize Primary quantiles are inverse volume-weighted CDFs of constant P1 element stress on A3 (1,739,398 tetrahedra). SAF$_{0.95}=Q_{0.95}/\sigma_0$ is dimensionless. Last-step changes use $100|Q^{A3}-Q^{A2}|/Q^{A3}$. All six $Q_{0.95}$ changes are below 0.233\%; the apex is 0.081\%. The maximum over all 18 $Q_{0.90/0.95/0.99}$ changes is 0.598\% (less than 0.60\%). These are finite-step differences on a fixed model, not certified continuum error bounds.\end{minipage}
\end{table}'''
write(S/'table9.tex',table9)
standalone=r'''\documentclass[11pt]{article}
\usepackage[paperwidth=200mm,paperheight=94mm,margin=6mm]{geometry}
\usepackage{fontspec,amsmath,booktabs,array,caption}\setmainfont{TeX Gyre Termes}
\pagestyle{empty}\begin{document}\setcounter{table}{8}
'''+table9+'\n'+r'\end{document}'
write(R/'table9_vector.tex',standalone)
old=(S/'table8.tex').read_text().replace('L2 populations','A3 populations').replace('L2 cells','A3 cells')
import re
old=re.sub(r'(?m)^(\$R[^\n]+? & .*? & )([\d,]+)( & [\d.]+ \\\\)$',lambda m:m.group(0),old)
for a,b in zip(['31,130','25,905','16,324','13,065','397,306','71,316'],[f"{r['cells']:,}" for r in ref['regions']]):old=old.replace('& '+a+' &','& '+b+' &')
write(S/'table8.tex',old)
# Mesh metrics are evaluated on every tetrahedron, in bounded chunks.
mesh_rows=[]
for name,level in [('local_A1','A1'),('local_A2','A2'),('local_A3','A3')]:
    a=np.load(D/'data'/name/'fields.npz');p=a['points_m'];t=a['tets'];vol=a['volumes_m3'];hmax=0.;sumh=0.
    for start in range(0,len(t),40000):
        tt=t[start:start+40000];h=np.sqrt(np.max([np.sum((p[tt[:,j]]-p[tt[:,k]])**2,axis=1) for j in range(4) for k in range(j)],axis=0));hmax=max(hmax,float(h.max()));sumh+=float(np.dot(h,vol[start:start+40000]))
    r=read(name);free=3*(len(p)-len(a['fixed_nodes']));mesh_rows.append(dict(level=level,free_DOF=free,hmax_mm=hmax*1000,hbarV_mm=sumh/vol.sum()*1000))
    line=f"{level} & {len(p):,} & {len(t):,} & {free:,} & {hmax*1000:.3f} & {sumh/vol.sum()*1000:.3f} & {r['peak_MPa']:.1f} "+r'\\'+'\n'
    text=(S/'table6.tex').read_text();text=text.replace('\\bottomrule',line+'\\bottomrule');write(S/'table6.tex',text)
edit(S/'table6.tex','Executed nested volume meshes','Executed global and local volume refinements')
write(R/'review/local_mesh_geometry_metrics.json',json.dumps(mesh_rows,indent=2))
checks=ref
text=(S/'table7.tex').read_text().replace('Check & L2 result','Check & A3 result')
for before,after in [('2.6715e-10',checks['free_residual']),('4.4666e-12',checks['force_balance']),('2.3218e-12',checks['reference_moment_balance']),('5.3538e-12',checks['work_energy_error'])]:text=text.replace(before,f'{after:.4e}')
write(S/'table7.tex',text)

main=R/'debunk_myth_10pages.tex'
text=main.read_text();text=re.sub(r'\\IfFontExistsTF\{Times New Roman\}[^\n]+',r'\\setmainfont{TeX Gyre Termes}',text);text=re.sub(r'\\IfFontExistsTF\{Arial\}[^\n]+',r'\\setsansfont{TeX Gyre Heros}',text);text=re.sub(r'\\IfFontExistsTF\{Courier New\}[^\n]+',r'\\setmonofont{Latin Modern Mono}[Scale=MatchLowercase]',text)
text=text.replace(r'\fontsize{9.0}{9.4}',r'\fontsize{9.2}{9.8}').replace(r'\date{Technical report\\9 November 2026}',r'\date{Preprint\\19 November 2026}').replace(r'\nocite{CT32,CT74,Mask18}',r'\nocite{CT32,CT74,Mask18,Exterior200M}')
text=text.replace(r'\input{sections/06_discussion}',r'\input{sections/05b_material_geometry}\input{sections/06_discussion}')
a=text.index('An isolated fossil tooth');b=text.index('\n\\end{abstract}',a)
text=text[:a]+r'''An isolated fossil tooth assigned to \textit{Otodus megalodon} provides a traceable stress-localisation experiment with explicit imaging, material and attachment assumptions. Three complete native-volume segmentations bracket the retained CT threshold by $\pm5\%$. Their selected volumes differ by less than 0.40\%; regional stress changes remain below 0.80\% on a common 0.288~mm closed-solid grid, while the separate grid-step effect reaches 6.21\%. On a fixed calibrated proxy, targeted refinement produces 1,739,398 tetrahedra: all six regional 95th-percentile stress changes are below 0.233\%, the apex change is 0.081\%, and all 18 tested percentile changes are below 0.60\%. Support-adjacent point peaks remain mesh-sensitive. An independently constructed geometric shell/core candidate and a six-stiffness elastic-attachment grid quantify assumptions that refinement alone cannot resolve. Full objective bilayer StVK changes the matched whole-domain 95th percentile by 0.499\%. Curvature statistics with standard errors, confidence intervals and finite-field MSE bounds show resolution dependence rather than a common limiting range. Finer jaw controls separate discretisation and constitutive-partition effects. The exactly 200M-triangle exterior is publicly downloadable with lossless compression and checksums. The evidence establishes conditional regional stress localisation; fracture, fossil tissue identification and biological bite calibration require independent measurements.'''+text[b:]
a=text.index('The complete optimised surface,');b=text.index('\n\n\\section*{Author contribution}',a)
text=text[:a]+r'''The complete optimised surface, unreduced native surface and lossless CT mask are anonymously downloadable from bibliography groups A and B. Group B also provides the exactly 200,000,000-triangle exterior with projected homogeneous L1 StVK attributes \citep{Exterior200M}; its lossless archive is 1,883,292,024 bytes and decompresses to the unchanged 5,381,693,946-byte PLY. The release includes a decoding note and SHA-256 checksums, and anonymous partial downloads were verified. The editable source and numerical record provide meshes, raw tensors, frozen masks, threshold masks, paired geometry, statistical bounds, material candidates, crop records and hashes. The original whole-body OBJ retains its human-scale object; a separately named display derivative removes only that object. Three-axis and bottom-to-top native CT movies contain 3,050 frames at 25~fps with LPS positions and area/intensity line profiles. Temporary decompressed caches are excluded. Complete preceding manuscript versions and their source material remain preserved separately.'''+text[b:]
write(R/'preprint.tex',text)
write(R/'main.tex',r'\input{preprint.tex}')

f=S/'01_introduction.tex'
between(f,'\\caption{Specimen, observed','\\label{fig:specimen}',r'''\caption{Specimen observations and computed fields. (a,b) Original photographs with their frames removed; (c) recovered appearance frame. Upper-right natural views are photograph-referenced, with inferred reverse-face appearance. The lower triptych is computed homogeneous L1 StVK von Mises stress under 1~MPa dead traction: unchanged original raster assets, turbo colour map and logarithmic 0.1--300~MPa limits. (d1) Original cervical crown--root photograph crops; (d2) native CT cervical-vicinity crop with its own explicit contrast window and calibrated axes. Neither identifies dated growth rings or a histological tissue boundary. (e1) Notebook $\Delta\kappa_1$ after removing only the human-scale object, dorsal fin upward. Separate negative/positive 99th-percentile asinh limits are $-1137.834$ and $795.835$ inverse source units; raw coordinates, signs and values are retained. (e2) Homogeneous tooth StVK deformation, $u\times10$, coloured by signed longitudinal Cauchy stress. (f) Executed finer wide-band jaw sensitivity at 10~kPa.}''')
edit(f,'Single material; native pores and EDJ not represented','Baseline homogeneous solid; candidate layers tested separately, native pores not resolved')
edit(f,'Legacy PBR appearance models','Archived PBR appearance models')

f=S/'02_geometry.tex'
edit(f,'A low/baseline/high threshold experiment and independent segmentation repeatability study have not been performed for this specimen.','Three complete native-grid reconstructions at $0.95T_0,T_0,1.05T_0$ use the same component rule; Section~\\ref{sec:materialgeometry} quantifies their volumes and the associated geometry sensitivity. Independent operator repeatability is not measured.')
between(f,'\\caption{Calibrated CT and geometric correspondence.','\\label{fig:sections}',r'''\caption{Native CT maximal sections and directional profiles. (a--c) The acquired $Z=1849$, $Y=1368$ and $X=749$ planes maximise thresholded cross-sectional area in their respective directions; the $X$ plane has the largest area overall. Full native pixels use one shared reversed-grayscale raw window $[-3292,26623]$, calibrated LPS axes and a white exterior display mask. This display mask does not alter the numerical profiles. (d--f) Area divided by its directional maximum (blue) and thresholded mean raw intensity scaled only for display (ochre); dotted lines locate the selected sections. Pearson $r$ and Spearman $\rho$ use the unscaled values on planes with area at least 1\% of that direction\textquotesingle s maximum. Axial/coronal/sagittal sample sizes are 2,836/1,878/723. Serial dependence prevents interpreting these as independent biological replicates; no inferential $p$ values are assigned. The companion geometry-correspondence plate retains the source/native/32M void comparison, three coordinate projections, true-distance labels and log displacement plots.}''')
between(f,'The three directional sweeps each contain','\nThe native exterior contains',r'''The three directional sweeps each contain 3,050 frames at 25~fps, lasting 122~s. Frame $f=0,\ldots,3049$ has playback time $t_f=f/25$~s. To include each maximal acquired plane exactly, native position $i_j(f)$ is piecewise linear through $(0,0),(c_j,m_j),(3049,n_j-1)$:
\begin{equation}
i_j(f)=\begin{cases}m_j f/c_j,&f\le c_j,\\m_j+(n_j-1-m_j)\dfrac{f-c_j}{3049-c_j},&f>c_j.\end{cases}
\label{eq:ctclock}
\end{equation}
For $j=(Z,Y,X)$, $n_j=(3050,2028,1676)$, maximal native indices are $m_j=(1849,1368,749)$ and anchor frames $c_j=(1849,2058,1363)$. Axial frames are acquired integer planes. Other fractional positions are explicitly linearly interpolated between adjacent native planes; no in-plane stride reduction is used. Exact frame coordinates accompany the media. The separate $Z$ bottom-to-top sweep shows the moving plane against the complete maximal-$X$ tooth silhouette. The last frame begins at 121.96~s; this is playback, not scanner acquisition, growth or mechanical time. Maximal thresholded areas are 234.879, 283.081 and 778.117~mm$^2$ for $Z,Y,X$. Pearson area--mean-intensity correlations are $-0.840$, $0.305$ and $0.141$; Spearman values are $-0.852$, $0.313$ and $0.029$. These are descriptive directional geometry/intensity associations, not calibration to density or strength. Native CT and FE sample volumes retain separate registered physical-grid metadata \citep{ITKResample}.
''')
edit(f,'Calibrated L2 mechanical proxy & 189,455 & 963,710','Calibrated A3 mechanical proxy & 336,418 & 1,739,398')
f=S/'02a_mapping_statistics.tex';edit(f,'Figure~\\ref{fig:sections} shows all three coordinate-plane projections','The companion geometry-correspondence plate shows all three coordinate-plane projections')

f=S/'03_mechanics.tex'
edit(f,'Its source coordinate bounds are $[-5.046,5.098]\\times[-2.240,4.865]\\times[-19.094,6.126]$, with physical scale unverified.','Its source coordinate bounds are $[-5.046,5.098]\\times[-2.240,4.865]\\times[-19.094,6.126]$. The original human reference has height 1.940661 source units; the body length is 23.091653 units, or 11.89886 human heights. The original proportions and coordinates remain available. Figure~\\ref{fig:specimen}(e1) removes only the 2,176 human-object faces, retaining 711,944 faces and 418,930 vertices. No assumed human height in metres or fossil body-size estimate is introduced.')
edit(f,'The Table~\\ref{tab:table9} baseline solves linear elasticity without contact, prey, fatigue or tissue interfaces.','The Table~\\ref{tab:table9} baseline solves homogeneous linear elasticity without contact, prey or fatigue. Candidate tissue phases and elastic attachment are evaluated separately in Section~\\ref{sec:materialgeometry}.')
edit(f,'Consequently, equal-looking legacy maxima','Consequently, equal-looking archived maxima')

f=S/'04_numerical_results.tex'
edit(f,'on all three meshes','through all six global/local meshes')
edit(f,'L2 has 563,385 free displacement degrees of freedom and required 53 iterations.','L2 has 563,385 free displacement degrees of freedom and required 53 iterations. Three subsequent local refinements target the frozen macroscopic-apex union, cells crossing the fixed-cap interfaces, and cells within 0.4~mm of fixed L0 side-corner edges with dihedral angle above $40^\\circ$. A3 contains 1,739,398 tetrahedra and uses 58 iterations. The predeclared cap is 1.8 million cells; the proposed A4 mesh would contain 3,307,077 and is outside this experiment. An independently coded element kernel agrees with $VB^TCB$ to $5.08\\times10^{-15}$ relative.')
edit(f,'the finest maximum edge is 2.473~mm','the global maximum edge remains 2.473~mm in unmarked coarse regions')
edit(f,'Owner-tetrahedron unsmoothed L2 exterior stress','Owner-tetrahedron unsmoothed A3 exterior stress');edit(f,'maximum 1,914.835~MPa','maximum 2,914.649~MPa')
edit(f,'All 31,999,434 CT-surface triangles carry nearest-L2-element-centroid regional $Q_{F,0.95}=Q_{0.95}/\\sigma_0$ labels','All 31,999,434 CT-surface triangles retain the frozen nearest-L2-centroid region classification, coloured by the A3 regional $Q_{F,0.95}=Q_{0.95}/\\sigma_0$ values')
edit(f,'(b) Relative L1--L2 changes, using L2 as denominator. The dashed 2\\% line is descriptive. Five regions are below 2\\%; the macroscopic apex remains at 5.89\\%.','(b) Relative A2--A3 changes, using A3 as denominator. The dashed 0.5\\% line is descriptive. All six are below 0.233\\%, including 0.081\\% at the macroscopic apex; all 18 tested quantiles change by less than 0.60\\%.')
edit(f,'Independent CDF inequalities immediately below and at all 54 reported values verify the readback across the three meshes.','The original global sequence supplies 54 regional quantiles. Every saved cell in the added geometry, material and support cases is independently read back for tensor, equilibrium and regional-quantile checks. At discrete CDF jumps, long-double cumulative masses and a floating-summation rank enclosure bound the inverse-CDF readback.')
edit(f,'which are 2.803 for $R_A$ and 1.381 for $R_B$','which are 2.791 for $R_A$ and 1.382 for $R_B$')
between(f,'Figure~\\ref{fig:convergence} shows the actual three-mesh','\nA percentile is not automatically',r'''Figure~\ref{fig:convergence} reports the global L0--L2 and local A1--A3 sequence. A2--A3 $Q_{0.95}$ changes are 0.020, 0.006, 0.023, 0.081, 0.048 and 0.232\% for $R_0,R_A,R_B,R_{\rm tip},R_{\rm cr},R_{\rm root}$. Thus all six meet the 0.5\% descriptive target on this step. Across all 18 $Q_{0.90/0.95/0.99}$ values, the maximum change is 0.598\%; all meet 2\%, although not all meet 0.5\%. This establishes finite-step percentile stability within the specified proxy and region definition; it is not a continuum error estimator or asymptotic convergence proof.

Point peaks in A1/A2/A3 are 1804.316/2794.228/2914.649~MPa. Independent recovery locates each maximum in a cell intersecting essential support nodes. Their drift is therefore reported separately from regional stability. It identifies support-adjacent sensitivity without proving a continuum singularity or distinguishing an unresolved notch from physical rounding. Angular-corner behaviour depends on angle and boundary conditions \citep{Williams1952}; neither a universal serration exponent nor a fossil strength follows from these values.
''')

f=S/'05_sensitivity_audit.tex'
edit(f,'no threshold $\\pm5\\%$ full-volume rerun','three full native $\\pm5\\%$ threshold reconstructions and common-grid geometry solves')
edit(f,'Incomplete; threshold uncertainty and repeatability remain unquantified.','Native volume changes below 0.40\\%; six $Q_{0.95}$ threshold contrasts below 0.80\\% at 0.288~mm. Separate FE grid effect reaches 6.21\\%; operator repeatability unmeasured.')
edit(f,'Tooth: three nested meshes, all 54 regional quantiles, quality and exceedance overlaps.','Tooth: three global and three targeted local meshes; frozen regions, all 18 final-step quantiles, quality and support-adjacent maxima.')
edit(f,'tooth apex changes 5.89\\%; jaw slivers remain.','all six tooth $Q_{0.95}$ changes below 0.233\\%, apex 0.081\\%; all 18 below 0.60\\%. Jaw slivers remain.')
edit(f,'Partial; assumed linear/StVK cases; no calibrated fossil tissue law or interface.','Candidate shell/core, three shell widths, four mesh levels and full bilayer StVK tested. Assumed Young moduli and geometric interface are not fossil calibration.')
edit(f,'six archived jaw savepoint constraint masks decoded independently.','six L1 Robin stiffnesses and six archived jaw savepoint masks decoded independently.')
edit(f,'No validated strength, toughness, flaw population or fracture threshold.','Principal tensile/compressive stresses extracted independently; no validated strength, toughness, flaw population or crack threshold.')
edit(f,'public complete 32M/native 74M surfaces and lossless mask linked first in the bibliography.','public complete 32M/native 74M surfaces, lossless mask and exact 200M exterior linked in bibliography groups A/B, with checksums.')
edit(f,'Completed for deposited new calculations','Completed for the supplied new calculations')
text=(S/'table12.tex').read_text();mark='Jaw L2 linear (10 kPa)'
linear=json.loads((D/'data/bilayer_L1_0p5mm/results.json').read_text());stvk=json.loads((D/'data/bilayer_StVK_L1/results.json').read_text())
print('Bilayer StVK result keys',list(stvk))
# Values independently read back in bilayer_stvk_readback_001; matched linear whole-domain quantile is retained by the solver record.
rows='Candidate bilayer L1 linear (1 MPa) & 0.000 & 71.675 & '+f"{linear['peak_MPa']:.3f} & {linear['max_displacement_mm']:.3f}"+r' \\'+'\n'
rows+='Candidate bilayer L1 StVK (1 MPa) & 100.000 & 72.032 & 1199.757 & 1.365 '+r'\\'+'\n'
text=text.replace(mark,rows+mark).replace('baseline assumed constants. Jaw:','baseline assumed constants; candidate bilayer uses the stated 100/30~GPa phases. Jaw:');write(S/'table12.tex',text)

f=S/'06_discussion.tex'
edit(f,'across the three meshes','across all six meshes')
edit(f,'the mineralised tissue architecture are absent from the mechanical proxy. Refining that proxy only reduces discretisation uncertainty within it.','the actual mineralised tissue architecture are absent from the baseline mechanical proxy. The shell/core candidates quantify one assumed contrast without identifying the fossil EDJ. Refinement reduces discretisation uncertainty within each specified model.')
edit(f,'The calibrated L2 maximum displacement is 0.619~mm.','The calibrated homogeneous A3 maximum displacement is 0.598~mm; the 0.5~mm candidate bilayer gives 1.300~mm on A3.')
edit(f,'A continuous single-material solid with no identified interface cannot test enameloid--dentine spalling.','A homogeneous solid cannot test enameloid--dentine spalling. The candidate bilayer supplies elastic contrast but has tied displacement continuity, no debonding law and no measured interface toughness; it also cannot establish spalling.')

write(S/'07_conclusions.tex',r'''\section{Conclusions}
The 18~$\mu$m specimen CT supports three complete threshold reconstructions, public native/optimised surfaces and an exactly 200M-triangle exterior. Native/optimised sampled positions are close (bidirectional area-uniform RMS 1.330~$\mu$m; sampled maximum 8.956~$\mu$m), while unclipped $H,K$ remain resolution-dependent. Correlation, Monte Carlo standard errors, confidence bands and finite-field MSE bounds do not establish a common limiting curvature range or a developmental trajectory.

The specified homogeneous 1~MPa crown-face experiment gives A3 regional $Q_{0.95}$ values of 10.546, 29.435, 14.571, 0.535, 62.689 and 258.321~MPa for the central, A-side, B-side, apex, transition and root-side regions. At 1,739,398 tetrahedra, all six last-step $Q_{F,0.95}$ changes are below 0.233\%, with 0.081\% at the apex; all 18 tested percentile changes are below 0.60\%. Support-adjacent point peaks remain mesh-sensitive. The supported result is stable regional stress localisation on this finite model, not a converged peak strength.

Threshold changes of $\pm5\%$ alter native selected volume by less than 0.40\% and the six common-grid $Q_{0.95}$ values by less than 0.80\%; the separate grid-step effect reaches 6.21\%. A geometric 0.5~mm shell/core candidate changes A3 $Q_{0.95}$ to 6.990, 54.447, 25.738, 1.077, 72.632 and 265.887~MPa, with all 18 adjacent-step changes below 0.64\%. Thus material assumptions can exceed mesh-step differences. Elastic attachment likewise changes regional stress and displacement; it is calibratable but not fitted to measurements here. Baseline edge-to-central factors are 2.791 and 1.382; one-lobe supports reverse their ordering in three of the 16 original L0 sensitivity cases.

Full objective StVK raises matched whole-domain tooth $Q_{0.95}$ by 0.207\% for the homogeneous L1 model and 0.499\% for the candidate bilayer. On the finer jaw domain at 10~kPa, linear/narrow/wide sensitivities give $Q_{0.95}=3.498/1.980/2.043$~MPa, with last-step changes 1.01/0.83/1.24\%. The matched objective full-StVK control at 1~kPa gives 0.471~MPa versus linear 0.350~MPa. Large linear motion and mixed-law nonobjectivity limit physical interpretation of the 10~kPa jaw cases. Neither a brittle-fracture threshold, calibrated fossil bite force nor ecological mechanism is identified.

The public 200M exterior in bibliography group B retains the native geometric information limit and carries explicitly projected homogeneous L1 StVK attributes. Lossless decoding and anonymous access are verified. Together with the complete numerical records and calibrated 3,050-frame native CT sweeps, it makes the finite-model conclusions inspectable and reproducible without equating surface density, model stability or attractive colour maps with biological validation.''')

refs=R/'references.bib'
with refs.open('a') as stream:stream.write(r'''
@misc{Exterior200M,author={Han, Eliguli},title={Exactly 200,000,000-triangle native-exterior refinement with projected StVK fields},year={2026},howpublished={GitHub release megalodon-ct-18um},note={Lossless Zstandard archive, 1,883,292,024 bytes; decoded PLY 5,381,693,946 bytes. Planar surface refinement, not a 200M-element FE solution. SHA-256 and decoding note accompany the release},url={https://github.com/Eliguli712/Antiterrastrae/releases/download/megalodon-ct-18um/Megalodon_Exterior_200M_StVK_lossless.ply.zst}}
''')
print('Prepared preprint source and audited vector tables.')
