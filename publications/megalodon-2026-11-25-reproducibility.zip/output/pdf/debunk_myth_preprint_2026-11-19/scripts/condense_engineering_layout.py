#!/usr/bin/env python3
"""Keep the full technical record while condensing duplicate main-paper prose."""
from pathlib import Path
import re
N=Path(__file__).resolve().parents[1];p=N/'DebunkMeg_complete_2026-11-19.tex';s=p.read_text()
full=N/'Supplementary_extended_methods_and_provenance.tex'
if not full.exists():full.write_text('% Unabridged technical/provenance record before main-paper condensation.\n'+s[s.index(r'\section{Imaging'):s.index(r'\section{Discussion}')])
def paragraph(prefix,new):
 global s
 start=s.index(prefix);end=s.index('\n\n',start);s=s[:start]+new+s[end:]
start=s.index(r'\section{Introduction}')+len(r'\section{Introduction}')
end=s.index(r'\begin{figure*}',start)
s=s[:start]+r'''
A broad triangular crown and serrated margins make a tooth assigned to \textit{Otodus megalodon} a useful specimen for examining where a specified load concentrates stress. Dynamic tooth--prey experiments address cutting performance \citep{Corn2016}; structural tooth and jaw models address different mechanical systems \citep{Whitenack2011,Ferrara2011,Wroe2008}. Comparative serration and dental-mineralisation studies provide anatomical context \citep{Moyer2017,Jambura2019,Shimada2002}, rather than material or bite calibration for this fossil.

The experiment links native CT geometry to controlled stress fields, regional summaries and checks of approximation, material and attachment assumptions. Collection identity, dental position and mesial/distal orientation are not independently established; no anterior/A2 assignment enters the calculation. Two specimen photographs and a recovered render appear in Figure~\ref{fig:specimen}. Visible defects are recorded as observations; their mechanical cause and timing are not determined.

'''+s[end:]
paragraph('The study connects three scales of evidence.',
 r'Native imaging constrains segmented geometry and voids; controlled FE solves define pressure-normalised stresses; whole-body and jaw references identify additional requirements for coupled mechanics or flow. Positional agreement is close, while curvature is resolution-dependent. The specified load gives higher root/transition summaries than the macroscopic apex, with edge-side ordering dependent on attachment. A dense mesh, a coloured render or a small solver residual alone does not establish strength or feeding behaviour.')
paragraph('The project author attributes the whole-body reference to Shimada;',
 r'The project author attributes the whole-body reference to Shimada; the comparative body-form source is cited separately \citep{Shimada2025}. The Notebook uses \nolinkurl{applied_forces/base_megalodon.obj}: 714,120 faces and 420,178 vertices. Figure~\ref{fig:specimen}(e1) removes only 2,176 human-reference faces, retaining 711,944 faces and 418,930 vertices. Original coordinates, bounds and proportions remain in the source record. The human height is 1.940661 source units and body length 23.091653 units, a ratio of 11.89886; no height in metres or fossil body length is inferred. Point-cloud Delaunay tetrahedralisation need not preserve the exterior and does not define the tooth solid.')
paragraph(r'The notebook-derived surface \texttt{shark\_surface.obj}',
 r'The original and compressed Notebook surfaces supply reproduced $\Delta\kappa_1,\Delta\kappa_2$ diagnostics through the saved functions and six-nearest-vertex inverse-distance transfer. A rigid $(-Z,Y,X)$ camera keeps the dorsal fin upward. Raw source-unit values are retained; they are distinct from physically calibrated CT curvature. The original files, transfers and display limits accompany the source.')
paragraph('Six original anterior-oblique COMSOL raster exports',
 r"The six archived COMSOL jaw exports retain their original legends and cameras; labels are savepoint names rather than six calibrated constitutive laws, and the NH-labelled set includes an alias. Independent archive decoding identifies Component 1, six savepoints, two saved surface meshes (1,620 vertices; 2,752/2,761 triangles), and differing fixed/load selections. Five surface fragments without tetrahedral adjacency are retained in the source. These exact masks and flags do not reconstruct historical stress fields or fossil force transfer. The separate juvenile white-shark reference is Auckland Museum's model \citep{AucklandJaw2016}; no volumetric jaw CT is identified.")
paragraph('The project archive compares St.',
 r'The constitutive audit compares StVK, neo-Hookean, Ogden and two- and five-parameter Mooney--Rivlin forms under explicitly retained energy conventions. StVK is quadratic in Green--Lagrange strain; the alternatives use isochoric invariants or principal stretches with a quadratic volume penalty. The small-strain shear tangent is $\mu$ for StVK/NH, $\mu_1\alpha_1/2$ for the stated Ogden convention, and $2(C_{10}+C_{01})$ for MR2/MR5. Higher-order MR5 coefficients do not change that tangent. Table~\ref{tab:tangent} gives every archived value and matching requirement; full energies and simple-shear checks accompany the mathematical source.')
paragraph('The finite-deformation equations distinguish current pressure',
 r"Finite deformation distinguishes pressure applied to the current surface from a dead traction fixed to the reference surface. Current pressure requires Nanson's reference-area conversion using the Jacobian and inverse-transpose deformation gradient \citep{COMSOLStVK}. Applying the current normal directly in a reference-area integral omits this conversion. The baseline uses small-strain pressure on the undeformed surface; the new StVK controls explicitly use reference dead traction.")
# The former paragraph repeats the same area-conversion distinction.
if 'A reference-surface weak form for follower pressure' in s:
 paragraph('A reference-surface weak form for follower pressure',
  r'These load definitions are recorded separately; their equality at infinitesimal displacement is not equality at finite deformation.')
paragraph('The photograph-referenced natural and paper-image reference-colour triptychs',
 r'Natural and paper-image reference-colour appearance exports are retained at their original 2,400$\times$1,320 pixels. Their metadata explicitly states that reference colours have no raw numerical FE field. Reverse-face continuation and roughness are illustrative. Figure~\ref{fig:specimen} instead labels the authentic archived stress field, and keeps the 32,687,264-face appearance geometry distinct from native CT and the mechanical proxy. Display-only glare compression, source hashes and blue-edge preservation checks are recorded with the original photographs.')
paragraph('The imposed 1~MPa is a standardised reference pressure,',
 r'The imposed 1~MPa is a reference pressure, without a matching fossil bite experiment. With a known resultant, constant pressure could be fitted by projecting that force onto the unit-pressure force direction; the residual checks directional compatibility and pressure must remain nonnegative. Attachment calibration additionally needs displacement/contact observations under known loads. These observations are absent, so neither biological pressure nor stiffness is fitted.')
# This follows the old display equation after its conversion into prose.
if 'That residual tests directional compatibility;' in s:
 paragraph('That residual tests directional compatibility;',
 r'Contact, a moving bite patch and whole-jaw force transfer require their own boundary measurements.')
paragraph('Dynamic cutting tests, structural tooth models',
 r'Dynamic cutting tests, structural models and extant tissue measurements address complementary evidence \citep{Corn2016,Whitenack2011,Enax2012}. Fossil functional inference additionally needs dental orientation, comparable loads, a damage survey and material/attachment observations. The verified result is conditional regional localisation and its measured sensitivities. Whole-animal bite force, ecological mechanisms and adaptation from damage are not identified.')
start=s.index(r'\section{Conclusions}');end=s.index(r'\FloatBarrier',start)
s=s[:start]+r'''\section{Conclusions}
Native 18~$\mu$m CT supports complete threshold reconstructions and openly downloadable optimised/native surfaces. Sampled positions are close (RMS 1.330~$\mu$m; maximum 8.956~$\mu$m), while raw mean/Gaussian curvature remains resolution-dependent. Correlation, confidence intervals and finite-field MSE bounds do not establish a common limiting curvature range or development.

Under the declared 1~MPa crown-face load, all six A2--A3 P1 regional Q95 changes are below 0.233\%, the apex change is 0.081\%, and all 18 percentile changes are below 0.60\%. In contrast, the same-L0 P1/P2 pair changes regional Q95 by 0.92--10.14\% and has a 37.78\% discrete energy-norm gap. Thus finite P1 mesh-step stability is not a complete error bound; an A3 P2 test remains absent. Support-adjacent point peaks remain mesh-sensitive.

Threshold perturbations of $\pm5\%$ change native volume by less than 0.40\% and common-grid Q95 by less than 0.80\%; the separate grid-step effect reaches 6.21\%. Candidate bilayer and attachment contrasts exceed many discretisation differences. Full StVK changes matched whole-domain tooth Q95 by 0.207\% (homogeneous) and 0.499\% (candidate bilayer). The actual EDJ, dentinal structure and attachment are not identified, and large-motion linear coefficients are applicability diagnostics, not measured tooth movement.

Finer jaw fields and the contact-impact framework remain conditional reference analyses; they identify neither calibrated fossil bite force, shock amplitude nor fracture. The public exact 200M exterior retains the native information limit and explicitly projected L1 StVK fields. Lossless decoding and anonymous access are verified. Regional stresses are inspectable model summaries, with tensile strength, toughness, flaw geometry and loading history still required for damage inference.

'''+s[end:]
# Keep the P1/P2 table in one column to avoid a full-width float queue.
start=s.index(r'\begin{table*}',s.index(r'\subsection{Same-domain P1/P2'))
end=s.index(r'\end{table*}',start)+len(r'\end{table*}')
tab=s[start:end].replace(r'\begin{table*}[tbp]',r'\begin{table}[htbp]').replace(r'\end{table*}',r'\end{table}')
tab=tab.replace(r'\fontsize{7.5}{8.2}',r'\fontsize{7.1}{7.9}\setlength{\tabcolsep}{1.6pt}')
tab=re.sub(r'\\caption\{.*?\}\\label\{tab:p1p2\}',r'\\caption{Same-L0 P1/P2 volume Q95 (MPa). Local $h$: volume-weighted 10th/50th/90th maximum-edge-length percentiles; identical cells in both spaces.}\\label{tab:p1p2}',tab,flags=re.S)
tab=tab.replace('Support-adjacent','Near support')
for m in list(re.finditer(r'\d\.\d{3}/\d\.\d{3}/\d\.\d{3}',tab))[::-1]:
 tab=tab[:m.start()]+'/'.join(f'{float(v):.2f}' for v in m[0].split('/'))+tab[m.end():]
s=s[:start]+tab+s[end:]
s=s.replace('Auckland Museums model',"Auckland Museum's model").replace('Markovs inequality',"Markov's inequality")
p.write_text(s)
print('Condensed duplicated prose; full technical record retained; P1/P2 table moved to one column.')
