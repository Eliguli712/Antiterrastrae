from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
main = root / 'DebunkMeg_complete_2026-11-19.tex'
s = main.read_text()
prior = root / 'original_versions/before_final_prose_packing.tex'
if prior.exists():
    raise SystemExit('Already applied: preserve the existing revision.')
prior.write_text(s)
before = len(s.split())

def para(prefix, replacement):
    global s
    pattern = re.escape(prefix) + r'.*?(?=\n\n)'
    s, count = re.subn(pattern, lambda _: replacement, s, count=1, flags=re.S)
    assert count == 1, prefix

para('A closed triangulated surface requires', r'''A closed triangulated manifold requires two faces per edge and manifold vertex links: two closed surfaces touching at one vertex satisfy the edge condition but fail the link condition. Native and optimised reports exhaustively check edge incidence and oriented vertex links, finding no boundary or nonmanifold edges/vertices. They do not exhaustively test self-intersection; positive volume and clean renders cannot establish embeddedness.''')
para('Robust tetrahedral meshing can accept', r'''Robust meshing accepts imperfect triangle soups \citep{Hu2018}, but the physical domain still requires definition. Taubin filtering alternates positive averaging and negative compensation without guaranteeing exact volume or notch preservation \citep{Taubin1995}. The solved proxy receives no additional smoothing.''')
para('Here $A_i$', r'''The outward-normal convention gives positive $H$ on a convex sphere. Angular deficit alone is dimensionless integrated curvature; area normalisation gives $K$ in mm$^{-2}$, while $H$ has units mm$^{-1}$.''')
para('The model omits body forces.', r'''Body forces are omitted. Exterior patch $\Gamma_P$ carries inward traction $\mathbf t=-\sigma_0\mathbf n$, $\sigma_0=1$~MPa; the remaining free exterior is traction free. All nodes in two geometric root-cap volumes are fixed, rather than only an anatomical attachment surface. Continuous piecewise-affine displacement/test fields satisfy these constraints. Weak balance equates internal elastic and applied-traction virtual work. Table~\ref{tab:table9} uses homogeneous linear elasticity without contact, prey or fatigue; candidate phases and elastic attachment are separate (Section~\ref{sec:materialgeometry}).''')
para('The MR5 value is an archived', r'''MR5 is an archived export setting, separate from the linear baseline. Tangent matching does not establish finite-strain agreement or biological validity; similar archived maxima cannot establish equivalence of five calibrated tissue laws.''')
para('Geometry constrains a possible fluid', r'''Wetted area, normals, tooth spacing, jaw gap and wall motion constrain a fluid calculation. For an incompressible Newtonian fluid, no slip equates fluid and wall velocities; opposing interface tractions balance, with fluid stress combining pressure and the viscosity-weighted symmetric velocity gradient \citep{COMSOLFSI}. A fixed wall has zero velocity; jaw motion changes the gap/domain. Geometric scaling by $a$ scales area by $a^2$, mean/Gaussian curvature by $a^{-1}/a^{-2}$ and, at fixed speed, density and viscosity, Reynolds number by $a$. Shape registration therefore does not preserve flow similarity. Without inlet/outlet conditions, kinematics or flow parameters, prescribed crown pressure supplies no estimates of drag, wall shear or fluid-mediated bite load.''')
para('The implementation checks are necessary', r'''Consistency checks do not validate biological support, remove segmentation bias or establish mesh convergence. Point peaks and regional functionals require separate refinement tests.''')
para('A percentile is not automatically', r'''A percentile can depend on one divergent sample: type-7 interpolation of 49 zeros and one value $M$ gives $Q_{0.99}=0.51M$. Markov's inequality bounds a physical volume percentile using regional mean squared stress (proof in the mathematical source). A mesh-uniform bound requires mesh-uniform $L^2$ control and alone establishes neither quantile convergence nor hotspot stability; direct readback and refinement remain necessary.''')
para('The performed checks support', r'''These checks support conditional regional comparisons; biological calibration, continuum error and coupled-system identification remain unresolved.''')
para('For homogeneous linear elasticity at fixed', r'''For homogeneous linear elasticity with fixed $\nu$, traction and Dirichlet geometry, multiplying $E$ by $c$ divides displacement by $c$ and leaves stress unchanged. Multiplying pressure by $a$ multiplies both by $a$. Heterogeneity, nonlinear geometry, contact, damage and stiffness-dependent attachment require separate treatment.''')
para('Six additional L0 solves combine', r'''Six L0 solves ($E=40,90$~GPa; $p=0.5,1,5$~MPa) verify these scalings by full-field recovery. Varying $\nu$ changes stiffness ratios and is a genuine stress sensitivity in the 16-case set. Neither test calibrates fossil material or an interface; Section~\ref{sec:stvknew} specifies separate StVK controls.''')
para('The six archived COMSOL jaw exports retain', r'''Six archived COMSOL jaw exports retain their legends/cameras; savepoint names do not identify six calibrated laws, and NH includes an alias. Decoding identifies Component~1, six savepoints, two surface meshes (1,620 vertices; 2,752/2,761 triangles) and differing fixed/load selections. Five surface fragments lacking tetrahedral adjacency accompany the source; masks alone cannot recover historical stress or fossil force transfer. The separate juvenile white-shark model is Auckland Museum's \citep{AucklandJaw2016}; no volumetric jaw CT is identified.''')
para('The full baseline ordering occurs', r'''Baseline ordering occurs in 13 cases. All three one-lobe cases give $R_{\rm root}>R_{\rm cr}>R_B>R_0>R_A>R_{\rm tip}$: neither A/B ordering nor both edges exceeding the centre is support-invariant. Root/transition remain highest and macroscopic apex lowest in all 16 cases, a result limited to these assumptions and geometry.''')

replacements = {
    'M. Meyer, M. Desbrun, Peter Schr{\\\"o}der, and Alan~H. Barr.': 'M. Meyer, M. Desbrun, P. Schr{\\\"o}der, and A.~H. Barr.',
    'Joachim Enax, Oleg Prymak, Dierk Raabe, and Matthias Epple.': 'J. Enax, O. Prymak, D. Raabe, and M. Epple.',
    'N. Bell, Luke~N. Olson, Jacob Schroder, and B. Southworth.': 'N. Bell, L.~N. Olson, J. Schroder, and B. Southworth.',
    r'\newblock URL \url{https://geometry.caltech.edu/pubs/DMSB_III.pdf}.': r'\newblock\href{https://geometry.caltech.edu/pubs/DMSB_III.pdf}{Author-hosted full text}.',
    r'\newblock URL \url{https://authors.library.caltech.edu/records/2zph7-ee089}.': r'\newblock\href{https://authors.library.caltech.edu/records/2zph7-ee089}{Caltech repository full text}.',
    r'\newblock\url{https://doc.comsol.com/6.4/doc/com.comsol.help.sme/sme_ug_modeling.05.151.html}.': r'\newblock\href{https://doc.comsol.com/6.4/doc/com.comsol.help.sme/sme_ug_modeling.05.151.html}{Official dynamic-contact documentation}.',
}
for a,b in replacements.items():
    assert a in s, a
    s = s.replace(a,b)
for url,label in [
    ('https://itk.org/files/Examples/src/Filtering/ImageGrid/ResampleAnImage/Documentation.html','Official resampling example'),
    ('https://doc.comsol.com/6.3/doc/com.comsol.help.sme/sme_ug_theory.06.079.html','Official theory documentation'),
    ('https://doc.comsol.com/6.4/doc/com.comsol.help.sme/sme_ug_theory.06.031.html','Official constitutive documentation'),
]:
    pattern = r'\\newblock URL\s+\\url\{' + re.escape(url) + r'\}\.'
    s, count = re.subn(pattern, lambda _: r'\newblock\href{' + url + '}{' + label + '}.', s)
    assert count == 1, url

main.write_text(s)
print({'before_words':before,'after_words':len(s.split()),'words_saved':before-len(s.split())})
