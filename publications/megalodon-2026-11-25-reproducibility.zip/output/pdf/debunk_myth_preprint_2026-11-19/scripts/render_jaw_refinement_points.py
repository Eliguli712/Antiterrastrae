"""Plot mesh-level changes using the archived jaw calibration results."""

import json

import numpy as np

import revise_figures as layout


OUTPUT = 'jaw_calibration_refinement_points'


def main():
    source_path = layout.REVIEW / 'jaw_calibration_curves.json'
    source = json.loads(source_path.read_text())
    series = {entry['law']: np.asarray(entry['rows']) for entry in source['series']}
    linear, narrow, neo_hookean = (series[key] for key in ('linear', 'narrow', 'neo_hookean'))
    np.testing.assert_array_equal(linear[:, 0], [0, 1, 2])
    np.testing.assert_array_equal(narrow[:, 0], [1, 2])
    assert tuple(neo_hookean[:, 0]) == (2,)
    assert linear[-1, 1] == narrow[-1, 1] == neo_hookean[-1, 1]

    fig = layout.canvas(121, 37)
    colors = ('#23528b', '#b54275')
    deviations = {}
    for panel, x, title, digits in [('f', 45, r'Jaw $Q_{0.95}/p$', 1),
                                     ('g', 89, r'Jaw $u_{\max}/L$', 3)]:
        column = 2 if panel == 'f' else 3
        axis = layout.axmm(fig, x, 9.5, 29, 18.8)
        deviation_linear = 100 * (linear[:, column] / linear[-1, column] - 1)
        deviation_narrow = 100 * (narrow[:, column] / narrow[-1, column] - 1)
        deviations[panel] = {'linear': deviation_linear.tolist(), 'narrow': deviation_narrow.tolist()}
        # Open circles and smaller crosses keep coincident L2 points legible.
        axis.plot(linear[:, 1] / 1e5, deviation_linear, linestyle='none', marker='o',
                  mfc='none', mec=colors[0], ms=3.8, mew=.78)
        axis.plot(narrow[:, 1] / 1e5, deviation_narrow, linestyle='none', marker='+',
                  color=colors[1], ms=3.4, mew=.78)
        axis.set_xlim(4.93, 5.99)
        axis.set_ylim(-3.29, .30)
        axis.set_xticks(linear[:, 1] / 1e5, ['5.04', '5.20', '5.90'])
        axis.set_yticks([-3, -2, -1, 0])
        axis.tick_params(labelsize=5.0, pad=1)
        axis.set_xlabel(r'Tetrahedra ($\times10^5$)', labelpad=1, fontsize=5.1)
        axis.set_ylabel('From own L2 (%)', labelpad=1, fontsize=5.1)
        layout.panel(fig, x-9, 35.8, panel)
        layout.txt(fig, x+14.5, 35.6, title, 6.1, ha='center', va='top')
        layout.txt(fig, x+14.5, 31.2,
                   f'L2  ○ {linear[-1, column]:.{digits}f}   + {narrow[-1, column]:.{digits}f}',
                   5.0, ha='center', va='top')
        layout.txt(fig, x+14.5, 2.2, f'Neo-Hookean L2 only: {neo_hookean[0,column]:.{digits}f}',
                   4.8, ha='center')
    layout.txt(fig, 82, .30, '○ Linear     + Narrow band', 4.9, ha='center')
    layout.save(fig, OUTPUT)
    metadata = {
        'source': str(source_path.relative_to(layout.R)),
        'deviation_definition': '100 (value / same-law L2 value - 1)',
        'departures_percent': deviations,
        'archived_source_values': source['series'],
        'scope': 'Computed-point markers only. Neo-Hookean has a single mesh and is annotated as an absolute value.',
    }
    (layout.REVIEW / f'{OUTPUT}.json').write_text(json.dumps(metadata, indent=2) + '\n')


if __name__ == '__main__':
    main()
