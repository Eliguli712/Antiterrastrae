#!/usr/bin/env python3
"""Exact same-domain section locations; P2 stress evaluated at triangle centres."""
from pathlib import Path
import json,sys,numpy as np
import pyvista as pv
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
from matplotlib.colors import LogNorm
import revise_figures as art

N=Path(__file__).resolve().parents[1];P=N.parents[2]
B=P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31'
art.F=N/'figures';art.V=N/'svg'
a=np.load(B/'numerics/L0/solution.npz');b=np.load(N/'numerics/p1_p2_common_domain/solution_P2.npz')
p=a['points_m'];t=a['tets'];basis=a['basis'];center=a['center_m'];q=(p-center)@basis*1000
grid=pv.UnstructuredGrid(np.column_stack([np.full(len(t),4),t]).ravel(),np.full(len(t),10,np.uint8),q)
grid.cell_data['source_cell']=np.arange(len(t))
cut=grid.slice(normal=(0,0,1),origin=(0,0,0)).triangulate()
faces=cut.faces.reshape(-1,4)[:,1:];owners=cut['source_cell'].astype(int)
positions=cut.points[faces].mean(1)/1000@basis.T+center
edge=p[t[:,1:]]-p[t[:,:1]];inverse=np.linalg.inv(edge);g=np.empty((len(t),4,3));g[:,1:]=inverse.transpose(0,2,1);g[:,0]=-g[:,1:].sum(1)
tail=np.einsum('ei,eij->ej',positions-p[t[owners,0]],inverse[owners]);L=np.column_stack([1-tail.sum(1),tail])
assert L.min()>-1e-8
grad=np.empty((len(owners),10,3));grad[:,:4]=(4*L[:,:,None]-1)*g[owners]
for k,(i,j) in enumerate([[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]]):grad[:,4+k]=4*(L[:,i,None]*g[owners,j]+L[:,j,None]*g[owners,i])
G2=np.einsum('eai,eaj->eij',b['displacement_m'][b['tets_P2'][owners]],grad)
def vm(G):
 e=(G+G.transpose(0,2,1))/2;s=29e9*np.trace(e,axis1=1,axis2=2)[:,None,None]*np.eye(3)+57e9*e;dev=s-np.trace(s,axis1=1,axis2=2)[:,None,None]*np.eye(3)/3
 return np.sqrt(1.5*np.sum(dev*dev,(1,2)))/1e6
v1=a['element_von_mises_Pa'][owners]/1e6;v2=vm(G2)
fig=art.canvas(58,36);lo=q[:,1].min();hi=q[:,1].max();floor=lo+.75*(hi-lo)
for i,(values,label) in enumerate([(v1,'c  P1'),(v2,'d  P2')]):
 ax=art.axmm(fig,5+i*29,10,23,22);poly=PolyCollection(cut.points[faces][:,:,:2],array=values,cmap='turbo',norm=LogNorm(1,1500),edgecolors='none',rasterized=True)
 ax.add_collection(poly);ax.set(xlim=(q[:,0].min()-.5,q[:,0].max()+.5),ylim=(floor,hi+.2),xticks=[-15,0,15]);ax.set_aspect('equal');ax.tick_params(labelsize=4.8,pad=.6)
 ax.set_xlabel('Transverse (mm)',fontsize=4.8,labelpad=.6)
 if i==0:ax.set_ylabel('Rootward (mm)',fontsize=4.8,labelpad=.6)
 else:ax.set_yticklabels([])
 art.txt(fig,5+i*29,35,label,6.2,weight='bold',va='top')
cb=fig.colorbar(poly,cax=art.axmm(fig,15,4,32,1.3),orientation='horizontal');cb.set_ticks([1,10,100,1000],labels=['1','10','100','1000']);cb.ax.tick_params(labelsize=4.6,pad=.6);art.txt(fig,13.5,4.6,'MPa',4.8,ha='right')
art.save(fig,'P1_P2_support_sections')
(N/'review/P1_P2_support_sections.json').write_text(json.dumps({'source':'L0 P1 / seeded L0 P2','same_cut_plane':'fixed L0 thickness coordinate = 0 mm','sampling':'Exact cut triangle centres; P2 shape-function derivatives; no interpolation from RGB or a different load','limits_MPa':[1,1500],'scale':'log','cuts':len(faces),'P1_range_MPa':[float(v1.min()),float(v1.max())],'P2_range_MPa':[float(v2.min()),float(v2.max())]},indent=2))
print('Saved matched root-side P1/P2 sections.')
