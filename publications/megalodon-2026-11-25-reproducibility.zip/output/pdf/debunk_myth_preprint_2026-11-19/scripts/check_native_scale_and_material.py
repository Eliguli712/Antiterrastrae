"""Re-read the 100 mm MR5 solution and test an explicitly uncalibrated
homogeneous-per-part anisotropic tension / cohesive-interface candidate.
The candidate is a constitutive coupon, NOT a fractured native tooth solve.
"""
from pathlib import Path
import ast, hashlib, json, csv
import numpy as np
from scipy import linalg
from scipy.optimize import root
N=Path(__file__).resolve().parents[1];P=N.parents[2]
O=N/'numerics/crown_root_100mm';O.mkdir(parents=True,exist_ok=True)
T=P/'output/paper_native74_5cm_10cm_2026-11-22'
source=T/'scripts/solve_mr5_10cm.py';tree=ast.parse(source.read_text())
ns={'np':np,'linalg':linalg,'PARAM':dict(C10=12e6,C01=3e6,C20=2e6,C11=1.5e6,C02=.8e6,bulk=250e6)}
for node in tree.body:
 if isinstance(node,ast.FunctionDef) and node.name in ['geometry','material','fields','rms_operator','qweighted','material_checks']:
  exec(compile(ast.Module(body=[node],type_ignores=[]),str(source),'exec'),ns)
path=T/'review/mr5_run001/100mm_MR5_solution.npz';a=np.load(path)
p,t,u=a['points_m'],a['tets'],a['displacement_m'];vol,grad=ns['geometry'](p,t)
force,vm,energy,strain,jmin=ns['fields'](p,t,vol,grad,u)
C,R,CR,gauge,weights,center,length=ns['rms_operator'](p,a['boundary_faces'])
external=np.zeros_like(p)
for k in range(4):np.add.at(external,t[:,k],vol[:,None]*np.array([0.,0.,50000.])/4)
r=(force-external).ravel();reaction=C.T@np.linalg.solve(C@C.T,C@r);free=r-reaction
checks={'status':'passed','scope':'Independent stored-field readback, not a second full nonlinear solve. Closed-solid MR5 proxy, not native pores.',
 'solution_sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest(),'nodes':len(p),'tetrahedra':len(t),
 'relative_constrained_residual':float(np.linalg.norm(free)/np.linalg.norm(external)),
 'relative_force_balance':float(np.linalg.norm((external.ravel()+reaction).reshape(-1,3).sum(0))/np.linalg.norm(external.sum(0))),
 'relative_VM_readback':float(np.linalg.norm(vm-a['element_von_mises_Pa'])/np.linalg.norm(vm)),
 'relative_energy_readback':float(abs(energy.sum()-a['element_energy_J'].sum())/energy.sum()),
 'energy_J':float(energy.sum()),'volume_Q95_Pa':ns['qweighted'](vm,vol,.95),
 'max_u_mm':float(np.linalg.norm(u,axis=1).max()*1000),'J_min':jmin,'constitutive_checks':ns['material_checks']()}
assert checks['relative_constrained_residual']<2e-7
assert checks['relative_force_balance']<1e-8
assert checks['relative_VM_readback']<1e-11
# Exact finite-strain similarity, under equal nominal pressure and geometrically
# similar support only. This is NOT a 50 mm replay of the MR5 body-load case.
ids=np.arange(0,len(t),max(1,len(t)//1000))
F=np.eye(3)+np.einsum('eai,eaj->eij',u[t[ids]],grad[ids])
_,g50=ns['geometry'](p*.5,t[ids]);F50=np.eye(3)+np.einsum('eai,eaj->eij',(u*.5)[t[ids]],g50)
checks['similarity_F_max_abs_error']=float(abs(F-F50).max());assert checks['similarity_F_max_abs_error']<1e-12
checks['similarity_scope']='Equal nominal traction: F and Cauchy stress invariant; u100=2u50, force100=4force50, energy100=8energy50. Fixed body force, fixed absolute support stiffness and fracture process lengths do not obey this pressure-only similarity.'
(O/'MR5_readback.json').write_text(json.dumps(checks,indent=2))
print('MR5 readback',json.dumps(checks),flush=True)
del a,p,t,u,vol,grad,force,external,C,R,r,reaction,free

def law(F,E=1.,nu=.25,k_ratio=.2,b=8.,axis=0):
 mu=E/(2*(1+nu));lam=E*nu/((1+nu)*(1-2*nu));J=np.linalg.det(F)
 if J<=0:raise ValueError('Nonpositive J')
 invT=np.linalg.inv(F).T;ln=np.log(J);a=np.eye(3)[axis];v=F@a;e=max(float(v@v-1),0.)
 W=mu/2*(np.sum(F*F)-3)-mu*ln+lam/2*ln**2
 W+=E*k_ratio/(2*b)*np.expm1(b*e*e)
 P=mu*(F-invT)+lam*ln*invT+2*E*k_ratio*e*np.exp(b*e*e)*np.outer(v,a)
 return float(W),P
# Finite difference and superposed-rotation checks of the candidate energy.
F=np.array([[1.08,.02,0.],[.01,.97,.01],[0.,0.,.98]]);W,PP=law(F);fd=np.zeros((3,3));h=2e-6
for i in range(3):
 for j in range(3):
  d=np.zeros((3,3));d[i,j]=h;fd[i,j]=(law(F+d)[0]-law(F-d)[0])/(2*h)
theta=.47;Q=np.array([[np.cos(theta),-np.sin(theta),0],[np.sin(theta),np.cos(theta),0],[0,0,1.]])
obj=np.linalg.norm(law(Q@F)[1]-Q@PP)/np.linalg.norm(PP)
der=np.linalg.norm(fd-PP)/np.linalg.norm(PP);assert der<1e-8 and obj<1e-12
rows=[]
for phase,E in [('crown',1.),('root',.3)]:
 for direction,axis in [('parallel',0),('transverse',2)]:
  x=np.zeros(2)
  for stretch in np.linspace(1.,1.2,81):
   def fn(z):
    ff=np.diag([stretch,*np.exp(z)]);pp=law(ff,E,axis=axis)[1];return np.array([pp[1,1],pp[2,2]])/E
   sol=root(fn,x);assert sol.success or np.linalg.norm(fn(sol.x))<1e-9
   x=sol.x;ff=np.diag([stretch,*np.exp(x)]);w,pp=law(ff,E,axis=axis);sig=pp@ff.T/np.linalg.det(ff)
   assert np.linalg.norm(fn(x))<1e-8
   rows.append(dict(phase=phase,direction=direction,stretch=stretch,transverse_2=ff[1,1],transverse_3=ff[2,2],sigma11_over_Ec=sig[0,0],energy_over_Ec=w))
with (O/'candidate_anisotropic_tension.csv').open('w')as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
# Bilinear opening law: dimensionless units Ec=1,L0=1. Compression is retained.
k,peak,dc=4.,.02,.04;d0=peak/k;Gc=.5*peak*dc

def cohesive(delta,history):
 history=max(history,max(delta,0.))
 damage=0. if history<=d0 else (1. if history>=dc else dc*(history-d0)/(history*(dc-d0)))
 return (k*delta if delta<0 else (1-damage)*k*delta),history,damage
hist=0.;cr=[]
for delta in np.r_[np.linspace(0,dc,1001),np.linspace(dc,0,101),np.linspace(0,-.005,21)]:
 tr,hist,damage=cohesive(float(delta),hist);cr.append([float(delta),tr,hist,damage])
area=float(np.trapezoid(np.array(cr[:1001])[:,1],np.array(cr[:1001])[:,0]));assert abs(area/Gc-1)<2e-5
assert np.all(np.diff(np.array(cr)[:,3])>=-1e-14) and cr[-1][1]<0
np.savetxt(O/'candidate_cohesive_opening.csv',cr,delimiter=',',header='opening_over_L0,traction_over_Ec,max_opening_over_L0,damage',comments='')
result=dict(status='passed',scope='Constitutive coupon and interface-law verification only. No native-tooth fracture, anatomical EDJ, socket contact or tissue calibration.',homogeneous_phase_E_ratios={'crown':1.,'root':.3},Poisson_ratio=.25,fibre_stiffness_ratio=.2,exponent=8.,gradient_relative_error=float(der),objectivity_relative_error=float(obj),stretch_range=[1.,1.2],stress_at_stretch_1p2=[r for r in rows if r['stretch']==1.2],cohesive=dict(stiffness=4.,peak=.02,initial_opening=d0,complete_opening=dc,energy_over_EcL0=Gc,integral_relative_error=abs(area/Gc-1),history_irreversible=True,compression_retained=True),coupled_native_fracture_solved=False)
(O/'candidate_material_checks.json').write_text(json.dumps(result,indent=2));print('Candidate coupon',json.dumps(result),flush=True)
