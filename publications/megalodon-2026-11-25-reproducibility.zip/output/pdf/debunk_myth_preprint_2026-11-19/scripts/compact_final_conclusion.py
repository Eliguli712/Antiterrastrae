from pathlib import Path
p=Path(__file__).resolve().parents[1]/'DebunkMeg_complete_2026-11-19.tex';s=p.read_text();before=len(s)
a=s.index('\\section{Conclusions}');b=s.index('\\FloatBarrier',a)
s=s[:a]+r'''\section{Conclusions}
\textbf{The evidence supports conditional regional stress localisation.} Native 18~$\mu$m CT supports complete threshold reconstructions and public geometry. Sampled positional RMS/maximum distances are 1.330/8.956~$\mu$m; curvature remains resolution-dependent, without a common limiting range or identified development.

Under 1~MPa crown-face pressure, all six A2--A3 P1 Q95 changes are below 0.233\%, the apex change is 0.081\%, and all 18 quantile changes are below 0.60\%. Same-L0 P1/P2 Q95 differences of 0.92--10.14\% and a 37.78\% energy-norm gap show why finite mesh-step stability is not a complete error estimate. A3 P2 remains absent and support-adjacent peaks remain sensitive. Threshold, candidate-layer and attachment comparisons retain their distinct error and modelling scopes.

\textbf{Root-to-edge amplification depends on pose, loading and attachment.} The matched P2 unit-margin ratio is 1.603, with a 26.04\% tooth-only energy gap. The contact-free 10~kPa NH jaw has verified equilibrium but $u_{\max}/L=1.219$, an applicability diagnostic. The separate 100~mm MR5 control gives Q95 691.740~Pa and constrained residual $7.56\times10^{-8}$.

Native 74M and public 200M surface displays add inspectable geometry, not native porous FE information. Verified anisotropic/cohesive coupons do not establish tooth fracture. Fossil tissue identity, strength, toughness, flaws and loading/contact history remain necessary. \emph{Geometric scaling, display magnification and biological development are distinct.}

'''+s[b:]
a=s.index('Table~\\ref{tab:principal} reports volume quantiles');b=s.index('\n\n',a)
s=s[:a]+r'''Table~\ref{tab:principal} gives volume quantiles of positive maximum principal stress, $\sigma_+$, and positive magnitude of negative minimum principal stress, $\sigma_-$. They are diagnostics rather than brittle-failure criteria. Both refined fixed-cap models peak in cells intersecting essential support nodes (Figure~\ref{fig:validation}e), supporting numerical support sensitivity without establishing a physical crack or continuum singularity.'''+s[b:]
a=s.index('Natural and paper-image reference-colour appearance');b=s.index('\n\n',a)
s=s[:a]+r'''Original 2,400$\times$1,320 appearance exports contain no numerical FE field; reverse-face continuation and roughness are illustrative. Figure~\ref{fig:specimen} labels authentic archived stresses separately from the 32,687,264-face appearance geometry, native CT and mechanical proxy. Original photographs, display-only glare processing, hashes and blue-margin preservation checks are retained.'''+s[b:]
s=s.replace('stress is $\\lambda$ times the strain trace plus twice $\\mu$ times strain.', 'stress is $\\lambda$ times the strain trace times identity plus twice $\\mu$ times strain.')
p.write_text(s);print('Additional editorial characters consolidated:',before-len(s))
