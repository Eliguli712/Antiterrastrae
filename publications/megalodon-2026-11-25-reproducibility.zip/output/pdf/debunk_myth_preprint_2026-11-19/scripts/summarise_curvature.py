from pathlib import Path
import json,csv
import numpy as np
R=Path(__file__).resolve().parents[1];D=R/'numerics/curvature_study'
rows=list(csv.DictReader(open(D/'resolution_statistics.csv')));ref=np.load(D/'reference_samples.npz')['curvature_reference'];out=[];eps=float(np.sqrt(np.log(2*51/.05)/(2*len(ref))))
refbands=[]
for j,field in enumerate(['H','K','Habs']):
 qq=np.quantile(ref[:,j],[.025-eps,.025,.025+eps,.975-eps,.975,.975+eps],method="inverted_cdf");qq[[1,4]]=np.quantile(ref[:,j],[.025,.975]);refbands.append(dict(field=field,Q025=float(qq[1]),Q975=float(qq[4]),Q025_DKW_low=float(qq[0]),Q025_DKW_high=float(qq[2]),Q975_DKW_low=float(qq[3]),Q975_DKW_high=float(qq[5]),N=len(ref),family_size=51,DKW_mass_band=eps))
for r in rows:
 vals=np.load(D/(r['run']+'_pairs.npz'))['curvature'][:,['H','K','Habs'].index(r['field'])]
 q=np.quantile(vals,[.025-eps,.025+eps,.975-eps,.975+eps],method="inverted_cdf");r.update(Q025_DKW_low=float(q[0]),Q025_DKW_high=float(q[1]),Q975_DKW_low=float(q[2]),Q975_DKW_high=float(q[3]),DKW_mass_band=eps)
with (D/'simultaneous_statistics.csv').open('w',newline='') as f:w=csv.DictWriter(f,list(rows[0]));w.writeheader();w.writerows(rows)
for field in ['H','K','Habs']:
 for spacing in [54,72,108,144]:
  case=[r for r in rows if r['field']==field and int(r['spacing_um'])==spacing]
  summary=dict(field=field,spacing_um=spacing)
  for key in ['Q025','Q975','r','RMSE','MSE','fraction_exceeding_epsilon','MSE_Hoeffding_upper','Q025_DKW_low','Q025_DKW_high','Q975_DKW_low','Q975_DKW_high']:
   v=[float(r[key]) for r in case];summary[key+'_min']=min(v);summary[key+'_max']=max(v);summary[key+'_mean']=float(np.mean(v))
  out.append(summary)
# Quantile-equivalence exploratory margin is five percent of reference 95% width.
verdict=[]
for j,field in enumerate(['H','K','Habs']):
 band=refbands[j];tol=.05*(band['Q975']-band['Q025']);cases=[r for r in rows if r['field']==field]
 compatible=all(abs(float(r['Q025'])-band['Q025'])<=tol and abs(float(r['Q975'])-band['Q975'])<=tol for r in cases)
 verdict.append(dict(field=field,exploratory_margin=tol,all_cases_within_margin=compatible,range_compatible=False if not compatible else None,conclusion='A common reference-compatible central 95% range is not supported at the declared exploratory margin' if not compatible else 'Finite sample compatibility only; no asymptotic proof'))
(R/'numerics/curvature_summary.json').write_text(json.dumps(dict(reference=refbands,resolutions=out,verdict=verdict,confidence='DKW rank bands simultaneous across 51 finite marginal fields; Monte Carlo uncertainty only. MSE Hoeffding bounds simultaneous across 48 comparisons. Grid phases are a sensitivity envelope.',formal_statement='Uniform-in-phase L2 convergence on a common surface implies uniform-in-phase convergence in measure by Markov; this finite experiment does not establish the premise.'),indent=2))
print('Complete finite-range summary; all three common-range tests unsupported.')
