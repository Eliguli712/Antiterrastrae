#!/usr/bin/env python3
"""Notebook-defined difference diagnostics, with source +Y drawn upward.

Only function definitions are read from notebook cell 22. No notebook cells,
solvers, file-writing instructions or display-limit errors are executed.
"""
from pathlib import Path
import ast,json,hashlib,time,os
import numpy as np
import trimesh
from scipy.spatial import cKDTree
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pyvista as pv
R=Path(__file__).resolve().parents[1];P=Path(os.environ.get('FEA_MEG_ROOT',str(R.parents[2])))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
nb=P/'applied_forces/stress_analysis.ipynb'
n=json.loads(nb.read_text());code=''.join(n['cells'][22]['source']);tree=ast.parse(code)
defs=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name in ['mean_curvature_signed','gaussian_curvature','map_vertex_field']]
scope=dict(np=np,cKDTree=cKDTree);exec(compile(ast.Module(body=defs,type_ignores=[]),'notebook_cell22_functions','exec'),scope)
sources=[P/'applied_forces/shark_surface.obj',P/'applied_forces/shark_surface_compressed.obj'];before={str(p):sha(p) for p in [nb,*sources]}
t=time.monotonic();meshes=[trimesh.load(p,force='mesh',process=False,skip_materials=True) for p in sources]
fields=[]
for mesh in meshes:
    H=scope['mean_curvature_signed'](mesh);K=scope['gaussian_curvature'](mesh);root=np.sqrt(np.maximum(H*H-K,0))
    fields.append([H+root,H-root]);print('curvatures',len(mesh.vertices),len(mesh.faces),flush=True)
full,comp=meshes;delta=[]
for j in range(2):delta.append(scope['map_vertex_field'](comp.vertices,fields[1][j],full.vertices,k=6)-fields[0][j])
delta=np.column_stack(delta);np.savez_compressed(R/'numerics/notebook_curvature_differences.npz',vertices=full.vertices,faces=full.faces,delta_kappa1=delta[:,0],delta_kappa2=delta[:,1])
limit=float(np.quantile(np.abs(delta),.99));tau=.01*limit
# The OBJ has a longitudinal source Z axis and dorsal +Y. This proper rotation
# places the snout to the left and the dorsal fin upward without deforming it.
v=full.vertices;v=np.column_stack([-v[:,2],v[:,1],v[:,0]]);v-=(v.min(0)+v.max(0))/2
for j in range(2):
    poly=pv.PolyData(v,np.column_stack([np.full(len(full.faces),3),full.faces]).ravel());poly['d']=np.arcsinh(delta[:,j]/tau)
    view=pv.Plotter(off_screen=True,window_size=(2100,800));view.set_background('white');view.add_mesh(poly,scalars='d',cmap='RdBu_r',clim=[-np.arcsinh(limit/tau),np.arcsinh(limit/tau)],lighting=False,show_scalar_bar=False)
    view.camera_position=[(0,0,80),(0,0,0),(0,1,0)];view.enable_parallel_projection();view.camera.parallel_scale=5.4;view.render();im=view.screenshot(return_img=True);view.close()
    mask=np.any(im[:,:,:3]<245,axis=2);yy,xx=np.where(mask)
    from PIL import Image
    Image.fromarray(im).crop((max(0,int(xx.min())-20),max(0,int(yy.min())-20),min(im.shape[1],int(xx.max())+21),min(im.shape[0],int(yy.max())+21))).save(R/f'figures/notebook_delta_kappa{j+1}_dorsal_up.png')
assert before=={str(p):sha(p) for p in [nb,*sources]}
(R/'review/notebook_curvature_provenance.json').write_text(json.dumps(dict(source_hashes=before,cell_index=22,fields='Exact notebook H/K-derived kappa1/kappa2 diagnostics; compressed minus original, k=6 inverse-distance nearest-vertex mapping.',units='inverse source-coordinate units; physical anatomical scale is uncalibrated',interpretation='Notebook-defined diagnostics, not validated physical principal curvatures, fossil-tooth stress or fluid output.',orientation='display=(-source_Z,source_Y,source_X); camera screen up=+source_Y (dorsal up)',display=dict(cmap='RdBu_r',asinh_scale=tau,symmetric_99percent_limit=limit,statistics_unclipped=True),source_faces=len(full.faces),source_vertices=len(full.vertices),seconds=time.monotonic()-t),indent=2))
print('Notebook diagnostics complete; original sources unchanged.',flush=True)
