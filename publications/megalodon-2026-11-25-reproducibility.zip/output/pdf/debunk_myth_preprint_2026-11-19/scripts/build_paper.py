#!/usr/bin/env python3
"""Compile with source datasets first and preserve explicit bibliography groups."""
from pathlib import Path
import re,subprocess,shutil
R=Path(__file__).resolve().parents[1]
def run(args,log):
    with (R/'review'/log).open('w') as f:subprocess.run(args,cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
run([(shutil.which('xelatex') or '/Library/TeX/texbin/xelatex'),'-interaction=nonstopmode','-halt-on-error','main.tex'],'latex_pass1.txt')
run([(shutil.which('bibtex') or '/Library/TeX/texbin/bibtex'),'main'],'bibtex.txt')
p=R/'main.bbl';s=p.read_text()
for key,title in [('CT32','A. Complete optimised specimen surface'),('CT74','B. Native surface and lossless voxel source'),('Corn2016','C. Scientific and numerical literature')]:
    stop=s.index('{'+key+'}')
    start=s.rfind('\\bibitem',0,stop)
    assert start>=0,key
    s=s[:start]+'\\item[]\\textbf{'+title+'}\n'+s[start:]
p.write_text(s)
for i in [2,3]:run([(shutil.which('xelatex') or '/Library/TeX/texbin/xelatex'),'-interaction=nonstopmode','-halt-on-error','main.tex'],f'latex_pass{i}.txt')
print('Compiled with grouped bibliography.')
