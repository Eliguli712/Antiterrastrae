#!/usr/bin/env python3
"""Short main-paper methods with complete figures, results and preserved source."""
from pathlib import Path
import re
N=Path(__file__).resolve().parents[1];p=N/'DebunkMeg_complete_2026-11-19.tex';s=p.read_text()
def section(start,end,new):
 global s
 i=s.index(start);j=s.index(end,i+len(start));s=s[:i]+new+'\n\n'+s[j:]
section(r'\subsection{Curvature stability:',r'\subsection{Photographs and appearance references}',r'''\subsection{Curvature stability: estimates, confidence and convergence}
Close surface positions do not imply stable curvature. Sixteen extractions at 54, 72, 108 and 144~$\mu$m (four grid phases each) are compared with a 36~$\mu$m reference on 64,000 common area-uniform points, split into eight 8,000-point batches. Unsmoothed, unclipped fields on the largest vertex-connected exterior are transferred by closest-triangle projection and barycentric interpolation. Mean-curvature correlations are about 0.37--0.57 and Gaussian-curvature correlations 0.08--0.21. In phase zero, signed-$H$ central 95\% ranges change from $[-8.85,6.92]$ at 144~$\mu$m to $[-23.20,22.55]$~mm$^{-1}$ at 54~$\mu$m, versus reference $[-31.34,30.31]$. Gaussian ranges change from $[-88.05,101.43]$ to $[-838.29,721.30]$~mm$^{-2}$, versus $[-2191.70,1127.13]$. A common range is unsupported within the declared 5\%-of-reference-width exploratory margin.

At 54~$\mu$m, phase zero, $r_H=0.56791$ (SE 0.00254; 95\% MC interval $[0.56191,0.57390]$) and $r_K=0.20765$ (SE 0.00564; $[0.19430,0.22100]$). MSEs are 157.582 (SE 0.967)~mm$^{-2}$ and 745140 (SE 7594)~mm$^{-4}$; regression slopes are 0.39277 and 0.10210. Signed-$H$ MSE decreases from 200.07 at 144~$\mu$m, while $K$ MSE remains about $7.2$--$7.5\times10^5$ without a decreasing finest-step trend. Positive correlation therefore does not establish scale agreement. Batch SE and Student-$t$ intervals with seven degrees of freedom cover Monte Carlo sampling, not reference, segmentation or biological uncertainty.

Simultaneous DKW percentile bands \citep{Massart1990} use 51 marginal fields and familywise error 0.05. Bounded-error Hoeffding intervals \citep{Hoeffding1963} give finite-field MSE bounds $[87.728,227.437]$~mm$^{-2}$ and $[0,1.89685\times10^6]$~mm$^{-4}$ for that 54~$\mu$m phase. The bounds may be wide. Full formulas, population-moment identities and raw results accompany the source. Vanishing MSE uniformly over grid phases would imply convergence in area measure by Markov's inequality; this finite experiment establishes neither that premise nor pointwise convergence. Grid phases are reconstruction perturbations, not independent teeth.''')
section(r'\subsection{Coordinate registration, state maps and their limits}',r'\subsection{DICOM calibration',r'''\subsection{Coordinate registration, state maps and their limits}\label{sec:registration}
The complete native/optimised CT surfaces \citep{CT74,CT32} derive from the native mask \citep{Mask18}. Across 10,000 bidirectional area-uniform pairs, all coordinate correlations exceed 0.99999995; RMS, 99th-percentile and maximum sampled distances are 1.330, 4.530 and 8.956~$\mu$m. This is sampled positional correspondence, separate from curvature or unsampled extrema.

Scanner coordinates add origin $(4.176,0.198,16.818)$~mm; mask-local coordinates instead add $(11.232,1.566,18.186)$~mm. Their affine registration uses the difference of these origins. Stored 16~$\mu$m through-slice coordinates are expanded by $18/16$ before adding the scanner origin. Units and frames accompany every projection.

For measured states, an invertible affine landmark fit describes linear shape correspondence; a smooth non-affine displacement allows additional deformation, fitted with a second-derivative regularisation penalty. Positive Jacobians provide only local orientation control. A relative non-affine Lipschitz constant below one on a convex domain is sufficient for global injectivity, with boundary coverage and anatomical correspondence still required. The present sample is one fossil at one biological time: reconstruction states do not identify development or growth rate. Nearest-surface maps need not be bijective. Projected arrows are geometric approximation distances, not biological movement; logarithmic distance plots retain zero values numerically and state their display floor.''')
# Shorten the procedural table while retaining unique numerical limits.
i=s.index(r'\toprule Obligation & Executed evidence & Status and boundary')
j=s.index(r'\bottomrule',i)
s=s[:i]+r'''\toprule Obligation & Executed evidence & Status and boundary\\\midrule
CT calibration/playback & 3,050 headers, raw spot checks, LPS coordinates and all frame-plane positions; 3,050 frames, 25~fps, 122~s. & Metadata/playback verified; no absolute scanner or acquisition-time calibration.\\
Segmentation & Three complete native thresholds ($\pm5\%$); seven saved sections; common 0.288~mm geometry solves. & Volume change $<0.40\%$, regional Q95 $<0.80\%$; separate grid effect 6.21\%; no operator-repeatability estimate.\\
Topology/curvature & Edge/link audits, volumes, distances, sphere/scale tests, 10,000 area pairs and 16 curvature grid phases. & Finite geometric/statistical checks; no exhaustive self-intersection or pore-identity validation.\\
Mesh/order & Three global and three local P1 meshes; same-L0 P1/P2 pair; three jaw meshes. Jaw quality minimum $2.47\times10^{-4}$, first percentiles 0.325--0.389. & Tooth last-step Q95 $<0.233\%$, all 18 $<0.60\%$; jaw Q95 steps 0.83--1.24\%. P1/P2 differs 0.92--10.14\%; not a continuum bound or notch-resolution proof.\\
Attachment/load & Three supports, three directions, two footprints, cap-depth changes, six Robin stiffnesses and six saved jaw masks. & Finite L0 set; no full factorial/pure lateral test or measured attachment. Contact impact is formulated, not solved.\\
Materials & $\nu=0.20/0.30$, doubled-$E$, six $E=40/90$~GPa and $p=0.5/1/5$~MPa scaling cases; tangents, three shell widths, four bilayer meshes and full StVK. & Candidate geometric phases and moduli, not identified fossil tissues or a calibrated interface.\\
Regions & Full tensors, physical volumes/masks and independent CDF inequalities for all Table~9 entries. & Completed for geometric unions; anatomical equivalence unverified.\\
Equilibrium/readback & Tooth patch/rigid/force/moment/work/scaling checks. Five 10~kPa jaw fields: 2,723,248 cells, residual $\le9.48\times10^{-8}$. & Current-moment defects: L0 linear 0.299; L2 bands 0.133/0.126. Full StVK at 1~kPa: force $5.77\times10^{-8}$, moment $3.18\times10^{-15}$; full 10~kPa unverified.\\
Fracture & Independently extracted principal tensile/compressive stresses. & No measured strength, toughness, flaws, crack/interface criterion or loading history.\\
Biology & Two photographs and primary comparative literature. & Dental position, histological EDJ, damage chronology and real root attachment unresolved.\\
Reproducibility & Editable source, fields/meshes, CT profiles/media, exact inputs, masks and hashes; zero-displacement and StVK objectivity tests. & Numerical verification is separate from biological validation; original and current fields retain distinct provenance.\\
'''+s[j:]
# Abbreviate printed author lists in standard numeric style; full originals persist.
replacements={
 'S. Wroe, D. R. Huber, M. B. Lowry, C. R. McHenry, S. Moreno, P. Clausen,\\n  T. L. Ferrara, E. Cunningham, M. N. Dean, and A. P. Summers.':'S. Wroe et al.',
}
for a,b in replacements.items():s=s.replace(a,b)
# Actual bibliographic author lines can wrap differently; only known long lists.
for key,author in [('Wroe2008','S. Wroe et al.'),('Jambura2019','P.~L. Jambura et al.'),('Hu2018','Y. Hu et al.')]:
 m=re.search(r'(\\bibitem(?:\[[\s\S]*?\])?\{'+key+r'\}\s*)(.*?)(\\newblock)',s,re.S)
 if m:s=s[:m.start(2)]+author+'\n'+s[m.end(2):]
s=s.replace(r'4.19\times10^{-12}',r'4.18\times10^{-12}')
s=s.replace('CC BY 4.0 \\citep{AucklandJaw2016}',r'\href{https://creativecommons.org/licenses/by/4.0/}{CC BY 4.0} \citep{AucklandJaw2016}')
p.write_text(s)
print('Retained complete numerical outcomes; condensed geometry/statistics and procedural repetition.')
