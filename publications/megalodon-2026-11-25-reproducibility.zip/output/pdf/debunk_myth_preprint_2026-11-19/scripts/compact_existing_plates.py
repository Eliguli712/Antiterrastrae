#!/usr/bin/env python3
"""Remove figure whitespace; retain plot values, limits, labels and native rasters."""
import inspect
import profile_figures as profiles
import publication_figures as publication

source=inspect.getsource(profiles.figure2)
for old,new in {
 'canvas(183,115)':'canvas(183,101)',
 'left+6,49,49,55':'left+6,45,49,44',
 "left,113,":"left,99,",
 "left+30,112,":"left+30,98,",
 "left+30,107,":"left+30,93,",
 'left+7,11,47,25':'left+7,10,47,22',
 "left,43,":"left,39,",
 "left+30,42,":"left+30,38,",
}.items():
 assert old in source,old
 source=source.replace(old,new)
exec(compile(source,__file__,'exec'),profiles.__dict__);profiles.figure2()

source=inspect.getsource(publication.validation_plate)
for old,new in {
 'canvas(183,145)':'canvas(183,115)',
 'fig,10,110,43,22':'fig,10,86,43,22',
 'fig,71,110,43,22':'fig,71,86,43,22',
 'fig,133,110,43,22':'fig,133,86,43,22',
 'fig,1,143,':'fig,1,113,',
 'fig,62,143,':'fig,62,113,',
 'fig,123,143,':'fig,123,113,',
 'fig,31,142,':'fig,31,112,',
 'fig,92,142,':'fig,92,112,',
 'fig,153,142,':'fig,153,112,',
 'fig,15,64,35,26':'fig,15,48,35,22',
 'fig,71,66,43,25':'fig,71,49,43,22',
 'fig,133,66,43,25':'fig,133,49,43,22',
 'fig,1,100,':'fig,1,77,',
 'fig,62,100,':'fig,62,77,',
 'fig,123,100,':'fig,123,77,',
 'fig,31,99,':'fig,31,76,',
 'fig,92,99,':'fig,92,76,',
 'fig,153,99,':'fig,153,76,',
 'fig,31,51.5,':'fig,31,40.5,',
 'fig,92,51.5,':'fig,92,40.5,',
 'fig,153,51.5,':'fig,153,40.5,',
 'fig,x+4,9,53,34':'fig,x+4,7,53,26',
 "fig,x+1,49,":"fig,x+1,38,",
 "fig,x+31,48,":"fig,x+31,37,",
 'fig,62,4,55,1.3':'fig,62,3,55,1.3',
 'fig,59,4.7,':'fig,59,3.7,',
 'fig,122,4.7,':'fig,122,3.7,',
}.items():
 assert old in source,old
 source=source.replace(old,new)
exec(compile(source,__file__,'exec'),publication.__dict__);publication.validation_plate()
print('Compacted Figures 2 and 8 without changing any data axis or scalar limit.')
