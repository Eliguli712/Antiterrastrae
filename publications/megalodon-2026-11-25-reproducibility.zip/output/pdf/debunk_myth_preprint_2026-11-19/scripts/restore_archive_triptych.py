#!/usr/bin/env python3
"""Restore authentic archived COMSOL fields in Figure 1, with their own units."""
import inspect,json
from pathlib import Path
import profile_figures as original
R=Path(__file__).resolve().parents[1]
source=inspect.getsource(original.figure1).split(' provenance=[]')[0]
source=source.replace("f'stvk_tooth_view_{j}.png'","f'archived_comsol_mapped_view_{j}.png'")
source=source.replace("'StVK σvM\\n(MPa), log'","'Archive σvM\\n(MPa), linear'")
source=source.replace("norm=LogNorm(.1,300)","norm=plt.Normalize(.05676644283690944,.32688821709539363)")
source=source.replace("cb.set_ticks([.1,1,10,100,300],labels=['0.1','1','10','100','300'])","cb.set_ticks([.06,.1,.2,.3],labels=['0.06','0.10','0.20','0.30'])")
exec(compile(source,__file__,'exec'),original.__dict__)
original.figure1()
(R/'review/figure1_archived_field_restoration.json').write_text(json.dumps(dict(status='passed',source='DICOM_16um/exports/von_mises_data_smoothed.txt',source_samples=191031,rendered_triangles=5554286,original_display_limits_Pa=[56766.44283690944,326888.21709539363],display_limits_MPa=[.05676644283690944,.32688821709539363],scale='linear',source_case='Archived COMSOL case; pressure/material/support not independently identified. It is not labelled as a verified StVK case.',appearance_references='The image-referenced PBR exports are preserved separately and not used as numerical stress values.'),indent=2))
