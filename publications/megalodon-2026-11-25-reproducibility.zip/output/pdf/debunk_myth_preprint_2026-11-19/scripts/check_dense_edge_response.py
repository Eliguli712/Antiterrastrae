"""Evaluate denser angular grids using the stored linear response operators."""
import json
from pathlib import Path

import numpy as np

PAPER = Path(__file__).resolve().parents[1]
PROJECT = PAPER.parents[2]
TRANSFER = PROJECT / 'output/jaw_tooth_transfer_2026-11-22'
BASE = PROJECT / 'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0'


def skew(x):
    return np.array([[0, -x[2], x[1]], [x[2], 0, -x[0]], [-x[1], x[0], 0]])


def to_stress(p, u):
    """Displacement-basis columns go through the exact per-cell affine gradients."""
    du = u[:, 1:] - u[:, :1]
    grad = np.linalg.solve(p[:, 1:] - p[:, :1], du.reshape(len(du), 3, -1))
    grad = grad.reshape(du.shape).swapaxes(1, 2)
    eps = (grad + grad.swapaxes(1, 2)) / 2
    return 57e9*eps + 29e9*np.trace(eps, axis1=1, axis2=2)[:, None, None, :]*np.eye(3)[None, :, :, None]


def q95(value, weights):
    order = np.argsort(value)
    volume = np.cumsum(weights[order], dtype=np.longdouble)
    return float(value[order[np.searchsorted(volume, .95*volume[-1])]])


def main():
    archive = json.loads((TRANSFER/'edge_data/results.json').read_text())
    ref = np.load(BASE/'solution.npz')
    masks = np.load(BASE/'region_masks.npz')
    registration = np.load(TRANSFER/'data_v3/registration.npz')
    op = np.load(TRANSFER/'data_v3/condensed_operators.npz')
    data = np.load(TRANSFER/'edge_data/unit_response_basis.npz')
    points, tets, faces = (ref[k] for k in ('points_m', 'tets', 'boundary_faces'))
    source_volume = ref['volumes_m3']
    Q0 = registration['reference_rotation']
    centers = registration['root_centres_tooth_m']-registration['tooth_root_centre_m']
    location = registration['reference_location_m']
    jaw_centers = registration['root_centres_jaw_m']
    L = float(registration['rotation_length_m'])
    St, Cj = op['tooth_stiffness_N_per_m'], op['jaw_compliance_m_per_N']
    Dm = op['tooth_unit_displacements'].reshape(len(points), 3, 12)
    U = data['unit_displacement_m_per_N'].reshape(2, len(points), 3, 3)
    force_to_reaction = data['root_reaction_N_per_N']
    tangent = Q0 @ ref['basis'][:, 2]
    axis = np.array([0., 1., 0.])
    np.testing.assert_allclose(axis @ tangent, 0, atol=1e-12)
    runs = {}
    max_outward = -np.inf
    for i, margin in enumerate(('RA', 'RB')):
        indices = masks[margin]
        cells, volume = tets[indices], source_volume[indices]
        Sforce = to_stress(points[cells], U[i][cells])
        Sroot = to_stress(points[cells], Dm[cells])
        patch = points[faces[data[f'patch_face_ids_{margin}']]]
        normal = np.cross(patch[:, 1]-patch[:, 0], patch[:, 2]-patch[:, 0])
        normal /= np.linalg.norm(normal, axis=1, keepdims=True)
        for pose in range(-15, 16):
            theta = np.deg2rad(pose)
            c, s = np.cos(theta), np.sin(theta)
            Q = np.array([[c, -s, 0], [s, c, 0], [0, 0, 1.]]) @ Q0
            offsets = centers @ Q.T + location - jaw_centers
            H = np.zeros((12, 12))
            for k, offset in enumerate(offsets):
                H[6*k:6*k+6, 6*k:6*k+6] = np.block(
                    [[Q.T, -Q.T @ skew(offset)/L], [np.zeros((3, 3)), Q.T]])
            compliance = H @ Cj @ H.T
            compliance = (compliance+compliance.T)/2
            solve_coupled = np.linalg.inv(compliance) + St
            angles = range(31) if pose == 0 else (0, 15, 30)
            for oblique in angles:
                beta = np.deg2rad(oblique)
                load = Q.T @ (np.cos(beta)*axis + np.sin(beta)*tangent)
                np.testing.assert_allclose(np.linalg.norm(load), 1, atol=1e-12)
                max_outward = max(max_outward, float(np.max(normal @ load)))
                root_u = np.linalg.solve(solve_coupled, -force_to_reaction[i] @ load)
                fixed = Sforce @ load
                for label, stress in (('fixed', fixed), ('tied', fixed + Sroot @ root_u)):
                    tensile = np.maximum(np.linalg.eigvalsh(stress)[:, -1], 0)
                    runs[f'{margin}_pose{pose}_oblique{oblique}_{label}'] = q95(tensile, volume)/1e6
    assert max_outward < 0
    errors = []
    for case in archive['cases']:
        if case['support'] not in ('fixed', 'tied'):
            continue
        expected = next(r['tensile_Q95_MPa_per_N'] for r in case['regions'] if r['region'] == case['loaded_margin'])
        actual = runs[case['name']]
        errors.append(abs(actual-expected)/expected)
    assert len(errors) == 36 and max(errors) < 1e-8, (len(errors), max(errors))
    record = dict(status='passed', margin_tensile_Q95_MPa_per_N=runs,
                  evaluated_results=len(runs), both_margin_crosschecks=len(errors),
                  max_archived_relative_error=max(errors), maximum_outward_normal_dot=max_outward,
                  scope='Exact linear operator evaluation on each displayed degree; no interpolation of percentiles or new contact model.')
    (PAPER/'review/dense_edge_response.json').write_text(json.dumps(record, indent=2))
    print({key: val for key, val in record.items() if key != 'margin_tensile_Q95_MPa_per_N'})


if __name__ == '__main__':
    main()
