"""Fit the CT-guided display separation over the full visible section width."""
from pathlib import Path
import json

import numpy as np
from PIL import Image
from scipy.ndimage import binary_fill_holes, map_coordinates


PAPER = Path(__file__).resolve().parents[1]
PROJECT = PAPER.parents[2]
SPACING_MM = .018


def read_section_intensity(x, y):
    reference = PAPER.parent / "debunk_myth_full_reconstruction_2026-10-31/numerics/L0/solution.npz"
    with np.load(reference) as frame:
        center = frame["center_m"] * 1000
        basis = frame["basis"]
    cache = PROJECT / "output/ct_web_2026-11-19/cache"
    shape = (2886, 1903, 746)
    raw = np.memmap(cache / "native_specimen_crop.i16", "<i2", mode="r", shape=shape)
    mask = np.memmap(cache / "selected_native_mask.u8", "u1", mode="r", shape=shape)
    crop_origin_mm = np.array([7.056, 1.368, 1.368])
    image = np.empty((len(y), len(x)), np.int16)
    solid = np.empty(image.shape, bool)
    for start in range(0, len(y), 48):
        strip = slice(start, start + 48)
        world = center + x[None, :, None] * basis[:, 0] + y[strip, None, None] * basis[:, 1]
        coords = ((world - crop_origin_mm) / SPACING_MM)[..., ::-1].transpose(2, 0, 1)
        image[strip] = map_coordinates(raw, coords, order=0, prefilter=False, cval=-3292)
        solid[strip] = map_coordinates(mask, coords, order=0, prefilter=False, cval=0) > 0
    return image, solid


def main():
    numerics = PAPER / "numerics"
    source = numerics / "figure4_adaptive_CT_masks.npz"
    with np.load(source) as prior:
        x, y, guide, root_old, crown_old = [
            prior[k] for k in ("x_mm", "y_mm", "cervical_trace_mm", "root", "crown")
        ]
    image, solid = read_section_intensity(x, y)
    np.testing.assert_array_equal(solid, root_old | crown_old)
    columns = np.arange(len(x))
    guide_row = np.clip(np.rint((guide - y[0])/SPACING_MM).astype(int), 0, len(y)-1)
    visible = binary_fill_holes(solid)[guide_row, columns]
    # The measured guide can wander along local contrast peaks. Pool both
    # flanks and the centre to get one continuous display curve without
    # reflecting the specimen or modifying the upper root outline.
    coefficients = np.polyfit(x[visible], guide[visible], 2)
    trace = np.polyval(coefficients, x)
    upper_root = np.max(np.where(root_old, y[:, None], -np.inf), axis=0)
    notch = (x > -8) & (x < 1) & np.isfinite(upper_root)
    notch_coefficients = np.polyfit(x[notch], upper_root[notch], 2)
    assert float(coefficients[0]) < 0 < float(notch_coefficients[0])
    root = solid & (y[:, None] >= trace)
    crown = solid & ~root
    np.testing.assert_array_equal(root | crown, solid)
    assert not (root & crown).any()
    rgb = np.full((*solid.shape, 3), 255, np.uint8)
    tone = np.clip((image.astype(float)+3292)/(26623+3292), 0, 1)
    for selected, colour in [(root, [69, 138, 176]), (crown, [217, 158, 66])]:
        rgb[selected] = np.rint(np.array(colour) * (.66+.34*tone[selected, None])).astype(np.uint8)
    raster = PAPER / "figures/figure4_cervical_display.png"
    Image.fromarray(rgb).save(raster)
    np.savez_compressed(numerics / "figure4_cervical_display.npz", x_mm=x, y_mm=y,
                        cervical_trace_mm=trace, root=root, crown=crown)
    visible_trace = trace[visible]
    turning_point = -coefficients[1]/(2*coefficients[0])
    report = {
        "status": "verified",
        "source_mask": str(source.relative_to(PAPER)),
        "display_raster": str(raster.relative_to(PAPER)),
        "pitch_mm": SPACING_MM,
        "orientation": "Original registered longitudinal and transverse coordinates",
        "specimen_pixels_unchanged": int(solid.sum()),
        "method": "Quadratic least-squares fit to the archived CT guide at all visible transverse positions",
        "guide_columns": int(visible.sum()),
        "guide_x_range_mm": [float(x[visible][0]), float(x[visible][-1])],
        "trace_y_range_mm": [float(visible_trace.min()), float(visible_trace.max())],
        "quadratic_coefficients": coefficients.tolist(),
        "quadratic_coefficients_measured_outer_notch": notch_coefficients.tolist(),
        "outer_notch_fit_x_range_mm": [-8, 1],
        "fit_RMS_mm": float(np.sqrt(np.mean((visible_trace-guide[visible])**2))),
        "turning_point_x_mm": float(turning_point),
        "root_pixels": int(root.sum()),
        "crown_pixels": int(crown.sum()),
        "scope": "A display-only partition. The opposite sign is a property of this full-width fit, not an anatomical interface measurement or a change to the FE masks.",
    }
    (PAPER / "review/figure4_cervical_display.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
