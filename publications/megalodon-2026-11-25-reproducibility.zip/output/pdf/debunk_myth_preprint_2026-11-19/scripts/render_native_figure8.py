"""Stream every original native triangle for Figure 8; no surface reduction.
Native display vertices use nearest boundary-owner principal tensile values
from a separately identified coarse P1 solution, not a native-volume solve.
"""
from pathlib import Path
import numpy as np,json,subprocess,struct,hashlib
from scipy.spatial import cKDTree
from matplotlib.colors import ListedColormap,LogNorm
from PIL import Image
import meshio, trimesh
N=Path(__file__).resolve().parents[1];P=N.parents[2];O=N/'numerics/crown_root_100mm';F=N/'figures';R=P/'output/jaw_tooth_transfer_2026-11-22'
a=np.load(P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0/solution.npz');p,t,f,basis=a['points_m'],a['tets'],a['boundary_faces'],a['basis']
reg=np.load(R/'data_v3/registration.npz');state=np.load(R/'edge_data/RA_pose0_oblique30_tied.npz');sig=np.maximum(np.linalg.eigvalsh(state['stress_Pa'])[:,-1],0)/1e6
lookup={tuple(sorted(face)):j//4 for j,face in enumerate(t[:,[[1,2,3],[0,2,3],[0,1,3],[0,1,2]]].reshape(-1,3))};owner=np.array([lookup[tuple(sorted(face))]for face in f]);tree=cKDTree(p[f].mean(1)*1000)
J=meshio.read(P/'applied_forces/custom_solver/great_white_jaw_fullres_gmsh_alg1_tet_vol.msh');jv=J.points;jf=J.cells_dict['triangle'];assert len(jf)==1009016
jn=trimesh.Trimesh(jv,jf,process=False).vertex_normals
v=np.memmap(P/'output/current_native74_stress_2026-11-20/cache/vertices.f64',dtype='<f8',shape=(37951699,3),mode='r');nf=np.memmap(P/'output/current_native74_stress_2026-11-20/cache/triangles.u32',dtype='<u4',shape=(74293846,3),mode='r')
normal=np.memmap(P/'output/scale_acrylic_2026-11-20/data/normals.f32',dtype='<f4',shape=(37951699,3),mode='r')
nearfile=O/'native_boundary_owner_tension_MPa_per_N.f32';supportedfile=O/'native_boundary_owner_distance_mm.f32'
if not nearfile.exists():
 values=np.memmap(nearfile,mode='w+',dtype='<f4',shape=(len(v),));dist=np.memmap(supportedfile,mode='w+',dtype='<f4',shape=(len(v),))
 for start in range(0,len(v),300000):
  dd,ix=tree.query(v[start:start+300000],workers=2);values[start:start+len(ix)]=sig[owner[ix]];dist[start:start+len(ix)]=dd
 values.flush();dist.flush()
values=np.memmap(nearfile,mode='r',dtype='<f4',shape=(len(v),));dist=np.memmap(supportedfile,mode='r',dtype='<f4',shape=(len(v),))
mid=jv.mean(0);focus=reg['root_centres_jaw_m'].mean(0)*1000

def camera(location,target,up=(0,0,1)):
 forward=np.array(target)-location;forward/=np.linalg.norm(forward);right=np.cross(forward,up);right/=np.linalg.norm(right);vv=np.cross(right,forward);return np.stack([right,vv,forward],axis=1)
C0=camera(mid+np.array([700.,-750,900]),mid+[0,45,0]);C1=camera(focus+[70,-100,120],focus)
B=(v[::100]-a['center_m']*1000)@basis;mins=B.min(0);maxs=B.max(0)
# Orthographic panels, fixed coordinates and fixed same-case stress limits.
def project(x,k):
 if k in [0,1]:
  center=(mid+np.array([0,45,0])) if k==0 else focus;cam=C0 if k==0 else C1;scale=2.5 if k==0 else 26.;q=(x-center)@cam;return np.c_[900+q[:,0]*scale,800-q[:,1]*scale,q[:,2]]
 q=(x-a['center_m']*1000)@basis;return np.c_[900+q[:,0]*26,95+(q[:,1]-mins[1])*27.,-q[:,2]]
proc=subprocess.Popen([str(O/'native_figure8_raster'),str(O)],stdin=subprocess.PIPE,stderr=(O/'raster_counts.txt').open('w'))

def send(k,xyz,rgb,faces):
 rows=np.c_[project(xyz,k),rgb].astype('<f4');proc.stdin.write(struct.pack('<III',k,len(rows),len(faces)));proc.stdin.write(rows.tobytes());proc.stdin.write(np.asarray(faces,dtype='<u4').tobytes())
# Source jaw surface, not the stepped FE boundary.
for first in range(0,len(jf),300000):
 faces=jf[first:first+300000];ids,ix=np.unique(faces,return_inverse=True);q=jv[ids];rgb=np.tile([.75,.78,.8],(len(ids),1))
 for k in [0,1]:
  light=(C0 if k==0 else C1)@np.array([-.3,.4,-.86]);shade=.40+.60*np.maximum(jn[ids]@light,0);send(k,q,rgb*shade[:,None],ix.reshape(-1,3))
palette=ListedColormap(np.array(json.loads((N/'numerics/reference_palette_512.json').read_text())['RGBA_8bit'])/255);norm=LogNorm(1e-4,.1)
for first in range(0,len(nf),700000):
 faces=nf[first:first+700000];ids,ix=np.unique(faces,return_inverse=True);q=v[ids];ff=ix.reshape(-1,3);pose=(q*.001-reg['tooth_root_centre_m'])@reg['reference_rotation'].T*1000+reg['reference_location_m']*1000
 s=((q-a['center_m']*1000)@basis)[:,1];s=(s-mins[1])/(maxs[1]-mins[1]);rgb=np.tile([.85,.62,.20],(len(ids),1));rgb[s>=.76]=[.20,.43,.67];shade=.62+.38*np.abs(normal[ids]@basis[:,2]);rgb*=shade[:,None]
 for k in [0,1]:send(k,pose,rgb,ff)
 colors=palette(norm(np.maximum(values[ids],1e-12)))[:,:3];colors[dist[ids]>1.5]=[.65,.67,.69];send(2,q,colors,ff)
 if first%7000000==0:print('Streamed native faces',first+len(faces),flush=True)
proc.stdin.close();assert proc.wait()==0
for k in range(3):
 raw=O/f'native_figure8_{k}.rgba';im=Image.frombytes('RGBA',(1800,1600),raw.read_bytes());im.save(F/f'native_figure8_{k}.png');raw.unlink()
record=dict(status='passed',native_tooth_triangles_per_panel=74293846,native_boundary_vertices=37951699,source_jaw_triangles_in_a=1009016,FE_jaw_boundary_triangles=281280,tooth_FE_tetrahedra=len(t),stress_case='RA_pose0_oblique30_tied',display='Original 74M surface; nearest coarse-boundary-owner principal tension at native vertices; unlit; beyond 1.5 mm nearest-centroid distance is grey. Display interpolates these assigned colours only.',colour_limits_MPa_per_N=[1e-4,.1],split='Geometric s=0.76, not identified histology or physical separation.',socket='Source jaw shape displayed; fitting/transfer measured to the FE jaw boundary. No anatomical socket is identified.',counts=(O/'raster_counts.txt').read_text())
(N/'review/figure8_native_counts.json').write_text(json.dumps(record,indent=2));print(record,flush=True)
