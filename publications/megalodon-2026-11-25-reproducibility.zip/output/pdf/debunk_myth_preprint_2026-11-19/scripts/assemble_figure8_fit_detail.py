"""Assemble the native fit overview, measured response curves and scale views."""
import argparse
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap,LogNorm
from PIL import Image
import revise_figures as plot
N=Path(__file__).resolve().parents[1];P=N.parents[2];F=N/'figures';R=P/'output/jaw_tooth_transfer_2026-11-22'
plot.R=N;plot.F=F;plot.V=N/'svg';plot.REVIEW=N/'review'
dense=json.loads((N/'review/dense_edge_response.json').read_text())
assert dense['status']=='passed'
values=dense['margin_tensile_Q95_MPa_per_N']
geometry=json.loads((N/'review/figure8_native_counts.json').read_text())
assert geometry['status']=='passed' and 'overview_window_center_px' in geometry
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--transfer-only', action='store_true')
transfer_only=parser.parse_args().transfer_only
fig=plot.canvas(183,68 if transfer_only else 110)
# Shift the retained four-panel row upward; all measured c,d curves are unchanged.
axmm0,txt0,panel0=plot.axmm,plot.txt,plot.panel
y_offset=0 if transfer_only else 42
plot.axmm=lambda fig,x,y,w,h:axmm0(fig,x,y+y_offset,w,h)
plot.txt=lambda fig,x,y,*args,**kw:txt0(fig,x,y+y_offset,*args,**kw)
plot.panel=lambda fig,x,y,text,*args,**kw:txt0(fig,x,y+y_offset,text,8,weight='bold',va='top')
image_path=F/'native_figure8_contact_0.png'
detail_path=F/'native_figure8_contact_1.png'
stress=np.array(Image.open(F/'native_figure8_continued_2.png').convert('RGBA'))
continuation=json.loads((N/'review/figure8_contact_continuation.json').read_text())
assert continuation['scalar_display']['native_faces_per_raster']==74_293_846
assert all(continuation['contact_locator']['pixels_changed'].values())
palette=np.array(json.loads((N/'numerics/reference_palette_512.json').read_text())['RGBA_8bit'])/255;cmap=ListedColormap(palette);norm=LogNorm(1e-4,.1)
p=np.load(P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0/solution.npz');basis=p['basis'];q=(p['points_m']-p['center_m'])@basis*1000;span=np.ptp(q[:,1])
overview=plot.axmm(fig,.6,27.2,44.5,39.5)
plot.picture(overview,image_path)
detail=plot.axmm(fig,18.6,11.9,25,22)
plot.picture(detail,detail_path)
from matplotlib.patches import Rectangle,ConnectionPatch
u,v=geometry['overview_window_center_px'];w=geometry['overview_window_width_px'];h=geometry['overview_window_height_px']
xo,yo=(u-w/2)/1800,1-(v+h/2)/1600
ww,hh=w/1800,h/1600
from matplotlib import patheffects
navy,red='#102c53','#d62c32'
frame=[patheffects.Stroke(linewidth=1.8,foreground=navy),patheffects.Normal()]
overview.add_patch(Rectangle((xo,yo),ww,hh,transform=overview.transAxes,fill=False,edgecolor=red,linewidth=.7,path_effects=frame))
fig.add_artist(ConnectionPatch((xo+ww,yo),(0.02,.96),coordsA='axes fraction',coordsB='axes fraction',
                               axesA=overview,axesB=detail,lw=.72,color=navy,zorder=8))
detail.add_patch(Rectangle((0,0),1,1,transform=detail.transAxes,fill=False,edgecolor=red,linewidth=.65,path_effects=frame))
plot.panel(fig,1,67,'a')
plot.txt(fig,23,67,'Candidate tooth–jaw placement',6.1,ha='center',va='top')
plot.txt(fig,31.1,10.7,'Seat detail',5.1,ha='center',va='top')
plot.txt(fig,23,6.5,'Pink: candidate seating footprint',5.1,ha='center')
ax=plot.axmm(fig,51,15,31,47)
ax.imshow(stress,extent=[-900/26,900/26,(1600-95)/(27*span),-95/(27*span)],aspect='auto',interpolation='none')
ax.set_xlim(q[:,0].min()-1,q[:,0].max()+1);ax.set_ylim(1.03,-.03)
ax.set_xlabel('Transverse (mm)',fontsize=5.5,labelpad=1);ax.set_ylabel('Rootward position s',fontsize=5.5,labelpad=1);ax.tick_params(labelsize=5.2,pad=1)
cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap=cmap),cax=plot.axmm(fig,83,18,1.3,39),extend='both',extendfrac=.025);cb.set_ticks([1e-4,1e-3,1e-2,.1]);cb.ax.tick_params(labelsize=5,pad=1)
plot.panel(fig,48,67,'b');plot.txt(fig,68,67,'74M display: margin A, 30°',6.1,ha='center',va='top');plot.txt(fig,68,6,r'Tension ($\mathrm{MPa\,N^{-1}}$), display continuation',5.1,ha='center')

def value(margin, pose, oblique, support):
 return values[f'{margin}_pose{pose}_oblique{oblique}_{support}']

margin_colour={'RA':'#435aa6','RB':'#66ad36'}
ax=plot.axmm(fig,101,16,33,43)
degrees=np.arange(31)
for margin, color in margin_colour.items():
 for support, style, label in [('fixed','--','fixed'),('tied','-','coupled')]:
  y=[value(margin,0,angle,support)/value(margin,0,0,support) for angle in degrees]
  ax.plot(degrees,y,linestyle=style,marker='x',markevery=[0,15,30],color=color,
          lw=.83,ms=3.4,mew=.8,label=f'{margin[-1]} {label}')
ax.set(xlabel='Obliquity (°)',ylabel='Tension Q95 / axial value',xticks=[0,15,30])
ax.tick_params(labelsize=5.3,pad=1);ax.grid(alpha=.14,lw=.35);ax.legend(fontsize=4.7,frameon=False,loc='upper left',handlelength=1.3)
plot.panel(fig,94,67,'c');plot.txt(fig,118,67,'Within-margin direction effect',6.1,ha='center',va='top')

ax=plot.axmm(fig,148,16,33,43)
degrees=np.arange(-15,16)
for margin, color in margin_colour.items():
 for angle,style in [(0,'-'),(30,'--')]:
  y=[value(margin,pose,angle,'tied')/value(margin,pose,angle,'fixed') for pose in degrees]
  ax.plot(degrees,y,linestyle=style,marker='x',markevery=[0,15,30],color=color,
          lw=.83,ms=3.4,mew=.8,label=f'{margin[-1]} {angle}°')
verify=json.loads((R/'review/P2_edge_audit_001/results.json').read_text())
assert verify['status']=='passed'
p2=json.loads((R/'p2_edge_data_v2/results.json').read_text())['regional_percentiles']
p2_values={row['state']:row['P2_tensile_Q90_Q95_Q99_MPa_per_N'][1] for row in p2 if row['region']=='RA'}
ax.plot([0],[p2_values['coupled']/p2_values['fixed']],'+',color='#132b49',ms=4,mew=1,label='A 0° P2')
ax.set(xlabel='Installation angle (°)',ylabel='Coupled / fixed tension Q95',xticks=[-15,0,15])
ax.tick_params(labelsize=5.3,pad=1);ax.grid(alpha=.14,lw=.35);ax.legend(fontsize=4.7,frameon=False,loc='upper left',handlelength=1.3)
plot.panel(fig,140,67,'d');plot.txt(fig,164,67,'Attachment effect',6.1,ha='center',va='top')
plot.axmm,plot.txt,plot.panel=axmm0,txt0,panel0
if transfer_only:
 plot.save(fig,'boundary_edge_transfer_top')
 raise SystemExit
# The two supplied images are used once, without a new stress inference.
paths=[Path('/var/folders/q1/xn03yx0d3lb4vlk97t91k1380000gn/T/codex-clipboard-54c716d4-d804-4ddf-97ab-30a9f8522703.png'),Path('/var/folders/q1/xn03yx0d3lb4vlk97t91k1380000gn/T/codex-clipboard-82a1b7da-80fd-4891-9961-ae3fc35f3df1.png')]
meta=json.loads((P/'output/paper_native74_5cm_10cm_2026-11-22/review/mr5_100-render-audit.json').read_text());lo,hi=[meta['colourbar_Pa'][k]for k in ['min','max']]
for j,path in enumerate(paths):
 out=F/f'supplied_native_scale_{50 if j==0 else 100}mm.png'
 if not out.is_file():
  original=Image.open(path)
  box=(int(.035*original.width),int(.145*original.height),int(.955*original.width),int((.87 if j==0 else .785)*original.height))
  original.crop(box).save(out)
 im=Image.open(out)
 x=1+j*92;ax=plot.axmm(fig,x+1,13,87,31);ax.imshow(im,interpolation='none');ax.set_axis_off();plot.panel(fig,x,48,'ef'[j]);plot.txt(fig,x+46,47.7,'5 cm: supplied appearance'if j==0 else '10 cm: independent MR5',6.3,ha='center',va='top')
 norm=plt.Normalize(0,1)if j==0 else plt.Normalize(lo,hi);cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap='turbo'),cax=plot.axmm(fig,x+11,9,65,1.5),orientation='horizontal',extend='both',extendfrac=.025);cb.ax.tick_params(labelsize=5.2,pad=1)
 if j==0:cb.set_ticks([0,.5,1]);label='Reference colour coordinate; not stress'
 else:cb.set_ticks([lo,(lo+hi)/2,hi],labels=[f'{lo:.0f}',f'{(lo+hi)/2:.0f}',f'{hi:,.0f}']);label='Von Mises stress (Pa), linear'
 plot.txt(fig,x+44,2.7,label,5.6,ha='center')
plot.save(fig,'boundary_edge_transmission_contact')
print('Native Figure 8 assembled with registered seating footprint and the audited display continuation.')
