#!/usr/bin/env python3
"""Render the original Component 1 jaw constraints in a common 3-by-2 view.

Uses the original jaw-only archive, each solver's own savepoint, and the saved
view3 camera. No tooth component, inferred stress field, or new solve is used.
"""
from __future__ import annotations

import csv
import hashlib
import io
import json
import re
import shutil
import struct
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection, PolyCollection
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "applied_forces/shark_dynamics_export.mph"
OUT = ROOT / "DICOM_16um/exports/jaw_constraints"
REFERENCE = Path("/Users/eliguli712/Downloads/Image 25.02.26 at 02.03 (1).jpg")
ORDER = ["std1", "std_nh", "std_og", "std_mr2", "std_mr5", "std_pr"]
NAMES = ["Baseline", "Neo-Hookean", "Ogden", "Mooney–Rivlin 2", "Mooney–Rivlin 5", "Pressure study"]
COLORS = dict(context="#d9e1e9", fixed="#447ec1", trailing="#7751a6", load="#e68b32", body="#087a62", pressure="#c53d50", edge="#203c61")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def props(node):
    return {x.get("name").removeprefix("p:"): x.get("valueMatrix", x.get("value", "")) for x in node.findall("propertyValue")}


def strings(value):
    return re.findall(r"'([^']*)'", value)


def read_matrix(data, pos, dtype):
    dim, = struct.unpack_from("<i", data, pos)
    pos += 4
    assert 0 < dim <= 4
    rows = []
    for _ in range(dim):
        n, = struct.unpack_from("<i", data, pos)
        pos += 4
        assert 0 < n < 1_000_000
        rows.append(np.frombuffer(data, dtype, n, pos).copy())
        pos += n * np.dtype(dtype).itemsize
    assert len({len(x) for x in rows}) == 1
    return np.array(rows).T, pos


def decode_mesh(data, node):
    assert struct.unpack_from("<i", data, 76)[0] == 9
    a, offsets = {}, {}
    for kind in ["vtx", "edg", "tri", "tet"]:
        token = struct.pack("<i", len(kind)) + kind.encode("utf-32le")
        hits = [m.start() for m in re.finditer(re.escape(token), data)]
        assert len(hits) == 1
        offsets[kind] = hits[0]
        a[kind], end = read_matrix(data, hits[0] + len(token), "<i4")
        corners, parameter_count = struct.unpack_from("<2i", data, end)
        assert corners == a[kind].shape[1]
        end += 8
        if parameter_count:
            parameters, end = read_matrix(data, end, "<f8")
            assert len(parameters) == parameter_count
        count, rowcount = struct.unpack_from("<2i", data, end)
        assert count == rowcount == len(a[kind])
        a[kind + "_entity"] = np.frombuffer(data, "<i4", count, end + 8).copy()
    nvertex = max(int(a[k].max()) for k in ["tet", "tri", "edg", "vtx"]) + 1
    token = struct.pack("<3i", nvertex, 3, nvertex)
    first_element = min(offsets.values())
    matches = [m.start() for m in re.finditer(re.escape(token), data[:first_element])]
    assert len(matches) == 1
    a["points"], end = read_matrix(data, matches[0] + 4, "<f8")
    assert end + 4 == first_element and struct.unpack_from("<i", data, end)[0] == 4
    assert a["points"].shape == (nvertex, 3) and np.isfinite(a["points"]).all()
    native = node.find("MeshNative")
    counts = list(map(int, native.findtext("numEntities").split(",")))
    box = np.array(list(map(float, native.findtext("boundingBox").split(",")))).reshape(3, 2)
    np.testing.assert_allclose(np.array([a["points"].min(0), a["points"].max(0)]).T, box, atol=1e-9)
    for typ, count in [("vtx", counts[0]), ("edg", counts[1]), ("tri", counts[2])]:
        assert (a[typ + "_entity"].min(), a[typ + "_entity"].max()) == (0, count - 1)
        a[typ + "_entity"] += 1
    for kind in ["tet", "tri", "edg", "vtx"]:
        assert a[kind].min() >= 0 and a[kind].max() < nvertex
    t = a["tet"]
    tetra_faces = np.concatenate([t[:, q] for q in [[0, 1, 2], [0, 1, 3], [0, 2, 3], [1, 2, 3]]])
    unique, multiplicity = np.unique(np.sort(tetra_faces, axis=1), axis=0, return_counts=True)
    assert multiplicity.max() <= 2
    listed = set(map(tuple, np.sort(a["tri"], axis=1)))
    exterior = set(map(tuple, unique[multiplicity == 1]))
    assert exterior <= listed
    unbacked_faces = listed - set(map(tuple, unique))
    volume = np.linalg.det(a["points"][t[:, 1:]] - a["points"][t[:, :1]]) / 6
    assert np.all(np.abs(volume) > 1e-14)
    return a, dict(vertices=nvertex, triangles=len(a["tri"]), tetrahedra=len(t), geometric_entities=counts,
                   coordinate_bounds_match=True, triangle_connectivity_valid=True,
                   surface_triangles_without_volume_adjacency=len(unbacked_faces),
                   complete_tet_exterior_present=True, nondegenerate_tetrahedra=True, bounding_box=box.tolist())


def decode_ids(raw):
    if not raw:
        return []
    encoded = list(map(int, raw.split(",")))
    if encoded[0] < 0:
        assert encoded[1] == -1
        ids = encoded[2:]
    else:
        ids = encoded[1:]
    assert len(set(ids)) == len(ids) and all(i > 0 for i in ids)
    return ids


def extraction():
    source_data = SOURCE.read_bytes()
    cases, meshes = [], {}
    with zipfile.ZipFile(io.BytesIO(source_data)) as archive:
        current = ET.fromstring(archive.read("dmodel.xml"))
        resource_map = {x.get("id"): x.get("resource") for x in current.iter() if x.get("class") == "MESH" and x.get("resource")}
        solvers = {s.findtext("study").split("/")[-1]: (s.get("tag"), s.findtext("savePoint").split("/")[-1]) for s in current.findall("./SolverSequenceList/SolverSequence")}
        camera_node = next(v for v in current.findall("./ViewList/View") if v.get("tag") == "view3")
        cp = {x.get("name").removeprefix("p:"): x.get("valueMatrix", x.get("value", "")) for x in camera_node.iter("propertyValue")}
        camera = {name: list(map(float, strings(cp[name]))) for name in ["position", "target", "up", "rotationpoint", "viewoffset"]}
        camera["zoomanglefull"] = float(cp["zoomanglefull"])
        for tag, title in zip(ORDER, NAMES):
            solver, savepoint = solvers[tag]
            with zipfile.ZipFile(io.BytesIO(archive.read(savepoint + "/model.zip"))) as snapshot:
                raw = snapshot.read("dmodel.xml")
                root = ET.fromstring(raw)
            st = next(x for x in root.findall("./StudyList/Study") if x.get("tag") == tag)
            settings = props(st.find("./StudyFeatureList/StudyFeature"))
            activate = strings(settings["activate"])
            assert dict(zip(activate[::2], activate[1::2]))["solid"] == "on"
            binding = strings(settings["mesh"])
            mesh_tag = dict(zip(binding[::2], binding[1::2]))["geom1"]
            node = next(x for x in root.findall("./MeshList/MeshSequence") if x.get("tag") == mesh_tag)
            reference = node.find("./MeshNative/mesh")
            resource = reference.get("resource") or resource_map[reference.get("id")]
            binary = archive.read(resource)
            mesh_key = sha(binary)
            if mesh_key not in meshes:
                arrays, checks = decode_mesh(binary, node)
                meshes[mesh_key] = dict(arrays=arrays, checks=checks, resource=resource)
            arrays = meshes[mesh_key]["arrays"]
            selections = {}
            for x in root.findall("./SelectionList/SelectionFeature"):
                if x.get("tag") not in ["sel_snout_dom", "sel_front_stress", "sel_trailing_edge"]:
                    continue
                exp = x.find("./outputSelection/explicit")
                selections[x.get("tag")] = dict(tag=x.get("tag"), dimension=int(exp.get("dim")),
                    ids=decode_ids(exp.get("entities", "")), raw_encoding=exp.get("entities"), properties=props(x))
            physics = next(x for x in root.findall("./PhysicsList/Physics") if x.get("tag") == "solid")
            features = []
            for f in physics.findall("./PhysicsFeatureList/PhysicsFeature"):
                if f.get("op") not in ["Fixed", "BoundaryLoad", "BodyLoad", "LinearElasticModel", "HyperelasticModel", "RigidMotionSuppression"]:
                    continue
                sel = f.find("selection")
                named = sel.findtext("named")
                if named:
                    selection = selections[named.split("/")[-1]]
                else:
                    exp = sel.find("explicit")
                    if sel.get("flags") in ["16", "17"] and exp.get("entities") is None:
                        selection = dict(all=True, dimension=int(exp.get("dim")))
                    else:
                        selection = dict(ids=decode_ids(exp.get("entities", "")), dimension=int(exp.get("dim")), raw_encoding=exp.get("entities", ""))
                features.append(dict(tag=f.get("tag"), type=f.get("op"), active="DISABLED" not in f.findtext("entityFlags", ""),
                    selection=selection, parameters={p.get("param"): strings(p.get("value", "")) for p in f.findall("param")}))
            global_params = {x.get("name"): x.get("expr") for x in root.findall("./ModelParam/expressions")}
            cases.append(dict(tag=tag, title=title, original_label=st.get("name"), solver=solver, savepoint=savepoint,
                              snapshot_sha256=sha(raw), component="comp1", physics="solid", mesh=mesh_tag,
                              mesh_sha256=mesh_key, mesh_resource=resource, features=features, named_selections=selections,
                              global_parameters=global_params, geometric_nonlinearity=settings.get("geometricNonlinearity")))
    manifest = dict(source=str(SOURCE.relative_to(ROOT)), source_sha256=sha(source_data), camera=camera,
                    reference_image=str(REFERENCE), layout="3 columns by 2 rows", cases=cases,
                    mesh_checks={key: value["checks"] for key, value in meshes.items()},
                    quantity="Saved supports and load selections, not von Mises values",
                    extraction="Offline archive extraction; no mesh rebuild, solve, or source MPH change")
    return meshes, manifest


def feature(case, tag):
    return next((f for f in case["features"] if f["tag"] == tag), None)


def selected(f, array_ids):
    if not f or not f["active"]:
        return np.zeros(len(array_ids), bool)
    return np.ones(len(array_ids), bool) if f["selection"].get("all") else np.isin(array_ids, f["selection"]["ids"])


def projection(points, camera):
    pos, target, up = (np.asarray(camera[k], float) for k in ["position", "target", "up"])
    forward = target - pos
    forward /= np.linalg.norm(forward)
    right = np.cross(forward, up)
    right /= np.linalg.norm(right)
    vertical = np.cross(right, forward)
    delta = points - pos
    depth = delta @ forward
    assert np.all(depth > 0)
    return np.column_stack([delta @ right / depth, delta @ vertical / depth]), depth


def panel(ax, arrays, case, camera, bounds, mode="combined"):
    p, tri = arrays["points"], arrays["tri"]
    screen, depth = projection(p, camera)
    fixed = selected(feature(case, "fix1"), arrays["tri_entity"])
    trailing = selected(feature(case, "fix_tail"), arrays["tri_entity"])
    loaded = selected(feature(case, "frontld"), arrays["tri_entity"])
    rgba = np.tile(matplotlib.colors.to_rgba(COLORS["context"]), (len(tri), 1))
    rgba[fixed] = matplotlib.colors.to_rgba(COLORS["fixed"])
    rgba[trailing] = matplotlib.colors.to_rgba(COLORS["trailing"])
    if mode == "combined":
        rgba[loaded] = matplotlib.colors.to_rgba(COLORS["load"])
    # Flat geometric lighting gives the same jaw surfaces readable relief.
    xyz = p[tri]
    normal = np.cross(xyz[:, 1]-xyz[:, 0], xyz[:, 2]-xyz[:, 0])
    normal /= np.linalg.norm(normal, axis=1)[:, None]
    light = np.array([-.25, .65, 1.0]); light /= np.linalg.norm(light)
    shade = .68 + .32*np.abs(normal @ light)
    rgba[:, :3] *= shade[:, None]
    order = np.argsort(depth[tri].mean(1))[::-1]
    ax.add_collection(PolyCollection(screen[tri][order], facecolors=rgba[order], edgecolors=(.1, .2, .3, .08), linewidth=.15))
    edgemask = selected(feature(case, "fixe_all"), arrays["edg_entity"])
    if edgemask.any():
        ax.add_collection(LineCollection(screen[arrays["edg"][edgemask]], colors=COLORS["edge"], linewidths=.48, alpha=.6))
    if mode == "combined":
        # Domain body loads stay in their exact saved selected domains.
        for f in [x for x in case["features"] if x["type"] == "BodyLoad" and x["active"]]:
            ids = np.flatnonzero(selected(f, arrays["tet_entity"]))
            if len(ids):
                choice = ids[np.linspace(0, len(ids)-1, min(5, len(ids)), dtype=int)]
                origin = p[arrays["tet"][choice]].mean(1)
                end = origin + [0, 0, .9]
                a, _ = projection(origin, camera); b, _ = projection(end, camera)
                ax.quiver(a[:, 0], a[:, 1], b[:, 0]-a[:, 0], b[:, 1]-a[:, 1], angles="xy", scale_units="xy", scale=1,
                          color=COLORS["body"], width=.006, zorder=6, headwidth=3.5)
        if loaded.any():
            ids = np.flatnonzero(loaded)
            centers = p[tri[ids]].mean(1)
            # A few surface arrows, on distinct x bands, communicate +z traction.
            choices = np.argsort(centers[:, 0])[np.linspace(0, len(ids)-1, 4, dtype=int)]
            origins = centers[choices]
            a, _ = projection(origins, camera); b, _ = projection(origins+[0, 0, 1.0], camera)
            ax.quiver(a[:, 0], a[:, 1], b[:, 0]-a[:, 0], b[:, 1]-a[:, 1], angles="xy", scale_units="xy", scale=1,
                      color="#a94e12", width=.006, zorder=7, headwidth=3.5)
    ax.set_xlim(bounds[0]); ax.set_ylim(bounds[1]); ax.set_aspect("equal"); ax.set_axis_off()
    # Coordinate triad is projected with the identical camera basis in all panels.
    base = np.array([4.8, 2.6, 18.])
    origin, _ = projection(base[None], camera)
    deltas = []
    for k in range(3):
        end = base.copy(); end[k] += .7
        q, _ = projection(end[None], camera); deltas.append(q[0]-origin[0])
    at = np.array([bounds[0][0]+.07*np.ptp(bounds[0]), bounds[1][0]+.10*np.ptp(bounds[1])])
    for label, delta, color in zip("xyz", deltas, ["#b13e65", "#4b9153", "#4a779a"]):
        delta *= .32
        ax.annotate("", xy=at+delta, xytext=at, arrowprops=dict(arrowstyle="->", color=color, lw=1.1))
        ax.text(*(at+delta*1.15), label, color=color, fontsize=8)
    return dict(fixed_surface_triangles=int(fixed.sum()), trailing_surface_triangles=int(trailing.sum()),
                front_traction_triangles=int(loaded.sum()), fixed_geometric_edge_segments=int(edgemask.sum()))


def render(meshes, manifest):
    camera = manifest["camera"]
    xy = np.concatenate([projection(m["arrays"]["points"], camera)[0] for m in meshes.values()])
    low, high = xy.min(0), xy.max(0)
    pad = (high-low)*.09
    bounds = [[float(low[k]-pad[k]), float(high[k]+pad[k])] for k in range(2)]
    manifest["common_projected_bounds"] = bounds
    fig, axes = plt.subplots(2, 3, figsize=(16, 10), facecolor="#f7faff")
    for i, (ax, case) in enumerate(zip(axes.flat, manifest["cases"])):
        arrays = meshes[case["mesh_sha256"]]["arrays"]
        checks = panel(ax, arrays, case, camera, bounds)
        case.update(checks)
        ax.set_title(f"{'ABCDEF'[i]}  {case['title']}\n{case['tag']}", fontsize=13, color="#18334f", pad=6)
        fixed = feature(case, "fix1")
        suffix = "Faces + edges fixed" if fixed and fixed["active"] else "Geometric edges + trailing faces fixed"
        ax.text(.5, -.035, suffix, transform=ax.transAxes, ha="center", fontsize=9, color="#38516a")
        ax.text(.5, -.08, f"{case['savepoint']} · {len(arrays['tri']):,} surface triangles", transform=ax.transAxes, ha="center", fontsize=8, color="#657789")
        pf, pa = plt.subplots(figsize=(6, 4.9), facecolor="#f7faff")
        panel(pa, arrays, case, camera, bounds)
        pa.set_title(f"{case['title']} · {case['tag']}", color="#18334f", fontsize=14)
        pf.subplots_adjust(left=.015, right=.985, top=.91, bottom=.015)
        pf.savefig(OUT / (case["tag"] + "_jaw_constraints.png"), dpi=220, facecolor=pf.get_facecolor())
        plt.close(pf)
    fig.suptitle("Jaw mechanics — saved constraints", x=.04, ha="left", y=.98, fontsize=23, color="#18334f", weight="bold")
    fig.text(.04, .925, "Original jaw model · one shared oblique camera · 3 columns × 2 rows", fontsize=12, color="#536b82")
    handles = [Patch(color=COLORS["fixed"], label="Fixed boundary faces"), Line2D([0], [0], color=COLORS["edge"], lw=2, label="Fixed geometric edges"),
               Patch(color=COLORS["trailing"], label="Trailing fixed selection"), Patch(color=COLORS["load"], label="Front traction selection"),
               Line2D([0], [0], color=COLORS["body"], marker=">", lw=1.5, label="Body-force direction (+z)")]
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(.5, .055), ncol=3, frameon=False, fontsize=10)
    fig.text(.04, .023, "Blue/purple constraints impose u = v = w = 0. Colors identify saved selections; they are not a stress scale.", fontsize=10, color="#536b82")
    fig.subplots_adjust(left=.035, right=.98, top=.84, bottom=.16, hspace=.35, wspace=.08)
    fig.savefig(OUT / "jaw_constraints_six_studies.png", dpi=220, facecolor=fig.get_facecolor())
    fig.savefig(OUT / "jaw_constraints_six_studies.svg", facecolor=fig.get_facecolor())
    plt.close(fig)


def write_pages(manifest):
    cards = []
    for case in manifest["cases"]:
        cards.append(f'''<figure class="jaw-panel"><h2>{case['title']}</h2><a href="{case['tag']}_jaw_constraints.png"><img src="{case['tag']}_jaw_constraints.png" alt="{case['title']} jaw constraint map in the common reference orientation"></a><figcaption><code>{case['tag']}</code> · {case['savepoint']}</figcaption></figure>''')
    legend = ''.join(f'<span><i style="background:{COLORS[key]}"></i>{label}</span>' for key, label in [
        ("fixed", "Fixed faces"), ("edge", "Fixed geometric edges"), ("trailing", "Trailing fixed selection"),
        ("load", "Front traction selection"), ("body", "+z body-force direction"), ("context", "Other surface")])
    rows = []
    for case in manifest["cases"]:
        pressure = feature(case, "bndl_pr")
        enabled = [f["tag"] for f in case["features"] if f["active"] and f["type"] in ["Fixed", "BodyLoad", "BoundaryLoad"]]
        rows.append(f"<tr><td>{case['tag']}</td><td>{case['savepoint']}</td><td>{case['fixed_surface_triangles']:,}</td><td>{case['trailing_surface_triangles']:,}</td><td>{case['front_traction_triangles']:,}</td><td>{', '.join(enabled)}</td><td>{'On' if pressure and pressure['active'] else 'Off'}</td></tr>")
    reference = ''
    if REFERENCE.exists():
        shutil.copyfile(REFERENCE, OUT / 'jaw_orientation_reference.jpg')
        manifest['reference_image_sha256'] = sha(REFERENCE.read_bytes())
        reference = '<details><summary>Orientation reference</summary><img class="reference" src="jaw_orientation_reference.jpg" alt="User supplied COMSOL jaw reference showing the requested oblique orientation"><p>The reference carries a von Mises scale. The six panels above use categorical constraint colors.</p></details>'
    style = '''*{box-sizing:border-box}body{margin:0;background:#f4f8fc;color:#18334f;font:16px/1.5 system-ui,sans-serif}main{max-width:1600px;margin:auto;padding:28px 24px}h1{font-size:clamp(25px,3vw,40px);margin:0 0 8px}header p{margin:8px 0;color:#536b82}.links{display:flex;flex-wrap:wrap;gap:12px;margin:18px 0}.links a{padding:8px 12px;background:white;border:1px solid #cedae5;border-radius:6px;color:#275f92;text-decoration:none}.legend{display:flex;gap:12px 24px;flex-wrap:wrap;margin:18px 0}.legend span{display:flex;align-items:center;gap:7px;font-size:14px}.legend i{display:inline-block;width:23px;height:11px}.jaw-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}.jaw-panel{margin:0;border:1px solid #d6e1eb;background:#f7faff;border-radius:9px;overflow:hidden}.jaw-panel h2{font-size:17px;text-align:center;margin:15px 8px 0}.jaw-panel img{display:block;width:100%;height:auto}.jaw-panel figcaption{text-align:center;padding:0 8px 14px;color:#536b82;font-size:14px}details{background:white;border:1px solid #d6e1eb;border-radius:9px;margin-top:20px;padding:16px}summary{cursor:pointer;font-weight:600}.reference{display:block;max-width:650px;width:100%;height:auto;margin:15px auto}.scroll{overflow-x:auto}table{border-collapse:collapse;font-size:13px;width:100%;min-width:950px}td,th{text-align:left;border-bottom:1px solid #d6e1eb;padding:10px}code{font-size:.9em}a{color:#275f92}.note{font-size:14px;color:#536b82;margin-top:16px}footer{margin-top:22px;color:#536b82;font-size:13px}@media(max-width:650px){main{padding:18px 10px}.jaw-grid{min-width:850px}.grid-wrap{overflow-x:auto}.links{gap:6px}.links a{font-size:13px}.legend{gap:8px 12px}}'''
    page = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Jaw constraints · 3 × 2 reference view</title><style>{style}</style></head><body><main>
<header><h1>Jaw mechanics — constraints</h1><p>Six original jaw studies · 3 columns × 2 rows · the same oblique orientation in every panel.</p></header>
<nav class="links"><a href="jaw_constraints_six_studies.png">Download the 3 × 2 PNG</a><a href="jaw_constraints_six_studies.svg">SVG figure</a><a href="constraints_manifest.json">Saved settings and camera</a><a href="study_constraints.csv">Study comparison CSV</a><a href="../jaw_structural_dynamics.html">Jaw structural dynamics page</a></nav>
<div class="legend">{legend}</div><div class="grid-wrap"><section class="jaw-grid" aria-label="Six jaw constraint panels">{''.join(cards)}</section></div>
<p class="note">Blue and purple selections impose <code>u = v = w = 0</code>; dark lines mark fixed geometric edges. Orange identifies front traction, including where it overlaps a support. Arrows show load direction. Click a panel for its full-size image.</p>
{reference}<details><summary>Saved study settings and source</summary><p>Source: <code>{manifest['source']}</code>, original Component 1 jaw geometry. Each panel uses its own solver savepoint and its saved <code>mesh1</code>, projected with the same saved <code>view3</code> camera. The floating surface pieces are preserved as in the source.</p><div class="scroll"><table><thead><tr><th>Study</th><th>Savepoint</th><th>All-face fixed feature: triangles</th><th>Trailing fixed: triangles</th><th>Front traction: triangles</th><th>Enabled support/load features</th><th>Saved pressure feature</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div><p>The pressure-study name is retained; its follower-pressure feature is disabled in this saved archive. The maps show the saved flags. The manifest records material nodes, load expressions, selections, mesh hashes, and camera parameters.</p></details>
<footer>Rendered from the saved jaw mesh without a new solve. Source MPH files are unchanged. All panels share camera orientation, projection, framing, and scale.</footer></main></body></html>'''
    (OUT / 'index.html').write_text(page)
    target = OUT.parent / 'jaw_structural_dynamics.html'
    # Keep the established URL and present the requested 3-by-2 jaw grid directly.
    root_page = page.replace('href="jaw_constraints_', 'href="jaw_constraints/jaw_constraints_')
    root_page = root_page.replace('href="constraints_manifest.json"', 'href="jaw_constraints/constraints_manifest.json"')
    root_page = root_page.replace('href="study_constraints.csv"', 'href="jaw_constraints/study_constraints.csv"')
    root_page = root_page.replace('href="../jaw_structural_dynamics.html"', 'href="jaw_constraints/index.html"').replace('Jaw structural dynamics page</a>', 'Standalone constraint viewer</a>')
    for case in manifest['cases']:
        root_page = root_page.replace(f'"{case["tag"]}_jaw_constraints.png"', f'"jaw_constraints/{case["tag"]}_jaw_constraints.png"')
    root_page = root_page.replace('src="jaw_orientation_reference.jpg"', 'src="jaw_constraints/jaw_orientation_reference.jpg"')
    root_page = root_page.replace('<title>Jaw constraints · 3 × 2 reference view</title>', '<title>Jaw Structural Dynamics — 3 × 2 Constraints</title>')
    target.write_text(root_page)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    meshes, manifest = extraction()
    render(meshes, manifest)
    write_pages(manifest)
    (OUT / "constraints_manifest.json").write_text(json.dumps(manifest, indent=2)+"\n")
    for key, mesh in meshes.items():
        np.savez_compressed(OUT / ("jaw_mesh_"+key[:12]+".npz"), **mesh["arrays"])
    with (OUT / 'study_constraints.csv').open('w', newline='') as f:
        keys = ['study', 'savepoint', 'fixed_surface_triangles', 'trailing_surface_triangles', 'front_traction_triangles', 'fixed_geometric_edge_segments']
        writer = csv.DictWriter(f, fieldnames=keys);writer.writeheader()
        for c in manifest['cases']:
            writer.writerow(dict(study=c['tag'],savepoint=c['savepoint'],**{k:c[k] for k in keys[2:]}))
    print(json.dumps({"source": manifest["source"], "meshes": manifest["mesh_checks"], "camera": manifest["camera"]}, indent=2))


if __name__ == "__main__":
    main()
