#!/usr/bin/env python3
"""Revise the existing open manuscript without replacing it."""
from pathlib import Path
import re,json
N=Path(__file__).resolve().parents[1]
path=N/'DebunkMeg_complete_2026-11-19.tex'
source=path.read_text()
assert r'\label{tab:p1p2}' not in source,'Already applied'
blocks=list(re.finditer(r'\\begin\{(equation\*?|align\*?)\}(.*?)\\end\{\1\}',source,re.S))
assert len(blocks)==20
supplement='% Definitions retained from the preceding complete manuscript.\n% Technical reference source, not a replacement main manuscript.\n'
for i,m in enumerate(blocks):supplement+=f'\n\\subsection*{{Definition {i+1}}}\n'+m[0]+'\n'
proposition=re.search(r'\\begin\{proposition\}.*?\\end\{proof\}',source,re.S)
if proposition:supplement+='\n'+proposition[0]+'\n'
(N/'Supplementary_mathematical_methods.tex').write_text(supplement)
replacements={
0:r'The nonlinear extension adds a smooth displacement field to the affine map. Fitting minimises weighted landmark mismatch together with a penalty on second spatial derivatives, so unresolved fine structure is not fitted freely.',
1:r'Each voxel centre is located by adding its index times the recorded spacing to the scanner origin, using the recorded direction matrix.',
2:r'For each direction, the native plane index increases linearly from the first plane to the maximum-area plane at its designated anchor frame, then linearly to the last plane.',
3:r'The coordinate correction leaves stored $x,y$ unchanged and multiplies stored $z$ by $18/16$.',
4:r'Gaussian curvature is angular deficit divided by mixed Voronoi area. Mean-curvature magnitude is half the norm of the cotangent curvature-normal vector; its signed value uses the outward normal. Full operators and boundary conventions accompany the source.',
5:r'Mean squared error separates exactly into squared mean bias, squared standard-deviation mismatch, and a correlation-dependent residual term.',
6:r'If mean squared discrepancy tends to zero uniformly over grid phases, the area fraction exceeding any fixed positive error threshold also tends to zero.',
7:r'Fluid velocity must equal wall velocity and opposing interface tractions must balance. Newtonian fluid stress combines pressure and the symmetric velocity gradient weighted by viscosity.',
9:r'The corresponding Young modulus is 71.373913~GPa, Poisson ratio 0.252173913 and bulk modulus 48.0~GPa.',
10:r'The finite-element weak balance equates internal elastic virtual work to the virtual work of the specified face traction for every admissible displacement test field.',
12:r'StVK energy is quadratic in Green--Lagrange strain, with separate volumetric and shear contributions. The comparison neo-Hookean form is linear in the first isochoric invariant; Ogden uses isochoric principal stretches raised to its exponent. MR2 is linear in the first two invariant offsets; MR5 adds their two squares and cross-product. The non-StVK forms use a common quadratic volume-change penalty. Exact energy conventions accompany the mathematical source.',
13:r'Reference traction is obtained from current pressure using the volume Jacobian and inverse-transpose deformation gradient applied to the reference normal.',
15:r'For P1, stresses are sorted and physical element volumes accumulated; the percentile is the first stress at which cumulative regional volume reaches the requested fraction.',
16:r'From highest to lowest regional $Q_{0.95}$, the order is root-side band, crown--root transition band, side A, side B, central crown and macroscopic apex.',
17:r'The volume percentile is bounded by the regional stress $L^2$ norm divided by the square root of the product of region volume and the upper-tail fraction.',
18:r'Pressure would be fitted by projecting the observed force onto the unit-pressure resultant and dividing by its squared magnitude; subtracting the fitted force gives the directional residual.',
}
for i in sorted(replacements,reverse=True):
 m=blocks[i];source=source[:m.start()]+replacements[i]+source[m.end():]
def replace(old,new):
 global source
 assert old in source,old[:110]
 source=source.replace(old,new,1)
replace(r'A linear correspondence model between two measured states is $\phi_t(x)=A_tx+b_t$, with invertible $A_t$ fitted to homologous landmarks. A nonlinear extension is',
 r'Between genuinely measured states, an invertible affine map is fitted to homologous landmarks; a smooth non-affine displacement can represent additional shape change.')
start=source.index(r'Minimising $\mathcal J$');end=source.index('\n\n',start)
source=source[:start]+r'The fitted map must preserve orientation and remain globally one-to-one. A sufficient condition is a relative non-affine Lipschitz constant below one on a convex domain. Positive local Jacobians alone do not guarantee global injectivity. Verified boundary coverage and anatomical correspondence remain necessary.'+source[end:]
replace('DICOM patient coordinates are evaluated at voxel centres:','DICOM patient coordinates are evaluated at voxel centres.')
replace(r'with $\mathbf{o}=(4.176,0.198,16.818)$~mm, $D=I$ for the recorded orientation and $h_x=h_y=h_z=0.018$~mm.',
 r'The origin is $(4.176,0.198,16.818)$~mm, the direction matrix is the identity and spacing is 0.018~mm on each axis.')
replace(r'native position $i_j(f)$ is piecewise linear through $(0,0),(c_j,m_j),(3049,n_j-1)$:',r'the native plane index follows two linear intervals:')
replace('The closed-solid mechanical proxy is mapped from its stored image-index coordinates to the native sampling frame by',
 'The closed-solid mechanical proxy is mapped from its stored image-index coordinates to the native sampling frame.')
replace(r'For an interior surface vertex $i$, the area-normalised discrete Gaussian curvature and cotangent mean-curvature vector are \citep{Meyer2003}',
 r'Interior-vertex curvature uses the area-normalised discrete operators of Meyer and colleagues \citep{Meyer2003}.')
replace(r'For $X=c_*(x)$ and $Y=c_h(\pi_hx)$, the reported correlation is accompanied by the exact identity',
 'Mean bias and amplitude mismatch are evaluated alongside correlation.')
replace(r'with population moments under $\mu$ (and empirical moments with divisor $N$).',
 r'The identity uses population moments under the common surface-area measure and empirical moments with divisor $N$.')
start=source.index('Distribution-free rank bands use');end=source.index('\n\n',start)
source=source[:start]+r"Distribution-free percentile bands use the DKW inequality \citep{Massart1990}, with familywise error 0.05 across 51 marginal fields. Bounded squared errors give simultaneous finite-field MSE intervals by Hoeffding's inequality \citep{Hoeffding1963}; declared field suprema determine the bounds. At 54~$\mu$m, phase zero, these are $[87.728,227.437]$~mm$^{-2}$ for $H$ and $[0,1.89685\times10^6]$~mm$^{-4}$ for $K$. Full expressions and sample-size constants accompany the source. They bound sampling uncertainty, not continuum error."+source[end:]
replace(r'A precise sufficient implication, uniform over grid phases $r$, is','The relevant implication is stated in engineering terms:')
replace(r'Indeed, each exceptional measure is at most its MSE divided by $\varepsilon^2$, by Markov\textquotesingle s inequality; taking the supremum proves the implication.',
 "Markov's inequality establishes this implication by bounding the exceptional area fraction using MSE and the chosen tolerance.")
replace(r'Here $n_s=-n_f$ are the outward normals of the two domains.','The outward interface normals oppose one another.')
replace(r'The displacement is $\mathbf u$, the linear strain $\boldsymbol\varepsilon(\mathbf u)=(\nabla\mathbf u+\nabla\mathbf u^T)/2$, and',
 r'Displacement is $\mathbf u$ and small strain is the symmetric displacement gradient. The isotropic stress law is')
replace('They imply\n','')
replace('The discrete weak problem is','The support constraints define the admissible displacement space.')
replace(r'Equation~\eqref{eq:weak} is a small-strain pressure experiment','The specified baseline is a small-strain pressure experiment')
replace('Representative forms are','The adopted energy conventions are described here.')
replace(r'Nanson\textquotesingle s formula gives',"Nanson's transformation gives the reference-area conversion.")
replace('For constant P1 element stress this is implemented exactly as a weighted empirical CDF:','The constant-P1 implementation uses an inverse volume-weighted distribution.')
replace('The baseline regional ordering is','The baseline ordering is attachment-specific.')
source=re.sub(r'\\begin\{proposition\}.*?\\end\{proof\}',r'A bounded regional mean squared stress controls a volume percentile by Markov''s inequality; the explicit inequality and proof accompany the mathematical source.',source,flags=re.S)

# Authorised image processing and quantitative colour mapping.
start=source.index(r'\caption{Specimen observations and computed fields.');end=source.index(r'\end{figure*}',start)
caption=r'''\captionsetup{font={compact,it}}
\caption{Specimen observations and computed fields. (a,b) Glare-compressed display derivatives; blue margins are retained and blue $\dagger$ marks observed edge defects, without assigning cause or age. (c) Recovered appearance frame. Upper-right natural views include inferred reverse-face appearance. The lower triptych and its colour bar share the archived 512-colour reference palette applied to unchanged COMSOL von Mises values: linear 0.056766--0.326888~MPa, raw maximum 0.401620~MPa, 5,554,286 triangles. Geometry, camera, scalar values, limits and ticks are unchanged; the originating load/material case remains unidentified. (d1) Glare-compressed cervical photograph crops. (d2) Original 18~$\mu$m CT voxels with unchanged axes and contrast: 1, root-side mineralised matrix; 2, low-attenuation track, contents undetermined. No preserved soft tissue or histological EDJ is identified. (e1) Notebook $\Delta\kappa_1$, human object removed, dorsal fin upward; separate signed asinh limits $-1137.834/795.835$ inverse source units. (e2) Homogeneous StVK deformation, $u\times10$, with signed longitudinal Cauchy stress. (f) Executed finer wide-band jaw sensitivity at 10~kPa.}\label{fig:specimen}\label{fig:appearance}
\par\smallskip{\fontsize{7}{7.6}\selectfont\itshape Model credits: (e1) body-form reference, K. Shimada et al. (2025) \citep{Shimada2025}; the Notebook mesh is attributed to Shimada by the project author, but its exact distributed-file licence is not independently matched. Curvature processing: E. Han. (f) White Shark Jaw, \textcopyright\ Auckland Museum (2016), CC BY 4.0 \citep{AucklandJaw2016}; remeshing and FE analysis: E. Han.}
'''
source=source[:start]+caption+source[end:]
replace('The native 74M and optimised 32M surfaces occupy the same complete specimen extent.',
 r'The complete native 74M and optimised 32M surfaces \citep{CT74,CT32}, derived from the native mask \citep{Mask18}, occupy the same specimen extent.')
replace('The whole-animal surface is the exact',
 r'The project author attributes the whole-body reference to Shimada; comparative body-form work is cited separately \citep{Shimada2025}. The analysed surface is the exact')
replace('No volumetric jaw CT is identified in the available source files.',
 r'The separate juvenile white-shark surface is credited to Auckland Museum \citep{AucklandJaw2016}. No volumetric jaw CT is identified in the available source files.')

res=json.loads((N/'review/p1_p2_run_002/results.json').read_text());rows=[]
labels={'R0':r'$R_0$','RA':r'$R_A$','RB':r'$R_B$','Rtip':r'$R_{\rm tip}$','Rcr':r'$R_{\rm cr}$','Rroot':r'$R_{\rm root}$','support_adjacent':'Support-adjacent'}
for row in res['regions']:
 hs='/'.join(f'{v:.3f}' for v in row['h_mm'])
 rows.append(f"{labels[row['region']]} & {hs} & {row['P1_vm_MPa'][1]:.3f} & {row['P2_vm_MPa'][1]:.3f} & {row['Q95_change_percent']:+.2f} & {row['P1_tensile_MPa'][1]:.3f} & {row['P2_tensile_MPa'][1]:.3f} "+r'\\')
ptext=r'''\subsection{Same-domain P1/P2 verification}\label{sec:p1p2}
Polynomial order is tested on the unchanged 55,852-tetrahedron L0 polyhedron with the same 1~MPa face pressure, material and six frozen region unions. P1 has 13,584 vertices; P2 adds edge midpoints, giving 90,728 nodes and 272,184 displacement degrees of freedom. Both spaces vanish on the same fixed-vertex/edge/face subcomplex: a quadratic midpoint is constrained exactly when both original endpoints are fixed. Straight-sided geometry is retained; displacement approximation changes rather than tooth shape or anatomical attachment.

Quadratic stiffness and consistent face traction are integrated exactly. The affine traction-patch discrepancy is $4.19\times10^{-12}$; embedding P1 in P2 preserves strain energy to $6.90\times10^{-12}$ relative. Force, moment, work and independent internal-force readback pass the archived tolerances. P2 stress varies within each tetrahedron; regional summaries use positive 27-, 125- and 343-point quadrature. The final quadrature step changes at most 0.556\% across 42 von Mises/tensile percentile summaries, including the support-adjacent set.

\begin{table*}[tbp]\centering\fontsize{7.5}{8.2}\selectfont
\caption{Same-L0 P1/P2 comparison at 1~MPa. Stress columns are volume-weighted 95th percentiles in MPa; $\sigma_+$ is positive maximum principal stress. Local $h$ is maximum tetrahedron edge length; volume-weighted 10th/50th/90th percentiles describe identical geometric cells in both spaces.}\label{tab:p1p2}
\begin{tabular}{lrrrrrr}\toprule
Region & $h_{10}/h_{50}/h_{90}$ (mm) & P1 $\vm$ & P2 $\vm$ & Change (\%) & P1 $\sigma_+$ & P2 $\sigma_+$\\\midrule
'''+ '\n'.join(rows)+r'''
\bottomrule\end{tabular}
\end{table*}

All six regional von Mises Q95 differences are 0.92--10.14\% in absolute value (Table~\ref{tab:p1p2}). Elastic energy increases from 0.068910 to 0.080382~J. The directly evaluated interspace energy gap is 0.011472~J, equivalent to a 37.78\% energy-norm difference relative to P2; nested-space orthogonality is below $2\times10^{-10}$. Support-adjacent Q95 increases from 485.248 to 538.471~MPa. These coarse-domain degree effects are distinct from A2--A3 P1 mesh-step changes. They do not estimate A3 P2 error or certify a continuum upper error bound. Full regional mesh-size distributions and displacement fields accompany the record \citep{P1P2Data}.

'''
index=source.index(r'\section{Geometry, candidate tissue layers');source=source[:index]+ptext+source[index:]
start=source.index(r'\caption{Executed refinement on one fixed proxy domain');end=source.index(r'\end{minipage}',start)
source=source[:start]+r'''\includegraphics[width=\linewidth]{figures/P1_P2_support_sections.pdf}
\caption{Refinement and polynomial-order checks on unchanged domains. (a) Frozen regional P1 $Q_{0.95}$ versus element count, log--log axes. (b) A2--A3 relative changes, using A3 as denominator; dashed 0.5\% guide. All six are below 0.233\%, the apex is 0.081\%, and all 18 quantiles change by less than 0.60\%. (c,d) Same-L0 P1/P2 mid-thickness root-side sections, shared logarithmic MPa scale and the same constrained subcomplex. Degree effects in Table~\ref{tab:p1p2} are separate from fine-mesh P1 stability.}\label{fig:convergence}
'''+source[end:]
impact=r'''\subsection{Contact impact, wave propagation and scope}\label{sec:impact}
Contact impact requires inertia, an approach velocity or force--time history, and a calibrated attachment/contact law. In the reference frame the governing balance is
\begin{equation}
\rho_0\,\ddot{\mathbf u}=\operatorname{Div}P+\rho_0\mathbf b,
\qquad P=FS\quad\text{for StVK}.
\end{equation}
Density is $\rho_0$, $P$ is first Piola stress and $\mathbf b$ is body acceleration. A frictionless unilateral model prevents interpenetration, permits compressive contact pressure and releases traction on separation. Normal compliance can regularise contact; stiffness, closing-rate damping and impact duration require independent calibration \citep{Laursen1997,COMSOLDynamic}. The Robin grid here is a separate static sensitivity.

When load rise time approaches an elastic-wave transit time, equilibrium cannot represent transient amplification or root-support reflections. Wave speed depends on density and tangent stiffness. Discontinuous contact can launch wavefronts; a nonlinear compressive shock additionally requires jump compatibility, an energy-admissible weak solution and a hyperbolic material regime \citep{PerezRozga2016}. A large static von Mises peak establishes none of these. Dynamic verification must refine time step and contact-zone mesh together, check impulse and energy, and distinguish physical from numerical damping. No measured impact history, density or dynamic contact calibration is available; shock amplitudes and impact fracture loads are therefore not inferred.

'''
index=source.index(r'\subsection{Fracture, interfaces and geometric scaling}');source=source[:index]+impact+source[index:]
replace('The candidate bilayer has tied displacement continuity, no debonding law and no measured interface toughness.',
 'The candidate bilayer has tied displacement continuity, no debonding law and no measured interface toughness. A paired interface-conforming versus centroid-assigned comparison is needed to isolate interface representation error; it has not been executed. Actual EDJ, dentinal organisation and root attachment remain unidentified.')
replace(r'all 18 percentile changes are below 0.60\%. Support-adjacent point peaks remain mesh-sensitive.',
 r'all 18 percentile changes are below 0.60\%. The same-L0 P1/P2 test nevertheless changes regional Q95 by 0.92--10.14\% and exposes a 37.78\% discrete energy-norm gap. A fine A3 P2 check remains absent. Support-adjacent point peaks remain mesh-sensitive.')
replace(r'Full objective bilayer StVK changes the matched whole-domain 95th percentile by 0.499\%.',
 r'Full objective bilayer StVK changes the matched whole-domain 95th percentile by 0.499\%. A coarse-domain P1/P2 comparison changes regional Q95 by 0.92--10.14\%, showing that small P1 mesh-step changes are not complete error estimates.')
replace('Mesh checks & Tooth: three global and three targeted local meshes;',
 'Mesh checks & Tooth: three global and three targeted local meshes, plus a same-domain P1/P2 pair (55,852 cells; 90,728 P2 nodes);')
replace('no pure lateral/full factorial test or measured attachment; jaw masks are not fossil force transfer.',
 'no pure lateral/full factorial test or measured attachment; dynamic contact/shock is formulated, not solved; jaw masks are not fossil force transfer.')
replace('Temporary caches are excluded.',
 r'The additional P1/P2 archive supplies the original mesh/regions, quadratic displacement, local edge lengths, quadrature checks and executable source \citep{P1P2Data}. Full mathematical definitions accompany the source. Temporary caches are excluded.')
newdata=r'''
\bibitem[Han(2026e)]{P1P2Data}
Eliguli Han. Same-domain P1/P2 verification data and code, 2026.
\newblock\href{https://eliguli712.github.io/Antiterrastrae/publications/megalodon-P1-P2-validation.zip}{Mesh, displacement, region and audit archive}.
One L0 homogeneous 1~MPa pair; not an A3 P2 or dynamic impact calculation.
'''
replace(r'\item[]\textbf{C. Scientific and numerical literature}',newdata+'\n'+r'\item[]\textbf{C. Scientific literature and reference-model credits}')
newrefs=r'''
\bibitem[Auckland Museum(2016)]{AucklandJaw2016}
Auckland Museum. White Shark Jaw. Sketchfab, 13 October 2016.
\newblock\href{https://sketchfab.com/3d-models/white-shark-jaw-a74fb3f4ea3c494db02617dab5fbd3ef}{Original 504,500-vertex, 1,009,016-triangle model}.
\newblock Creative Commons Attribution 4.0. Juvenile \textit{Carcharodon carcharias}, New Zealand.

\bibitem[Shimada et al.(2025)]{Shimada2025}
K. Shimada et al. Reassessment of the possible size, form, weight, cruising speed, and growth parameters of the extinct megatooth shark, \textit{Otodus megalodon} (Lamniformes: Otodontidae), and new evolutionary insights into its gigantism, life history strategies, ecology, and extinction.
\newblock\emph{Palaeontologia Electronica}, 28(1):a12, 2025.
\newblock\doi{10.26879/1502}. Body-form reference; article CC BY. This does not authenticate the archived OBJ licence.

\bibitem[Laursen and Chawla(1997)]{Laursen1997}
T. A. Laursen and V. Chawla. Design of energy conserving algorithms for frictionless dynamic contact problems.
\newblock\emph{International Journal for Numerical Methods in Engineering}, 40(5):863--886, 1997.
\newblock\href{https://doi.org/10.1002/(SICI)1097-0207(19970315)40:5\%3C863::AID-NME92\%3E3.0.CO;2-V}{Publisher record and DOI}.

\bibitem[COMSOL AB(2026)]{COMSOLDynamic}
COMSOL AB. Explicit Dynamic Contact Analysis. Structural Mechanics Module 6.4 documentation.
\newblock\url{https://doc.comsol.com/6.4/doc/com.comsol.help.sme/sme_ug_modeling.05.151.html}.
\newblock Accessed 19 November 2026.

\bibitem[P\'erez and R\'ozga(2016)]{PerezRozga2016}
E. P\'erez and K. R\'ozga. Hyperbolicity and genuine nonlinearity conditions for certain p-systems of conservation laws, weak solutions and the entropy condition.
\newblock arXiv:1602.00264, 2016.
\newblock\url{https://arxiv.org/abs/1602.00264}. One-dimensional analysis, not a shock solution for this tooth.
'''
replace(r'\end{thebibliography}',newrefs+'\n'+r'\end{thebibliography}')
replace(r'\begin{thebibliography}{24}',r'\begin{thebibliography}{30}')
replace(r'\fontsize{9.0}{9.4}',r'\fontsize{9.0}{9.2}')
replace('height=14mm,keepaspectratio','height=10mm,keepaspectratio')
for a,b in {
 'Katherine~A. Corn':'K.~A. Corn','Stacy~C. Farina':'S.~C. Farina','Jeffrey Brash':'J. Brash','Adam~P. Summers':'A.~P. Summers',
 'Lisa~B. Whitenack':'L.~B. Whitenack','David~C. Simkins':'D.~C. Simkins','Philip~J. Motta':'P.~J. Motta',
 'Joshua~K. Moyer':'J.~K. Moyer','William~E. Bemis':'W.~E. Bemis','Patrick~L. Jambura':'P.~L. Jambura',
 "Ren{\\'e} Kindlimann":'R. Kindlimann',"Faviel~A. L{\\'o}pez-Romero":"F.~A. L{\\'o}pez-Romero",
 'Kenshu Shimada':'K. Shimada','Yixin Hu':'Y. Hu','Qingnan Zhou':'Q. Zhou','Xifeng Gao':'X. Gao','Alec Jacobson':'A. Jacobson','Denis Zorin':'D. Zorin',
 'Gabriel Taubin':'G. Taubin','Mark Meyer':'M. Meyer','Mathieu Desbrun':'M. Desbrun','Pascal Massart':'P. Massart','Wassily Hoeffding':'W. Hoeffding',
 'Tom Gustafsson':'T. Gustafsson','Nathan Bell':'N. Bell','Ben Southworth':'B. Southworth','Ming-Yuan He':'M.-Y. He','John~W. Hutchinson':'J.~W. Hutchinson'
}.items():
 bib=source.index(r'\begin{thebibliography}');source=source[:bib]+source[bib:].replace(a,b)
path.write_text(source)
print('Updated the open source in place; original mathematical definitions preserved; P1/P2, contact and model credits added.')
