"""Replot the complete Figure 10 from its numerical display checkpoint."""
import argparse
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
from matplotlib.colors import LogNorm, TwoSlopeNorm
from matplotlib.ticker import MultipleLocator
from scipy.interpolate import PchipInterpolator

WIDTH, HEIGHT = 1472, 2240
EXTENT = (-1.15, 1.15, 1.03, -.03)

plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],
    'font.size':6.5,'axes.labelsize':6.5,'axes.titlesize':7,
    'xtick.labelsize':6,'ytick.labelsize':6,'legend.fontsize':6,
    'axes.linewidth':.55,'lines.linewidth':.7,'xtick.major.width':.5,
    'ytick.major.width':.5,'xtick.major.size':2,'ytick.major.size':2,
    'axes.spines.top':False,'axes.spines.right':False,
    'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})


class Plate:
    BLUE, ORANGE, RED = '#287eab', '#c27629', '#ba433c'

    @staticmethod
    def canvas(w, h):
        fig = plt.figure(figsize=(w/25.4,h/25.4),facecolor='white')
        fig._mm = w,h
        return fig

    @staticmethod
    def axmm(fig,x,y,w,h):
        fw,fh = fig._mm
        return fig.add_axes([x/fw,y/fh,w/fw,h/fh])

    @staticmethod
    def txt(fig,x,y,s,size=6.5,**kwargs):
        fw,fh = fig._mm
        return fig.text(x/fw,y/fh,s,fontsize=size,**kwargs)

    @classmethod
    def panel(cls, fig,x,y,s):
        cls.txt(fig,x,y,s,8,weight='bold',va='top')


plate = Plate()


def compose(pixels, archive, current, valid, table, output_pdf, preview_png=None):
    norms = [LogNorm(.01, 3, clip=True), LogNorm(.01, 3, clip=True),
             TwoSlopeNorm(vmin=-2, vcenter=0, vmax=2)]
    cmaps = ['turbo', 'turbo', 'RdBu_r']
    fig = plate.canvas(183, 57)
    for i, (title, data) in enumerate(zip(
        ('Archive / own Q95', 'A3 / own Q95', 'A3 − archive'), (archive,current,current-archive)
    )):
        rgba = np.zeros((HEIGHT, WIDTH, 4), dtype=np.uint8)
        rgba[pixels[0], pixels[1]] = (232, 209, 242, 255)
        colour = plt.colormaps[cmaps[i]](norms[i](data[valid]), bytes=True)
        rgba[pixels[0][valid], pixels[1][valid]] = colour
        x = 7 + 34*i
        ax = plate.axmm(fig, x, 13, 23, 35)
        ax.imshow(rgba, extent=EXTENT, aspect='auto', interpolation='none')
        ax.set(xlim=EXTENT[:2], ylim=EXTENT[2:], xticks=[-1,0,1], yticks=[0,.5,1],
               xlabel=r'$\xi$', ylabel=r'$s$' if i == 0 else '')
        ax.tick_params(labelsize=5,pad=1,labelleft=i == 0)
        cb = fig.colorbar(plt.cm.ScalarMappable(norm=norms[i],cmap=cmaps[i]),
                          cax=plate.axmm(fig,x+24,17,1,27),extend='both')
        cb.set_ticks([.01,.1,1,3], labels=['.01','.1','1','3']) if i < 2 else cb.set_ticks([-2,0,2])
        cb.ax.tick_params(labelsize=4.4,pad=1)
        plate.panel(fig,x-6,55,'abc'[i])
        plate.txt(fig,x+10,54,title,5.7,ha='center',va='top')

    mid, _, a, c, d, se = table.T
    finer = np.linspace(mid[0], mid[-1], 2560)
    path = lambda data: PchipInterpolator(mid,data,extrapolate=False)(finer)
    ax = plate.axmm(fig,115,13,27,35)
    ax.plot(finer,path(a),color=plate.BLUE,label='Archive',lw=.55)
    ax.plot(finer,path(c),color=plate.ORANGE,label='A3',lw=.55)
    ax.set(xlabel=r'Rootward $s$',ylabel='Mean / own Q95')
    ax.legend(fontsize=4.8,frameon=False,loc='upper left')
    plate.panel(fig,107,55,'d')
    plate.txt(fig,129,54,f'{len(table)} axial bins',5.8,ha='center',va='top')
    second = plate.axmm(fig,154,13,27,35)
    second.axhline(0,color='#5d7280',lw=.42)
    dd, error = path(d), 1.96*path(se)
    second.fill_between(finer,dd-error,dd+error,color=plate.RED,alpha=.22,lw=0)
    second.plot(finer,dd,color=plate.RED,lw=.55)
    second.set(xlabel=r'Rootward $s$',ylabel='Mean shape difference')
    for axis in (ax,second):
        axis.set(xlim=(0,1),xticks=[0,.25,.5,.75,1])
        axis.xaxis.set_minor_locator(MultipleLocator(.05))
        axis.tick_params(which='major',labelsize=4.8,pad=1)
        axis.tick_params(which='minor',length=1)
        axis.grid(alpha=.16,lw=.3)
    plate.panel(fig,145,55,'e')
    plate.txt(fig,166,54,r'$\pm$1.96 MC standard errors',5.5,ha='center',va='top')
    plate.txt(fig,91.5,1.7,'Apex 0 → 1 root | Lavender: either projection exceeds 0.5 mm | Distinct load cases',5.3,ha='center')
    fig.savefig(output_pdf,dpi=600)
    if preview_png is not None:
        fig.savefig(preview_png,dpi=270)
    plt.close(fig)


def replot(checkpoint, output_pdf):
    with np.load(checkpoint, allow_pickle=False) as data:
        assert (data['width'],data['height']) == (WIDTH,HEIGHT)
        assert int(data['native_triangles_submitted']) == 74_293_846
        mask = np.unpackbits(data['foreground_mask'], count=WIDTH*HEIGHT).reshape(HEIGHT,WIDTH)
        pixels = np.where(mask)
        archive,current = data['archive_normalised'],data['A3_normalised']
        valid = np.isfinite(archive) & np.isfinite(current)
        assert len(pixels[0]) == len(archive) == len(current)
        compose(pixels,archive,current,valid,data['profile_rows'],output_pdf)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('checkpoint', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    replot(args.checkpoint,args.output)
