"""Replace only the angular line charts in Figure 8 with exact 1/8° results."""
import json
import os
from pathlib import Path
import sys
from tempfile import TemporaryDirectory

import fitz
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
from matplotlib.ticker import MultipleLocator
import numpy as np

WORK = Path(__file__).resolve().parents[1]
PROJECT = Path(os.environ.get('FEA_MEG_ROOT',WORK.parents[2]))
LEGACY = PROJECT/'output/pdf/debunk_myth_preprint_2026-11-19'
TRANSFER = PROJECT/'output/jaw_tooth_transfer_2026-11-22'
STEM = 'boundary_edge_transmission_distributed'
sys.path.insert(0,str(LEGACY/'scripts'))
import revise_figures as plate


def compose_curves(filename):
    record = json.loads((WORK/'review/fine_edge_response.json').read_text())
    assert record['status']=='passed' and record['angular_step_degrees']==.125
    values = record['margin_tensile_Q95_MPa_per_N']
    margin_colors = {'RA':'#435aa6','RB':'#66ad36'}
    plt.rcParams['path.simplify'] = False
    fig = plate.canvas(183,68)

    def value(margin,pose,beta,support):
        return values[f'{margin}_pose{pose:g}_oblique{beta:g}_{support}']

    ax = plate.axmm(fig,101,16,33,43)
    oblique = np.arange(241)/8
    for margin,colour in margin_colors.items():
        for support,style,label in [('fixed','--','fixed'),('tied','-','coupled')]:
            trace = [value(margin,0,beta,support)/value(margin,0,0,support) for beta in oblique]
            ax.plot(oblique,trace,linestyle=style,marker='x',markevery=[0,120,240],color=colour,
                    lw=.6,ms=3,mew=.68,label=f'{margin[-1]} {label}')
    ax.set(xlabel='Obliquity (°)',ylabel='Tension Q95 / axial value',xticks=[0,10,20,30])
    plate.panel(fig,94,67,'c')
    plate.txt(fig,118,67,'Within-margin direction effect',6.1,ha='center',va='top')

    bx = plate.axmm(fig,148,16,33,43)
    degrees = np.arange(-120,121)/8
    for margin,colour in margin_colors.items():
        for oblique,style in [(0,'-'),(30,'--')]:
            trace = [value(margin,pose,oblique,'tied')/value(margin,pose,oblique,'fixed') for pose in degrees]
            bx.plot(degrees,trace,linestyle=style,marker='x',markevery=[0,120,240],color=colour,
                    lw=.6,ms=3,mew=.68,label=f'{margin[-1]} {oblique}°')
    p2 = json.loads((TRANSFER/'p2_edge_data_v2/results.json').read_text())['regional_percentiles']
    p2 = {row['state']:row['P2_tensile_Q90_Q95_Q99_MPa_per_N'][1] for row in p2 if row['region']=='RA'}
    bx.plot([0],[p2['coupled']/p2['fixed']],'+',color='#132b49',ms=4,mew=1,label='A 0° P2')
    bx.set(xlabel='Installation angle (°)',ylabel='Coupled / fixed tension Q95',xticks=[-15,-5,5,15])
    plate.panel(fig,140,67,'d')
    plate.txt(fig,164,67,'Attachment effect',6.1,ha='center',va='top')

    for axis in (ax,bx):
        axis.xaxis.set_minor_locator(MultipleLocator(2.5))
        axis.tick_params(pad=1,labelsize=5.3)
        axis.tick_params(which='minor',length=1)
        axis.grid(alpha=.16,lw=.32)
        axis.legend(fontsize=4.7,frameon=False,loc='upper left',handlelength=1.25)
    fig.savefig(filename)
    plt.close(fig)


def full_and_preview():
    original = LEGACY/'figures'
    figures = WORK/'figures'
    with TemporaryDirectory(prefix='tooth-edge-curves-') as tmp:
        updated = Path(tmp)/'right.pdf'
        compose_curves(updated)
        with fitz.open(original/(STEM+'.pdf')) as base, fitz.open(updated) as right, fitz.open() as result:
            full = base[0].rect
            top = right[0].rect
            assert abs(full.width-top.width)<.02
            split = 92.8/25.4*72
            left_clip = fitz.Rect(0,0,split,top.height)
            right_clip = fitz.Rect(split,0,full.width,top.height)
            bottom_clip = fitz.Rect(0,top.height,full.width,full.height)
            page = result.new_page(width=full.width,height=full.height)
            for doc, clip in [(base,left_clip),(right,right_clip),(base,bottom_clip)]:
                page.show_pdf_page(clip,doc,0,clip=clip)
            full_path = figures/(STEM+'.pdf')
            result.save(full_path,garbage=4,deflate=True)
            page.get_pixmap(dpi=190).save(WORK/'review'/('figure8-review.png'))
            # Compact reviewer copy, while the publication build uses the full vector and raster file.
            result.rewrite_images(dpi_threshold=480,dpi_target=330,quality=92)
            result.save(figures/(STEM+'_preview.pdf'),garbage=4,deflate=True)


if __name__ == '__main__':
    full_and_preview()
