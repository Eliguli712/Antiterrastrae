// Extract the ordered specimen-local vertices and triangles from the released r5 3MF XML stream.
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

int main(int argc, char** argv) {
    try {
        constexpr uint64_t vertices = 37'951'699, triangles = 74'293'846;
        if (argc != 2 && argc != 3) return 1;
        const bool verify = argc == 3 && std::strcmp(argv[2],"--verify")==0;
        if (argc == 3 && !verify) return 1;
        const std::filesystem::path directory(argv[1]);
        std::filesystem::create_directories(directory);
        const auto vertex_path = directory/"vertices.f64", face_path = directory/"triangles.u32";
        if (!verify && (std::filesystem::exists(vertex_path) || std::filesystem::exists(face_path)))
            throw std::runtime_error("Target arrays already exist; choose an empty cache");
        const auto vertex_temp = directory/"vertices.f64.build", face_temp = directory/"triangles.u32.build";
        std::ofstream vertex_file, face_file;
        std::ifstream vertex_check, face_check;
        if (verify) {
            vertex_check.open(vertex_path, std::ios::binary);
            face_check.open(face_path, std::ios::binary);
            if (!vertex_check || !face_check) throw std::runtime_error("Cannot read existing files");
        } else {
            vertex_file.open(vertex_temp, std::ios::binary);
            face_file.open(face_temp, std::ios::binary);
            if (!vertex_file || !face_file) throw std::runtime_error("Cannot create output files");
        }
        auto record = [verify](auto& fields, auto& input, auto& output) {
            const auto* data = reinterpret_cast<const char*>(fields);
            if (verify) {
                char known[sizeof(fields)];
                input.read(known,sizeof(fields));
                if (!input || std::memcmp(known,data,sizeof(fields)))
                    throw std::runtime_error("Source geometry differs from cache");
            } else {
                output.write(data,sizeof(fields));
            }
        };
        uint64_t nv = 0, nf = 0;
        std::vector<char> bytes(8 << 20);
        std::string carry;
        while (std::cin) {
            std::cin.read(bytes.data(), bytes.size());
            carry.append(bytes.data(), std::cin.gcount());
            const auto end = carry.rfind('>');
            if (end == std::string::npos) continue;
            std::string block = carry.substr(0, end+1);
            carry.erase(0, end+1);
            const char* p = block.data();
            while ((p=std::strchr(p,'<'))) {
                if (std::strncmp(p, "<vertex ", 8)==0) {
                    if (nf || nv>=vertices) throw std::runtime_error("Unexpected vertex order");
                    char* cursor = const_cast<char*>(p);
                    double xyz[3];
                    for (auto& coordinate : xyz) {
                        cursor = std::strchr(cursor, '"')+1;
                        coordinate = std::strtod(cursor,&cursor);
                        if (*cursor++!='"') throw std::runtime_error("Invalid vertex coordinate");
                    }
                    record(xyz,vertex_check,vertex_file);
                    ++nv;
                } else if (std::strncmp(p,"<triangle ",10)==0) {
                    if (nv!=vertices || nf>=triangles) throw std::runtime_error("Unexpected face order");
                    char* cursor = const_cast<char*>(p);
                    uint32_t ids[3];
                    for (auto& id : ids) {
                        cursor = std::strchr(cursor, '"')+1;
                        auto val = std::strtoul(cursor,&cursor,10);
                        if (*cursor++!='"' || val>=nv) throw std::runtime_error("Invalid triangle index");
                        id = uint32_t(val);
                    }
                    record(ids,face_check,face_file);
                    ++nf;
                }
                ++p;
            }
        }
        if (nv!=vertices || nf!=triangles) throw std::runtime_error("Incomplete raw geometry");
        if (verify) {
            if (vertex_check.peek()!=EOF || face_check.peek()!=EOF)
                throw std::runtime_error("Existing arrays have excess bytes");
        } else {
            vertex_file.close();
            face_file.close();
            if (!vertex_file || !face_file) throw std::runtime_error("Cannot finish writing arrays");
            std::filesystem::rename(vertex_temp,vertex_path);
            std::filesystem::rename(face_temp,face_path);
        }
        std::cout << nv << " vertices and " << nf << " triangles "
                  << (verify ? "verified" : "extracted") << '\n';
    } catch(const std::exception& e) {
        std::cerr << e.what() << '\n';
        return 2;
    }
}
