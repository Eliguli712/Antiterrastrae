"""Generate exact Figure 10 legacy-cache arrays from the archived fixed-field BDF."""
import argparse
import hashlib
from pathlib import Path

import numpy as np

BDF_SHA256 = 'c0b7830860a5c12caf68fce8bc2e34da4c1e19734489e57c61bdbc2b6db770d6'
EXPECTED = {
    'fe_v.npy': 'f1ac291a68969b0ece1b91e73a141ee6a6a61e1f44d8eee0c31c50f0dc27af95',
    'fe_f.npy': 'e593a855b870e82086cc62b76605dc7c91e4b9772377ee6558c0cc192e8a6a3a',
}


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def build(source, cache):
    assert digest(source)==BDF_SHA256, "Archived BDF hash differs"
    cache.mkdir(parents=True, exist_ok=True)
    assert not any((cache/name).exists() for name in EXPECTED), "Use an empty cache"
    v = np.lib.format.open_memmap(cache/'fe_v.npy',mode='w+',dtype='<f8',shape=(2_767_405,3))
    f = np.lib.format.open_memmap(cache/'fe_f.npy',mode='w+',dtype='<i4',shape=(5_554_286,3))
    vs,fs = [],[]
    vi,fi = 0,0

    def write(buffer, output, pos, dtype, offset):
        if not buffer:
            return pos
        batch = np.fromstring(b'\n'.join(buffer).decode('ascii'),sep=' ',dtype=dtype).reshape(-1,3)
        output[pos:pos+len(batch)] = batch-offset
        buffer.clear()
        return pos+len(batch)

    with source.open('rb') as stream:
        for line in stream:
            fields = b' '.join((line[24:32],line[32:40],line[40:48]))
            if line.startswith(b'GRID '):
                vs.append(fields)
                if len(vs)==100_000:
                    vi = write(vs,v,vi,'<f8',0)
            elif line.startswith(b'CTRIA3 '):
                fs.append(fields)
                if len(fs)==100_000:
                    fi = write(fs,f,fi,'<i4',1)
        vi = write(vs,v,vi,'<f8',0)
        fi = write(fs,f,fi,'<i4',1)
    assert vi==len(v) and fi==len(f)
    v.flush()
    f.flush()
    for name,sha in EXPECTED.items():
        assert digest(cache/name)==sha,name


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source_bdf',type=Path)
    parser.add_argument('cache_dir',type=Path)
    args = parser.parse_args()
    build(args.source_bdf,args.cache_dir)
