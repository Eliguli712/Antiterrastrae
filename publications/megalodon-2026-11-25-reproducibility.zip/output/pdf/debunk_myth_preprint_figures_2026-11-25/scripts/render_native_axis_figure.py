"""Figure 10: exact native mesh depth, independent scalar projections, denser A3 profiles."""
import csv
import hashlib
import json
import os
from pathlib import Path
import struct
import subprocess
from tempfile import TemporaryDirectory

import numpy as np
import pyvista as pv
from scipy.spatial import cKDTree
from vtkmodules.vtkCommonDataModel import vtkStaticCellLocator

WORK = Path(__file__).resolve().parents[1]
PROJECT = Path(os.environ.get('FEA_MEG_ROOT', WORK.parents[2]))
LEGACY = PROJECT / 'output/pdf/debunk_myth_preprint_2026-11-19'
SAMPLES = LEGACY / 'numerics/archive_axis_dense/samples.npz'
CACHE = PROJECT / 'output/current_native74_stress_2026-11-20/cache'
A3 = PROJECT / 'output/publication_validation_2026-11-12/data/local_A3/fields.npz'
AXIS_FRAME = PROJECT / 'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0/solution.npz'
ARCHIVE_CACHE = PROJECT / 'output/tooth_continuous_surfaces/cache'
ARCHIVE_VALUES = PROJECT / 'DICOM_16um/exports/von_mises_data_smoothed.txt'
from replot_figure10 import WIDTH, HEIGHT, EXTENT, compose
TRIANGLES, VERTICES = 74_293_846, 37_951_699
N_BINS = 320
CUTOFF_MM = .5
OUT = WORK / 'figures'
REVIEW = WORK / 'review'
STEM = 'archive_axis_comparison_dense_recovered'


def read_frame():
    saved_frame = REVIEW/'figure10_axis_frame.npz'
    if saved_frame.exists():
        with np.load(saved_frame,allow_pickle=False) as data:
            return tuple(data[name] for name in ('center','basis','lo','hi'))
    with np.load(AXIS_FRAME) as frame:
        center, basis = frame['center_m'] * 1000, frame['basis']
        points = frame['points_m'][np.unique(frame['boundary_faces'])] * 1000
    local = (points - center) @ basis
    np.testing.assert_allclose(basis @ basis.T, np.eye(3), atol=1e-12)
    return center, basis, local.min(0), local.max(0)


def native_depth(tmp, frame):
    center, basis, lo, hi = frame
    depth_file = tmp / 'native-depth.f32'
    exe = tmp / 'native-depth'
    subprocess.run(['c++', '-O3', '-std=c++17', str(WORK/'scripts/native_depth_raster.cpp'),
                    '-o', str(exe)], check=True)
    vertices = np.memmap(CACHE/'vertices.f64', '<f8', 'r', shape=(VERTICES, 3))
    faces = np.memmap(CACHE/'triangles.u32', '<u4', 'r', shape=(TRIANGLES, 3))
    x0, x1, y1, y0 = EXTENT
    lower, upper = np.full(2, np.inf), np.full(2, -np.inf)
    with subprocess.Popen([str(exe), str(WIDTH), str(HEIGHT), str(depth_file)],
                          stdin=subprocess.PIPE, stdout=subprocess.PIPE) as process:
        for i in range(0, TRIANGLES, 800_000):
            ids, indexed = np.unique(faces[i:i+800_000], return_inverse=True)
            local = (vertices[ids] - center) @ basis
            xis = 2*(local[:, 0]-lo[0])/(hi[0]-lo[0])-1
            ss = (local[:, 1]-lo[1])/(hi[1]-lo[1])
            lower = np.minimum(lower, (xis.min(), ss.min()))
            upper = np.maximum(upper, (xis.max(), ss.max()))
            projected = np.column_stack((
                (xis-x0)/(x1-x0)*WIDTH, (ss-y0)/(y1-y0)*HEIGHT, -local[:, 2],
            )).astype('<f4')
            process.stdin.write(struct.pack('<II', len(ids), indexed.size//3))
            process.stdin.write(projected.tobytes())
            process.stdin.write(indexed.astype('<u4').tobytes())
            if i % 16_000_000 == 0:
                print(f'Native depth: {i:,}/{TRIANGLES:,} triangles', flush=True)
        process.stdin.close()
        submitted = int(process.stdout.read())
        assert process.wait() == 0
    assert submitted == TRIANGLES
    assert (lower > (x0, y0)).all() and (upper < (x1, y1)).all(), (lower, upper)
    depth = np.fromfile(depth_file, '<f4').reshape((HEIGHT, WIDTH))
    rows, cols = np.where(np.isfinite(depth))
    xyz = np.column_stack((
        lo[0]+((x0+(cols+.5)*(x1-x0)/WIDTH)+1)*(hi[0]-lo[0])/2,
        lo[1]+(y0+(rows+.5)*(y1-y0)/HEIGHT)*(hi[1]-lo[1]),
        -depth[rows, cols],
    )) @ basis.T + center
    print(f'Visible native depth samples: {len(rows):,}', flush=True)
    return (rows, cols), xyz, [lower.tolist(), upper.tolist()]


def archive_mesh_field():
    raw = np.loadtxt(ARCHIVE_VALUES, comments='%')
    points = np.load(ARCHIVE_CACHE/'fe_v.npy')
    faces = np.load(ARCHIVE_CACHE/'fe_f.npy', mmap_mode='r')
    assert raw.shape == (191031, 4) and faces.shape == (5554286, 3)
    _, nodes = cKDTree(raw[:, :3]).query(points, workers=4)
    values = raw[nodes, 3] / 1e6
    points[:, 2] *= 18/16
    return points, faces, values


def recovered_a3_field():
    with np.load(A3) as field:
        vertices = field['points_m'] * 1000
        tets, boundary_faces = field['tets'], field['boundary_faces']
        volume, stress = field['volumes_m3'], field['von_mises_Pa']/1e6
    assert len(boundary_faces) == 88_208
    amount, vv = np.zeros(len(vertices)), np.zeros(len(vertices))
    for nodes in tets.T:
        np.add.at(vv, nodes, volume)
        np.add.at(amount, nodes, volume*stress)
    ids, index = np.unique(boundary_faces, return_inverse=True)
    return vertices[ids], index.reshape(-1, 3), amount[ids]/vv[ids]


def project_closest(query, vertices, faces, values):
    from vtkmodules.vtkCommonCore import reference
    from vtkmodules.vtkCommonDataModel import vtkGenericCell

    surface = pv.PolyData.from_regular_faces(vertices, faces)
    locator = vtkStaticCellLocator()
    locator.SetDataSet(surface)
    locator.BuildLocator()
    ids = np.empty(len(query), dtype=np.int64)
    distances = np.empty(len(query))
    closest = np.empty_like(query)
    cell = vtkGenericCell()
    distance, facet_id, sub_id = reference(0.), reference(0), reference(0)
    query_point = np.zeros(3)
    nearest = np.zeros(3)
    for k, row in enumerate(query):
        query_point[:] = row
        locator.FindClosestPoint(query_point, nearest, cell, facet_id, sub_id, distance)
        ids[k], distances[k], closest[k] = int(facet_id), float(distance), nearest
    assert (ids >= 0).all() and (distances >= 0).all()
    expected = np.linalg.norm(query - closest, axis=1)
    np.testing.assert_allclose(np.sqrt(distances), expected, atol=1e-11)
    valid = distances <= CUTOFF_MM**2
    out = np.full(len(query), np.nan)
    for i in range(0, len(query), 100_000):
        part = slice(i, i+100_000)
        if not valid[part].any():
            continue
        use = np.flatnonzero(valid[part]) + i
        nodes = faces[ids[use]]
        tri = vertices[nodes]
        e0, e1, ep = tri[:, 1]-tri[:, 0], tri[:, 2]-tri[:, 0], closest[use]-tri[:, 0]
        dot = lambda a,b: np.einsum('ij,ij->i', a,b)
        a,b,d = dot(e0,e0),dot(e0,e1),dot(e1,e1)
        determinant = a*d-b*b
        assert np.all(determinant > 0)
        u = (d*dot(e0,ep)-b*dot(e1,ep))/determinant
        v = (a*dot(e1,ep)-b*dot(e0,ep))/determinant
        weights = np.column_stack((1-u-v,u,v))
        assert weights.min() >= -1e-5, weights.min()
        out[use] = np.einsum('ij,ij->i', weights, values[nodes])
    return out, valid


def profiles():
    with np.load(SAMPLES) as sample:
        q95 = sample['normalizers_MPa']
        s = sample['s']
        a = sample['archive_MPa'] / q95[0]
        c = sample['A3_MPa'] / q95[1]
    d = c-a
    bins = np.clip((s*N_BINS).astype(int), 0, N_BINS-1)
    n = np.bincount(bins, minlength=N_BINS)
    assert n.min() > 100 and n.sum() == len(s)
    mean = lambda data: np.bincount(bins, weights=data, minlength=N_BINS)/n
    a_avg, c_avg, d_avg = mean(a), mean(c), mean(d)
    se = np.sqrt(np.bincount(bins, weights=(d-d_avg[bins])**2) / (n*(n-1)))
    table = np.column_stack(((np.arange(N_BINS)+.5)/N_BINS, n, a_avg, c_avg, d_avg, se))
    with (REVIEW/'axial_profiles_320.csv').open('w', newline='') as stream:
        writer = csv.writer(stream)
        writer.writerow(['s_mid','n','archive_normalised_mean','A3_normalised_mean','difference_mean','difference_MC_SE'])
        writer.writerows((f'{s_:.9f}', int(n_), a_, c_, d_, se_)
                         for s_,n_,a_,c_,d_,se_ in table)
    return q95, table




def main():
    q95, table = profiles()
    with TemporaryDirectory(prefix='native-axis-depth-') as directory:
        pixels, xyz, bounds = native_depth(Path(directory), read_frame())
    archive, archive_valid = project_closest(xyz, *archive_mesh_field())
    print(f'Archive projection: {archive_valid.sum():,}/{len(xyz):,} within cutoff', flush=True)
    current, current_valid = project_closest(xyz, *recovered_a3_field())
    valid = archive_valid & current_valid
    print(f'Common projection: {valid.sum():,}/{len(xyz):,} within cutoff', flush=True)
    normalized_archive, normalized_a3 = archive/q95[0], current/q95[1]
    mask = np.zeros((HEIGHT,WIDTH),dtype=bool)
    mask[pixels] = True
    np.savez_compressed(REVIEW/'figure10_display_checkpoint.npz',
        width=WIDTH,height=HEIGHT,native_triangles_submitted=TRIANGLES,
        foreground_mask=np.packbits(mask),
        archive_normalised=normalized_archive,A3_normalised=normalized_a3,
        profile_rows=table,normalizers_MPa=q95,cutoff_mm=CUTOFF_MM)
    compose(pixels,normalized_archive,normalized_a3,valid,table,
            OUT/(STEM+'.pdf'),REVIEW/(STEM+'.png'))
    record = dict(
        native_triangles_submitted_to_common_depth=TRIANGLES, native_source_vertices=VERTICES,
        native_normalised_bounds=bounds, map_raster_pixels=[WIDTH,HEIGHT],
        foreground_samples=len(xyz), common_projection_samples=int(valid.sum()),
        archive_projection_samples=int(archive_valid.sum()),
        a3_projection_samples=int(current_valid.sum()), cutoff_mm=CUTOFF_MM,
        archive_source_faces=5_554_286, a3_projection_source_faces=88_208,
        original_profile_samples=int(table[:,1].sum()), bins=N_BINS,
        samples_per_bin_min=int(table[:,1].min()), samples_per_bin_max=int(table[:,1].max()),
        paired_surface_Q95_MPa=q95.tolist(),
        line='Shape-preserving cubic interpolation of 320 bin means and standard errors, drawn at 2,560 coordinates without extrapolation. Original samples unchanged.',
        scope='Native surface depth and projections of existing archived and A3 fields; no native porous FEM. Independent Q95 normalizers and A3 profile draws unchanged.',
        figure_sha256=hashlib.sha256((OUT/(STEM+'.pdf')).read_bytes()).hexdigest(),
    )
    (REVIEW/'figure10_native_projection.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2),flush=True)


if __name__ == '__main__':
    main()
