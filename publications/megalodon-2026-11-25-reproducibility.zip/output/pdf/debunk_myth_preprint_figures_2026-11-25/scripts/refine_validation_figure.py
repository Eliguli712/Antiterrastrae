"""Figure 9: retain the audited original native rasters and retypeset the data panels."""
import hashlib
import json
import os
from pathlib import Path
import sys

import numpy as np
import pyvista as pv
from matplotlib import pyplot as plt
from matplotlib.collections import PolyCollection
from matplotlib.colors import ListedColormap, LogNorm
from matplotlib.ticker import MultipleLocator
from PIL import Image
from scipy.interpolate import PchipInterpolator

WORK = Path(__file__).resolve().parents[1]
PROJECT = Path(os.environ.get('FEA_MEG_ROOT', WORK.parents[2]))
LEGACY = PROJECT/'output/pdf/debunk_myth_preprint_2026-11-19'
DATA = PROJECT/'output/publication_validation_2026-11-12'
BASE = PROJECT/'output/pdf/debunk_myth_full_reconstruction_2026-10-31'
STEM = 'validation_material_attachment_native_continuous'
sys.path.insert(0, str(LEGACY/'scripts'))
import revise_figures as plate


def json_at(path):
    return json.loads(path.read_text())


def case(name):
    return json_at(DATA/'data'/name/'results.json')


def curve(axis, x, y, colour, label=None, log_y=False, size=2.4):
    x, y = np.asarray(x), np.asarray(y)
    dense = np.linspace(x[0], x[-1], 257)
    values = PchipInterpolator(x, np.log10(y) if log_y else y, extrapolate=False)(dense)
    axis.plot(dense, 10**values if log_y else values, lw=.53, c=colour, label=label)
    axis.plot(x, y, 'o', ms=size, mew=0, c=colour)


def line_style(axis, minor_step):
    axis.xaxis.set_minor_locator(MultipleLocator(minor_step))
    axis.grid(alpha=.16,lw=.3)
    axis.tick_params(pad=1)
    axis.tick_params(which='minor',length=1)


def native_inputs():
    record = json_at(LEGACY/'review/bilayer_stvk_native_continuous.json')
    assert record['status']=='passed' and record['raster_faces_by_panel']==[74_293_846]*3
    files = [LEGACY/'figures'/f'bilayer_stvk_native_continuous_{i}.png' for i in range(3)]
    return record, files


def candidate_section():
    with np.load(DATA/'data/bilayer_A3_0p5mm/fields.npz') as state, np.load(BASE/'numerics/L0/solution.npz') as frame:
        xyz = (state['points_m']-frame['center_m']) @ frame['basis'] * 1000
        tets, shear = state['tets'], state['mu_Pa']
    grid = pv.UnstructuredGrid(np.column_stack([np.full(len(tets),4),tets]).ravel(),
                               np.full(len(tets),10,np.uint8),xyz)
    grid.cell_data['phase'] = (shear > 25e9).astype(np.uint8)
    cut = grid.slice(normal=(0,0,1),origin=(0,0,0)).triangulate()
    return cut.points[cut.faces.reshape(-1,4)[:,1:]][:,:,:2], cut['phase']


def compose(images, section, preview=False):
    fig = plate.canvas(183,145)
    results = json_at(DATA/'review/final_readback_001/results.json')

    ax = plate.axmm(fig,10,110,43,22)
    volumes = [5663.654461944,5642.047776744,5619.798825048]
    curve(ax,[95,100,105],volumes,plate.BLUE)
    ax.set(xlabel=r'Threshold / $T_0$ (%)',ylabel='Native volume (mm³)')
    line_style(ax,1)
    plate.panel(fig,1,143,'a')
    plate.txt(fig,31,142,'Full native reconstructions',6.5,ha='center',va='top')

    ax = plate.axmm(fig,71,110,43,22)
    changes = np.asarray(results['threshold_Q95_signed_percent'])
    for j in range(6):
        curve(ax,[95,100,105],[changes[0,j],0,changes[1,j]],plate.COLORS[j],size=2)
    ax.set(xlabel=r'Threshold / $T_0$ (%)',ylabel=r'$Q_{0.95}$ change (%)',ylim=(-.9,.75))
    ax.axhline(0,c='#888',lw=.38)
    line_style(ax,1)
    plate.panel(fig,62,143,'b')
    plate.txt(fig,92,142,'Fixed 0.288 mm FE grid',6.5,ha='center',va='top')

    ax = plate.axmm(fig,133,110,43,22)
    checks = [
        (-.16,'homogeneous_last_step_all_18_percent',plate.BLUE,'Single material'),
        (.16,'bilayer_last_step_all_18_percent',plate.ORANGE,'Candidate bilayer'),
    ]
    for shift,key,colour,label in checks:
        vals = np.asarray(results[key])[:,1]
        ax.bar(np.arange(6)+shift,vals,width=.29,color=colour,label=label)
    ax.axhline(.5,c='#555',ls='--',lw=.6)
    ax.set(ylim=(0,.75),ylabel=r'A2–A3 $Q_{0.95}$ change (%)')
    ax.set_xticks(range(6),plate.LABELS,fontsize=5.2)
    ax.tick_params(pad=1)
    ax.legend(fontsize=4.9,frameon=False,handlelength=1)
    plate.panel(fig,123,143,'c')
    plate.txt(fig,153,142,'Adjacent local meshes',6.5,ha='center',va='top')

    ax = plate.axmm(fig,15,64,35,26)
    triangles, phases = section
    ax.add_collection(PolyCollection(triangles,array=phases,cmap=ListedColormap(['#a3b8c5','#dbb34e']),
                                     clim=(0,1),edgecolors='none',rasterized=True))
    ax.autoscale()
    ax.set_aspect('equal')
    ax.set(xlabel='Transverse (mm)',ylabel='Longitudinal (mm)')
    ax.tick_params(pad=1,labelsize=5.3)
    plate.panel(fig,1,100,'d')
    plate.txt(fig,31,99,'Independent candidate layers',6.5,ha='center',va='top')
    plate.txt(fig,31,51.5,'Gold: shell; blue: core | 0.5 mm rule',5.2,ha='center')

    ax = plate.axmm(fig,71,66,43,25)
    model_groups = [
        (['local_A1','local_A2','local_A3'],plate.BLUE,'Single material'),
        (['bilayer_L2_0p5mm','bilayer_A2_0p5mm','bilayer_A3_0p5mm'],plate.ORANGE,'Candidate bilayer'),
    ]
    for names,colour,label in model_groups:
        models = [case(name) for name in names]
        curve(ax,[entry['tetrahedra']/1e6 for entry in models],
              [entry['peak_MPa'] for entry in models],colour,label)
    ax.set(xlabel='Tetrahedra (million)',ylabel='Point peak (MPa)')
    line_style(ax,.1)
    ax.legend(fontsize=4.9,frameon=False,handlelength=1)
    plate.panel(fig,62,100,'e')
    plate.txt(fig,92,99,'Peaks meet fixed-support cells',6.5,ha='center',va='top')
    plate.txt(fig,92,51.5,'Peak drift is distinct from quantile stability',5.2,ha='center')

    ax = plate.axmm(fig,133,66,43,25)
    ks = np.arange(10,16)
    displacement = [case('robin_L1_k'+str(k))['max_displacement_mm'] for k in ks]
    ax.set_yscale('log')
    curve(ax,ks,displacement,plate.BLUE,log_y=True)
    ax.axvspan(10,12,alpha=.08,color=plate.RED)
    ax.set(xlabel=r'$\log_{10} k$ (N m$^{-3}$)',ylabel=r'$u_{\max}$ (mm)')
    line_style(ax,.25)
    plate.panel(fig,123,100,'f')
    plate.txt(fig,153,99,'Calibratable Robin attachment',6.5,ha='center',va='top')
    plate.txt(fig,153,51.5,'Shaded: large-motion linear coefficients',5.2,ha='center')

    for j,title in enumerate(['Front','Oblique','Reverse']):
        x = 61*j
        axis = plate.axmm(fig,x+4,9,53,34)
        with Image.open(images[j]) as image:
            if preview:
                image.thumbnail((600,650),Image.Resampling.LANCZOS)
            axis.imshow(image,interpolation='none')
        axis.set_axis_off()
        plate.panel(fig,x+1,49,'ghi'[j])
        plate.txt(fig,x+31,48,title+' / candidate bilayer StVK',6.2,ha='center',va='top')

    cb = fig.colorbar(plt.cm.ScalarMappable(norm=LogNorm(.1,300),cmap='turbo'),
                      cax=plate.axmm(fig,62,4,55,1.3),orientation='horizontal',extend='both')
    cb.set_ticks([.1,1,10,100,300],labels=['0.1','1','10','100','300'])
    cb.ax.tick_params(labelsize=5,pad=1)
    plate.txt(fig,59,4.7,'MPa',5.4,ha='right')
    plate.txt(fig,122,4.7,'Projected StVK σvM; 74M surface',5.3)
    suffix = '_preview' if preview else ''
    fig.savefig(WORK/'figures'/(STEM+suffix+'.pdf'),dpi=300 if preview else 600)
    if not preview:
        fig.savefig(WORK/'review'/('figure9-review.png'),dpi=240)
    plt.close(fig)


if __name__ == '__main__':
    record, images = native_inputs()
    section = candidate_section()
    compose(images, section)
    compose(images, section, preview=True)
    record['native_rasters_preserved'] = [
        dict(file=p.name,size=Image.open(p).size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in images
    ]
    record['trace_display'] = 'Shape-preserving interpolation at 257 display coordinates per curve; archived experiment values shown as markers (three thresholds, three refinements per model, six stiffnesses). Log-space displacement interpolation, no extrapolated points.'
    (WORK/'review'/'figure9_native_projection.json').write_text(json.dumps(record,indent=2)+'\n')
