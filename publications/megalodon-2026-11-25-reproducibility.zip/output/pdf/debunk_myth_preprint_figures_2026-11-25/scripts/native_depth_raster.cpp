#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>
#include <vector>

struct Point { float x, y, z; };

int main(int argc, char** argv) {
    if (argc != 4) return 1;
    const int width = std::atoi(argv[1]);
    const int height = std::atoi(argv[2]);
    std::vector<float> depth(size_t(width) * height, std::numeric_limits<float>::infinity());
    std::vector<Point> points;
    std::vector<std::array<uint32_t, 3>> faces;
    uint64_t submitted = 0;
    uint32_t vertices, triangles;
    while (std::cin.read(reinterpret_cast<char*>(&vertices), 4)) {
        std::cin.read(reinterpret_cast<char*>(&triangles), 4);
        points.resize(vertices);
        faces.resize(triangles);
        std::cin.read(reinterpret_cast<char*>(points.data()), vertices * sizeof(Point));
        std::cin.read(reinterpret_cast<char*>(faces.data()), triangles * sizeof(faces[0]));
        if (!std::cin) return 2;
        submitted += triangles;
        for (const auto& face : faces) {
            const Point &a = points[face[0]], &b = points[face[1]], &c = points[face[2]];
            const double bax = b.x-a.x, bay = b.y-a.y, cax = c.x-a.x, cay = c.y-a.y;
            const double area = bax * cay - bay * cax;
            if (area == 0) continue;
            const int x0 = std::max(0, int(std::ceil(std::min({a.x, b.x, c.x})-.5)));
            const int x1 = std::min(width-1, int(std::floor(std::max({a.x, b.x, c.x})-.5)));
            const int y0 = std::max(0, int(std::ceil(std::min({a.y, b.y, c.y})-.5)));
            const int y1 = std::min(height-1, int(std::floor(std::max({a.y, b.y, c.y})-.5)));
            for (int y=y0; y<=y1; ++y) {
                for (int x=x0; x<=x1; ++x) {
                    const double ax = x+.5-a.x, ay = y+.5-a.y;
                    const double u = (ax*cay-ay*cax)/area, v = (bax*ay-bay*ax)/area;
                    if (u < -1e-9 || v < -1e-9 || u+v > 1+1e-9) continue;
                    const float z = a.z+u*(b.z-a.z)+v*(c.z-a.z);
                    auto& nearest = depth[size_t(y)*width+x];
                    nearest = std::min(nearest, z);
                }
            }
        }
    }
    std::ofstream out(argv[3], std::ios::binary);
    out.write(reinterpret_cast<const char*>(depth.data()), depth.size()*sizeof(float));
    if (!out) return 3;
    std::cout << submitted << '\n';
}
