# Figure 10 replay

## Portable replay

Install NumPy, SciPy and Matplotlib. The archive uses the ordinary little-endian Float64 representation. Run from any directory.

```sh
python scripts/replot_figure10.py review/figure10_display_checkpoint.npz figure10.pdf
```

The checkpoint contains a packed Boolean foreground mask, the archive and A3 normalized Float64 values at each visible native surface pixel, 320 profile rows, and the two independently estimated surface Q95 normalizers. Replay reproduced the manuscript PDF's rendered pixels byte for byte at 300 dpi on the original machine. Exact PDF hashes can differ because of creation metadata or fonts. The checkpoint SHA-256 is `75f9afb385e5ec902cd58cda996291ac8d7049f3a5dba0cb03510a7bd0337b88` (15,743,773 bytes).

The full native mesh supplied all 74,293,846 source triangles to one orthographic depth calculation. The same surface sampling positions were used for the three maps. The maps show the existing archive and A3 fields and their normalized difference, with independent barycentric projection and a 0.5 mm common-distance mask. The lines retain the original 1,280,000 A3 surface pairs and conditional Monte Carlo errors. The native depth display therefore has a different geometry from the A3 profile sampling domain.

## Full depth and projection replay

Install Python with NumPy, SciPy, Matplotlib, PyVista and VTK, plus a C++17 compiler. Use a little-endian machine. Set `FEA_MEG_ROOT` to the directory containing the following project-relative paths. Keep this supplement’s `scripts/`, `figures/` and `review/` adjacent. The runner writes a fresh checkpoint, exact face count, profile CSV and figures. The included frame checkpoint contains the exact original L0 affine frame and boundary bounds needed for the map, so the full L0 volume is optional.

| Input path relative to `FEA_MEG_ROOT` | SHA-256 |
| --- | --- |
| `output/current_native74_stress_2026-11-20/cache/vertices.f64` | `4f13df2eccd0a730411aff5fcd1e34210882490e3a32f969a6b2748f3197153a` |
| `output/current_native74_stress_2026-11-20/cache/triangles.u32` | `83b7c6bf0ff12c490b1948fa27ade2550e7d7e2458b9aa2528136e1162e3ed26` |
| `DICOM_16um/exports/surface_mesh_smoothed.bdf` | `c0b7830860a5c12caf68fce8bc2e34da4c1e19734489e57c61bdbc2b6db770d6` |
| `DICOM_16um/exports/von_mises_data_smoothed.txt` | `5617ee4bea61d8e459a4d4ca912cb6b4d1c90d109cf0353eb44a320bfcc00ee6` |
| `output/tooth_continuous_surfaces/cache/fe_v.npy` | `f1ac291a68969b0ece1b91e73a141ee6a6a61e1f44d8eee0c31c50f0dc27af95` |
| `output/tooth_continuous_surfaces/cache/fe_f.npy` | `e593a855b870e82086cc62b76605dc7c91e4b9772377ee6558c0cc192e8a6a3a` |
| `output/publication_validation_2026-11-12/data/local_A3/fields.npz` | `87293337ca3bc929661b61a4053a0649cc84a8d48af43053dc379bf1f0f57016` |
| `output/pdf/debunk_myth_preprint_2026-11-19/numerics/archive_axis_dense/samples.npz` | `d7333a0b47ffb36c7be7cddc2cbb58d6e8b1cd25c8f81f352b73619be082ad29` |

The measured scalar values are in the public [archive comparison ZIP](https://eliguli712.github.io/Antiterrastrae/publications/megalodon-archive-axis-data.zip). Its member `DICOM_16um/exports/von_mises_data_smoothed.txt` contains the authentic 191,031 COMSOL export rows. The large fixed-width `surface_mesh_smoothed.bdf` exists in the specimen working archive and is required for a full closest-facet reconstruction. The older public comparison ZIP lists that external requirement. Use the portable checkpoint to reproduce the published figure without the BDF. The exact A3 volume and boundary field are public in the [regional FE fields archive](https://github.com/Eliguli712/Antiterrastrae/releases/download/megalodon-ct-18um/DebunkMeg_Regional_Fields_A2_A3_2026-11-22.zip). The 1,280,000-draw file is the newer `archive_axis_dense` input listed above. The older public ZIP's 32,000-pair sample cannot substitute for it.

Build the legacy cache from the BDF. The parser reads both the fixed-width geometry and the original order. Coordinates are left in the archive frame. Figure 10 applies the z-only factor 18/16 during projection.

```sh
python scripts/build_archive_bdf_cache.py \
  "$FEA_MEG_ROOT/DICOM_16um/exports/surface_mesh_smoothed.bdf" \
  "$FEA_MEG_ROOT/output/tooth_continuous_surfaces/cache"
```

Use the exact [50 mm r5 source 3MF](https://github.com/Eliguli712/Antiterrastrae/releases/download/megalodon-independent-sizes-r5/Megalodon_Native74_50mm_Stress.3mf), SHA-256 `3a703c5eddcce42fa217b0e115ce23e95afab744c46976be98fcef22e29e3a3a`. The corresponding 50 mm display transform is intentionally left unapplied. The raster works in the original specimen-local geometry and discards the independent 3MF colour properties.

```sh
c++ -O3 -std=c++17 scripts/extract_native_geometry.cpp -o extract-native-geometry
unzip -p Megalodon_Native74_50mm_Stress.3mf 3D/3dmodel.model | \
  ./extract-native-geometry "$FEA_MEG_ROOT/output/current_native74_stress_2026-11-20/cache"
python scripts/render_native_axis_figure.py
```

The expected extracted native array dimensions are 37,951,699 by 3 coordinates and 74,293,846 by 3 triangle indices. Check the SHA-256 sums above before processing. The exact compact L0 frame file `review/figure10_axis_frame.npz` has SHA-256 `a955e98985f0e1aaecbaaffe35fb9ffccb47e68380a275c8bd4d4b98e795bf43`. The source L0 solution, if used instead, has SHA-256 `eadff84cb332b2d099697b43fa54b5662c0f8e4218fdcab95954327b17e0b9ed`.
