"""Write full native74 3MFs with explicit appearance or computed-field provenance."""
from pathlib import Path
import argparse,hashlib,json,subprocess,time,zipfile,xml.etree.ElementTree as ET
import numpy as np
from matplotlib import colormaps

O=Path(__file__).resolve().parents[1];ROOT=O.parents[1];C=O/'cache'
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--case',choices=['paper50','mr5_100'],required=True);a=p.parse_args()
NV,NF=37951699,74293846
size=50 if a.case=='paper50' else 100
props=json.loads((ROOT/f'output/current_native74_stress_2026-11-20/inputs/{size}mm-properties.json').read_text())
source=ROOT/'full_3D/Megalodon_FullCT_Native_Internal_74M_18um.3mf'
expected_vertices='eb8373f2ddf70e7ff98bc3a190f4db92e15b19e32313a529943d7c557886d4d5'
def sha(path):
 with path.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()
assert sha(source)==props['source_geometry_sha256']
if a.case=='paper50':
 rgb=np.memmap(C/'50mm-paper-reference-rgb.u8',dtype='u1',mode='r',shape=(NV,3))
 rough=np.memmap(C/'50mm-paper-reference-roughness.f32',dtype='<f4',mode='r',shape=(NV,))
 packed=np.empty(NV,dtype='u4')
 for first in range(0,NV,1000000):
  row=rgb[first:first+1000000].astype('u4');r=np.clip(np.rint((rough[first:first+len(row)]-.22)/.05),0,8).astype('u4')
  packed[first:first+len(row)]=(((row[:,0]<<16)|(row[:,1]<<8)|row[:,2])<<4)|r
 unique,index=np.unique(packed,return_inverse=True);del packed
 palette=np.column_stack([(unique>>20)&255,(unique>>12)&255,(unique>>4)&255]).astype('u1')
 roughness=.22+(unique&15)*.05
 title='Astraeus Krystallisia - 50 mm native74 - paper-reference appearance'
 metadata=json.loads((O/'review/appearance_projection.json').read_text())
 metadata.update({'kind':'reference appearance','numerical_stress_field':False,'material_palette_entries':len(palette),'roughness_quantization_step':.05})
 stem='Megalodon_50mm_Native74_Paper_Reference'
else:
 audit=json.loads((O/'review/mr5_100-render-audit.json').read_text());lo,hi=audit['colourbar_Pa']['min'],audit['colourbar_Pa']['max']
 values=np.memmap(C/'mr5_100-values-Pa.f32',dtype='<f4',mode='r',shape=(NV,))
 index=np.empty(NV,dtype='u4')
 for first in range(0,NV,1000000):
  v=np.asarray(values[first:first+1000000]);good=np.isfinite(v)
  ix=np.full(len(v),256,dtype='u4');ix[good]=np.minimum((np.clip((v[good]-lo)/(hi-lo),0,1)*256).astype('u4'),255)
  index[first:first+len(v)]=ix
 palette=np.vstack([np.rint(colormaps['turbo'](np.linspace(0,1,256))[:,:3]*255).astype('u1'),[154,163,173]]).astype('u1')
 roughness=np.ones(len(palette))*.62
 title='Astraeus Krystallisia - 100 mm native74 - independent MR5 FEM'
 metadata=dict(audit);metadata['kind']='independent nonlinear MR5 numerical field';metadata['numerical_stress_field']=True
 metadata['stress_data_format']={'member':'Metadata/stress_vertex_values_Pa.f32','dtype':'little-endian Float32','units':'Pa','count':NV,'ordering':'original native74 vertex order','unsupported_value':'NaN'}
 solver_run=Path(audit['source_solution']).parent
 solver_result=json.loads((solver_run/'result.json').read_text())
 assert solver_result['status']=='completed' and solver_result['tip_two_successive_2percent_checks_passed']
 metadata['FEM_case']=solver_result
 stem='Megalodon_100mm_Native74_MR5_Computed'
ci=C/f'{a.case}-export-colour-index.u32';np.asarray(index,dtype='<u4').tofile(ci);del index
subprocess.run(['c++','-O3','-std=c++17',str(O/'scripts/export_native74_colours.cpp'),'-o',str(C/'export_native74_colours')],check=True)
M='http://schemas.microsoft.com/3dmanufacturing/material/2015/02'
core='http://schemas.microsoft.com/3dmanufacturing/core/2015/02'
display=['<m:pbspeculardisplayproperties id="3">']
display += [f'<m:pbspecular name="Reference_{i}" specularcolor="#{"383838" if a.case=="paper50" else "000000"}" glossiness="{1-float(r):.6f}"/>' for i,r in enumerate(roughness)]
display.append('</m:pbspeculardisplayproperties><m:colorgroup id="2" displaypropertiesid="3">')
display += [f'<m:color color="#{int(r):02X}{int(g):02X}{int(b):02X}FF"/>' for r,g,b in palette]
display.append('</m:colorgroup>')
R=np.asarray(props['print_transform']['R']);T=np.asarray(props['print_transform']['T'])
transform=' '.join(format(float(x),'.17g')for x in np.r_[R.T.ravel(),T])
metadata.update({'nominal_height_mm':size,'source_vertices':NV,'source_triangles':NF,'source_geometry_sha256':props['source_geometry_sha256'],
 'source_original_vertex_xml_sha256':expected_vertices,'print_transform':props['print_transform'],'all_source_triangle_indices_and_order_preserved':True,'surface_reduction':False})
head=(f'<?xml version="1.0" encoding="UTF-8"?><model unit="millimeter" xmlns="{core}" xmlns:m="{M}" requiredextensions="m"><metadata name="Title">{title}</metadata><resources>'+''.join(display)+'<object id="1" type="model"><mesh><vertices>').encode()
resources=ET.fromstring(head.decode().split('<object id=')[0]+'</resources></model>')
colour_nodes=resources.findall('.//{'+M+'}color')
specular_nodes=resources.findall('.//{'+M+'}pbspecular')
assert len(colour_nodes)==len(specular_nodes)==len(palette)
assert all(set(c.attrib)=={'color'} for c in colour_nodes)
end=('</triangles></mesh></object></resources><build><item objectid="1" transform="'+transform+'"/></build></model>').encode()
(O/'models').mkdir(exist_ok=True);target=O/'models'/f'{stem}.3mf'
ct=b'<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="model" ContentType="application/vnd.ms-package.3dmanufacturing-3dmodel+xml"/><Default Extension="json" ContentType="application/json"/><Default Extension="f32" ContentType="application/octet-stream"/></Types>'
rels=b'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/></Relationships>'
model_hash=hashlib.sha256();vertex_hash=hashlib.sha256();vertices=0
with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=1,allowZip64=True)as z:
 z.writestr('[Content_Types].xml',ct);z.writestr('_rels/.rels',rels);z.writestr('Metadata/provenance.json',json.dumps(metadata,indent=2))
 if a.case=='mr5_100':
  z.write(C/'mr5_100-values-Pa.f32','Metadata/stress_vertex_values_Pa.f32')
  for name in ['result.json','history.json','manifest.json']:
   z.write(solver_run/name,'Metadata/FEM_'+name)
 with z.open('3D/3dmodel.model','w',force_zip64=True)as out:
  def write(b):out.write(b);model_hash.update(b)
  write(head)
  with zipfile.ZipFile(source)as original,original.open('3D/3dmodel.model')as f:
   carry=b'';inside=False
   while block:=f.read(8<<20):
    carry+=block;cut=carry.rfind(b'>')+1
    if not cut:continue
    block,carry=carry[:cut],carry[cut:]
    if not inside:
     if b'<vertices>'not in block:continue
     block=block.split(b'<vertices>',1)[1];inside=True
    done=b'</vertices>'in block
    body=block.split(b'</vertices>',1)[0]if done else block
    write(body);vertex_hash.update(body);vertices+=body.count(b'<vertex ')
    if done:break
  assert vertices==NV and vertex_hash.hexdigest()==expected_vertices
  write(b'</vertices><triangles>')
  with (O/f'review/{a.case}-export-faces.log').open('w')as err:
   process=subprocess.Popen([str(C/'export_native74_colours'),str(ROOT/'output/current_native74_stress_2026-11-20/cache/triangles.u32'),str(ci),str(len(palette))],stdout=subprocess.PIPE,stderr=err)
   while block:=process.stdout.read(8<<20):write(block)
   assert process.wait()==0
  write(end)
with zipfile.ZipFile(target)as z:
 with z.open('3D/3dmodel.model')as f:assert hashlib.file_digest(f,'sha256').hexdigest()==model_hash.hexdigest()
 for n in z.namelist():
  if n=='3D/3dmodel.model':continue
  with z.open(n)as f:
   while f.read(8<<20):pass
record={'status':'passed','case':a.case,'file':str(target.relative_to(O)),'bytes':target.stat().st_size,'sha256':sha(target),
 'source_vertices':NV,'source_triangles':NF,'original_vertex_xml_preserved':True,
 'all_ordered_face_indices_and_all_corner_property_indices_checked_during_export':True,
 'model_stream_readback_SHA256_and_zip_CRC_match':True,'palette_entries':len(palette),'embedded_numerical_stress':a.case=='mr5_100'}
(O/f'review/{a.case}-3mf-export-audit.json').write_text(json.dumps(record,indent=2))
print(json.dumps(record,indent=2),flush=True)
