"""Render archived 5 cm reference values or independently solved 10 cm values.

All native74 triangles are submitted. Appearance transfer and numerical stress
transfer are separate datasets and are never inferred from one another.
"""
from pathlib import Path
import argparse
import hashlib
import json
import math
import struct
import subprocess
import time
import numpy as np
from matplotlib import colormaps
from PIL import Image
from scipy.spatial import cKDTree

O=Path(__file__).resolve().parents[1]
ROOT=O.parents[1]
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--case',choices=['archive50','mr5_100'],required=True)
parser.add_argument('--solution',type=Path)
parser.add_argument('--reuse-field',action='store_true')
args=parser.parse_args()
NV,NF=37951699,74293846
C=O/'cache'
NATIVE=ROOT/'output/current_native74_stress_2026-11-20/cache'
v=np.memmap(NATIVE/'vertices.f64',dtype='<f8',mode='r',shape=(NV,3))
faces=np.memmap(NATIVE/'triangles.u32',dtype='<u4',mode='r',shape=(NF,3))
normals=np.memmap(ROOT/'output/scale_acrylic_2026-11-20/data/normals.f32',dtype='<f4',mode='r',shape=(NV,3))
size=50 if args.case=='archive50' else 100
props=json.loads((ROOT/f'output/current_native74_stress_2026-11-20/inputs/{size}mm-properties.json').read_text())
R,T=np.asarray(props['print_transform']['R']),np.asarray(props['print_transform']['T'])
field_path=C/f'{args.case}-values-Pa.f32'
field=np.memmap(field_path,dtype='<f4',mode='r+' if args.reuse_field else 'w+',shape=(NV,))
started=time.monotonic()
def log(*text):print(time.strftime('%H:%M:%S'),*text,flush=True)
def sha(p):
 with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()

if args.reuse_field:
 record=json.loads((O/f'review/{args.case}-render-audit.json').read_text())
 assert record['status']=='passed' and sha(field_path)==record['stress_file_sha256']
 lo,hi=record['colourbar_Pa']['min'],record['colourbar_Pa']['max']
elif args.case=='archive50':
 source=ROOT/'DICOM_16um/exports/von_mises_data_smoothed.txt'
 data=np.loadtxt(source,comments='%')
 tree=cKDTree(data[:,:3])
 for start in range(0,NV,300000):
  q=np.array(v[start:start+300000]);q[:,2]*=16/18
  _,ids=tree.query(q,workers=4)
  field[start:start+len(q)]=data[ids,3]
  if start%3000000==0:log('Mapped archived COMSOL values',start+len(q),'/',NV)
 lo,hi=56766.44283690944,326888.21709539363
 record={'case':args.case,'source':str(source.relative_to(ROOT)),'source_sha256':sha(source),
  'source_samples':len(data),'physical_interpretation':'Original archived Pa values projected onto a 50 mm display geometry; not a recalibrated 50 mm mechanical solve.',
  'coordinate_registration':'Native 18 um Z -> legacy forced 16 um Z for the archived sample lookup.',
  'new_FEM_solve':False,'stress_rescaled':False}
else:
 assert args.solution and args.solution.is_file()
 d=np.load(args.solution)
 p=d['points_m']*1000;t=d['tets'];boundary=d['boundary_faces']
 sums=np.zeros(len(p));weights=np.zeros(len(p))
 for a in range(4):
  np.add.at(sums,t[:,a],d['element_von_mises_Pa']*d['volumes_m3'])
  np.add.at(weights,t[:,a],d['volumes_m3'])
 nodal=sums/weights
 boundary_file=C/'100mm-MR5-boundary.bin'
 with boundary_file.open('wb')as stream:
  stream.write(struct.pack('<III',len(p),len(boundary),len(t)))
  stream.write(p.astype('<f8').tobytes());stream.write(nodal.astype('<f8').tobytes())
  stream.write(boundary.astype('<u4').tobytes());stream.write(t.astype('<u4').tobytes())
 factor=100/51.63315333301228
 projector=ROOT/'output/scale_acrylic_2026-11-20/scripts/project_boundary'
 process=subprocess.Popen([str(projector),str(boundary_file),str(.75*factor)],stdin=subprocess.PIPE,stdout=subprocess.PIPE)
 max_distance=0.;valid=0
 for start in range(0,NV,250000):
  q=np.array(v[start:start+250000])*factor
  process.stdin.write(struct.pack('<I',len(q)));process.stdin.write(q.astype('<f8').tobytes());process.stdin.flush()
  raw=bytearray();expected=len(q)*8
  while len(raw)<expected:
   block=process.stdout.read(expected-len(raw))
   assert block,'Projector exited early'
   raw.extend(block)
  a=np.frombuffer(raw,dtype='<f4')
  field[start:start+len(q)]=a[:len(q)]
  valid+=int(np.isfinite(a[:len(q)]).sum());max_distance=max(max_distance,float(a[len(q):].max()))
  if start%5000000==0:log('Projected independently solved MR5 stress',start+len(q),'/',NV)
 process.stdin.close();assert process.wait()==0
 good=field[np.isfinite(field)]
 lo,hi=np.quantile(good,[.02,.98]).tolist()
 assert hi>lo>=0
 record={'case':args.case,'source_solution':str(args.solution.resolve()),'source_solution_sha256':sha(args.solution),
  'physical_interpretation':'Independent SI 100 mm nonlinear MR5 closed-solid FEM with the explicitly approved replacement RMS constraints.',
  'new_FEM_solve':True,'stress_rescaled':False,'native_vertices_with_supported_projection':valid,
  'max_boundary_projection_distance_mm':max_distance,'display_limits_rule':'2nd/98th percentiles of finite projected values, the same linear percentile convention as the original paper renderer.'}
field.flush()
record['stress_file_sha256']=sha(field_path)
record['colourbar_Pa']={'min':lo,'max':hi,'scale':'linear','palette':'Matplotlib Turbo','lighting_for_quantitative_view':'unlit'}
record['vertices']=NV;record['triangles_per_view']=NF
record['paper_camera_convention']='Front +Y, Reverse -Y, Oblique yaw pi-0.49; matched to supplied paper, no image mirroring.'
record['numeric_values_inferred_from_appearance']=False

raster_dir=C/f'raster-{args.case}';raster_dir.mkdir(exist_ok=True)
binary=C/'raster_paper74'
assert binary.exists()
with (O/f'review/{args.case}-raster.log').open('w')as err:
 process=subprocess.Popen([str(binary),str(raster_dir)],stdin=subprocess.PIPE,stderr=err)
 for start in range(0,NF,1000000):
  ff=faces[start:start+1000000];ids,indices=np.unique(ff,return_inverse=True)
  xyz=v[ids]@R.T+T;xyz[:,2]-=size/2;xyz*=100/size;xyz[:,2]+=136.73910524340096
  n=normals[ids]@R.T;n/=np.maximum(np.linalg.norm(n,axis=1)[:,None],1e-30)
  values=np.asarray(field[ids]);rgb=colormaps['turbo'](np.clip((values-lo)/(hi-lo),0,1))[:,:3]
  rgb[~np.isfinite(values)]=np.array([154,163,173])/255
  rows=np.column_stack([xyz,n,rgb,np.full(len(ids),.42)]).astype('<f4')
  process.stdin.write(struct.pack('<III',len(ids),len(ff),0));process.stdin.write(rows.tobytes());process.stdin.write(indices.astype('<u4').tobytes())
  if start%10000000==0:log('Rendered field',args.case,start+len(ff),'/',NF)
 process.stdin.close();assert process.wait()==0
plots=[]
for mode in ['paper','unlit']:
 for view in ['front','oblique','reverse']:
  raw=raster_dir/f'{mode}-{view}.rgba';im=Image.frombytes('RGBA',(2400,3200),raw.read_bytes());box=im.getchannel('A').getbbox()
  assert box
  target=O/'plots'/f'{args.case}_{mode}_{view}.png';im.crop(box).save(target)
  plots.append({'file':str(target.relative_to(O)),'view':view,'mode':mode,'source_triangles':NF,'sha256':sha(target)})
  raw.unlink()
record['plots']=plots;record['wall_time_seconds']=time.monotonic()-started;record['status']='passed'
(O/f'review/{args.case}-render-audit.json').write_text(json.dumps(record,indent=2))
log('NUMERICAL FIELD RENDER COMPLETE',args.case)
