"""Independent 100 mm MR5 FEM with archived body load and explicit RMS.

The user authorized this open-source replacement for inaccessible COMSOL.
RMS averages use boundary-area weights, not COMSOL's unavailable automatic
geometrical-point selection. This difference is material for nonzero net loads.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '2')
os.environ.setdefault('OMP_NUM_THREADS', '2')
from pathlib import Path
import argparse
import gc
import hashlib
import json
import time
import numpy as np
from scipy import sparse, linalg
from scipy.sparse.linalg import cg
from scipy.spatial import cKDTree
from skfem import MeshTet
import pyamg

O = Path(__file__).resolve().parents[1]
ROOT = O.parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--run-dir', required=True, type=Path)
parser.add_argument('--max-level', type=int, default=4)
args = parser.parse_args()
OUT = args.run_dir.resolve()
OUT.mkdir(parents=True, exist_ok=True)
PARAM = dict(C10=12e6, C01=3e6, C20=2e6, C11=1.5e6, C02=.8e6, bulk=250e6)
MU = 2 * (PARAM['C10'] + PARAM['C01'])
LAM = PARAM['bulk'] - 2 * MU / 3
BODY = np.array([0., 0., 5e4])

def log(*values):
    print(time.strftime('%H:%M:%S'), *values, flush=True)

def save(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False))

def geometry(p, t):
    tri = p[t]
    edges = (tri[:,1:] - tri[:,:1]).transpose(0,2,1)
    det = np.linalg.det(edges)
    grad = np.empty((len(t),4,3))
    grad[:,1:] = np.linalg.inv(edges)
    grad[:,0] = -grad[:,1:].sum(axis=1)
    return np.abs(det) / 6, grad

def boundary(mesh):
    indices = mesh.boundary_facets()
    faces = mesh.facets[:,indices].T.copy()
    owner = mesh.f2t[0,indices]
    p = mesh.p.T
    tri = p[faces]
    normal = np.cross(tri[:,1] - tri[:,0], tri[:,2] - tri[:,0])
    inward = np.einsum('ij,ij->i', normal, p[mesh.t[:,owner].T].mean(1) - tri.mean(1)) > 0
    faces[inward] = faces[inward][:,[0,2,1]]
    return faces

def material(F):
    J = np.linalg.det(F)
    if np.any(J <= 0):
        raise ValueError('Nonpositive Jacobian')
    invT = np.linalg.inv(F).transpose(0,2,1)
    C = F.transpose(0,2,1) @ F
    I1 = np.trace(C,axis1=1,axis2=2)
    I2 = (I1**2 - np.einsum('eij,eji->e', C, C)) / 2
    j23, j43 = J**(-2/3), J**(-4/3)
    A, B = I1*j23 - 3, I2*j43 - 3
    W = PARAM['C10']*A + PARAM['C01']*B + PARAM['C20']*A*A + PARAM['C11']*A*B + PARAM['C02']*B*B + PARAM['bulk']/2*(J-1)**2
    d1 = PARAM['C10'] + 2*PARAM['C20']*A + PARAM['C11']*B
    d2 = PARAM['C01'] + PARAM['C11']*A + 2*PARAM['C02']*B
    P = 2*(d1*j23)[:,None,None]*(F - I1[:,None,None]/3*invT)
    P += 2*(d2*j43)[:,None,None]*(I1[:,None,None]*F - F@C - 2*I2[:,None,None]/3*invT)
    P += (PARAM['bulk']*(J-1)*J)[:,None,None]*invT
    return W, P, J

def material_checks():
    eye = np.eye(3)[None]
    W, P, _ = material(eye)
    assert abs(float(W[0])) < 1e-8 and np.max(np.abs(P)) < 1e-8
    F = np.array([[[1.012,.003,-.002],[.001,.991,.004],[-.003,.002,1.006]]])
    W, P, _ = material(F)
    finite = np.empty((3,3))
    step = 2e-6
    for i in range(3):
        for j in range(3):
            d = np.zeros_like(F); d[0,i,j] = step
            finite[i,j] = (material(F+d)[0][0] - material(F-d)[0][0]) / (2*step)
    error = float(np.linalg.norm(finite-P[0]) / np.linalg.norm(P[0]))
    assert error < 2e-7, error
    angle = .31
    R = np.array([[np.cos(angle),-np.sin(angle),0],[np.sin(angle),np.cos(angle),0],[0,0,1]])
    WR, PR, _ = material(R[None] @ F)
    objective = float(np.linalg.norm(PR-R[None]@P) / np.linalg.norm(P))
    assert np.allclose(WR,W,atol=1e-6,rtol=1e-10) and objective < 1e-10
    Fv = np.eye(3)[None]*1.0001
    _, Pv, Jv = material(Fv)
    stress = Pv@Fv.transpose(0,2,1)/Jv[:,None,None]
    expected = PARAM['bulk']*(Jv[0]-1)
    assert np.allclose(stress[0], np.eye(3)*expected, atol=1e-5, rtol=1e-9)
    return {'energy_gradient_relative_error':error,'objectivity_relative_error':objective,
        'identity_and_uniform_dilatation_checks':'passed'}

def rms_operator(p, faces):
    area = np.linalg.norm(np.cross(p[faces[:,1]]-p[faces[:,0]], p[faces[:,2]]-p[faces[:,0]]),axis=1)/2
    weights = np.zeros(len(p))
    for corner in range(3):
        np.add.at(weights, faces[:,corner], area/3)
    weights /= weights.sum()
    center = np.einsum('i,ij->j', weights,p)
    length = float(np.max(np.ptp(p,axis=0)))
    r = (p-center)/length
    C = np.zeros((6,3*len(p)))
    R = np.zeros((3*len(p),6))
    for j in range(3):
        C[j,j::3] = weights
        R[j::3,j] = 1
    C[3,1::3] = -weights*r[:,2]; C[3,2::3] = weights*r[:,1]
    C[4,0::3] = weights*r[:,2]; C[4,2::3] = -weights*r[:,0]
    C[5,0::3] = -weights*r[:,1]; C[5,1::3] = weights*r[:,0]
    R[1::3,3] = -r[:,2]; R[2::3,3] = r[:,1]
    R[0::3,4] = r[:,2]; R[2::3,4] = -r[:,0]
    R[0::3,5] = -r[:,1]; R[1::3,5] = r[:,0]
    CR = C@R
    assert np.linalg.cond(CR) < 1e4
    # QR chooses six independent gauge DOFs solely to invert the singular K0.
    # All six gauge constraints are subsequently removed by the exact rigid
    # correction; the physical constraints are only C u = 0.
    _, _, pivots = linalg.qr(R.T, mode='economic', pivoting=True, check_finite=False)
    gauge = np.asarray(pivots[:6])
    return C, R, CR, gauge, weights, center, length

def assemble(p,t,vol,grad):
    K = sparse.csr_matrix((3*len(p),3*len(p)))
    for first in range(0,len(t),16000):
        tt=t[first:first+16000];g=grad[first:first+16000];vv=vol[first:first+16000]
        dofs=(3*tt[:,:,None]+np.arange(3)).reshape(len(tt),12)
        rows=np.repeat(dofs,12,axis=1).ravel().astype('i4')
        cols=np.tile(dofs,(1,12)).ravel().astype('i4')
        data=np.empty((len(tt),12,12))
        for a in range(4):
            for b in range(4):
                x,y=g[:,a],g[:,b]
                block=LAM*x[:,:,None]*y[:,None,:]+MU*y[:,:,None]*x[:,None,:]
                block += MU*np.einsum('ij,ij->i',x,y)[:,None,None]*np.eye(3)
                data[:,3*a:3*a+3,3*b:3*b+3]=vv[:,None,None]*block
        K += sparse.coo_matrix((data.ravel(),(rows,cols)),shape=K.shape).tocsr()
    return K

def fields(p,t,vol,grad,u,forces=True):
    internal=np.zeros_like(p) if forces else None
    vm=np.empty(len(t));energy=np.empty(len(t));strain=np.empty(len(t));minimum=1.
    for first in range(0,len(t),30000):
        tt=t[first:first+30000];g=grad[first:first+30000];vv=vol[first:first+30000]
        F=np.eye(3)+np.einsum('eai,eaj->eij',u[tt],g)
        W,P,J=material(F)
        sigma=P@F.transpose(0,2,1)/J[:,None,None]
        dev=sigma-np.trace(sigma,axis1=1,axis2=2)[:,None,None]/3*np.eye(3)
        vm[first:first+len(tt)]=np.sqrt(1.5*np.einsum('eij,eij->e',dev,dev))
        energy[first:first+len(tt)]=W*vv
        strain[first:first+len(tt)]=np.linalg.norm((F.transpose(0,2,1)@F-np.eye(3))/2,axis=(1,2))
        minimum=min(minimum,float(J.min()))
        if forces:
            local=np.einsum('eij,eaj->eai',P,g)*vv[:,None,None]
            for a in range(4):np.add.at(internal,tt[:,a],local[:,a])
    return internal,vm,energy,strain,minimum

def qweighted(x,w,q):
    order=np.argsort(x);cs=np.cumsum(w[order])
    return float(x[order[min(np.searchsorted(cs,q*cs[-1]),len(order)-1)]])

class ParentLocator:
    def __init__(self,p,t):
        self.origin=p[t[:,0]]
        self.inverse=np.linalg.inv((p[t[:,1:]]-self.origin[:,None]).transpose(0,2,1))
        self.tree=cKDTree(p[t].mean(1))
        self.count=len(t)
    def __call__(self,points):
        result=np.full(len(points),-1,dtype='i4')
        for k in [16,64,256,1024]:
            todo=np.flatnonzero(result<0)
            if not len(todo):break
            for start in range(0,len(todo),10000):
                ids=todo[start:start+10000]
                candidates=self.tree.query(points[ids],k=min(k,self.count),workers=2)[1]
                bary=np.einsum('nkij,nkj->nki',self.inverse[candidates],points[ids,None]-self.origin[candidates])
                inside=(bary.min(2)>=-2e-9)&(bary.sum(2)<=1+2e-9)
                hit=inside.any(1)
                result[ids[hit]]=candidates[hit,inside[hit].argmax(1)]
        assert np.all(result>=0),'Refined centroid outside frozen parent domain'
        return result

def solve_mesh(mesh):
    p,t=mesh.p.T.copy(),mesh.t.T.copy()
    faces=boundary(mesh);vol,grad=geometry(p,t)
    C,R,CR,gauge,weights,center,length=rms_operator(p,faces)
    K=assemble(p,t,vol,grad)
    rigid_error=float(np.linalg.norm(K@R)/(np.linalg.norm(K.data)*np.linalg.norm(R)))
    assert rigid_error < 1e-12
    affine=np.array([[.0002,.00003,-.00001],[.00004,-.0001,.00002],[.00001,-.00002,.00006]])
    eps=(affine+affine.T)/2
    sigma=LAM*np.trace(eps)*np.eye(3)+2*MU*eps
    area_vectors=np.cross(p[faces[:,1]]-p[faces[:,0]],p[faces[:,2]]-p[faces[:,0]])/2
    exact=np.zeros_like(p)
    for a in range(3):np.add.at(exact,faces[:,a],(area_vectors@sigma.T)/3)
    affine_u=(p@affine.T).ravel()
    patch_error=float(np.linalg.norm(K@affine_u-exact.ravel())/np.linalg.norm(exact))
    assert patch_error<1e-9,patch_error
    force=np.zeros_like(p)
    for a in range(4):np.add.at(force,t[:,a],vol[:,None]*BODY/4)
    force=force.ravel()
    free=np.setdiff1d(np.arange(len(force)),gauge)
    A=K[free][:,free].tocsr()
    amg=pyamg.smoothed_aggregation_solver(A,B=R[free],symmetry='symmetric',max_coarse=100)
    pre=amg.aspreconditioner()
    def inverse(rhs):
        multipliers=np.linalg.solve(CR.T,R.T@rhs)
        balanced=rhs-C.T@multipliers
        answer,info=cg(A,balanced[free],M=pre,rtol=2e-11,atol=1e-15,maxiter=1500)
        assert info==0,('CG',info)
        u=np.zeros(len(rhs));u[free]=answer
        u-=R@np.linalg.solve(CR,C@u)
        assert np.linalg.norm(C@u) < 1e-11
        return u
    linear=inverse(force)
    linear_multipliers=np.linalg.solve(CR.T,R.T@force)
    linear_residual=K@linear-force+C.T@linear_multipliers
    lin_error=float(np.linalg.norm(linear_residual)/np.linalg.norm(force))
    assert lin_error<2e-7,lin_error
    u=np.zeros_like(force)
    trace=[]
    for iteration in range(12):
        internal,vm,energy,strain,jmin=fields(p,t,vol,grad,u.reshape(-1,3))
        residual=force-internal.ravel()
        multipliers=np.linalg.solve(CR.T,R.T@residual)
        projected=residual-C.T@multipliers
        error=float(np.linalg.norm(projected)/np.linalg.norm(force))
        trace.append({'iteration':iteration,'constrained_relative_residual':error,'energy_J':float(energy.sum()),'J_min':jmin})
        log('MR5 iteration',iteration,'residual',error)
        if error<2e-7:break
        du=inverse(residual)
        old_potential=float(energy.sum()-u@force)
        accepted=False
        for cut in range(12):
            candidate=u+du*2**(-cut)
            try:
                _,_,ee,_,_=fields(p,t,vol,grad,candidate.reshape(-1,3),forces=False)
                potential=float(ee.sum()-candidate@force)
                # Constitutive energy has subtraction noise near F=I.
                if potential<=old_potential+max(1e-13,abs(old_potential)*2e-6):
                    u=candidate;accepted=True;break
            except ValueError:pass
        assert accepted,'MR5 line search failed'
    assert trace[-1]['constrained_relative_residual']<2e-7,trace
    reaction=(-C.T@multipliers).reshape(-1,3)
    balance=float(np.linalg.norm(reaction.sum(0)+force.reshape(-1,3).sum(0))/np.linalg.norm(force.reshape(-1,3).sum(0)))
    constraint=float(np.linalg.norm(C@u))
    work_error=float(abs(u@internal.ravel()-u@force)/max(abs(u@force),1e-30))
    assert balance<1e-8 and constraint<1e-11 and work_error<1e-6
    metrics={'nodes':len(p),'tetrahedra':len(t),'boundary_faces':len(faces),
        'constrained_relative_residual':trace[-1]['constrained_relative_residual'],
        'force_balance_relative_error':balance,'constraint_norm_m':constraint,
        'virtual_work_relative_error':work_error,'linear_K_rigid_null_relative_error':rigid_error,
        'full_affine_traction_patch_relative_error':patch_error,
        'linear_constrained_solve_relative_residual':lin_error,
        'applied_force_N':force.reshape(-1,3).sum(0).tolist(),'reaction_force_N':reaction.sum(0).tolist(),
        'energy_J':float(energy.sum()),'max_displacement_m':float(np.linalg.norm(u.reshape(-1,3),axis=1).max()),
        'J_min':jmin,'max_green_strain_norm':float(strain.max()),'volume_m3':float(vol.sum()),
        'max_element_von_mises_Pa':float(vm.max()),'volume_weighted_Q95_Pa':qweighted(vm,vol,.95),
        'volume_weighted_Q99_Pa':qweighted(vm,vol,.99),'quasi_Newton_trace':trace,
        'rigid_constraint_definition':'Zero boundary-area-weighted mean displacement and reference-centred mean rotational displacement; six constraints; no root clamps.',
        'COMSOL_automatic_constraint_reproduced':False}
    del A,amg,pre,K,C,R;gc.collect()
    return p,t,faces,u.reshape(-1,3),vm,vol,energy,strain,metrics

checks=material_checks()
source=ROOT/'output/scale_acrylic_2026-11-20/inputs/solution.npz'
d=np.load(source)
p=d['points_m']*np.array([1.,1.,18/16])
t=d['tets'].astype('i4')
native_height=51.63315333301228
p*=100/native_height
mesh=MeshTet(p.T,t.T,sort_t=False)
ref=np.load(ROOT/'output/scale_acrylic_2026-11-20/inputs/qf_solution.npz')
basis=ref['basis']
principal0=p@basis
axis_min=principal0[:,1].min();axis_span=np.ptp(principal0[:,1])
base_tip=((principal0[t].mean(1)[:,1]-axis_min)/axis_span)<=.12
base_vol,_=geometry(p,t)
fixed_tip_volume=float(base_vol[base_tip].sum())
parents=ParentLocator(p,t)
history=[];streak=0
for level in range(args.max_level+1):
    log('Assemble independent 100 mm MR5 level',level,'nodes',mesh.p.shape[1],'tets',mesh.t.shape[1])
    p,t,faces,u,vm,vol,energy,strain,metrics=solve_mesh(mesh)
    metrics['level']=level
    # Fixed macroscopic apex ROI in the same calibrated native principal frame.
    parent=parents(p[t].mean(1))
    tip=base_tip[parent]
    assert abs(vol[tip].sum()/fixed_tip_volume-1)<1e-9
    metrics['tip_roi']={'volume_m3':float(vol[tip].sum()),'Q95_Pa':qweighted(vm[tip],vol[tip],.95),
        'Q99_Pa':qweighted(vm[tip],vol[tip],.99),'energy_J':float(energy[tip].sum())}
    if history:
        keys=['Q95_Pa','Q99_Pa','energy_J']
        change={key:100*abs(metrics['tip_roi'][key]-history[-1]['tip_roi'][key])/max(abs(history[-1]['tip_roi'][key]),1e-30) for key in keys}
        metrics['tip_last_step_change_percent']=change
        # Also guard total energy for boundary-area RMS convergence.
        stable=max(change.values())<2 and abs(metrics['energy_J']/history[-1]['energy_J']-1)<.02
        streak=streak+1 if stable else 0
    history.append(metrics)
    save(OUT/'history.json',history)
    np.savez_compressed(OUT/'100mm_MR5_solution.npz',points_m=p,tets=t,displacement_m=u,
        element_von_mises_Pa=vm,volumes_m3=vol,boundary_faces=faces,element_energy_J=energy,
        green_strain_norm=strain,basis=basis,parent_L0=parent,tip_element_indices=np.flatnonzero(tip))
    save(OUT/'latest_metrics.json',metrics)
    if streak>=2 and level>=3:break
    if level==args.max_level:break
    if level==0:
        mesh=mesh.refined()
    else:
        # Refinement follows geometry and energy density, not a target image.
        density=energy/vol
        mark=tip | (density>=np.quantile(density,.75))
        mesh=mesh.refined(np.flatnonzero(mark).astype('i4'))
    del p,t,faces,u,vm,vol,energy,strain;gc.collect()

summary={'status':'completed','solver':'Independent open-source P1-tetrahedral compressible MR5, constrained quasi-Newton, AMG/CG linear steps',
    'physical_nominal_native_height_mm':100,'source_native_height_mm':native_height,
    'coordinate_calibration':'Archived legacy mesh Z recalibrated 16 -> declared 18 um, then SI 100 mm native principal height.',
    'material_Pa':PARAM,'body_force_N_per_m3':BODY.tolist(),
    'boundary_conditions':'Six boundary-area-weighted mean-displacement/rotation constraints; documented replacement for inaccessible COMSOL automatic point selection.',
    'exact_COMSOL_reproduction_claimed':False,'stress_rescaling_used':False,
    'stored_displacement_or_stress_used_as_answer':False,'constitutive_checks':checks,
    'tip_two_successive_2percent_checks_passed':streak>=2,'final':history[-1],'levels_solved':len(history),
    'scope':'Closed-solid proxy mechanics; native74 is the display surface, not a pore-resolved volume domain.',
    'legacy_5cm_paper_reference':'Original appearance is retained separately; archived metre/mm mismatch prevents treating its stresses as a calibrated physical 50 mm validation.'}
save(OUT/'result.json',summary)
log('MR5 COMPUTATION COMPLETE',len(history),'solved meshes; tip stable',streak>=2)
