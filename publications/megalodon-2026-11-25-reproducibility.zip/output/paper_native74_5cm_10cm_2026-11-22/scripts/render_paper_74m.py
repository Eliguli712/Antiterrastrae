"""Render all native74 faces with the original paper 3MF reference appearance.

This is explicitly an appearance projection, never a numerical stress solve.
The preserved published 5 cm model provides the exact geometry and transform.
"""
from pathlib import Path
import hashlib
import json
import struct
import subprocess
import time
import numpy as np
from PIL import Image
from scipy.spatial import cKDTree

O = Path(__file__).resolve().parents[1]
ROOT = O.parents[1]
C = O / 'cache'
SOURCE = ROOT / 'output/tooth_continuous_surfaces/cache'
NATIVE = ROOT / 'output/current_native74_stress_2026-11-20/cache'
NV, NF = 37951699, 74293846
start_time = time.monotonic()

def sha(p):
    with p.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def log(*values):
    print(time.strftime('%H:%M:%S'), *values, flush=True)

meta = json.loads((SOURCE / 'stress_source.json').read_text())
source_model = ROOT / 'full_3D/Megalodon_FullCT_StressColors_PBR.3mf'
assert sha(source_model) == meta['sha256']
props = json.loads((ROOT / 'output/current_native74_stress_2026-11-20/inputs/50mm-properties.json').read_text())
v = np.memmap(NATIVE / 'vertices.f64', dtype='<f8', mode='r', shape=(NV, 3))
f = np.memmap(NATIVE / 'triangles.u32', dtype='<u4', mode='r', shape=(NF, 3))
source_v = np.load(SOURCE / 'web_original_ct_vertices.npy', mmap_mode='r')
source_f = np.load(SOURCE / 'natural_full_faces.npy', mmap_mode='r')
source_rgb = np.load(SOURCE / 'stress_area_weighted_vertex_rgb.npy', mmap_mode='r')
appearance = np.load(SOURCE / 'stress_face_appearance.npy', mmap_mode='r')
assert source_v.shape == (16272624, 3) and source_f.shape == (32687264, 3)
assert source_rgb.shape == source_v.shape

rough_path = C / 'paper_source_roughness.f32'
if not rough_path.exists():
    weights = np.zeros(len(source_v), dtype='f4')
    total = np.zeros(len(source_v), dtype='f4')
    levels = np.asarray(meta['source_metadata']['specular_model']['roughness_levels'])
    for first in range(0, len(source_f), 250000):
        ff = source_f[first:first + 250000]
        tri = source_v[ff]
        area = (np.linalg.norm(np.cross(tri[:,1] - tri[:,0], tri[:,2] - tri[:,0]), axis=1) / 2).astype('f4')
        rough = levels[appearance[first:first + len(ff), 0] - 100]
        for corner in range(3):
            np.add.at(weights, ff[:,corner], area)
            np.add.at(total, ff[:,corner], (area * rough).astype('f4'))
    roughness = np.clip(total / np.maximum(weights, 1e-30), .22, .62).astype('<f4')
    roughness.tofile(rough_path)
    del weights, total, roughness
roughness = np.memmap(rough_path, dtype='<f4', mode='r', shape=(len(source_v),))

rgb_path = C / '50mm-paper-reference-rgb.u8'
native_rough_path = C / '50mm-paper-reference-roughness.f32'
projection_audit = O / 'review/appearance_projection.json'
if not (rgb_path.exists() and native_rough_path.exists() and projection_audit.exists()):
    log('Building spatial paper-appearance lookup; target geometry remains unreduced')
    # A uniform spatial lookup avoids expensive searches deep inside cavities
    # absent from the older paper mesh. Each occupied 0.10 mm source cell keeps
    # an actual original vertex/material sample. This only limits appearance
    # transfer, never the 74M geometry or the FEM calculation.
    low = np.asarray(source_v).min(axis=0)
    dims = np.ceil((np.asarray(source_v).max(axis=0)-low)/.10).astype('i8')+2
    keys = np.empty(len(source_v),dtype='u8')
    for first in range(0,len(source_v),500000):
        cell=np.floor((source_v[first:first+500000]-low)/.10).astype('u8')
        keys[first:first+len(cell)] = cell[:,0] + np.uint64(dims[0])*(cell[:,1]+np.uint64(dims[1])*cell[:,2])
    _, representatives = np.unique(keys,return_index=True)
    del keys
    tree = cKDTree(source_v[representatives])
    log('Appearance lookup samples',len(representatives))
    rgb = np.memmap(rgb_path, dtype='u1', mode='w+', shape=(NV, 3))
    rough = np.memmap(native_rough_path, dtype='<f4', mode='w+', shape=(NV,))
    maximum = 0.0
    sums = 0.0
    for first in range(0, NV, 250000):
        points = np.array(v[first:first + 250000])
        points[:,2] *= 16 / 18
        distances, nearest = tree.query(points, workers=4)
        nearest = representatives[nearest]
        rgb[first:first + len(points)] = source_rgb[nearest]
        rough[first:first + len(points)] = roughness[nearest]
        maximum = max(maximum, float(distances.max()))
        sums += float(distances.sum())
        if first % 5000000 == 0:
            log('Appearance projected', first + len(points), '/', NV)
    rgb.flush()
    rough.flush()
    del tree, rgb, rough
    record = {'source_paper_3MF_sha256': meta['sha256'], 'native_geometry_sha256': props['source_geometry_sha256'],
        'target_5cm_3MF': 'Megalodon_Native74_50mm_Stress.3mf',
        'vertices_projected': NV, 'source_appearance_vertices': len(source_v),
        'method': 'Nearest original paper vertex/material sample from a uniform 0.10 mm occupied source-cell lookup; target vertices and faces are never reduced.',
        'appearance_lookup_source_mm': .10, 'appearance_lookup_samples': len(representatives),
        'registration': 'Native declared 18 um Z -> original forced 16 um Z by factor 16/18 for appearance lookup only.',
        'geometry_changed': False, 'maximum_lookup_distance_source_mm': maximum,
        'mean_lookup_distance_source_mm': sums / NV,
        'numerical_stress_values_inferred_from_colour': False, 'new_FEM_solve': False,
        'data_scope': 'Paper-referenced surface appearance; does not represent a computed native-pore stress field.'}
    projection_audit.write_text(json.dumps(record, indent=2))
rgb = np.memmap(rgb_path, dtype='u1', mode='r', shape=(NV, 3))
rough = np.memmap(native_rough_path, dtype='<f4', mode='r', shape=(NV,))
normals = np.memmap(ROOT / 'output/scale_acrylic_2026-11-20/data/normals.f32', dtype='<f4', mode='r', shape=(NV,3))
R = np.asarray(props['print_transform']['R'])
T = np.asarray(props['print_transform']['T'])
if not (C / 'raster_paper74').exists() or (C / 'raster_paper74').stat().st_mtime < (O / 'scripts/raster_paper74.cpp').stat().st_mtime:
    subprocess.run(['c++', '-O3', '-std=c++17', str(O / 'scripts/raster_paper74.cpp'), '-o', str(C / 'raster_paper74')], check=True)
raster_dir = C / 'raster-50'
raster_dir.mkdir(exist_ok=True)
with (O / 'review/full74-raster.log').open('w') as err:
    raster = subprocess.Popen([str(C / 'raster_paper74'), str(raster_dir)], stdin=subprocess.PIPE, stderr=err)
    for first in range(0, NF, 1000000):
        ff = f[first:first + 1000000]
        ids, local = np.unique(ff, return_inverse=True)
        points = v[ids] @ R.T + T
        points[:,2] -= 25
        points *= 2
        points[:,2] += 136.73910524340096
        n = normals[ids] @ R.T
        n /= np.maximum(np.linalg.norm(n, axis=1)[:,None], 1e-30)
        data = np.column_stack([points, n, rgb[ids] / 255, rough[ids]]).astype('<f4')
        assert data.shape[1] == 10
        raster.stdin.write(struct.pack('<III', len(ids), len(ff), 0))
        raster.stdin.write(data.tobytes())
        raster.stdin.write(local.astype('<u4').tobytes())
        if first % 10000000 == 0:
            log('Rendered full native faces', first + len(ff), '/', NF)
    raster.stdin.close()
    assert raster.wait() == 0

records = []
for mode in ['paper', 'unlit']:
    for view in ['front', 'oblique', 'reverse']:
        raw = raster_dir / f'{mode}-{view}.rgba'
        im = Image.frombytes('RGBA', (2400, 3200), raw.read_bytes())
        box = im.getchannel('A').getbbox()
        assert box and box[0] > 0 and box[1] > 0 and box[2] < 2400 and box[3] < 3200
        path = O / 'plots' / f'5cm_native74_{mode}_{view}.png'
        im.crop(box).save(path)
        records.append({'view': view, 'mode': mode, 'file': str(path.relative_to(O)), 'pixels': list(im.crop(box).size),
            'faces_submitted_to_camera': NF, 'sha256': sha(path)})
        raw.unlink()
audit = {'status': 'passed', 'nominal_height_mm': 50, 'actual_height_mm': props['actual_dimensions_mm'][2],
    'vertices': NV, 'source_triangles_per_view': NF, 'surface_decimation': False,
    'paper_camera_convention': 'Front: +Y view (yaw pi), Reverse: -Y view (yaw 0), Oblique: yaw pi-0.49; labels matched to supplied paper landmarks.',
    'paper_appearance_render': 'Reference RGB/roughness projected from complete original paper-coloured 3MF to unchanged native74 geometry.',
    'lighting': 'Soft dielectric approximate shading plus a separate unlit reference-colour render.',
    'source_paper_colours_are_numeric_FEM': False, 'new_FEM_solve': False,
    'plots': records, 'wall_time_seconds': time.monotonic() - start_time}
(O / 'review/5cm_full74_render_audit.json').write_text(json.dumps(audit, indent=2))
log('COMPLETE: all 74,293,846 triangles rendered from both sides and obliquely')
