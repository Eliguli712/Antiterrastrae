"""Compose final full-native visualizations and the documented MR5 result."""
from pathlib import Path
import argparse,hashlib,json,shutil,zipfile
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import colors,cm
from matplotlib.font_manager import FontProperties
from matplotlib.backends.backend_pdf import PdfPages
import numpy as np
from PIL import Image

O=Path(__file__).resolve().parents[1];ROOT=O.parents[1]
p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);a=p.parse_args();RUN=a.run.resolve()
result=json.loads((RUN/'result.json').read_text());manifest=json.loads((RUN/'manifest.json').read_text())
assert result['status']=='completed' and manifest['run']['status']=='completed'
assert result['tip_two_successive_2percent_checks_passed']
audits={name:json.loads((O/f'review/{name}').read_text())for name in ['5cm_full74_render_audit.json','archive50-render-audit.json','mr5_100-render-audit.json','paper50-3mf-export-audit.json','mr5_100-3mf-export-audit.json']}
assert all(d['status']=='passed'for d in audits.values())
F=O/'figures';F.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':14,
 'text.color':'#17394d','axes.labelcolor':'#17394d','xtick.color':'#17394d','ytick.color':'#17394d',
 'figure.facecolor':'#eef4f8','savefig.facecolor':'#eef4f8','pdf.fonttype':42})
fontpath=ROOT/'output/acrylic_baskerville_v4_2026-11-20/review/font_cache/Baskerville-Italic.ttf'
serif=FontProperties(fname=str(fontpath))
def image(prefix,view):return np.asarray(Image.open(O/f'plots/{prefix}_{view}.png').convert('RGBA'))
def header(fig,subtitle):
 fig.text(.05,.958,'Astraeus Krystallisia',fontproperties=serif,fontsize=31,va='top',color='#172d3c')
 fig.text(.052,.898,subtitle,fontsize=16,va='top',color='#466276')
def bar(fig,bounds,record):
 lo,hi=record['colourbar_Pa']['min'],record['colourbar_Pa']['max']
 ax=fig.add_axes(bounds);cb=fig.colorbar(cm.ScalarMappable(norm=colors.Normalize(lo,hi),cmap='turbo'),cax=ax,orientation='horizontal',extend='both',extendfrac=.025)
 ticks=np.linspace(lo,hi,6);cb.set_ticks(ticks);cb.set_ticklabels([f'{v:,.0f}'for v in ticks]);cb.ax.tick_params(labelsize=11)
 cb.set_label('Von Mises stress (Pa) | linear',fontsize=12,labelpad=8)
 cb.outline.set_linewidth(.6)
 return lo,hi
figs=[]
fig=plt.figure(figsize=(18,9.7));header(fig,'5 cm | full native 74M 3MF geometry | supplied paper-reference appearance')
grid=fig.add_gridspec(1,3,left=.035,right=.965,top=.805,bottom=.14,wspace=.04)
for j,view in enumerate(['front','oblique','reverse']):
 ax=fig.add_subplot(grid[0,j]);ax.imshow(image('5cm_native74_paper',view),interpolation='nearest');ax.set_axis_off();ax.set_title(view.title(),fontweight='bold',fontsize=19,pad=10)
fig.text(.052,.085,'74,293,846 source triangles in every view | 37,951,699 vertices | no surface reduction',fontsize=12,color='#36556a')
fig.text(.052,.045,'Paper-referenced material appearance projected onto native geometry. This coloured appearance is not a new numerical stress solution.',fontsize=11,color='#526b7a')
fig.savefig(F/'5cm_74M_Paper_Reference_Three_Views.png',dpi=300);figs.append(fig)

for key,prefix,subtitle,note,name in [
 ('archive50-render-audit.json','archive50_unlit','5 cm display | original archived COMSOL von Mises values on all native74 faces',
  'Archived Pa values retained unchanged. The physical 50 mm calibration of the legacy model is not certified.',
  '5cm_74M_Archived_COMSOL_Three_Views'),
 ('mr5_100-render-audit.json','mr5_100_unlit','10 cm | independently calculated nonlinear MR5 FEM | full native74 display',
  'SI 100 mm geometry; body load 50,000 N/m3; explicit boundary-area RMS constraints; closed-solid mechanical proxy.',
  '10cm_74M_MR5_Computed_Three_Views')]:
 fig=plt.figure(figsize=(18,10));header(fig,subtitle)
 grid=fig.add_gridspec(1,3,left=.035,right=.965,top=.81,bottom=.24,wspace=.04)
 for j,view in enumerate(['front','oblique','reverse']):
  ax=fig.add_subplot(grid[0,j]);ax.imshow(image(prefix,view),interpolation='nearest');ax.set_axis_off();ax.set_title(view.title(),fontweight='bold',fontsize=19,pad=10)
 bar(fig,[.22,.145,.56,.022],audits[key])
 fig.text(.052,.065,note,fontsize=11,color='#36556a')
 fig.text(.052,.031,'74,293,846 triangles per view | all native vertices mapped | unlit colours | 2nd/98th-percentile limits; raw values retained.',fontsize=10,color='#526b7a')
 fig.savefig(F/(name+'.png'),dpi=300);figs.append(fig)

# A front/reverse comparison retains independent legends to avoid equating the
# uncalibrated legacy case with the new physical 100 mm calculation.
fig=plt.figure(figsize=(16,15));header(fig,'Archived reference and independently solved 10 cm MR5 | full native 74M surface')
for row,(prefix,label,record)in enumerate([
 ('archive50_unlit','5 cm display / archived COMSOL reference',audits['archive50-render-audit.json']),
 ('mr5_100_unlit','10 cm / independently solved MR5',audits['mr5_100-render-audit.json'])]):
 bottom=.49 if row==0 else .09
 for col,view in enumerate(['front','reverse']):
  ax=fig.add_axes([.10+col*.43,bottom+.055,.36,.275]);ax.imshow(image(prefix,view),interpolation='nearest');ax.set_axis_off();ax.set_title(view.title(),fontsize=17,fontweight='bold',pad=6)
 fig.text(.07,bottom+.355,label,fontsize=17,fontweight='bold')
 bar(fig,[.23,bottom+.02,.54,.014],record)
fig.text(.052,.05,'Matched display height; separate Pa limits shown. 10 cm uses the documented replacement RMS constraints.',fontsize=11,color='#36556a')
fig.text(.052,.023,'5 cm is a projection of the archived field; 10 cm is a fresh SI calculation. Native-pore-resolved mechanics and point-peak convergence are not claimed.',fontsize=9,color='#526b7a')
fig.savefig(F/'5cm_10cm_Front_Reverse_Documented_Comparison.png',dpi=300);figs.append(fig)

history=json.loads((RUN/'history.json').read_text());n=np.array([h['tetrahedra']for h in history])
fig=plt.figure(figsize=(16,9));header(fig,'10 cm MR5 | frozen macroscopic tip ROI | refinement and numerical checks')
grid=fig.add_gridspec(1,3,left=.07,right=.95,top=.78,bottom=.38,wspace=.31)
for j,(key,label,unit)in enumerate([('Q95_Pa','Tip Q95','Pa'),('Q99_Pa','Tip Q99','Pa'),('energy_J','Tip strain energy','J')]):
 ax=fig.add_subplot(grid[0,j]);values=np.array([h['tip_roi'][key]for h in history]);ax.plot(n,values,'o-',color='#126d8b',lw=2)
 ax.set_xlabel('Tetrahedra');ax.set_ylabel(label+' ('+unit+')');ax.ticklabel_format(axis='x',style='sci',scilimits=(0,0));ax.grid(alpha=.2)
last=result['final'];changes=[h['tip_last_step_change_percent']for h in history[-2:]]
lines=[f"Two successive refinements: max tip changes {max(changes[0].values()):.3f}% and {max(changes[1].values()):.3f}% (criterion <2%).",
 f"Final mesh: {last['nodes']:,} nodes; {last['tetrahedra']:,} tetrahedra. Full 74M surface is used for visualization.",
 f"Constrained relative residual {last['constrained_relative_residual']:.3e}; force-balance error {last['force_balance_relative_error']:.3e}; virtual-work error {last['virtual_work_relative_error']:.3e}.",
 'MR5 parameters: C10=12, C01=3, C20=2, C11=1.5, C02=0.8 MPa; bulk modulus 250 MPa.',
 'Constraints: zero boundary-area-weighted mean displacement and reference-centred rotational displacement.',
 'The explicit RMS operator differs from inaccessible COMSOL automatic point selection; this replacement was authorized.']
for j,line in enumerate(lines):fig.text(.07,.29-j*.036,line,fontsize=11,color='#36556a')
fig.savefig(F/'10cm_MR5_Convergence_and_Checks.png',dpi=300);figs.append(fig)

pdf=ROOT/'output/pdf/Native74_5cm_Paper_10cm_MR5_Visualizations.pdf';pdf.parent.mkdir(exist_ok=True,parents=True)
with PdfPages(pdf,metadata={'Title':'Astraeus Krystallisia - full native74 5 cm reference and computed 10 cm MR5','Author':'eliguli712',
 'Subject':'Full 74M geometry, source-referenced appearance and archived field, independent SI MR5 with explicitly authorized RMS constraints'})as writer:
 for fig in figs:writer.savefig(fig,dpi=300);plt.close(fig)
shutil.copy2(pdf,O/pdf.name)

# Preserve portable, correctly named full-resolution view images as well.
for prefix,title in [('5cm_native74_paper','5cm_74M_Paper'),('archive50_unlit','5cm_74M_Archived_COMSOL'),('mr5_100_unlit','10cm_74M_MR5')]:
 for view in ['front','oblique','reverse']:shutil.copy2(O/f'plots/{prefix}_{view}.png',F/f'{title}_{view}.png')
S=O/'sources';S.mkdir(exist_ok=True)
for name,expected in [('full_ct_paper_reference.png','ffed5df25a35e37d5afdc138da3af19282ffd61a9165644d08b0e7ac6c928421'),('numerical_paper_reference.png','cf47bb45634b16c99c58f6f9ac92edd09dd7d5e781186df994759d0264ff39d1')]:
 source=ROOT/'output/paper_matched_5cm_10cm_2026-11-22/sources'/name
 with source.open('rb')as stream:assert hashlib.file_digest(stream,'sha256').hexdigest()==expected
 shutil.copy2(source,S/name)

readme=f'''Astraeus Krystallisia - full native 74M visualizations and independent 10 cm MR5

All displayed native models retain 37,951,699 vertices and 74,293,846 original triangle indices, including internal void boundaries. Every source face is submitted to each camera. Ordinary depth occlusion determines visibility. There is no surface decimation, hole filling or geometry smoothing.

5 cm paper appearance
The source is the original paper-coloured 32M 3MF, SHA-256 39ce24d78fbee473f2819296fe508e522abf8375fba49660e367bcd188668023. Its original face-area-weighted RGB and roughness are transferred to the native74 geometry using a uniform 0.10 mm source-cell lookup. This affects appearance lookup only, never native geometry. Native 18 um Z is registered to the earlier forced 16 um source frame for lookup. The derived 50 mm 74M 3MF embeds these reference colours and specular materials. It has no numerical stress field. The supplied reference PNGs remain unchanged in the earlier locked-reference package. A new 74M view is not a pixel-identical copy of the 32M reference image.

5 cm archived numerical display
The original von_mises_data_smoothed.txt field is separately projected to all native vertices in the same registered frame. Original Pa values are unchanged. The linear Turbo limits remain 56,766.44283690944 to 326,888.21709539363 Pa. This reproduces the archived field's appearance on a 50 mm display geometry; it is not a recalibrated physical 50 mm FEM. The archived export and MPH declare metres although their coordinate magnitudes are tens of units. That legacy unit issue prevents treating these Pa numbers as a validated SI 50 mm benchmark.

10 cm independent numerical calculation
The user authorized open-source FEM with explicitly documented rigid-motion constraints because COMSOL startup fails with licence error -88. The new calculation is in SI units, calibrates legacy Z from 16 to declared 18 um, and sets native principal height to 100 mm. It solves the homogeneous closed-solid archived proxy, not all native CT pores.

MR5 energy: W = C10*(I1bar-3) + C01*(I2bar-3) + C20*(I1bar-3)^2 + C11*(I1bar-3)*(I2bar-3) + C02*(I2bar-3)^2 + bulk/2*(J-1)^2. Constants are C10=12 MPa, C01=3 MPa, C20=2 MPa, C11=1.5 MPa, C02=0.8 MPa, bulk=250 MPa. Reference-volume body force is (0,0,50000) N/m3. No 1 MPa pressure or root clamp is applied.

Six RMS constraints enforce zero boundary-area-weighted mean displacement and zero boundary-area-weighted reference-centred rotational displacement. COMSOL's automatic geometrical-point selection is not reproduced. Under non-self-equilibrating body force, this constraint choice changes reaction distribution and can change stresses. The solver uses P1 tetrahedra and constant-reference-tangent quasi-Newton steps, with the full nonlinear MR5 first Piola force and Cauchy von Mises stress. Six temporary gauge DOFs invert the singular reference tangent; exact rigid correction removes those gauge constraints, leaving only the stated RMS conditions. No stored stress or displacement is used as a numerical answer and no field is scaled from 5 cm.

Constitutive energy-gradient, objectivity, identity/dilatation, full affine-traction patch, rigid-nullspace, force balance and virtual work checks pass. The final mesh has {last['nodes']:,} nodes and {last['tetrahedra']:,} tetrahedra. Constrained relative residual: {last['constrained_relative_residual']:.9e}. Force-balance error: {last['force_balance_relative_error']:.9e}. Virtual-work error: {last['virtual_work_relative_error']:.9e}.

The tip ROI is a frozen union of original L0 tetrahedra with centroid longitudinal coordinate s<=0.12; containment-checked child assignment preserves its volume. Q95, Q99 and integrated energy change by <2% on two successive refinements, with total energy also changing <2%. This is conditional closed-solid-proxy h-convergence; it does not certify singular point maxima, unresolved serrations, pore-resolved mechanics or biological strength.

Display and files
The 10 cm field is recovered to nodes by volume-weighted element-scalar averaging and transferred by containing-tetrahedron interpolation, with a bounded nearest-boundary fallback. It uses the paper renderer's linear 2nd/98th-percentile display convention, with its own computed Pa limits printed on the legend. Raw values are retained. Appearance and numerical fields are separate datasets. Front/Reverse labels are matched to supplied paper landmarks through opposite cameras, not mirrored images. Separate unlit views preserve quantitative colours; shaded material views are visual approximations.

Large 3MFs are in models/ and are linked separately rather than duplicated inside the plot/data ZIP. The final solver NPZ, history, bounded-run manifest, rendering and export audits document the calculation. Reproduce using review/mr5_run_command.json, then render_reference_and_fem_fields.py --case mr5_100 --solution <verified final NPZ>, export_derived_3mf.py --case mr5_100, and finish_visualizations.py --run <verified run directory>.

Format reference: https://github.com/3MFConsortium/spec_materials/blob/master/3MF%20Materials%20Extension.md
RMS theory reference: installed COMSOL 6.4 Structural Mechanics documentation, sme_ug_theory.06.071.html and sme_ug_solid.07.069.html.
'''
(O/'README.txt').write_text(readme)
(O/'review/final_solver_location.json').write_text(json.dumps({'run':str(RUN),'result':str(RUN/'result.json'),'solution':str(RUN/'100mm_MR5_solution.npz'),'run_status':manifest['run']['status'],'tip_two_successive_2percent_checks_passed':True},indent=2))

selected=[O/'README.txt',O/pdf.name,O/'review/final_solver_location.json',RUN/'100mm_MR5_solution.npz',RUN/'result.json',RUN/'history.json',RUN/'manifest.json',RUN/'stdout.txt',RUN/'stderr.txt']
selected+=list(F.glob('*.png'))+list((O/'scripts').glob('*.py'))+list((O/'scripts').glob('*.cpp'))
selected+=list(S.glob('*.png'))
selected+=list((O/'review').glob('*audit.json'))+[O/'review/appearance_projection.json',O/'review/mr5_contract.json',O/'review/mr5_run_command.json']
selected=sorted(set(selected));delivery={'status':'passed','triangles_per_native_view':74293846,'new_10cm_solve':True,'COMSOL_automatic_constraints_reproduced':False,
 'tip_convergence':True,'models':[audits['paper50-3mf-export-audit.json'],audits['mr5_100-3mf-export-audit.json']],'files':[]}
for path in selected:
 with path.open('rb')as f:dg=hashlib.file_digest(f,'sha256').hexdigest()
 delivery['files'].append({'path':str(path.relative_to(O)),'bytes':path.stat().st_size,'sha256':dg})
(O/'delivery_manifest.json').write_text(json.dumps(delivery,indent=2));selected.append(O/'delivery_manifest.json')
with zipfile.ZipFile(O/'Native74_5cm_Paper_10cm_MR5_Plots_and_Data.zip','w',zipfile.ZIP_DEFLATED,compresslevel=4)as z:
 for path in selected:z.write(path,path.relative_to(O))
with zipfile.ZipFile(O/'Native74_5cm_Paper_10cm_MR5_Plots_and_Data.zip')as z:assert z.testzip()is None
print(json.dumps({'status':'passed','PDF':str(pdf),'figure_files':len(list(F.glob('*.png'))),'data_zip_bytes':(O/'Native74_5cm_Paper_10cm_MR5_Plots_and_Data.zip').stat().st_size,'tip_stability_last_steps':changes},indent=2),flush=True)
