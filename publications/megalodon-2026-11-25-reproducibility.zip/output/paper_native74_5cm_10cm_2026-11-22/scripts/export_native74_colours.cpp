#include <charconv>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <stdexcept>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
constexpr uint64_t NV=37951699,NF=74293846;
struct Map{int fd;void*p;size_t size;Map(const char*name){fd=open(name,O_RDONLY);if(fd<0)throw std::runtime_error("Cannot open array");struct stat s;fstat(fd,&s);size=s.st_size;p=mmap(nullptr,size,PROT_READ,MAP_PRIVATE,fd,0);if(p==MAP_FAILED)throw std::runtime_error("Map failed");}~Map(){munmap(p,size);close(fd);}};
struct Buffer{std::string data;Buffer(){data.reserve(8<<20);}void text(const char*s){data+=s;}void integer(uint32_t n){char b[24];auto q=std::to_chars(b,b+24,n);data.append(b,q.ptr);}void flush(){std::cout.write(data.data(),data.size());data.clear();}void maybe(){if(data.size()>(4<<20))flush();}~Buffer(){flush();}};
int main(int argc,char**argv){try{
 if(argc!=4)return 2;Map ff(argv[1]),cc(argv[2]);uint64_t palette=std::stoull(argv[3]);
 if(ff.size!=NF*12||cc.size!=NV*4)throw std::runtime_error("Array count differs from native74");
 const uint32_t*f=(uint32_t*)ff.p,*c=(uint32_t*)cc.p;Buffer out;
 for(uint64_t i=0;i<NF;i++){
  auto a=f[3*i],b=f[3*i+1],d=f[3*i+2];
  if(a>=NV||b>=NV||d>=NV||c[a]>=palette||c[b]>=palette||c[d]>=palette)throw std::runtime_error("Invalid face or property index");
  out.text("<triangle v1=\"");out.integer(a);out.text("\" v2=\"");out.integer(b);out.text("\" v3=\"");out.integer(d);
  out.text("\" pid=\"2\" p1=\"");out.integer(c[a]);out.text("\" p2=\"");out.integer(c[b]);out.text("\" p3=\"");out.integer(c[d]);out.text("\"/>");out.maybe();
 }
 std::cerr<<"Exported all "<<NF<<" ordered faces and "<<NF*3<<" checked corner colours\n";return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 10;}}
