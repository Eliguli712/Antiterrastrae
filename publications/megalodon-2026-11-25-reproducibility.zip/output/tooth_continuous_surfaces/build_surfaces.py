"""Continuous, source-based tooth surfaces and compact display meshes.

The FE field and the image-referenced colors embedded in the 3MF files are
deliberately separate datasets. Input geometry and appearance are never edited.
"""
from pathlib import Path
import base64
import gc
import hashlib
import json
import re
import time
import zipfile

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pyvista as pv
from scipy.spatial import cKDTree
from vtkmodules.vtkFiltersCore import vtkQuadricClustering

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
CACHE = OUT / 'cache'
CACHE.mkdir(exist_ok=True)
CTCACHE = ROOT / 'full_3D/ct_internal_reconstruction/cache'
EXPORTS = ROOT / 'DICOM_16um/exports'
REPORT = {}


def log(*args):
    print(*args, flush=True)


def basis_from_vertices(v):
    center = np.mean(v, axis=0)
    cov = np.cov((v-center).T)
    values, axes = np.linalg.eigh(cov)
    axes = axes[:, np.argsort(values)[::-1]]
    y, x = axes[:, 0], axes[:, 1]
    if y[2] < 0:
        y = -y
    if x[1] < 0:
        x = -x
    z = np.cross(x, y)
    z /= np.linalg.norm(z)
    return center, np.column_stack((x, y, z))


def load_fe():
    vp, fp = CACHE/'fe_v.npy', CACHE/'fe_f.npy'
    if not vp.exists() or not fp.exists():
        v = np.lib.format.open_memmap(vp, mode='w+', dtype=np.float64, shape=(2767405, 3))
        f = np.lib.format.open_memmap(fp, mode='w+', dtype=np.int32, shape=(5554286, 3))
        vi = fi = 0
        vs, fs = [], []
        with (EXPORTS/'surface_mesh_smoothed.bdf').open('rb') as src:
            for line in src:
                if line.startswith(b'GRID '):
                    vs.append(line[24:32]+b' '+line[32:40]+b' '+line[40:48])
                    if len(vs) == 100000:
                        a = np.fromstring(b'\n'.join(vs).decode(), sep=' ').reshape(-1, 3)
                        v[vi:vi+len(a)] = a
                        vi += len(a)
                        vs.clear()
                elif line.startswith(b'CTRIA3 '):
                    fs.append(line[24:32]+b' '+line[32:40]+b' '+line[40:48])
                    if len(fs) == 100000:
                        a = np.fromstring(b'\n'.join(fs).decode(), sep=' ', dtype=np.int32).reshape(-1, 3)-1
                        f[fi:fi+len(a)] = a
                        fi += len(a)
                        fs.clear()
        if vs:
            a = np.fromstring(b'\n'.join(vs).decode(), sep=' ').reshape(-1, 3)
            v[vi:vi+len(a)] = a
            vi += len(a)
        if fs:
            a = np.fromstring(b'\n'.join(fs).decode(), sep=' ', dtype=np.int32).reshape(-1, 3)-1
            f[fi:fi+len(a)] = a
            fi += len(a)
        assert (vi, fi) == (len(v), len(f)), (vi, fi)
        assert f.min() == 0 and f.max() < len(v)
        v.flush()
        f.flush()
        log('FE mesh parsed:', vi, fi)
    return np.load(vp, mmap_mode='r'), np.load(fp, mmap_mode='r')


def polydata(v, f):
    # VTK accepts compact int32 cell connectivity; avoid a 4-column int64 copy.
    from vtkmodules.vtkCommonDataModel import vtkCellArray, vtkPolyData
    from vtkmodules.vtkCommonCore import vtkPoints
    from vtkmodules.util.numpy_support import numpy_to_vtk, numpy_to_vtkIdTypeArray
    pts = vtkPoints()
    pts.SetData(numpy_to_vtk(np.ascontiguousarray(v, dtype=np.float32), deep=True))
    cells = vtkCellArray()
    offsets = np.arange(0, 3*len(f)+1, 3, dtype=np.int32)
    cells.SetData(numpy_to_vtk(offsets, deep=True), numpy_to_vtk(np.asarray(f, dtype=np.int32).ravel(), deep=True))
    mesh = vtkPolyData()
    mesh.SetPoints(pts)
    mesh.SetPolys(cells)
    return pv.wrap(mesh)


def cluster(mesh, spacing):
    alg = vtkQuadricClustering()
    alg.SetInputData(mesh)
    bounds = np.array(mesh.bounds).reshape(3, 2)
    divs = np.maximum(2, np.ceil(np.diff(bounds, axis=1).ravel()/spacing).astype(int))
    alg.SetNumberOfXDivisions(int(divs[0]))
    alg.SetNumberOfYDivisions(int(divs[1]))
    alg.SetNumberOfZDivisions(int(divs[2]))
    alg.CopyCellDataOn()
    alg.UseInputPointsOn()
    alg.Update()
    return pv.wrap(alg.GetOutput()).copy()


def compact(mesh, target):
    if mesh.n_cells <= target:
        return mesh.copy()
    return mesh.decimate(1-target/mesh.n_cells, volume_preservation=True)


def render_image(mesh, name, title, subtitle, scalar=None, rgb=None, clim=None, angle=0, shading=True):
    log('render:', name, mesh.n_points, mesh.n_cells)
    p = pv.Plotter(off_screen=True, window_size=(1450, 1920))
    p.set_background('#eef4f8')
    kwargs = dict(show_edges=False, smooth_shading=shading, show_scalar_bar=False,
                  lighting=shading, ambient=.65, diffuse=.35, specular=.06, specular_power=30)
    if rgb is not None:
        p.add_mesh(mesh, scalars=rgb, rgb=True, preference='point', **kwargs)
    else:
        p.add_mesh(mesh, scalars=scalar, clim=clim, cmap='turbo', n_colors=512,
                   interpolate_before_map=True, **kwargs)
    r = np.deg2rad(angle)
    p.camera_position = [(100*np.sin(r), 0, 100*np.cos(r)), (0, 0, 0), (0, 1, 0)]
    p.enable_parallel_projection()
    p.camera.parallel_scale = 27
    image = p.screenshot(return_img=True)
    p.close()
    fig = plt.figure(figsize=(9.4, 11.6), dpi=260, facecolor='#eef4f8')
    ax = fig.add_axes([.03, .05, .82 if clim else .94, .85])
    ax.imshow(image)
    ax.set_axis_off()
    if clim:
        cax = fig.add_axes([.88, .16, .035, .68])
        sm = plt.cm.ScalarMappable(norm=plt.Normalize(*clim), cmap='turbo')
        cb = fig.colorbar(sm, cax=cax)
        cb.set_label('Von Mises (Pa)', fontsize=11)
        cb.ax.tick_params(labelsize=9)
    fig.text(.07, .965, title, fontsize=19, fontweight='bold', color='#163348')
    fig.text(.07, .936, subtitle, fontsize=9, color='#3d5f74')
    fig.savefig(OUT/name, dpi=260, facecolor=fig.get_facecolor())
    plt.close(fig)


def parse_appearance(path, key, cached_v, cached_f):
    dest = CACHE/f'{key}_face_appearance.npy'
    metap = CACHE/f'{key}_source.json'
    digest = hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()
    if dest.exists() and metap.exists():
        meta = json.loads(metap.read_text())
        if meta['sha256'] == digest:
            return np.load(dest, mmap_mode='r'), meta
    # Parse every geometry record as well as material indices. This checks that
    # the cached mesh is exactly the geometry in each colored 3MF package.
    a = np.lib.format.open_memmap(dest, mode='w+', dtype=np.uint16, shape=(len(cached_f), 2))
    vi = fi = 0
    palettes = {}
    vr = re.compile(rb'<vertex x="([^"]+)" y="([^"]+)" z="([^"]+)"\s*/>')
    fr = re.compile(rb'<triangle v1="(\d+)" v2="(\d+)" v3="(\d+)" pid="(\d+)" p1="(\d+)"\s*/>')
    with zipfile.ZipFile(path) as archive:
        source_meta = json.loads(archive.read('Metadata/appearance_and_source.json'))
        with archive.open('3D/3dmodel.model') as s:
            carry = b''
            first = True
            while True:
                data = s.read(8*1024*1024)
                if not data:
                    break
                data = carry+data
                split = data.rfind(b'>')+1
                data, carry = data[:split], data[split:]
                if first:
                    for group, contents in re.findall(rb'<m:colorgroup id="(\d+)"[^>]*>(.*?)</m:colorgroup>', data, re.S):
                        colors = re.findall(rb'<m:color color="#([0-9A-Fa-f]{6})[0-9A-Fa-f]{2}"\s*/>', contents)
                        palettes[str(int(group))] = [[int(c[i:i+2], 16) for i in (0, 2, 4)] for c in colors]
                    assert len(palettes) == 9
                    first = False
                rows = vr.findall(data)
                if rows:
                    v = np.asarray(rows, dtype=np.float64)
                    assert np.array_equal(v, cached_v[vi:vi+len(v)]), (path.name, 'vertices', vi)
                    vi += len(v)
                rows = fr.findall(data)
                if rows:
                    f = np.asarray(rows, dtype=np.uint32)
                    assert np.array_equal(f[:, :3], cached_f[fi:fi+len(f)]), (path.name, 'faces', fi)
                    a[fi:fi+len(f), 0] = f[:, 3]
                    a[fi:fi+len(f), 1] = f[:, 4]
                    fi += len(f)
        # Reaching EOF also verifies the ZIP member CRC.
    assert (vi, fi) == (len(cached_v), len(cached_f)), (vi, fi)
    a.flush()
    meta = {'file': str(path), 'sha256': digest, 'vertices_verified': vi,
            'triangles_verified': fi, 'geometry_equal_to_cache': True,
            'palette': palettes, 'source_metadata': source_meta,
            'zip_member_crc_verified': True}
    metap.write_text(json.dumps(meta, indent=2)+'\n')
    log('verified geometry and parsed appearance:', key)
    return a, meta


def source_vertex_colors(vertices, faces, variants):
    paths = {key: CACHE/f'{key}_area_weighted_vertex_rgb.npy' for key in variants}
    cache_record = CACHE/'vertex_rgb_sources.json'
    hashes = {key: meta['sha256'] for key, (_, meta) in variants.items()}
    if all(p.exists() for p in paths.values()) and cache_record.exists() and json.loads(cache_record.read_text()) == hashes:
        return {key: np.load(p, mmap_mode='r') for key, p in paths.items()}
    # Transfer area on the ORIGINAL mesh. Copying a representative triangle's
    # color through clustering can amplify tiny repair-patch colors enormously.
    # Original face-area weighting avoids that display artifact.
    log('area-weight original 3MF face colors at original vertices')
    accum = np.zeros((len(vertices), 7), dtype=np.float32)
    lookup = {}
    for key, (_, meta) in variants.items():
        palettes = [np.asarray(p, dtype=np.uint8) for p in meta['palette'].values()]
        assert all(np.array_equal(palettes[0], p) for p in palettes)
        lookup[key] = palettes[0]
    for start in range(0, len(faces), 200000):
        f = np.asarray(faces[start:start+200000])
        a, b, c = vertices[f[:, 0]], vertices[f[:, 1]], vertices[f[:, 2]]
        area = np.linalg.norm(np.cross(b-a, c-a), axis=1).astype(np.float32)/2
        weighted = np.empty((len(f), 7), dtype=np.float32)
        weighted[:, 0] = area
        for column, (key, (appearance, _)) in enumerate(variants.items()):
            weighted[:, 1+3*column:4+3*column] = lookup[key][appearance[start:start+len(f), 1]]*area[:, None]
        for j in range(3):
            np.add.at(accum, f[:, j], weighted)
    for column, key in enumerate(variants):
        rgb = np.lib.format.open_memmap(paths[key], mode='w+', dtype=np.uint8, shape=(len(vertices), 3))
        for start in range(0, len(vertices), 200000):
            row = accum[start:start+200000]
            rgb[start:start+len(row)] = np.clip(np.rint(row[:, 1+3*column:4+3*column]/np.maximum(row[:, :1], 1e-30)), 0, 255).astype(np.uint8)
        rgb.flush()
    del accum
    gc.collect()
    cache_record.write_text(json.dumps(hashes, indent=2)+'\n')
    return {key: np.load(p, mmap_mode='r') for key, p in paths.items()}


def encode(a):
    return base64.b64encode(np.ascontiguousarray(a).tobytes()).decode()


def pack_mesh(mesh, colors):
    m = mesh.compute_normals(cell_normals=False, point_normals=True, split_vertices=False)
    pts = np.asarray(m.points)
    scale = float(np.max(np.abs(pts)))
    f = m.faces.reshape(-1, 4)[:, 1:]
    assert m.n_points < 65536 and f.min() >= 0 and f.max() < m.n_points
    return {'positions': encode(np.rint(pts/scale*32760).astype('<i2')),
            'normals': encode(np.rint(m.point_normals*127).astype('i1')),
            'indices': encode(f.astype('<u2')), 'scale': scale,
            'vertices': m.n_points, 'triangles': m.n_cells,
            'colors': {k: encode(np.asarray(v, dtype='u1')) for k, v in colors.items()}}


def main():
    started = time.monotonic()
    v, f = load_fe()
    center, basis = basis_from_vertices(v)
    data = np.loadtxt(EXPORTS/'von_mises_data_smoothed.txt', comments='%')
    tree = cKDTree(data[:, :3])
    distances, nn = tree.query(v, workers=-1)
    vm = data[nn, 3]
    selected = f[np.linspace(0, len(f)-1, 220000, dtype=np.int64)]
    tri_vm = vm[selected].mean(axis=1)
    clim = np.quantile(tri_vm, [.02, .98]).tolist()
    REPORT['fe'] = {'source_mesh': str(EXPORTS/'surface_mesh_smoothed.bdf'),
        'source_field': str(EXPORTS/'von_mises_data_smoothed.txt'),
        'source_samples': len(data), 'source_vertices': len(v), 'source_triangles': len(f),
        'interpolation': 'Nearest exported COMSOL value at each mesh vertex; linear interpolation across connected faces.',
        'geometry_smoothing': False, 'matches_first_image_norm': True,
        'color_limits_pa': clim, 'raw_field_range_pa': [float(data[:, 3].min()), float(data[:, 3].max())],
        'nearest_distance_mm': {'maximum': float(distances.max()), 'p99': float(np.quantile(distances, .99))},
        'orientation_basis': basis.tolist(), 'orientation_center_mm': center.tolist()}
    mesh = polydata((v-center)@basis, f)
    mesh.point_data['von_mises_pa'] = vm.astype(np.float32)
    render_image(mesh, 'von_mises_frontal_continuous.png', 'Continuous Von Mises Tooth Surface',
        'Original COMSOL field | surface_mesh_smoothed | connected surface, same scale as reference',
        scalar='von_mises_pa', clim=clim, shading=False)
    render_image(mesh, 'von_mises_oblique_continuous.png', 'Continuous Von Mises Tooth Surface',
        'Original COMSOL field | oblique view | unchanged mesh geometry',
        scalar='von_mises_pa', clim=clim, angle=28, shading=True)
    display = compact(cluster(mesh, .15), 16000)
    # Reevaluate the original field after reduction, avoiding interpolation drift.
    display_xyz = np.asarray(display.points)@basis.T+center
    _, ix = tree.query(display_xyz, workers=-1)
    display_vm = data[ix, 3]
    display.point_data.clear()
    fe_rgb = np.rint(matplotlib.colormaps['turbo'](plt.Normalize(*clim)(display_vm))[:, :3]*255).astype(np.uint8)
    payload = {'fe': pack_mesh(display, {'fe': fe_rgb}), 'clim': clim,
               'legend': np.rint(matplotlib.colormaps['turbo'](np.linspace(0, 1, 32))[:, :3]*255).astype(int).tolist()}
    del mesh, display, v, f, vm, data, tree, distances, nn, selected, tri_vm
    gc.collect()
    log('continuous FE surface complete')

    cv = np.load(CTCACHE/'supplied_v.npy', mmap_mode='r')
    cf = np.load(CTCACHE/'supplied_f.npy', mmap_mode='r')
    variants = {}
    for key, filename in [('stress', 'Megalodon_FullCT_StressColors_PBR.3mf'),
                          ('natural', 'Megalodon_FullCT_NaturalColors_PBR.3mf')]:
        appearances, meta = parse_appearance(ROOT/'full_3D'/filename, key, cv, cf)
        variants[key] = (appearances, meta)
        REPORT[key] = {k: val for k, val in meta.items() if k != 'palette'}
    reduced_path = CACHE/'ct_exterior_reduced.vtp'
    if reduced_path.exists():
        ct = pv.read(reduced_path)
    else:
        labels = np.load(CTCACHE/'supplied_face_components.npy', mmap_mode='r')
        largest = int(np.argmax(np.bincount(labels)))
        exterior_ids = np.flatnonzero(labels == largest).astype(np.int32)
        log('reduce connected CT exterior for display:', len(cv), len(exterior_ids))
        ct = polydata(cv, cf[exterior_ids])
        ct.cell_data['source_face_id'] = exterior_ids
        smaller = cluster(ct, .12)
        del ct
        gc.collect()
        ct = smaller
        ct.save(reduced_path)
    log('CT display surface:', ct.n_points, ct.n_cells)
    # Reuse exactly the FE basis to keep root above and tip below in all views.
    ct.points = (ct.points-center)@basis
    source_rgb = source_vertex_colors(cv, cf, variants)
    log('index original CT vertices for faithful appearance transfer')
    source_tree = cKDTree(cv)
    _, ct_nn = source_tree.query(np.asarray(ct.points)@basis.T+center, workers=-1)
    color_arrays = {}
    for key, (appearance, meta) in variants.items():
        rgb = source_rgb[key][ct_nn]
        color_arrays[key] = rgb
        ct.point_data[key+'_rgb'] = rgb
        render_image(ct, key+'_3mf_frontal_continuous.png',
            'Full CT Tooth — '+('Embedded Paper Colors' if key == 'stress' else 'Natural Colors'),
            'Direct 3MF appearance | root above, tip below | connected display surface',
            rgb=key+'_rgb', shading=True)
    # Resample the already decoded appearance onto the compact display vertices;
    # VTK quadric reduction does not preserve point arrays by default.
    smallct = compact(ct, 36000)
    _, color_nn = source_tree.query(np.asarray(smallct.points)@basis.T+center, workers=-1)
    colors = {k: source_rgb[k][color_nn] for k in variants}
    payload['ct'] = pack_mesh(smallct, colors)
    REPORT['display'] = {'ct_render_triangles': ct.n_cells,
        'ct_interactive_triangles': smallct.n_cells, 'fe_interactive_triangles': payload['fe']['triangles'],
        'method': 'Connected display mesh reduction, never triangle subsampling. All original files unchanged.',
        'ct_component': 'Largest connected exterior only for the preview; internal cavity surfaces remain in the original 3MFs.',
        '3mf_color_mapping': 'Area-weighted original face palettes at original vertices, then nearest-source-vertex transfer to display mesh.',
        'pbr_preview': 'Approximate lighting; per-face specular/gloss material extension is not reproduced exactly.'}
    (OUT/'preview_data.json').write_text(json.dumps(payload, separators=(',', ':')))
    REPORT['runtime_seconds'] = time.monotonic()-started
    (OUT/'source_report.json').write_text(json.dumps(REPORT, indent=2)+'\n')
    log('COMPLETE', REPORT['runtime_seconds'], 'seconds')


if __name__ == '__main__':
    main()
