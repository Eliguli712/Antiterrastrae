"""Download only requested large replay archives, verifying byte count and SHA-256."""
import argparse
import hashlib
import json
from pathlib import Path
from urllib.request import Request, urlopen

here = Path(__file__).resolve().parent
lock = json.loads((here/'inputs.lock.json').read_text())
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('names', nargs='*')
parser.add_argument('--output', type=Path, default=Path('input-archives'))
args = parser.parse_args()
if not args.names:
    for asset in lock:
        print(asset['name'], asset['bytes'], asset['experiment'])
    raise SystemExit
indexed = {entry['name']:entry for entry in lock}
args.output.mkdir(parents=True, exist_ok=True)
for name in args.names:
    if name not in indexed:
        parser.error('Unknown locked input: '+name)
    entry = indexed[name]
    destination = args.output / name
    partial = args.output / (name+'.part')
    if destination.is_file():
        with destination.open('rb') as stream:
            assert destination.stat().st_size == entry['bytes']
            assert hashlib.file_digest(stream, 'sha256').hexdigest() == entry['sha256']
    else:
        with urlopen(Request(entry['url'], headers={'User-Agent':'Megalodon-replay/1'}), timeout=90) as response, partial.open('wb') as stream:
            digest = hashlib.sha256()
            for chunk in iter(lambda:response.read(1_048_576), b''):
                digest.update(chunk)
                stream.write(chunk)
        assert partial.stat().st_size == entry['bytes'] and digest.hexdigest() == entry['sha256'], name
        partial.replace(destination)
    print('Verified', destination, flush=True)
