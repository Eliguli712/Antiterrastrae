"""Render measured candidate registration and verified finite unit-force responses."""
from pathlib import Path
import json,sys
import numpy as np
import pyvista as pv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
from matplotlib.colors import ListedColormap,LogNorm
from PIL import Image
import revise_figures as plot

N=Path(__file__).resolve().parents[1];P=N.parents[2]
R=P/'output/jaw_tooth_transfer_2026-11-22';B=P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31';OLD=P/'output/ct_fea_calibrated_2026-11-08'
plot.R=N;plot.F=N/'figures';plot.V=N/'svg';plot.REVIEW=N/'review'
audit=json.loads((R/'review/independent_transfer_audit_001/results.json').read_text());assert audit['status']=='passed'
data=json.loads((R/'edge_data/results.json').read_text());cases={c['name']:c for c in data['cases']}
reg=np.load(R/'data_v3/registration.npz');a=np.load(B/'numerics/L0/solution.npz');jaw=np.load(OLD/'data/jaw_L2_full_1kPa/fields.npz')
p,t,f,basis=[a[k] for k in ['points_m','tets','boundary_faces','basis']]
posed=(p-reg['tooth_root_centre_m'])@reg['reference_rotation'].T+reg['reference_location_m']
pj=jaw['points_m']*1000;fj=jaw['boundary_faces']
tooth=pv.PolyData(posed*1000,np.column_stack([np.full(len(f),3),f]).ravel());jpoly=pv.PolyData(pj,np.column_stack([np.full(len(fj),3),fj]).ravel())
image_path=N/'figures/jaw_tooth_candidate_registration.png'
camera=pj.mean(0);scene=pv.Plotter(off_screen=True,window_size=(1800,1500));scene.set_background('white')
scene.add_mesh(jpoly,color='#d0d5d8',smooth_shading=False,ambient=.45,diffuse=.6)
scene.add_mesh(tooth,color='#d9a630',smooth_shading=False,ambient=.45,diffuse=.6)
for k,color in [(0,'#435aa6'),(1,'#66ad36')]:
    pts=reg['projected_points_m'][reg['root_face_side']==k]*1000
    scene.add_points(pts,color=color,point_size=7,render_points_as_spheres=True)
scene.camera_position=[camera+np.array([700,-750,900]),camera+np.array([0,45,0]),(0,0,1)]
scene.enable_parallel_projection();scene.reset_camera();scene.camera.zoom(1.05);scene.render()
rendered=scene.screenshot(return_img=True);scene.close()
assert np.mean(np.any(rendered[:,:,:3]<245,axis=2))>.02,'Registration panel must contain visible geometry.'
Image.fromarray(rendered).save(image_path)
detail_path=N/'figures/jaw_tooth_root_fit_detail.png'
detail=pv.Plotter(off_screen=True,window_size=(1000,850));detail.set_background('white')
detail.add_mesh(jpoly,color='#d0d5d8',ambient=.45,diffuse=.6)
detail.add_mesh(tooth,color='#d9a630',ambient=.45,diffuse=.6)
focus=reg['root_centres_jaw_m'].mean(0)*1000
for k,color in [(0,'#435aa6'),(1,'#66ad36')]:
    selected=np.flatnonzero(reg['root_face_side']==k)
    detail.add_points(reg['projected_points_m'][selected]*1000,color=color,point_size=5,render_points_as_spheres=True)
    for idx in selected[::10]:
        detail.add_lines(np.vstack([reg['posed_root_points_m'][idx],reg['projected_points_m'][idx]])*1000,color='#222222',width=1)
detail.camera_position=[focus+np.array([70,-100,120]),focus,(0,0,1)]
detail.enable_parallel_projection();detail.camera.parallel_scale=27;detail.reset_camera_clipping_range();detail.render()
detail_image=detail.screenshot(return_img=True);detail.close()
assert np.mean(np.any(detail_image[:,:,:3]<245,axis=2))>.02
Image.fromarray(detail_image).save(detail_path)

fig=plot.canvas(183,69)
plot.picture(plot.axmm(fig,.5,15,46,47),image_path)
plot.picture(plot.axmm(fig,26,43,20,18),detail_path)
plot.txt(fig,36,41.8,'Root-fit detail',4.8,ha='center')
plot.panel(fig,1,67,'a');plot.txt(fig,23,67,'Candidate root placement',6.1,ha='center',va='top')
plot.txt(fig,23,10,'White-shark reference; ideal connectors',5.4,ha='center')
plot.txt(fig,23,6,'RMS gap 0.874 mm; jaw scale assumed',5.3,ha='center')

# Constant owner-element principal tension, without averaging the two faces.
state=np.load(R/'edge_data/RA_pose0_oblique30_tied.npz');stress=state['stress_Pa'];tensile=np.maximum(np.linalg.eigvalsh(stress)[:,-1],0)/1e6
lookup={tuple(sorted(face)):j//4 for j,face in enumerate(t[:,[[1,2,3],[0,2,3],[0,1,3],[0,1,2]]].reshape(-1,3))}
owner=np.array([lookup[tuple(sorted(face))] for face in f]);vector=np.cross(p[f[:,1]]-p[f[:,0]],p[f[:,2]]-p[f[:,0]])
visible=(vector@basis[:,2])>=0;canonical=(p-a['center_m'])@basis;s=(canonical[:,1]-canonical[:,1].min())/np.ptp(canonical[:,1]);xy=np.column_stack([canonical[:,0]*1000,s])
palette=np.array(json.loads((N/'numerics/reference_palette_512.json').read_text())['RGBA_8bit'])/255
cmap=ListedColormap(palette);norm=LogNorm(1e-4,.1)
ax=plot.axmm(fig,51,15,31,47);collection=PolyCollection(xy[f[visible]],array=np.maximum(tensile[owner[visible]],1e-30),cmap=cmap,norm=norm,edgecolors='none',rasterized=False)
ax.add_collection(collection);ax.set_xlim(xy[:,0].min()-1,xy[:,0].max()+1);ax.set_ylim(1.03,-.03)
ax.set_xlabel('Transverse (mm)',fontsize=5.5,labelpad=1);ax.set_ylabel('Rootward position s',fontsize=5.5,labelpad=1);ax.tick_params(labelsize=5.2,pad=1)
cb=fig.colorbar(collection,cax=plot.axmm(fig,83,18,1.3,39));cb.set_ticks([1e-4,1e-3,1e-2,.1]);cb.ax.tick_params(labelsize=5,pad=1)
plot.panel(fig,48,67,'b');plot.txt(fig,68,67,'Margin A: unit oblique load',6.1,ha='center',va='top');plot.txt(fig,68,6,r'Principal tension ($\mathrm{MPa\,N^{-1}}$)',5.3,ha='center')

def value(margin,angle,oblique,support):
    c=cases[f'{margin}_pose{angle}_oblique{oblique}_{support}']
    return next(r['tensile_Q95_MPa_per_N'] for r in c['regions'] if r['region']==margin)

colors={'RA':'#435aa6','RB':'#66ad36'}
ax=plot.axmm(fig,101,16,33,43)
for margin in ['RA','RB']:
    for support,style in [('fixed','--'),('tied','-')]:
        xx=[0,15,30];yy=[value(margin,0,b,support)/value(margin,0,0,support) for b in xx]
        ax.plot(xx,yy,style+'o',color=colors[margin],lw=.85,ms=2.4,label=f'{margin[-1]} '+('fixed' if support=='fixed' else 'coupled'))
ax.axhline(1,color='#777777',lw=.45);ax.set_xlabel('Obliquity (°)',fontsize=5.8,labelpad=2);ax.set_ylabel('Tension Q95 / axial value',fontsize=5.8,labelpad=2)
ax.tick_params(labelsize=5.5,pad=1);ax.set_xticks([0,15,30]);ax.grid(alpha=.14,lw=.35);ax.legend(fontsize=4.7,frameon=False,loc='upper left',handlelength=1.3)
plot.panel(fig,94,67,'c');plot.txt(fig,118,67,'Within-margin direction effect',6.1,ha='center',va='top')

ax=plot.axmm(fig,148,16,33,43)
for margin in ['RA','RB']:
    for beta,style in [(0,'-'),(30,'--')]:
        xx=[-15,0,15];yy=[value(margin,a,beta,'tied')/value(margin,a,beta,'fixed') for a in xx]
        ax.plot(xx,yy,style+'o',color=colors[margin],lw=.85,ms=2.4,label=margin[-1]+f' {beta}°')
ax.axhline(1,color='#777777',lw=.45);ax.set_xlabel('Installation angle (°)',fontsize=5.8,labelpad=2);ax.set_ylabel('Coupled / fixed tension Q95',fontsize=5.8,labelpad=2)
verified_p2=json.loads((R/'review/P2_edge_audit_001/results.json').read_text());assert verified_p2['status']=='passed'
p2data=json.loads((R/'p2_edge_data_v2/results.json').read_text())
pf=next(r['P2_tensile_Q90_Q95_Q99_MPa_per_N'][1] for r in p2data['regional_percentiles'] if r['state']=='fixed' and r['region']=='RA')
pc=next(r['P2_tensile_Q90_Q95_Q99_MPa_per_N'][1] for r in p2data['regional_percentiles'] if r['state']=='coupled' and r['region']=='RA')
ax.plot([0],[pc/pf],'D',color='#222222',ms=3,label='A 0° P2')
ax.tick_params(labelsize=5.5,pad=1);ax.set_xticks([-15,0,15]);ax.grid(alpha=.14,lw=.35);ax.legend(fontsize=4.7,frameon=False,loc='upper left',handlelength=1.3)
plot.panel(fig,140,67,'d');plot.txt(fig,164,67,'Attachment effect',6.1,ha='center',va='top')
plot.save(fig,'boundary_edge_transmission')
(N/'review/boundary_edge_figure.json').write_text(json.dumps(dict(source=str(R/'edge_data/results.json'),source_audit=str(R/'review/independent_transfer_audit_001/results.json'),field_case='RA_pose0_oblique30_tied',display='Undeformed P1 owner stress, principal tension per1N; original reference palette, explicit new log axis.',limits_MPa_per_N=[1e-4,.1],scope='Geometric candidate only; comparisons normalised within each margin because the frozen contact-proxy patch areas differ.'),indent=2))
print('Rendered candidate registration, unit tensile field and conditional amplification curves.')
