"""Evaluate the mixed-area curvature operator and draw all native faces."""
from pathlib import Path
import json
import struct
import subprocess
import tempfile

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
import trimesh

from curvature_core import curvature

paper = Path(__file__).resolve().parents[1]
project = paper.parents[2]
cache = project / 'output/current_native74_stress_2026-11-20/cache'
nv, nf = 37_951_699, 74_293_846
vertices = np.memmap(cache / 'vertices.f64', '<f8', 'r', shape=(nv, 3))
faces = np.memmap(cache / 'triangles.u32', '<u4', 'r', shape=(nf, 3))
frame = np.load(project / 'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0/solution.npz')
centre, basis = frame['center_m'] * 1000, frame['basis']
sphere = trimesh.creation.icosphere(subdivisions=4, radius=10)
k, h, _, a = curvature(sphere.vertices, sphere.faces)
assert abs(k @ a - 4*np.pi) < 1e-8 and abs(np.median(h) - .1) < .001
print('Evaluating native curvature on every triangle', flush=True)
fields = curvature(vertices, faces)
assert all(np.isfinite(f).all() for f in fields)
limits = [float(np.quantile(np.abs(f), .99)) for f in fields[:3]]
norms = [mpl.colors.AsinhNorm(linear_width=x*.01, vmin=(-x if i != 1 else 0), vmax=x)
         for i, x in enumerate(limits)]
maps = [mpl.colormaps['RdBu_r'], mpl.colormaps['viridis'], mpl.colormaps['RdBu_r']]
print('Rendering native faces, colour limits:', limits, flush=True)
with tempfile.TemporaryDirectory() as tmp:
    executable = Path(tmp) / 'raster'
    subprocess.run(['clang++', '-O3', '-std=c++17', str(paper/'scripts/native_figure8_raster.cpp'),
                    '-o', str(executable)], check=True)
    proc = subprocess.Popen([str(executable), tmp], stdin=subprocess.PIPE, stderr=subprocess.PIPE)
    for start in range(0, nf, 600_000):
        part = faces[start:start+600_000]
        ids, inverse = np.unique(part, return_inverse=True)
        coordinates = (vertices[ids]-centre) @ basis
        xyz = np.column_stack((900+coordinates[:,0]*27, 800-coordinates[:,1]*27, -coordinates[:,2]))
        for i, (field, norm, cmap) in enumerate(zip(fields, norms, maps)):
            colours = cmap(norm(field[ids]))[:,:3]
            payload = np.column_stack((xyz, colours)).astype('<f4')
            proc.stdin.write(struct.pack('<III', i, len(ids), len(part)))
            proc.stdin.write(payload.tobytes())
            proc.stdin.write(inverse.astype('<u4').tobytes())
    proc.stdin.close()
    counts = proc.stderr.read().decode()
    assert proc.wait() == 0 and counts.count('74293846') == 3, counts
    fig = plt.figure(figsize=(6.98, 3.79))
    for i, (norm, cmap, name, unit) in enumerate(zip(norms, maps, ('$K$', '$|H|$', '$H$'), ('mm⁻²','mm⁻¹','mm⁻¹'))):
        rgba = Image.frombytes('RGBA',(1800,1600),(Path(tmp)/f'native_figure8_{i}.rgba').read_bytes())
        rgba = rgba.crop(rgba.getchannel('A').getbbox())
        rgba.save(paper/'figures'/f'native18_curvature_{i}.png')
        # The full render remains available outside the manuscript.
        rgba.thumbnail((520, 830), Image.Resampling.LANCZOS)
        x = .01+.327*i
        ax = fig.add_axes([x,.15,.245,.66])
        ax.imshow(rgba,interpolation='none')
        ax.set_axis_off()
        ax.set_title(name, fontsize=10)
        bar = fig.colorbar(mpl.cm.ScalarMappable(norm=norm,cmap=cmap),
                           cax=fig.add_axes([x+.25,.22,.014,.44]), extend='both')
        bar.set_ticks([norm.vmin, (norm.vmax*.1 if i==1 else 0), norm.vmax])
        bar.set_ticklabels([f'{a:.3g}' for a in bar.get_ticks()])
        bar.ax.tick_params(labelsize=5,pad=1)
        bar.ax.set_title(unit,fontsize=6,pad=4)
    fig.text(.5,.93,'18 µm native surface',ha='center',fontsize=9,weight='bold')
    fig.text(.5,.07,'74,293,846 faces submitted per map',ha='center',fontsize=7)
    fig.savefig(paper/'figures/native18_curvature_display.pdf')
    plt.close(fig)
record = dict(vertices=nv, faces=nf, raster_counts=counts, display_p99_limits=limits,
              sphere_integral_K=float(k@a), sphere_median_H=float(np.median(h)),
              method='Mixed Voronoi area, angular deficit and cotangent mean curvature. Full solid-triangle raster; no sampled points or geometry smoothing.')
(paper/'review/native18_curvature_display.json').write_text(json.dumps(record,indent=2))
print(record, flush=True)
