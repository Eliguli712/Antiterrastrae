"""Retain measured panels c,d; add full native geometry and supplied scale views."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap,LogNorm
from PIL import Image
import revise_figures as plot
N=Path(__file__).resolve().parents[1];P=N.parents[2];F=N/'figures';R=P/'output/jaw_tooth_transfer_2026-11-22'
plot.R=N;plot.F=F;plot.V=N/'svg';plot.REVIEW=N/'review'
data=json.loads((R/'edge_data/results.json').read_text());cases={c['name']:c for c in data['cases']}
geometry=json.loads((N/'review/figure8_native_counts.json').read_text())
assert geometry['status']=='passed' and 'overview_window_center_px' in geometry
fig=plot.canvas(183,110)
# Shift the retained four-panel row upward; all measured c,d curves are unchanged.
axmm0,txt0,panel0=plot.axmm,plot.txt,plot.panel
plot.axmm=lambda fig,x,y,w,h:axmm0(fig,x,y+42,w,h)
plot.txt=lambda fig,x,y,*args,**kw:txt0(fig,x,y+42,*args,**kw)
plot.panel=lambda fig,x,y,text,*args,**kw:txt0(fig,x,y+42,text,8,weight='bold',va='top')
def publication_image(source,width_mm,height_mm):
 im=Image.open(source);im.thumbnail((round(width_mm/25.4*450),round(height_mm/25.4*450)),Image.Resampling.LANCZOS);out=source.with_name(source.stem+'_450dpi.png');im.save(out);return out
image_path=publication_image(F/'native_figure8_0.png',31,33);detail_path=publication_image(F/'native_figure8_1.png',30,27)
publication_image(F/'native_figure8_2.png',31,47)
palette=np.array(json.loads((N/'numerics/reference_palette_512.json').read_text())['RGBA_8bit'])/255;cmap=ListedColormap(palette);norm=LogNorm(1e-4,.1)
p=np.load(P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0/solution.npz');basis=p['basis'];q=(p['points_m']-p['center_m'])@basis*1000;span=np.ptp(q[:,1])
source=(N/'scripts/plot_boundary_edge_transmission.py').read_text();source=source[source.index("plot.picture(plot.axmm(fig,.5,"):source.index("plot.save(fig,'boundary_edge_transmission')")]
overview=plot.axmm(fig,.6,31.0,31,32)
plot.picture(overview,image_path)
detail=plot.axmm(fig,16,12.4,30,25)
plot.picture(detail,detail_path)
from matplotlib.patches import Rectangle,ConnectionPatch
u,v=geometry['overview_window_center_px'];w=geometry['overview_window_width_px'];h=geometry['overview_window_height_px']
xo,yo=(u-w/2)/1800,1-(v+h/2)/1600
ww,hh=w/1800,h/1600
overview.add_patch(Rectangle((xo,yo),ww,hh,transform=overview.transAxes,fill=False,edgecolor='#235473',linewidth=.82))
fig.add_artist(ConnectionPatch((xo+ww,yo),(0.02,.96),coordsA='axes fraction',coordsB='axes fraction',
                               axesA=overview,axesB=detail,lw=.65,color='#235473',zorder=8))
detail.add_patch(Rectangle((0,0),1,1,transform=detail.transAxes,fill=False,edgecolor='#235473',linewidth=.65))
plot.panel(fig,1,67,'a')
plot.txt(fig,23,67,'Candidate tooth–jaw placement',6.1,ha='center',va='top')
plot.txt(fig,31,11.8,'Seat detail',5.1,ha='center',va='top')
plot.txt(fig,23,6.5,'Jaw 1,009,016 · Tooth 74,293,846 faces',5.1,ha='center')
source=source[source.index('# Constant owner-element'):]
start=source.index('# Constant owner-element');end=source.index('\ndef value(',start)
replacement="""
ax=plot.axmm(fig,51,15,31,47)
im=Image.open(F/'native_figure8_2_450dpi.png')
ax.imshow(im,extent=[-900/26,900/26,(1600-95)/(27*span),-95/(27*span)],aspect='auto',interpolation='none')
ax.set_xlim(q[:,0].min()-1,q[:,0].max()+1);ax.set_ylim(1.03,-.03)
ax.set_xlabel('Transverse (mm)',fontsize=5.5,labelpad=1);ax.set_ylabel('Rootward position s',fontsize=5.5,labelpad=1);ax.tick_params(labelsize=5.2,pad=1)
cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap=cmap),cax=plot.axmm(fig,83,18,1.3,39),extend='both',extendfrac=.025);cb.set_ticks([1e-4,1e-3,1e-2,.1]);cb.ax.tick_params(labelsize=5,pad=1)
plot.panel(fig,48,67,'b');plot.txt(fig,68,67,'74M display: margin A, 30°',6.1,ha='center',va='top');plot.txt(fig,68,6,r'Projected tension ($\\mathrm{MPa\\,N^{-1}}$)',5.3,ha='center')
"""
source=source[:start]+replacement+source[end:]
source=source.replace("'Candidate root placement'","'Jaw + native tooth placement'").replace("'White-shark reference; ideal connectors'","'Jaw 1,009,016; tooth 74,293,846 faces'").replace("'RMS gap 0.874 mm; jaw scale assumed'","'Crown / root; gap RMS 0.874 mm'")
exec(compile(source,__file__,'exec'),globals())
plot.axmm,plot.txt,plot.panel=axmm0,txt0,panel0
# The two supplied images are used once, without a new stress inference.
paths=[Path('/var/folders/q1/xn03yx0d3lb4vlk97t91k1380000gn/T/codex-clipboard-54c716d4-d804-4ddf-97ab-30a9f8522703.png'),Path('/var/folders/q1/xn03yx0d3lb4vlk97t91k1380000gn/T/codex-clipboard-82a1b7da-80fd-4891-9961-ae3fc35f3df1.png')]
meta=json.loads((P/'output/paper_native74_5cm_10cm_2026-11-22/review/mr5_100-render-audit.json').read_text());lo,hi=[meta['colourbar_Pa'][k]for k in ['min','max']]
for j,path in enumerate(paths):
 out=F/f'supplied_native_scale_{50 if j==0 else 100}mm.png'
 if not out.is_file():
  original=Image.open(path)
  box=(int(.035*original.width),int(.145*original.height),int(.955*original.width),int((.87 if j==0 else .785)*original.height))
  original.crop(box).save(out)
 im=Image.open(out)
 im.thumbnail((round(87/25.4*450),round(33/25.4*450)),Image.Resampling.LANCZOS)
 x=1+j*92;ax=plot.axmm(fig,x+1,13,87,31);ax.imshow(im,interpolation='none');ax.set_axis_off();plot.panel(fig,x,48,'ef'[j]);plot.txt(fig,x+46,47.7,'5 cm: supplied appearance'if j==0 else '10 cm: independent MR5',6.3,ha='center',va='top')
 norm=plt.Normalize(0,1)if j==0 else plt.Normalize(lo,hi);cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap='turbo'),cax=plot.axmm(fig,x+11,9,65,1.5),orientation='horizontal',extend='both',extendfrac=.025);cb.ax.tick_params(labelsize=5.2,pad=1)
 if j==0:cb.set_ticks([0,.5,1]);label='Reference colour coordinate; not stress'
 else:cb.set_ticks([lo,(lo+hi)/2,hi],labels=[f'{lo:.0f}',f'{(lo+hi)/2:.0f}',f'{hi:,.0f}']);label='Von Mises stress (Pa), linear'
 plot.txt(fig,x+44,2.7,label,5.6,ha='center')
plot.save(fig,'boundary_edge_transmission_revised')
print('Native Figure 8 assembled; c,d measurements unchanged, both colourbar ends extended.')
