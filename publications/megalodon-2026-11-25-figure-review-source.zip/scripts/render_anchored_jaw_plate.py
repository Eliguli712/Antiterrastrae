"""Re-read the six jaw fields and expose the actual fixed-face footprint."""
from pathlib import Path
import json

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
import pyvista as pv

import revise_figures as layout
from update_ct_assets import trim

paper=Path(__file__).resolve().parents[1]
project=paper.parents[2]
old=project/'output/ct_fea_calibrated_2026-11-08/data/jaw_L2_narrow_local/fields.npz'
nh=project/'output/jaw_full_stvk_2026-11-20/data/L2_10kPa_NH_polish/fields.npz'
data=np.load(old)
p, t, f, owner=[data[k]for k in ('points_m','tets','boundary_faces','boundary_owner')]
fixed=np.zeros(len(p),bool)
fixed[data['fixed_node_indices']]=True
fixed_face=fixed[f].all(axis=1)
assert fixed_face.any()
xyz=(p-p.mean(0))*1000
poly=pv.PolyData(xyz,np.c_[np.full(len(f),3),f].ravel())
seat=poly.extract_cells(fixed_face).extract_surface()
seat_edge=seat.extract_feature_edges(boundary_edges=True,non_manifold_edges=False,
                                     feature_edges=False,manifold_edges=False)
# Anchor marks are attached to actual fixed surface points. Their length is
# a graphic convention only and specifies no traction or spring stiffness.
fixed_centres=xyz[f[fixed_face]].mean(axis=1)
targets=np.linspace(fixed_centres[:,0].min(),fixed_centres[:,0].max(),9)[1:-1]
anchor_points=[]
for x in targets:
    strip=np.abs(fixed_centres[:,0]-x)<8
    if not np.any(strip):
        continue
    options=fixed_centres[strip]
    anchor_points.append(options[np.argmin(options[:,1])])
def invariant(tensor, factor):
    dev=tensor-np.trace(tensor,axis1=1,axis2=2)[:,None,None]*np.eye(3)/3
    return np.sqrt(factor*np.einsum('eij,eij->e',dev,dev))
def gradients(displacement):
    g=np.empty((len(t),3,3))
    for start in range(0,len(t),100_000):
        tri=t[start:start+100_000]
        edge=(p[tri[:,1:]]-p[tri[:,:1]]).transpose(0,2,1)
        du=(displacement[tri[:,1:]]-displacement[tri[:,:1]]).transpose(0,2,1)
        g[start:start+len(tri)]=du@np.linalg.inv(edge)
    return g
fig=layout.canvas(183,90)
titles=['Linear elasticity','Linear bulk / narrow StVK','Full neo-Hookean',
        'Linear equivalent strain','Mixed-model equivalent strain','Green–Lagrange equivalent strain']
records=[]
for col in range(3):
    case=np.load(nh) if col==2 else data
    assert np.array_equal(case['fixed_node_indices'],data['fixed_node_indices'])
    assert np.array_equal(case['tets'],t) and np.array_equal(case['points_m'],p)
    linear=col==0
    u=case['linear_displacement_m' if linear else 'displacement_m']
    assert abs(u[fixed]).max()<1e-12
    g=gradients(u)
    strain=(g+g.transpose(0,2,1))/2
    if not linear:
        use=case['green_or_linear_flag'].astype(bool) if col==1 else np.ones(len(g),bool)
        strain[use]+=.5*g[use].transpose(0,2,1)@g[use]
    eq=invariant(strain,2/3)
    vm=invariant(case['linear_stress_Pa' if linear else 'cauchy_stress_Pa'],1.5)
    saved_vm=case['linear_von_mises_Pa' if linear else 'von_mises_Pa']
    saved_eq=case['linear_equivalent_strain' if linear else 'equivalent_strain']
    np.testing.assert_allclose(vm,saved_vm,rtol=6e-7,atol=1e-7)
    np.testing.assert_allclose(eq,saved_eq,rtol=6e-7,atol=1e-11)
    records.append(dict(law=titles[col],max_fixed_motion_m=float(abs(u[fixed]).max()),
                        max_VM_difference_Pa=float(abs(vm-saved_vm).max()),
                        max_equivalent_strain_difference=float(abs(eq-saved_eq).max())))
    for row,field in enumerate([vm/1e6,eq]):
        norm=mpl.colors.LogNorm(*[(.001,100),(1e-5,1)][row])
        cmap=mpl.colormaps['turbo']
        rgb=cmap(norm(np.maximum(field[owner],norm.vmin)).filled(0))[:,:3]
        rgb[fixed_face]=[.66,.76,.80]
        poly.cell_data['RGB']=rgb
        view=pv.Plotter(off_screen=True,window_size=(1900,1700))
        view.set_background('white')
        view.add_mesh(poly,scalars='RGB',rgb=True,show_scalar_bar=False,ambient=.82,diffuse=.23)
        view.add_mesh(seat_edge,color='#24495a',line_width=2)
        for anchor in anchor_points:
            tip=anchor+[0,-16,0]
            view.add_lines(np.array([anchor,tip]),color='#24495a',width=3)
            view.add_lines(np.array([tip+[-5,0,0],tip+[5,0,0]]),color='#24495a',width=3)
        view.camera_position=[(700,-750,900),(0,0,0),(0,1,0)]
        view.enable_parallel_projection()
        view.reset_camera()
        raster=Image.fromarray(trim(view.screenshot(return_img=True)))
        view.close()
        raster.save(paper/'figures'/f'jaw_anchored_{row}_{col}.png')
        raster.thumbnail((930,800),Image.Resampling.LANCZOS)
        x=61*col
        y=48 if row==0 else 5
        ax=layout.axmm(fig,x+1,y,51,36)
        ax.imshow(raster,interpolation='none')
        ax.set_axis_off()
        layout.panel(fig,x+1,y+40,'abcdef'[3*row+col])
        layout.txt(fig,x+28,y+39,titles[3*row+col],6,ha='center',va='top')
        bar=fig.colorbar(mpl.cm.ScalarMappable(norm=norm,cmap=cmap),
                         cax=layout.axmm(fig,x+53,y+6,1.4,26),extend='both')
        bar.set_ticks([.001,.1,10,100]if row==0 else [1e-5,1e-3,.1,1])
        bar.ax.tick_params(labelsize=5,pad=1)
        layout.txt(fig,x+54,y+33,'MPa'if row==0 else 'strain',5,ha='center')
layout.txt(fig,91.5,1.15,'Slate patch and anchor symbols: actual fixed boundary',6,ha='center')
fig.savefig(paper/'figures/jaw_anchored_3x2.pdf',dpi=550)
fig.savefig(paper/'figures/jaw_anchored_3x2.png',dpi=320)
(paper/'review/jaw_anchored_readback.json').write_text(json.dumps(dict(
    reference_triangles=len(f),tetrahedra=len(t),fixed_nodes=int(fixed.sum()),
    fixed_boundary_triangles=int(fixed_face.sum()),anchor_points=len(anchor_points),
    checks=records,scope='Verified scalar readback of saved equilibria. Anchor symbols mark actual imposed fixed nodes and do not define a new contact model.'),indent=2))
