#!/usr/bin/env python3
"""Authentic junction crops and maximum native CT planes with line profiles."""
from pathlib import Path
import json,hashlib
import numpy as np
from PIL import Image
from scipy import ndimage as ndi
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm
import calibrated_figures as cf
import revise_figures as old
R=Path(__file__).resolve().parents[1];P=R.parents[2];D=P/'output/ct_profiles_2026-11-09';F=R/'figures'
old.R=R;old.F=F;old.V=R/'svg';old.REVIEW=R/'review'
def native_picture(ax,path):
 ax.imshow(Image.open(path),interpolation='none');ax.set_axis_off()
old.picture=native_picture
A=np.load(D/'data/native_profiles_and_maximum_sections.npz');report=json.loads((D/'review/native_profiles.json').read_text());origin=np.array([4.176,.198,16.818]);lo=-3292.;hi=26623.;threshold=10361.669921875

def display_mask(raw):
 labels,n=ndi.label(raw>threshold)
 if not n:return np.zeros(raw.shape,bool)
 sizes=np.bincount(labels.ravel());sizes[0]=0
 return ndi.binary_fill_holes(labels==sizes.argmax())

def extent(raw,axes):
 return [origin[axes[0]]-.009,origin[axes[0]]+(raw.shape[1]-.5)*.018,origin[axes[1]]-.009,origin[axes[1]]+(raw.shape[0]-.5)*.018]

def junctions():
 crops={}
 for key in ['a','b']:
  image=Image.open(F/f'specimen_photo_{key}_bordercrop.png')
  box=(int(.13*image.width),int(.42*image.height),int(.91*image.width),int(.73*image.height))
  image.crop(box).save(F/f'photograph_junction_{key}.png');crops[key]=dict(source=f'specimen_photo_{key}_bordercrop.png',crop_xyxy=box,photograph_pixels_changed=False)
 raw=A['sagittal_raw_maximum'];x0=int((13.-origin[1])/.018);x1=int((28.-origin[1])/.018);y0=int((45.-origin[2])/.018);y1=int((56.-origin[2])/.018);patch=raw[y0:y1,x0:x1]
 foreground=patch[patch>threshold];limits=np.quantile(foreground,[.01,.99]).tolist()
 fig=old.canvas(30,29);ax=old.axmm(fig,7,5,22,23);ax.imshow(patch,cmap='gray_r',origin='lower',vmin=limits[0],vmax=limits[1],extent=[origin[1]+x0*.018,origin[1]+x1*.018,origin[2]+y0*.018,origin[2]+y1*.018],interpolation='none');ax.set_xlabel('Y (mm)',fontsize=5.2,labelpad=1);ax.set_ylabel('Z (mm)',fontsize=5.2,labelpad=1);ax.tick_params(labelsize=5,pad=1);old.save(fig,'junction_CT_detail');fig.savefig(F/'junction_CT_detail.png',dpi=1200,bbox_inches=None)
 (R/'review/junction_crop_records.json').write_text(json.dumps(dict(photographs=crops,CT=dict(native_X_index=749,crop_zyx=[y0,y1,x0,x1],reversed_grayscale_raw_limits=limits,scope='Gross cervical vicinity chosen for texture display; no registered internal tissue boundary or growth dating inferred.')),indent=2))

def figure1():
 # Reuse the previous exact pixel assets for StVK, without a field remap or downsampling.
 original=cf.figure1
 cf.__dict__['F']=F
 # Temporarily draw the unchanged overall layout, then replace only the authorised panels.
 fig=old.canvas(183,94)
 for i,(file,title) in enumerate([('specimen_photo_a_bordercrop.png','a  Photograph'),('specimen_photo_b_bordercrop.png','b  Photograph'),('intro_render_frame.png','c  Recovered frame')]):
  x=i*30.5;old.picture(old.axmm(fig,x,47,29,43),F/file);old.txt(fig,x,92,title,6.5,va='top')
 for j,title in enumerate(['Front','Oblique','Reverse*']):
  x=96+j*29;old.picture(old.axmm(fig,x,69,26,19),F/f'appearance_natural_{j}.png');old.picture(old.axmm(fig,x,46,26,19),F/f'stvk_tooth_view_{j}.png');old.txt(fig,x+13,91,title,6.2,ha='center')
 old.txt(fig,94,66,'Natural appearance (* inferred reverse)',5.7)
 old.txt(fig,94,45.0,'StVK σvM\n(MPa), log',4.7,va='top')
 cb=fig.colorbar(plt.cm.ScalarMappable(norm=LogNorm(.1,300),cmap='turbo'),cax=old.axmm(fig,122,44,56,1.1),orientation='horizontal');cb.set_ticks([.1,1,10,100,300],labels=['0.1','1','10','100','300']);cb.ax.tick_params(labelsize=4.6,pad=.8)
 for j,key in enumerate(['a','b']):old.picture(old.axmm(fig,0,7+15*j,27,13.5),F/f'photograph_junction_{key}.png');old.txt(fig,.5,8+15*j,key,5.1,color='white')
 old.txt(fig,13.5,42,'d1  Cervical photographs',5.8,ha='center',va='top');old.txt(fig,13.5,3,'Original pixels; unscaled',4.7,ha='center')
 old.picture(old.axmm(fig,28,5,27,32),F/'junction_CT_detail.png');old.txt(fig,41.5,42,'d2  CT texture',6,ha='center',va='top')
 old.picture(old.axmm(fig,56,15,46,22),F/'notebook_delta_kappa1_no_human.png');old.txt(fig,79,39,r'e1  Notebook $\Delta\kappa_1$',6.3,ha='center');norm,neg,pos=cf.colour_norm();cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap='RdBu_r'),cax=old.axmm(fig,60,9,39,1.6),orientation='horizontal');cb.set_ticks([-neg,-100,0,100,pos],labels=[f'{-neg:.0f}','-100','0','100',f'{pos:.0f}']);cb.ax.tick_params(labelsize=4.9,pad=1);old.txt(fig,79,1.5,'Inverse source units; scale object removed',4.8,ha='center')
 old.picture(old.axmm(fig,106,6,31,29),F/'stvk_tooth_signed_deformed.png');old.txt(fig,122,39,'e2  Finite deformation',6.1,ha='center');old.txt(fig,120,3,'u ×10 display',5.5,ha='center');limits=json.loads((R/'review/current_field_display.json').read_text());limit=limits['tooth_signed_limit_MPa'];tau=limits['tooth_signed_asinh_scale_MPa'];from matplotlib.colors import FuncNorm
 norm=FuncNorm((lambda x:np.arcsinh(x/tau),lambda x:tau*np.sinh(x)),vmin=-limit,vmax=limit);cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap='RdBu_r'),cax=old.axmm(fig,139,12,1.3,19));cb.set_ticks([-limit,0,limit],labels=[f'{-limit:.0f}','0',f'{limit:.0f}']);cb.ax.tick_params(labelsize=5,pad=1);old.txt(fig,140,33,r'$\sigma_{ll}$ MPa',5.3,ha='center')
 old.picture(old.axmm(fig,153,8,28,28),F/'jaw_fine_full_vm.png');old.txt(fig,167,41,'f  Wide-band jaw FEA',6,ha='center',va='top');old.txt(fig,167,5,'E = 150 MPa; ν = 0.3',5.2,ha='center');old.txt(fig,167,1,'Traction = 10 kPa',5.2,ha='center');fig.set_size_inches(183/25.4,90/25.4);old.save(fig,'geometry_pack_1_specimen')
 provenance=[]
 for j in range(3):
  p=F/f'stvk_tooth_view_{j}.png';source=P/'output/pdf/debunk_myth_calibrated_2026-11-08/figures'/p.name;assert p.read_bytes()==source.read_bytes();im=Image.open(p);provenance.append(dict(file=p.name,pixels=im.size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
 (R/'review/StVK_unchanged_image_mapping.json').write_text(json.dumps(dict(status='passed',same_original_PNG_bytes=True,stress_limits_MPa=[.1,300],norm='log',cmap='turbo',images=provenance,fields='Actual equilibrated L1 StVK owner-tetrahedron stresses; natural appearance colours remain a separate row.'),indent=2))

def figure2():
 fig=old.canvas(183,115)
 for j,row in enumerate(report['directions']):
  left=2+j*61;raw=A[row['key']+'_raw_maximum'];axes=[(0,1),(0,2),(1,2)][j];mask=display_mask(raw);ex=extent(raw,axes);y,x=np.where(mask);ax=old.axmm(fig,left+6,49,49,55)
  ax.imshow(np.ma.array(raw,mask=~mask),cmap='gray_r',vmin=lo,vmax=hi,origin='lower',extent=ex,interpolation='none');ax.contour(mask,levels=[.5],colors='#263c47',linewidths=.35,origin='lower',extent=ex)
  # Crop display whitespace only; calibrated coordinates and original pixels remain unchanged.
  ax.set_xlim(origin[axes[0]]+max(0,x.min()-20)*.018,origin[axes[0]]+min(raw.shape[1],x.max()+21)*.018);ax.set_ylim(origin[axes[1]]+max(0,y.min()-20)*.018,origin[axes[1]]+min(raw.shape[0],y.max()+21)*.018)
  ax.set_xlabel('XYZ'[axes[0]]+' (mm)',labelpad=1);ax.set_ylabel('XYZ'[axes[1]]+' (mm)',labelpad=1);ax.tick_params(pad=1,labelsize=6)
  old.panel(fig,left,113,'abc'[j]);old.txt(fig,left+30,112,f'{row["axis"]}={row["max_native_index"]}: maximal section',7,ha='center',va='top');old.txt(fig,left+30,107,f'A = {row["max_area_mm2"]:.3f} mm²',6.1,ha='center',va='top')
  ax=old.axmm(fig,left+7,11,47,25);area=A[row['key']+'_counts'].astype(float);mean=A[row['key']+'_mean_raw'];use=A[row['key']+'_analysis_mask'];position=A[row['key']+'_LPS_mm'];scaled=np.full(len(mean),np.nan);scaled[use]=(mean[use]-np.nanmin(mean[use]))/np.ptp(mean[use]);ax.plot(position,area/area.max(),c='#176b90',lw=.8,label='A / max A');ax.plot(position,scaled,c='#b96a27',lw=.7,label='Mean I: display range');ax.axvline(row['max_plane_LPS_mm'],color='#952b38',lw=.6,ls=':');ax.set_ylim(-.03,1.04);ax.set_xlabel(row['axis']+' (LPS mm)',labelpad=1);ax.set_ylabel('Normalised trace',labelpad=1);ax.tick_params(pad=1,labelsize=5.8);ax.grid(alpha=.15,lw=.4);ax.legend(fontsize=4.8,frameon=False,loc='best',handlelength=1)
  old.panel(fig,left,43,'def'[j]);old.txt(fig,left+30,42,f'r = {row["Pearson_area_vs_mean_raw"]:.3f}; ρ = {row["Spearman_area_vs_mean_raw"]:.3f}; n = {row["analysis_planes"]}',6.1,ha='center',va='top')
 old.txt(fig,91.5,1,'Raw voxel values retained | shared reversed grayscale window [-3292, 26623] | full native area counts',6,ha='center');old.save(fig,'geometry_pack_2_reconstruction')

if __name__=='__main__':junctions();figure1();figure2()
