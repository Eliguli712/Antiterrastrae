"""A CT-guided crown/root display partition, independent of the FE regions."""
from pathlib import Path
import inspect
import json

import fitz
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from scipy import ndimage

import publication_figures as figure

paper=figure.R
project=paper.parents[2]
frame=np.load(figure.B/'numerics/L0/solution.npz')
centre=frame['center_m']*1000
basis=frame['basis']
shape=(2886,1903,746)
cache=project/'output/ct_web_2026-11-19/cache'
raw=np.memmap(cache/'native_specimen_crop.i16',dtype='<i2',mode='r',shape=shape)
chosen=np.memmap(cache/'selected_native_mask.u8',dtype='u1',mode='r',shape=shape)
pitch=.018
origin=np.array([7.056,1.368,1.368])
local=(frame['points_m']*1000-centre)@basis
limits=np.array([local.min(axis=0),local.max(axis=0)])
x=np.arange(limits[0,0]-1,limits[1,0]+1,pitch)
y=np.arange(limits[0,1]-1,limits[1,1]+1,pitch)
plane=np.empty((len(y),len(x)),np.int16)
solid=np.empty(plane.shape,bool)
for j in range(0,len(y),48):
    world=centre+x[None,:,None]*basis[:,0]+y[j:j+48,None,None]*basis[:,1]
    coords=((world-origin)/pitch)[...,::-1].transpose(2,0,1)
    plane[j:j+48]=ndimage.map_coordinates(raw,coords,order=0,prefilter=False,cval=-3292)
    solid[j:j+48]=ndimage.map_coordinates(chosen,coords,order=0,prefilter=False,cval=0)>0
# A guided trace near the established geometric cervical neighbourhood.
# Mask-normalised smoothing serves only to locate the display curve.
guess=limits[0,1]+.76*np.ptp(limits[:,1])
sigma=.2/pitch
support=ndimage.gaussian_filter(solid.astype(float),sigma)
blur=ndimage.gaussian_filter(np.where(solid,plane,0).astype(float),sigma)
blur/=np.maximum(support,1e-9)
score=np.abs(np.gradient(blur,pitch,axis=0))
interior=support>.96
columns=[]
offsets=[]
for xj in range(0,len(x),14):
    rows=np.flatnonzero(interior[:,xj] & (abs(y-guess)<=4.0))
    if len(rows)==0:
        continue
    # Distance prior restricts the trace to the visually guided cervical zone.
    strength=score[rows,xj]/max(1,np.quantile(score[rows,xj],.9))
    objective=np.clip(strength,0,3)-.13*(y[rows]-guess)**2
    columns.append(xj)
    offsets.append(y[rows[np.argmax(objective)]])
assert len(columns)>12
offsets=ndimage.median_filter(offsets,size=9,mode='nearest')
trace=np.interp(x,x[columns],offsets)
trace=ndimage.gaussian_filter1d(trace,1.35/pitch)
root=solid&(y[:,None]>=trace[None])
crown=solid&~root
assert root.any() and crown.any() and np.array_equal(root|crown,solid)
rgba=np.ones((*plane.shape,4))
gray=np.clip((plane.astype(float)+3292)/(26623+3292),0,1)
for mask,shade in [(root,[.27,.54,.69]),(crown,[.85,.62,.26])]:
    rgba[mask,:3]=np.array(shade)*(.66+.34*gray[mask,None])

def adaptive(ax):
    raster=Image.fromarray(np.uint8(np.rint(rgba[:,:,:3]*255)))
    raster.save(paper/'figures/figure4_adaptive_mask_native.png')
    raster.thumbnail((710,940),Image.Resampling.LANCZOS)
    ax.imshow(raster,extent=(x[0]-pitch/2,x[-1]+pitch/2,y[0]-pitch/2,y[-1]+pitch/2),
              interpolation='none',origin='lower')
    ii=np.clip(np.rint((trace-y[0])/pitch).astype(int),0,len(y)-1)
    inside=ndimage.binary_fill_holes(solid)[ii,np.arange(len(x))]
    ax.plot(x,np.where(inside,trace,np.nan),color='#182829',lw=.75)
    root_y,root_x=np.unravel_index(ndimage.distance_transform_edt(ndimage.binary_fill_holes(root)).argmax(), root.shape)
    ax.text(x[root_x],y[root_y],'Root',color='white',fontsize=5.5,weight='bold',ha='center',va='center')
    ax.text(0,-3,'Crown',color='#25282a',fontsize=5.5,weight='bold',ha='center')
source=inspect.getsource(figure.field_and_convergence)
source=source[:source.index('    summaries=')]
start=source.index('    axs[0].scatter')
end=source.index('    axs[1].add_collection',start)
source=source[:start]+'    adaptive(axs[0])\n'+source[end:]
source=source.replace("'Region masks'","'CT-guided crown / root'").replace("'field_fullresolution_qf'","'field_cervical_adaptive'")
figure.adaptive=adaptive
exec(compile(source,__file__,'exec'),figure.__dict__)
figure.field_and_convergence()
top=fitz.open(paper/'figures/field_cervical_adaptive.pdf')
bottom=fitz.open(paper/'figures/jaw_calibration_strip.pdf')
out=fitz.open()
w,h=top[0].rect.width,top[0].rect.height
hh=bottom[0].rect.height
page=out.new_page(width=w,height=h+hh)
page.show_pdf_page(fitz.Rect(0,0,w,h),top,0)
page.show_pdf_page(fitz.Rect(0,h,w,h+hh),bottom,0)
out.save(paper/'figures/field_qf_adaptive_calibration.pdf',garbage=4,deflate=True)
page.get_pixmap(matrix=fitz.Matrix(2.5,2.5)).save(paper/'figures/field_qf_adaptive_calibration.png')
np.savez_compressed(paper/'numerics/figure4_adaptive_CT_masks.npz',x_mm=x,y_mm=y,
                    cervical_trace_mm=trace,root=root,crown=crown)
record=dict(pitch_mm=pitch,level='longitudinal reference frame, thickness=0',guide_s=.76,
            search_halfwidth_mm=4,trace_range_mm=[float(trace.min()),float(trace.max())],
            crown_samples=int(crown.sum()),root_samples=int(root.sum()),
            interpolation='nearest acquired voxel',parameter_recovery='masked intensity gradient, bounded search, median and Gaussian regularisation',
            partition_is_FE_mask=False,partition_is_histological_boundary=False)
(paper/'review/figure4_CT_partition.json').write_text(json.dumps(record,indent=2))
print(record)
