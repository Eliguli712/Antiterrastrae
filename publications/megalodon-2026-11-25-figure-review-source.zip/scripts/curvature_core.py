#!/usr/bin/env python3
"""Authentic, units-correct curvature diagnostic from the saved native CT mask.

The visualization uses every fourth/eighth native-grid sample (72/144 um).
It is explicitly not the 18 um quantitative pore surface or an FEA field.
"""
from pathlib import Path
import hashlib,json,sys,time,zlib,gc
import numpy as np
from skimage.measure import marching_cubes
import trimesh
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
import pyvista as pv

ROOT=Path(__file__).resolve().parents[1]
PROJECT=ROOT.parents[2]
SOURCE=PROJECT/'full_3D/Megalodon_FullCT_SpecimenMask_18um.mha'


def read_subset(path,stride=4):
    with path.open('rb') as f:
        header={}
        while True:
            line=f.readline().decode().strip()
            if '=' in line:
                key,val=line.split('=',1);header[key.strip()]=val.strip()
            if line.startswith('ElementDataFile'):break
        nx,ny,nz=map(int,header['DimSize'].split());plane=nx*ny
        out=np.empty(((nz+stride-1)//stride,(ny+stride-1)//stride,(nx+stride-1)//stride),np.uint8)
        decoder=zlib.decompressobj();carry=b'';z=0;written=0
        for block in iter(lambda:f.read(65536),b''):
            raw=carry+decoder.decompress(block);count=len(raw)//plane
            if count:
                a=np.frombuffer(raw[:count*plane],np.uint8).reshape(count,ny,nx)
                for i in range(count):
                    if (z+i)%stride==0:out[written]=a[i,::stride,::stride];written+=1
                z+=count
            carry=raw[count*plane:]
        assert z==nz and len(carry)==0 and written==len(out),(z,nz,len(carry))
    return out,header


def curvature(v,f):
    nv=len(v);area=np.zeros(nv);angles=np.zeros(nv);kn=np.zeros((nv,3));norm=np.zeros((nv,3))
    for start in range(0,len(f),100000):
        part=f[start:start+100000];p=v[part]
        e=[p[:,1]-p[:,0],p[:,2]-p[:,1],p[:,0]-p[:,2]]
        cross=np.cross(e[0],-e[2]);double=np.linalg.norm(cross,axis=1)
        assert double.min()>1e-14
        dots=np.column_stack([np.einsum('ij,ij->i',e[j],-e[(j+2)%3]) for j in range(3)])
        cot=dots/double[:,None];theta=np.arctan2(double[:,None],dots)
        obt=theta>np.pi/2
        for j in range(3):
            a=(np.einsum('ij,ij->i',e[j],e[j])*cot[:,(j+2)%3]
                +np.einsum('ij,ij->i',e[(j+2)%3],e[(j+2)%3])*cot[:,(j+1)%3])/8
            a=np.where(obt.any(1),np.where(obt[:,j],double/4,double/8),a)
            np.add.at(area,part[:,j],a);np.add.at(angles,part[:,j],theta[:,j]);np.add.at(norm,part[:,j],cross)
            # Each triangle contributes the cotangent opposite to its edge.
            other=(j+1)%3;weight=cot[:,(j+2)%3]
            delta=(p[:,j]-p[:,other])*weight[:,None]
            np.add.at(kn,part[:,j],delta);np.add.at(kn,part[:,other],-delta)
    assert np.all(area>0)
    normal=norm/np.linalg.norm(norm,axis=1)[:,None]
    mean_normal=kn/(2*area[:,None])
    hmag=.5*np.linalg.norm(mean_normal,axis=1)
    hsigned=.5*np.einsum('ij,ij->i',mean_normal,normal)
    gaussian=(2*np.pi-angles)/area
    return gaussian,hmag,hsigned,area


def main():
    started=time.monotonic();dest=ROOT/'figures';cache=ROOT/'numerics/curvature';cache.mkdir(exist_ok=True)
    sphere=trimesh.creation.icosphere(subdivisions=4,radius=10)
    sk,sh,ss,sa=curvature(sphere.vertices,sphere.faces)
    assert abs(np.sum(sk*sa)-4*np.pi)<1e-8
    assert abs(np.median(sh)-.1)<.001 and np.median(ss)>0
    k2,h2,s2,_=curvature(sphere.vertices*2,sphere.faces)
    np.testing.assert_allclose(k2,sk/4,rtol=1e-10,atol=1e-12)
    np.testing.assert_allclose(h2,sh/2,rtol=1e-10,atol=1e-12)
    data,header=read_subset(SOURCE,4)
    offset=np.fromstring(header['Offset'],sep=' ')-np.array([4.176,.198,16.818])
    models=[]
    for stride,array in [(4,data),(8,data[::2,::2,::2])]:
        print('Extracting curvature surface, stride',stride,flush=True)
        verts,faces,_,_=marching_cubes(array,.5,spacing=(.018*stride,)*3,allow_degenerate=False)
        verts=verts[:,[2,1,0]]+offset
        volume=np.einsum('ij,ij->i',verts[faces[:,0]],np.cross(verts[faces[:,1]],verts[faces[:,2]])).sum()/6
        if volume<0:faces=faces[:,[0,2,1]]
        values=curvature(verts,faces)
        np.savez_compressed(cache/f'curvature_{stride}.npz',vertices_mm=verts,faces=faces,K_per_mm2=values[0],Habs_per_mm=values[1],Hsigned_per_mm=values[2],mixed_area_mm2=values[3])
        models.append((stride,verts,faces,values))
        print('surface',stride,len(verts),len(faces),flush=True)
    allk=np.concatenate([m[3][0] for m in models]);allh=np.concatenate([m[3][1] for m in models]);alls=np.concatenate([m[3][2] for m in models])
    km=float(np.quantile(np.abs(allk),.99));hm=float(np.quantile(allh,.99));sm=float(np.quantile(np.abs(alls),.99))
    ranges=[(-km,km),(0,hm),(-sm,sm)];cmaps=['coolwarm','viridis','coolwarm']
    frame=np.load(ROOT/'numerics/L2/solution.npz');center=frame['center_m']*1000;basis=frame['basis']
    fig,axes=plt.subplots(2,3,figsize=(9.5,8.6),layout='constrained')
    for row,(stride,v,f,val) in enumerate(models):
        local=(v-center)@basis
        poly=pv.PolyData(local,np.column_stack([np.full(len(f),3,np.int32),f]).ravel())
        for col in range(3):
            poly.point_data['value']=val[col]
            view=pv.Plotter(off_screen=True,window_size=(1200,1500))
            view.set_background('white');view.add_mesh(poly,scalars='value',cmap=cmaps[col],clim=ranges[col],lighting=False,show_scalar_bar=False)
            view.camera_position=[(0,0,150),(0,0,0),(0,1,0)];view.enable_parallel_projection();view.camera.parallel_scale=30
            view.render();pixels=view.screenshot(return_img=True);view.close()
            ax=axes[row,col];ax.imshow(pixels);ax.axis('off')
            ax.set_title(['Gaussian $K$','Mean magnitude $|H|$','Signed mean $H$'][col]+f'\n{stride*18} '+r'$\mu$m sampling',fontsize=11)
            fig.colorbar(plt.cm.ScalarMappable(norm=Normalize(*ranges[col]),cmap=cmaps[col]),ax=ax,fraction=.04,pad=.01,shrink=.65,
                         label=r'mm$^{-2}$' if col==0 else r'mm$^{-1}$')
        del poly;gc.collect()
    fig.savefig(dest/'curvature_recomputed.pdf',dpi=500);fig.savefig(dest/'curvature_recomputed.png',dpi=400);plt.close(fig)
    report=dict(source=str(SOURCE),source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),source_spacing_mm=[.018]*3,
        display_sampling_um=[72,144],source_voxels_modified=False,method='mixed-area angle deficit and cotangent mean-curvature normal; outward-positive mean sign',
        sphere_integral_K=float(np.sum(sk*sa)),sphere_mean_H=float(np.median(sh)),scale_units_check='K scales as length^-2; H as length^-1: passed',
        shared_color_ranges=ranges,models=[dict(stride=m[0],vertices=len(m[1]),triangles=len(m[2])) for m in models],
        limitation='Visualization-only resampling. Not a CT tissue classifier, native-resolution pore measurement, or evidence that curvature is preserved under arbitrary simplification.',
        seconds=time.monotonic()-started)
    (cache/'report.json').write_text(json.dumps(report,indent=2));print('completed',report['seconds'],flush=True)


if __name__=='__main__':main()
