"""Compose full-resolution curvature and the revised companion CT report."""
from pathlib import Path
import json

import fitz
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from scipy import ndimage
from PIL import Image

paper=Path(__file__).resolve().parents[1]
project=paper.parents[2]
study=project/'output/native_inference_2026-11-24'
present=study/'presentation'
figure=paper/'figures'
record=json.loads((paper/'review/native18_curvature_display.json').read_text())
old=fitz.open(figure/'geometry_pack_3_curvature.pdf')
old[0].add_redact_annot(fitz.Rect(0,0,269,old[0].rect.height),fill=False)
old[0].apply_redactions(images=1,graphics=1,text=0)
rect=old[0].rect
fig=plt.figure(figsize=(270/72,rect.height/72))
fig.text(.5,.94,'Curvature on the native 18 µm surface',ha='center',fontsize=8,weight='bold')
for j,(name,cmap,unit) in enumerate([('$K$','RdBu_r','mm⁻²'),('$|H|$','viridis','mm⁻¹'),('$H$','RdBu_r','mm⁻¹')]):
    lim=record['display_p99_limits'][j]
    norm=matplotlib.colors.AsinhNorm(linear_width=.01*lim,vmin=0 if j==1 else -lim,vmax=lim)
    x=.023+j*.325
    ax=fig.add_axes([x,.24,.31,.59])
    rgba=Image.open(figure/f'native18_curvature_{j}.png')
    rgba.thumbnail((475,710),Image.Resampling.LANCZOS)
    ax.imshow(rgba,interpolation='none')
    ax.set_axis_off()
    ax.set_title(name,fontsize=9)
    bar=fig.colorbar(matplotlib.cm.ScalarMappable(norm=norm,cmap=cmap),
                     cax=fig.add_axes([x+.018,.195,.262,.017]),orientation='horizontal',
                     extend='both' if j!=1 else 'max')
    ticks=[0,.1*lim,lim] if j==1 else [-lim,0,lim]
    bar.set_ticks(ticks,labels=[f'{t:.3g}'for t in ticks])
    bar.ax.tick_params(labelsize=5,pad=1,length=1.5)
    bar.set_label(unit,fontsize=6,labelpad=2)
fig.text(.5,.075,'74,293,846 faces submitted per map',ha='center',fontsize=7)
fig.savefig(figure/'native_curvature_left.pdf')
plt.close(fig)
left=fitz.open(figure/'native_curvature_left.pdf')
out=fitz.open()
page=out.new_page(width=rect.width,height=rect.height)
page.show_pdf_page(fitz.Rect(0,0,269,rect.height),left,0)
page.show_pdf_page(fitz.Rect(270,0,rect.width,rect.height),old,0,
                   clip=fitz.Rect(270,0,rect.width,rect.height))
out.save(figure/'geometry_pack_3_native.pdf',garbage=4,deflate=True)
page.get_pixmap(matrix=fitz.Matrix(2.4,2.4)).save(figure/'geometry_pack_3_native.png')

ct_old=fitz.open(present/'Native18_PCA_PPCA_MPPCA_and_Microstructure.pdf')
result=json.loads((study/'review/run001/result.json').read_text())
front=fitz.open()
titles=['Figure 1. Maximum sections in the volume-weighted PCA frame',
        'Figure 2. Section-area profiles in the volume-weighted PCA frame']
for panel,title in enumerate(titles):
    extent=ct_old[panel].rect
    fig=plt.figure(figsize=(extent.width/72,extent.height/72),facecolor='black')
    axes=fig.subplots(1,3)
    fig.subplots_adjust(left=.08,right=.95,top=.79,bottom=.22,wspace=.34)
    fig.text(.05,.95,title,color='white',fontsize=23,va='top',weight='bold')
    fig.text(.05,.885,'Otodus megalodon  |  18 µm CT sampling',color='#afc8d4',fontsize=15,va='top')
    for i,ax in enumerate(axes):
        ax.set_facecolor('black')
        ax.tick_params(colors='#d2e4ef',labelsize=10)
        ax.set_title(f'Axis {i+1}',color='white',fontsize=15)
        for spine in ax.spines.values():
            spine.set_color('#8298a5')
        if panel==0:
            data=np.load(present/'media'/f'principal_axis{i+1}_native_samples.npz')
            raw=data['raw_signed16']
            foreground=ndimage.binary_fill_holes(data['mask']>0)
            ux,vy=data['u_coordinates_mm'],data['v_coordinates_mm']
            ax.imshow(np.ma.array(raw,mask=~foreground),
                      cmap=matplotlib.colormaps['gray'].with_extremes(bad='black'),
                      vmin=-3292,vmax=26623,interpolation='none',
                      extent=[ux[0]-.009,ux[-1]+.009,vy[-1]-.009,vy[0]+.009])
            ax.set_xlabel('In-plane u (mm)',color='#d2e4ef')
            ax.set_ylabel('In-plane v (mm)',color='#d2e4ef')
            yy,xx=np.where(foreground)
            ax.set_xlim(ux[xx.min()]-.5,ux[xx.max()]+.5)
            ax.set_ylim(vy[yy.max()]-.5,vy[yy.min()]+.5)
        else:
            curve=np.loadtxt(study/'review/run001/data'/f'native-sections-axis{i+1}.csv',
                             delimiter=',',skiprows=1)
            peak=np.argmax(curve[:,1])
            ax.plot(curve[:,0],curve[:,1],color='#76ccf2',lw=1.65)
            ax.axvline(curve[peak,0],color='#f6b866',ls=':',lw=1.2)
            ax.set_xlabel('Plane offset (mm)',color='#d2e4ef')
            ax.set_ylabel('Section area (mm²)',color='#d2e4ef')
            ax.grid(alpha=.2)
    lines=[
        ('Nearest acquired voxels are displayed in one linear raw window [−3292, 26623]. Higher raw attenuation appears brighter.',
         'The exterior mask sets the background to black. Internal greyscale values and quantitative section areas are preserved.'),
        ('Areas come from intersections with every native triangle. Inward-oriented void boundaries subtract from the total.',
         'Dotted lines locate the sections above. Isotropic-noise PPCA retains the PCA subspace. Its residual includes true specimen thickness.')]
    for idx,line in enumerate(lines[panel]):
        fig.text(.05,.133-idx*.050,line,color='#d2e4ef',fontsize=11.5)
    path=figure/f'ppca_black_{panel+1}.pdf'
    fig.savefig(path,dpi=260,facecolor='black')
    plt.close(fig)
    with fitz.open(path)as pdf:
        front.insert_pdf(pdf)
front.insert_pdf(ct_old,from_page=2)
front.set_metadata({**ct_old.metadata,'title':'Native 18 µm CT: PCA, PPCA and internal microstructure'})
front.save(paper/'Native18_PCA_PPCA_Black_CT_2026-11-25.pdf',garbage=4,deflate=True)
