#!/usr/bin/env python3
"""Publication plates derived from audited fields; no invented texture or values."""
from pathlib import Path
import json,hashlib
import numpy as np
import pyvista as pv
from PIL import Image
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm,ListedColormap
from matplotlib.collections import PolyCollection
import revise_figures as old
import update_ct_assets as previous

R=Path(__file__).resolve().parents[1];P=R.parents[2]
D=P/'output/publication_validation_2026-11-12';B=P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31'
F=R/'figures';old.R=R;old.F=F;old.V=R/'svg';old.REVIEW=R/'review';previous.F=F
REGIONS=old.REGIONS;LABELS=old.LABELS;COLORS=old.COLORS
def case(name):return json.loads((D/'data'/name/'results.json').read_text())
def vals(name):return np.array([[r[k] for k in ['Q90_MPa','Q95_MPa','Q99_MPa']] for r in case(name)['regions']])
def boundary_owner(t,faces):
    local=np.array([[1,2,3],[0,3,2],[0,1,3],[0,2,1]])
    af=t[:,local].reshape(-1,3);_,idx,cnt=np.unique(np.sort(af,axis=1),axis=0,return_index=True,return_counts=True)
    chosen=idx[cnt==1];assert np.array_equal(np.sort(af[chosen],axis=1),np.sort(faces,axis=1))
    return chosen//4

def field_and_convergence():
    a=np.load(D/'data/local_A3/fields.npz');ref=np.load(B/'numerics/L0/solution.npz');p=a['points_m'];t=a['tets'];faces=a['boundary_faces']
    q=(p-ref['center_m'])@ref['basis']*1000;owner=boundary_owner(t,faces);surf=q[faces];order=np.argsort(surf[:,:,2].mean(1));cent=q[t].mean(1)
    base_masks=np.load(B/'numerics/L0/region_masks.npz');parent=a['parent_L0']
    fig=old.canvas(121,91);axs=[old.axmm(fig,9+37*i,48,29,36) for i in range(3)]
    for i,ax in enumerate(axs):
        ax.set_aspect('equal');ax.set(xlim=(q[:,0].min()-1,q[:,0].max()+1),ylim=(q[:,1].min()-1,q[:,1].max()+1));ax.set_xlabel('Transverse (mm)',labelpad=1)
        if i==0:ax.set_ylabel('Longitudinal (mm)',labelpad=1)
        else:ax.set_yticklabels([])
        ax.tick_params(pad=1,labelsize=5.5);old.panel(fig,2+39*i,89,'abc'[i]);old.txt(fig,20+39*i,88,['Region masks','Load / support','A3 stress'][i],6.4,ha='center',va='top')
    axs[0].scatter(cent[::35,0],cent[::35,1],s=.12,c='#dfe1e5',rasterized=True,linewidths=0)
    for j,key in enumerate(REGIONS):
        use=np.flatnonzero(np.isin(parent,base_masks[key]));use=use[::max(1,len(use)//8000)]
        axs[0].scatter(cent[use,0],cent[use,1],s=.15,color=COLORS[j],rasterized=True,linewidths=0)
    for label,(xx,yy) in zip(LABELS,[(0,-4),(-12,-2),(11,0),(0,-23),(0,7),(0,12.5)]):axs[0].text(xx,yy,label,fontsize=5.4,color='white',weight='bold',ha='center',va='center')
    axs[1].add_collection(PolyCollection(surf[order,:,:2],facecolors='#dfe1e5',edgecolors='none',rasterized=True))
    axs[1].add_collection(PolyCollection(surf[a['loaded_faces'],:,:2],facecolors='#2879bb',edgecolors='none',rasterized=True))
    fixed=a['fixed_nodes'];axs[1].scatter(q[fixed,0],q[fixed,1],c='#c92f40',s=.25,rasterized=True,linewidths=0)
    pc=PolyCollection(surf[order,:,:2],array=a['von_mises_Pa'][owner][order]/1e6,cmap='turbo',norm=LogNorm(.5,500),edgecolors='none',rasterized=True);axs[2].add_collection(pc)
    cb=fig.colorbar(pc,cax=old.axmm(fig,113.2,53,1.2,25),extend='both');cb.set_ticks([1,10,100],labels=['1','10','100']);cb.ax.tick_params(labelsize=5.5,pad=1);old.txt(fig,115.7,80,'MPa',5.5,ha='center')
    old.txt(fig,60,40.5,'Blue: 1 MPa pressure    Red: bilateral fixed caps',5.8,ha='center')
    for x,name in [(1,'front'),(42,'oblique')]:old.picture(old.axmm(fig,x,3,38 if x==1 else 35,31),F/f'qf_full32m_{name}.png')
    old.panel(fig,1,37,'d');old.txt(fig,40,36,'Full 32M surface / regional reference',6.4,ha='center',va='top')
    q95=vals('local_A3')[:,1];pal=plt.colormaps['turbo'](LogNorm(.4,300)(q95));legend=old.axmm(fig,80,2,40,31);legend.axis('off')
    for i,(label,val,color) in enumerate(zip(LABELS,q95,pal)):
        yy=.92-i*.157;legend.plot([.03],[yy],marker='s',c=color,ms=4);legend.text(.12,yy,label+'  '+f'{val:.3f}',fontsize=6,va='center')
    legend.set(xlim=(0,1),ylim=(0,1));old.txt(fig,100,36,r'A3 $Q_{0.95}$ (MPa); numeric $Q_F$',5.7,ha='center',va='top');old.save(fig,'field_fullresolution_qf')
    summaries=[json.loads((B/f'numerics/L{i}/summary.json').read_text()) for i in range(3)]
    elements=[s['tetrahedra'] for s in summaries]+[case('local_A'+str(i))['tetrahedra'] for i in range(1,4)]
    values=np.array([[x['Q95_MPa'] for x in s['table9']] for s in summaries]+[vals('local_A'+str(i))[:,1].tolist() for i in range(1,4)])
    fig=old.canvas(58,91);ax=old.axmm(fig,11,47,44,36)
    for j in range(6):ax.plot(elements,values[:,j],'-o',c=COLORS[j],ms=2,label=LABELS[j],lw=.7)
    ax.set(xscale='log',yscale='log');ax.set_xlabel('Tetrahedral elements',labelpad=1);ax.set_ylabel(r'$Q_{0.95}$ (MPa)',labelpad=1);ax.grid(alpha=.17,lw=.4);ax.set_xticks([1e5,1e6]);ax.set_yticks([1,10,100]);ax.tick_params(pad=1);ax.legend(ncol=3,fontsize=5.3,loc='lower right',columnspacing=.6,handlelength=1)
    old.panel(fig,1,89,'a');old.txt(fig,30,88,'Global + local refinement',6.5,ha='center',va='top')
    ax=old.axmm(fig,11,9,44,25);change=100*abs(values[-1]-values[-2])/values[-1];ax.bar(range(6),change,color=COLORS,width=.7);ax.axhline(.5,ls='--',c='#333333',lw=.65);ax.set_xticks(range(6),LABELS,fontsize=5.3);ax.set_ylabel('A2–A3 change (%)',labelpad=1);ax.set(ylim=(0,.56));ax.tick_params(pad=1)
    for i,v in enumerate(change):ax.text(i,v+.012,f'{v:.3f}',ha='center',fontsize=5.1)
    old.panel(fig,1,39,'b');old.txt(fig,31,38,'All six below 0.233%',6.5,ha='center',va='top');old.txt(fig,31,1,'Dashed: 0.5%; 18-quantile maximum <0.60%',5.1,ha='center');old.save(fig,'mesh_convergence_vertical')
    np.savez_compressed(R/'numerics/figure4_6_readback.npz',q95_MPa=q95,last_step_relative_percent=change,elements=elements)

def bilayer_stvk_views():
    a=np.load(D/'data/bilayer_StVK_L1/fields.npz');ref=np.load(B/'numerics/L1/solution.npz');q=(a['points_m']-ref['center_m'])@ref['basis']*1000;q[:,:2]*=-1;f=a['boundary_faces'];owner=a['boundary_owner'];poly=pv.PolyData(q,np.column_stack([np.full(len(f),3),f]).ravel());vm=a['von_mises_Pa'][owner]/1e6
    for j,cam in enumerate([(0,0,150),(100,20,140),(0,0,-150)]):previous.render(poly,vm,f'bilayer_stvk_view_{j}',cam,clim=(.1,300),log=True)
    (R/'review/bilayer_StVK_image_mapping.json').write_text(json.dumps(dict(source='bilayer_StVK_L1/fields.npz',material='Assumed candidate 0.5 mm crown shell/core; full objective StVK',pressure_MPa=1.,norm='log',limits_MPa=[.1,300],cmap='turbo',camera_vectors=[[0,0,150],[100,20,140],[0,0,-150]],render_window_pixels=[1400,1250],source_rasters_embedded_without_downsampling=True),indent=2))

def validation_plate():
    fig=old.canvas(183,145);results=json.loads((D/'review/final_readback_001/results.json').read_text());threshold=json.loads((D/'review/threshold_reconstruction.json').read_text())
    # Row one: volume, conditional geometry sensitivity, local percentile stability.
    ax=old.axmm(fig,10,110,43,22)
    volumes=np.array([5663.654461944,5642.047776744,5619.798825048]);ax.plot([95,100,105],volumes,'o-',c=old.BLUE,ms=3);ax.set(xlabel=r'Threshold / $T_0$ (%)',ylabel='Native volume (mm³)');ax.tick_params(pad=1);ax.grid(alpha=.15)
    old.panel(fig,1,143,'a');old.txt(fig,31,142,'Full native reconstructions',6.5,ha='center',va='top')
    ax=old.axmm(fig,71,110,43,22);changes=np.asarray(results['threshold_Q95_signed_percent'])
    for j in range(6):ax.plot([95,100,105],[changes[0,j],0,changes[1,j]],'o-',c=COLORS[j],ms=2)
    ax.set(xlabel=r'Threshold / $T_0$ (%)',ylabel=r'$Q_{0.95}$ change (%)',ylim=(-.9,.75));ax.axhline(0,c='#888',lw=.4);ax.grid(alpha=.15);ax.tick_params(pad=1)
    old.panel(fig,62,143,'b');old.txt(fig,92,142,'Fixed 0.288 mm FE grid',6.5,ha='center',va='top')
    ax=old.axmm(fig,133,110,43,22)
    for shift,key,color,label in [(-.16,'homogeneous_last_step_all_18_percent',old.BLUE,'Single material'),(.16,'bilayer_last_step_all_18_percent',old.ORANGE,'Candidate bilayer')]:
        dat=np.asarray(results[key]);ax.bar(np.arange(6)+shift,dat[:,1],width=.29,color=color,label=label)
    ax.axhline(.5,c='#555',ls='--',lw=.6);ax.set(ylim=(0,.75),ylabel=r'A2–A3 $Q_{0.95}$ change (%)');ax.set_xticks(range(6),LABELS,fontsize=5.2);ax.tick_params(pad=1);ax.legend(fontsize=4.9,frameon=False,handlelength=1)
    old.panel(fig,123,143,'c');old.txt(fig,153,142,'Adjacent local meshes',6.5,ha='center',va='top')
    # Row two: actual cell-labelled interface, support-sensitive peaks, Robin grid.
    a=np.load(D/'data/bilayer_A3_0p5mm/fields.npz');ref=np.load(B/'numerics/L0/solution.npz');q=(a['points_m']-ref['center_m'])@ref['basis']*1000;t=a['tets'];grid=pv.UnstructuredGrid(np.column_stack([np.full(len(t),4),t]).ravel(),np.full(len(t),10,np.uint8),q);grid.cell_data['phase']=(a['mu_Pa']>25e9).astype(np.uint8);cut=grid.slice(normal=(0,0,1),origin=(0,0,0)).triangulate();face=cut.faces.reshape(-1,4)[:,1:];ax=old.axmm(fig,15,64,35,26);ax.add_collection(PolyCollection(cut.points[face][:,:,:2],array=cut['phase'],cmap=ListedColormap(['#a3b8c5','#dbb34e']),clim=(0,1),edgecolors='none',rasterized=True));ax.autoscale();ax.set_aspect('equal');ax.set_xlabel('Transverse (mm)',labelpad=1);ax.set_ylabel('Longitudinal (mm)',labelpad=1);ax.tick_params(pad=1,labelsize=5.3)
    old.panel(fig,1,100,'d');old.txt(fig,31,99,'Independent candidate layers',6.5,ha='center',va='top');old.txt(fig,31,51.5,'Gold: shell; blue: core | 0.5 mm rule',5.2,ha='center')
    ax=old.axmm(fig,71,66,43,25)
    for names,c,label in [(['local_A1','local_A2','local_A3'],old.BLUE,'Single material'),(['bilayer_L2_0p5mm','bilayer_A2_0p5mm','bilayer_A3_0p5mm'],old.ORANGE,'Candidate bilayer')]:
        ax.plot([case(n)['tetrahedra']/1e6 for n in names],[case(n)['peak_MPa'] for n in names],'o-',c=c,ms=2.5,label=label)
    ax.set(xlabel='Tetrahedra (million)',ylabel='Point peak (MPa)');ax.grid(alpha=.15);ax.tick_params(pad=1);ax.legend(fontsize=4.9,frameon=False,handlelength=1)
    old.panel(fig,62,100,'e');old.txt(fig,92,99,'Peaks meet fixed-support cells',6.5,ha='center',va='top');old.txt(fig,92,51.5,'Peak drift is distinct from quantile stability',5.2,ha='center')
    ax=old.axmm(fig,133,66,43,25);ks=np.arange(10,16);u=np.array([case('robin_L1_k'+str(k))['max_displacement_mm'] for k in ks]);ax.semilogy(ks,u,'o-',c=old.BLUE,ms=2.5);ax.axvspan(10,12,alpha=.08,color=old.RED);ax.set(xlabel=r'$\log_{10} k$ (N m$^{-3}$)',ylabel=r'$u_{\max}$ (mm)');ax.tick_params(pad=1);ax.grid(alpha=.15)
    old.panel(fig,123,100,'f');old.txt(fig,153,99,'Calibratable Robin attachment',6.5,ha='center',va='top');old.txt(fig,153,51.5,'Shaded: large-motion linear coefficients',5.2,ha='center')
    # Actual new full StVK fields; native raster dimensions are retained in PDF/SVG.
    for j,title in enumerate(['Front','Oblique','Reverse']):
        x=61*j;old.picture(old.axmm(fig,x+4,9,53,34),F/f'bilayer_stvk_view_{j}.png');old.panel(fig,x+1,49,'ghi'[j]);old.txt(fig,x+31,48,title+' / candidate bilayer StVK',6.2,ha='center',va='top')
    cb=fig.colorbar(plt.cm.ScalarMappable(norm=LogNorm(.1,300),cmap='turbo'),cax=old.axmm(fig,62,4,55,1.3),orientation='horizontal');cb.set_ticks([.1,1,10,100,300],labels=['0.1','1','10','100','300']);cb.ax.tick_params(labelsize=5,pad=1);old.txt(fig,59,4.7,'MPa',5.4,ha='right');old.txt(fig,122,4.7,'Computed StVK σvM; log scale; 1 MPa',5.3)
    old.save(fig,'validation_material_attachment')

if __name__=='__main__':
    field_and_convergence();bilayer_stvk_views();validation_plate()
