"""Stream every original native triangle for Figure 8; no surface reduction.
Native display vertices use nearest boundary-owner principal tensile values
from a separately identified coarse P1 solution, not a native-volume solve.
"""
from pathlib import Path
import numpy as np,json,subprocess,struct,hashlib
from scipy.spatial import cKDTree
from matplotlib.colors import ListedColormap,LogNorm
from PIL import Image
import meshio, trimesh
N=Path(__file__).resolve().parents[1];P=N.parents[2];O=N/'numerics/crown_root_100mm';F=N/'figures';R=P/'output/jaw_tooth_transfer_2026-11-22'
a=np.load(P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0/solution.npz');p,t,f,basis=a['points_m'],a['tets'],a['boundary_faces'],a['basis']
reg=np.load(R/'data_v3/registration.npz');state=np.load(R/'edge_data/RA_pose0_oblique30_tied.npz');sig=np.maximum(np.linalg.eigvalsh(state['stress_Pa'])[:,-1],0)/1e6
lookup={tuple(sorted(face)):j//4 for j,face in enumerate(t[:,[[1,2,3],[0,2,3],[0,1,3],[0,1,2]]].reshape(-1,3))};owner=np.array([lookup[tuple(sorted(face))]for face in f]);tree=cKDTree(p[f].mean(1)*1000)
J=meshio.read(P/'applied_forces/custom_solver/great_white_jaw_fullres_gmsh_alg1_tet_vol.msh');jv=J.points;jf=J.cells_dict['triangle'];assert len(jf)==1009016
jn=trimesh.Trimesh(jv,jf,process=False).vertex_normals
v=np.memmap(P/'output/current_native74_stress_2026-11-20/cache/vertices.f64',dtype='<f8',shape=(37951699,3),mode='r');nf=np.memmap(P/'output/current_native74_stress_2026-11-20/cache/triangles.u32',dtype='<u4',shape=(74293846,3),mode='r')
normal=np.memmap(P/'output/scale_acrylic_2026-11-20/data/normals.f32',dtype='<f4',shape=(37951699,3),mode='r')
# Recover a continuous scalar from the same verified P1 solution.
# The nodal stress diagnostic is the volume-weighted mean of incident
# element positive principal stresses. Projection uses 8 boundary nodes.
weights=np.zeros(len(p)); totals=np.zeros(len(p))
volume=a['volumes_m3']
for corner in range(4):
 np.add.at(weights,t[:,corner],volume)
 np.add.at(totals,t[:,corner],volume*sig)
boundary_nodes=np.unique(f)
nodal=totals[boundary_nodes]/weights[boundary_nodes]
field_tree=cKDTree(p[boundary_nodes]*1000)
appearance=P/'output/tooth_continuous_surfaces/cache'
source_v=np.load(appearance/'web_original_ct_vertices.npy',mmap_mode='r')
source_rgb=np.load(appearance/'natural_area_weighted_vertex_rgb.npy',mmap_mode='r')
assert len(source_v)==len(source_rgb)==16272624
appearance_tree=cKDTree(source_v)
natural_median=np.median(source_rgb[::100],axis=0)/255.
def pose(q):
 return (q*.001-reg['tooth_root_centre_m'])@reg['reference_rotation'].T*1000+reg['reference_location_m']*1000
mid=jv.mean(0);focus=pose(v[::100]).mean(0)
def camera(location,target,up=(0,0,1)):
 forward=np.array(target)-location;forward/=np.linalg.norm(forward);right=np.cross(forward,up);right/=np.linalg.norm(right);vv=np.cross(right,forward);return np.stack([right,vv,forward],axis=1)
C0=camera(mid+np.array([700.,-750,900]),mid+[0,45,0]);C1=C0
B=(v[::100]-a['center_m']*1000)@basis;mins=B.min(0);maxs=B.max(0)
# Orthographic panels, fixed coordinates and fixed same-case stress limits.
def project(x,k):
 if k in [0,1]:
  center=(mid+np.array([0,45,0])) if k==0 else focus;cam=C0 if k==0 else C1;scale=2.5 if k==0 else 24.;q=(x-center)@cam;return np.c_[900+q[:,0]*scale,800-q[:,1]*scale,q[:,2]]
 q=(x-a['center_m']*1000)@basis;return np.c_[900+q[:,0]*26,95+(q[:,1]-mins[1])*27.,-q[:,2]]
proc=subprocess.Popen([str(O/'native_figure8_raster'),str(O)],stdin=subprocess.PIPE,stderr=(O/'raster_counts.txt').open('w'))

def send(k,xyz,rgb,faces):
 rows=np.c_[project(xyz,k),rgb].astype('<f4');proc.stdin.write(struct.pack('<III',k,len(rows),len(faces)));proc.stdin.write(rows.tobytes());proc.stdin.write(np.asarray(faces,dtype='<u4').tobytes())
# Source jaw surface, not the stepped FE boundary.
for first in range(0,len(jf),300000):
 faces=jf[first:first+300000];ids,ix=np.unique(faces,return_inverse=True);q=jv[ids];rgb=np.tile([.75,.78,.8],(len(ids),1))
 for k in [0,1]:
  light=(C0 if k==0 else C1)@np.array([-.3,.4,-.86]);shade=.40+.60*np.maximum(jn[ids]@light,0);send(k,q,rgb*shade[:,None],ix.reshape(-1,3))
palette=ListedColormap(np.array(json.loads((N/'numerics/reference_palette_512.json').read_text())['RGBA_8bit'])/255);norm=LogNorm(1e-4,.1)
for first in range(0,len(nf),700000):
 faces=nf[first:first+700000];ids,ix=np.unique(faces,return_inverse=True);q=v[ids];ff=ix.reshape(-1,3);placement=pose(q)
 # Nearest original natural-colour vertex in the archived through-slice frame.
 appearance_q=q.copy();appearance_q[:,2]*=16/18
 _,natural_id=appearance_tree.query(appearance_q,workers=4,distance_upper_bound=.60)
 has_colour=natural_id<len(source_rgb)
 natural=np.tile(natural_median,(len(q),1))
 natural[has_colour]=source_rgb[natural_id[has_colour]]/255.
 shade=.82+.18*np.maximum(normal[ids]@reg['reference_rotation'].T@(-C0[:,2]),0)
 for k in [0,1]:send(k,placement,natural*shade[:,None],ff)
 distance,neighbours=field_tree.query(q,k=8,workers=4,distance_upper_bound=2.5)
 influence=1/np.maximum(distance,1e-10)**2
 safe=np.minimum(neighbours,len(nodal)-1)
 recovered=(influence*nodal[safe]).sum(1)/np.maximum(influence.sum(1),1e-30)
 colors=palette(norm(np.maximum(recovered,1e-12)))[:,:3]
 colors[distance[:,0]>1.5]=[.65,.67,.69]
 send(2,q,colors,ff)
 if first%7000000==0:print('Streamed native faces',first+len(faces),flush=True)
proc.stdin.close();assert proc.wait()==0
for k in range(3):
 raw=O/f'native_figure8_{k}.rgba';im=Image.frombytes('RGBA',(1800,1600),raw.read_bytes());im.save(F/f'native_figure8_{k}.png');raw.unlink()
anchor=project(focus[None],0)[0,:2].tolist()
record=dict(overview_window_center_px=anchor,overview_window_width_px=1800*2.5/24,
 overview_window_height_px=1600*2.5/24,source_natural_colour_vertices=len(source_v),natural_colour_cutoff_mm=.60,natural_colour_fallback='Median of source natural palette outside support',status='passed' ,native_tooth_triangles_per_panel=74293846,native_boundary_vertices=37951699,source_jaw_triangles_in_a=1009016,FE_jaw_boundary_triangles=281280,tooth_FE_tetrahedra=len(t),stress_case='RA_pose0_oblique30_tied',display='Original 74M surface; up to eight boundary nodes within 2.5 mm for inverse-distance interpolation of volume-weighted nodal principal tensile stress from the same P1 case; unlit; beyond 1.5 mm nearest-node distance is grey. All native triangles retained. Display recovery only.',colour_limits_MPa_per_N=[1e-4,.1],socket='Source jaw shape displayed; fitting/transfer measured to the FE jaw boundary. No anatomical socket is identified.',counts=(O/'raster_counts.txt').read_text())
(N/'review/figure8_native_counts.json').write_text(json.dumps(record,indent=2));print(record,flush=True)
