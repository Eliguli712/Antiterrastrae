Saved registered archive/current comparison and audit, 23 November 2026.
paired_surface_values.npz contains all 32,000 pairs, coordinates, distances and differences.
axial_profiles.csv contains the 20-bin means and Monte Carlo standard errors.
The authentic 191,031-row COMSOL export and original display script are included.
The primary replay also needs the archived BDF geometry cache, L0 frame and current A3 field.
Those larger inputs are identified by path and SHA-256 in the run manifest; they are not duplicated here.
This archive alone can recompute saved-pair statistics but is not the complete FE input archive.
Unmatched archive/current load cases: differences are descriptive, not calibrated stress errors.
