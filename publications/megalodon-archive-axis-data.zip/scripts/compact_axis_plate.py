#!/usr/bin/env python3
"""Remove unused title-band whitespace without changing any numerical input."""
from pathlib import Path
import numpy as np,csv
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm,Normalize
import revise_figures as plot
R=Path(__file__).resolve().parents[1];OUT=R/'numerics/archive_axis_comparison';plot.R=R;plot.F=R/'figures';plot.V=R/'svg';plot.REVIEW=R/'review'
a=np.load(OUT/'paired_surface_values.npz');valid=a['valid'];xi=a['xi'];s=a['s'];shape=np.column_stack([a['archive_shape'],a['current_shape']]);dshape=a['shape_delta']
rows=[{k:float(v) for k,v in row.items()} for row in csv.DictReader((OUT/'axial_profiles.csv').open())]
source=(R/'scripts/archive_axis_comparison.py').read_text();source='fig=plot.canvas'+source.split('fig=plot.canvas',1)[1];source=source.split("print(json.dumps",1)[0]
source=source.replace('183,61','183,56').replace(',59,',',54,').replace(',58,',',53,')
exec(compile(source,__file__,'exec'),globals())
