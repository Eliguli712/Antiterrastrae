#!/usr/bin/env python3
"""Read authentic COMSOL scalars; compare on a common area-sampled surface.

The archived loading/constitutive case is not independently identified. Differences
are descriptive case-to-case values, never a same-load error or calibration.
"""
from pathlib import Path
import json,time,hashlib,sys
import numpy as np
from scipy.spatial import cKDTree
from scipy.stats import pearsonr,spearmanr
import pyvista as pv
from PIL import Image
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm,Normalize
import revise_figures as plot

R=Path(__file__).resolve().parents[1];P=R.parents[2];D=P/'output/publication_validation_2026-11-12'
OUT=R/'numerics/archive_axis_comparison';OUT.mkdir(exist_ok=True)
F=R/'figures';plot.R=R;plot.F=F;plot.V=R/'svg';plot.REVIEW=R/'review'
start=time.monotonic();source=P/'DICOM_16um/exports/von_mises_data_smoothed.txt'
raw=np.loadtxt(source,comments='%');assert raw.shape==(191031,4)
v=np.load(P/'output/tooth_continuous_surfaces/cache/fe_v.npy',mmap_mode='r');faces=np.load(P/'output/tooth_continuous_surfaces/cache/fe_f.npy',mmap_mode='r')
assert len(v)==2767405 and len(faces)==5554286
tree=cKDTree(raw[:,:3]);distance,nearest=tree.query(v,workers=2);vertex_vm=raw[nearest,3]
check=np.linspace(0,len(v)-1,32,dtype=int)
for i in check:
    brute=np.linalg.norm(raw[:,:3]-v[i],axis=1);assert np.isclose(brute.min(),distance[i],rtol=1e-10,atol=1e-12)
sample_faces=faces[np.linspace(0,len(faces)-1,220000,dtype=np.int64)]
limits=np.quantile(vertex_vm[sample_faces].mean(1),[.02,.98]);assert np.allclose(limits,[56766.44283690944,326888.21709539363],rtol=2e-10)
meta=json.loads((P/'output/tooth_continuous_surfaces/source_report.json').read_text())['fe'];oldB=np.array(meta['orientation_basis']);oldC=np.array(meta['orientation_center_mm'])
# A display rotation only: match the requested crown-up triptych. No scalar edits.
qold=(np.asarray(v)-oldC)@oldB;qold[:,:2]*=-1
poly=pv.PolyData(qold,np.column_stack([np.full(len(faces),3,np.int32),faces]).ravel());poly.point_data['vm_MPa']=vertex_vm/1e6
for j,camera in enumerate([(0,0,150),(100,20,140),(0,0,-150)]):
    viewer=pv.Plotter(off_screen=True,window_size=(1400,1250));viewer.set_background('white');viewer.add_mesh(poly,scalars='vm_MPa',cmap='turbo',clim=limits/1e6,lighting=False,show_scalar_bar=False);viewer.camera_position=[camera,(0,0,0),(0,1,0)];viewer.enable_parallel_projection();viewer.reset_camera();im=viewer.screenshot(return_img=True);viewer.close();yy,xx=np.where(np.any(im[:,:,:3]<245,axis=2));Image.fromarray(im).crop((max(0,int(xx.min())-10),max(0,int(yy.min())-10),min(im.shape[1],int(xx.max())+11),min(im.shape[0],int(yy.max())+11))).save(F/f'archived_comsol_mapped_view_{j}.png')
del poly,qold
ref=np.load(P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0/solution.npz');a=np.load(D/'data/local_A3/fields.npz');p=a['points_m'];t=a['tets'];bf=a['boundary_faces'];q=(p-ref['center_m'])@ref['basis']*1000
local=np.array([[1,2,3],[0,3,2],[0,1,3],[0,2,1]]);af=t[:,local].reshape(-1,3);_,ix,count=np.unique(np.sort(af,axis=1),axis=0,return_index=True,return_counts=True);ix=ix[count==1];assert np.array_equal(np.sort(af[ix],axis=1),np.sort(bf,axis=1));owner=ix//4;del af
area=np.linalg.norm(np.cross(p[bf[:,1]]-p[bf[:,0]],p[bf[:,2]]-p[bf[:,0]]),axis=1)/2
rng=np.random.default_rng(20261119);pick=rng.choice(len(bf),32000,p=area/area.sum());u=rng.random(32000);w=rng.random(32000);weights=np.column_stack([1-np.sqrt(u),np.sqrt(u)*(1-w),np.sqrt(u)*w]);points=(p[bf[pick]]*weights[:,:,None]).sum(1)
archived_xyz=np.asarray(v).copy();archived_xyz[:,2]*=18/16
archive_mesh=pv.PolyData(archived_xyz,np.column_stack([np.full(len(faces),3,np.int32),faces]).ravel());face_id,closest=archive_mesh.find_closest_cell(points*1000,return_closest_point=True)
tri=archived_xyz[faces[face_id]];e0=tri[:,1]-tri[:,0];e1=tri[:,2]-tri[:,0];ep=closest-tri[:,0];d00=np.sum(e0*e0,1);d01=np.sum(e0*e1,1);d11=np.sum(e1*e1,1);d20=np.sum(ep*e0,1);d21=np.sum(ep*e1,1);det=d00*d11-d01*d01
b1=(d11*d20-d01*d21)/det;b2=(d00*d21-d01*d20)/det;bary=np.column_stack([1-b1-b2,b1,b2]);assert bary.min()>-1e-5 and np.allclose(bary.sum(1),1)
archive=vertex_vm[faces[face_id]]*bary;archive=archive.sum(1)/1e6;current=a['von_mises_Pa'][owner[pick]]/1e6;dist=np.linalg.norm(points*1000-closest,axis=1);valid=dist<=.5
qq=(points-ref['center_m'])@ref['basis']*1000;surfaceq=(ref['points_m'][np.unique(ref['boundary_faces'])]-ref['center_m'])@ref['basis']*1000
lo=surfaceq.min(0);hi=surfaceq.max(0);s=(qq[:,1]-lo[1])/(hi[1]-lo[1]);xi=2*(qq[:,0]-(lo[0]+hi[0])/2)/(hi[0]-lo[0]);zeta=2*(qq[:,2]-(lo[2]+hi[2])/2)/(hi[2]-lo[2])
assert valid.sum()>24000
normalizers=np.quantile(np.stack([archive[valid],current[valid]]),.95,axis=1);shape=np.column_stack([archive/normalizers[0],current/normalizers[1]]);delta=current-archive;dshape=shape[:,1]-shape[:,0]
rows=[]
for k in range(20):
    mask=valid&(s>=k/20)&(s<(k+1)/20 if k<19 else s<=1)
    n=int(mask.sum())
    if n<3:continue
    rows.append(dict(s_mid=(k+.5)/20,n=n,archive_mean_MPa=float(archive[mask].mean()),current_mean_MPa=float(current[mask].mean()),delta_mean_MPa=float(delta[mask].mean()),archive_shape_mean=float(shape[mask,0].mean()),current_shape_mean=float(shape[mask,1].mean()),shape_delta_mean=float(dshape[mask].mean()),shape_delta_SE_MC=float(dshape[mask].std(ddof=1)/np.sqrt(n))))
import csv
with (OUT/'axial_profiles.csv').open('w',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
np.savez_compressed(OUT/'paired_surface_values.npz',points_m=points,xi=xi,s=s,zeta=zeta,archive_MPa=archive,current_MPa=current,delta_MPa=delta,archive_shape=shape[:,0],current_shape=shape[:,1],shape_delta=dshape,projection_distance_mm=dist,valid=valid,current_boundary_face=pick,archive_boundary_face=face_id)
record=dict(status='passed',raw_source_samples=len(raw),raw_archive_range_Pa=[float(raw[:,3].min()),float(raw[:,3].max())],original_display_quantiles=[.02,.98],original_display_limits_Pa=limits.tolist(),original_display_limits_MPa=(limits/1e6).tolist(),normalization='1 MPa = 10^6 Pa; field shape = sigma / its own common-surface Q95. Global transverse xi, apex-to-root s and thickness zeta use the fixed L0 frame. No coordinate offset is applied to a stress scalar.',original_export_header='Model static_dynamics.mph; Length unit m. Literal numeric coordinates agree with the archived BDF; CT registration treats those numbers as image-coordinate mm. Header/physical-scale and strict3bdf case identity remain unresolved.',source_to_native_z_factor=18/16,axes=dict(center_mm=(ref['center_m']*1000).tolist(),basis_columns_transverse_longitudinal_thickness=ref['basis'].tolist(),ranges_mm=[lo.tolist(),hi.tolist()]),area_sampling=dict(n=32000,seed=20261119,accepted=int(valid.sum()),fraction=float(valid.mean()),maximum_allowed_projection_mm=.5),paired_surface_Q95_MPa=normalizers.tolist(),mean_case_difference_MPa=float(delta[valid].mean()),absolute_case_difference_Q95_MPa=float(np.quantile(abs(delta[valid]),.95)),Pearson_r=float(pearsonr(archive[valid],current[valid]).statistic),Spearman_rho=float(spearmanr(archive[valid],current[valid]).statistic),scope='Different cases: unknown archive pressure/material/support versus homogeneous A3 1 MPa. Raw differences are descriptive, not same-load error, constitutive effect, fracture evidence or bite calibration. Normalization is for field shape only; quantiles are common reference surface-area Monte Carlo summaries, not Table 9 volume quantiles.',runtime_seconds=time.monotonic()-start)
(R/'review/axis_comparison_run_001/results.json').write_text(json.dumps(record,indent=2));(OUT/'summary.json').write_text(json.dumps(record,indent=2))
fig=plot.canvas(183,61)
for j,title in enumerate(['Archive / own Q95','Current A3 / own Q95','Current − archive']):
    ax=plot.axmm(fig,7+j*34,13,24,36);values=shape[:,j] if j<2 else dshape;norm=LogNorm(.01,3) if j<2 else Normalize(-2,2);sel=np.flatnonzero(valid)[::2];im=ax.scatter(xi[sel],s[sel],c=values[sel],s=.18,cmap='turbo' if j<2 else 'RdBu_r',norm=norm,linewidths=0,rasterized=True);ax.set(xlim=(-1.15,1.15),ylim=(-.02,1.02),xticks=[-1,0,1],yticks=[0,.5,1]);ax.set_xlabel(r'$\xi$ [−]',labelpad=1);ax.set_ylabel(r'$s$ [−]',labelpad=1);ax.tick_params(labelsize=5,pad=1);plot.panel(fig,j*34+.5,59,'abc'[j]);plot.txt(fig,j*34+17,58,title,5.8,ha='center',va='top')
    cb=fig.colorbar(im,cax=plot.axmm(fig,31.5+j*34,17,1,27));cb.set_ticks([.01,.1,1,3] if j<2 else [-2,0,2]);cb.ax.tick_params(labelsize=4.3,pad=1)
ax=plot.axmm(fig,116,15,27,33);xx=np.array([x['s_mid'] for x in rows]);ax.plot(xx,[x['archive_shape_mean'] for x in rows],c=plot.BLUE,label='Archive');ax.plot(xx,[x['current_shape_mean'] for x in rows],c=plot.ORANGE,label='A3');ax.set(xlabel=r'$s$ [−]',ylabel='Axial mean / own Q95');ax.tick_params(labelsize=5,pad=1);ax.legend(fontsize=4.8,frameon=False);ax.grid(alpha=.15);plot.panel(fig,108,59,'d');plot.txt(fig,130,58,'Same surface-area measure',5.8,ha='center',va='top')
ax=plot.axmm(fig,154,15,27,33);yy=np.array([x['shape_delta_mean'] for x in rows]);se=np.array([x['shape_delta_SE_MC'] for x in rows]);ax.plot(xx,yy,c=plot.RED);ax.fill_between(xx,yy-1.96*se,yy+1.96*se,color=plot.RED,alpha=.18);ax.axhline(0,c='#777',lw=.5);ax.set(xlabel=r'$s$ [−]',ylabel='Mean normalised difference');ax.tick_params(labelsize=5,pad=1);ax.grid(alpha=.15);plot.panel(fig,146,59,'e');plot.txt(fig,167,58,'±1.96 MC standard errors',5.5,ha='center',va='top')
plot.txt(fig,91.5,1.7,'s = 0 apex → 1 root | ξ, ζ: signed whole-tooth spans | unmatched loads: shape comparison, not a stress-error test',5.2,ha='center');plot.save(fig,'archive_axis_comparison')
print(json.dumps({k:record[k] for k in ['raw_archive_range_Pa','original_display_limits_MPa','area_sampling','paired_surface_Q95_MPa','mean_case_difference_MPa','Pearson_r','Spearman_rho']},indent=2))
