"""Update the vector widths of existing cervical guides without rerendering images."""
from collections import Counter
import json
from pathlib import Path
import re
import tempfile

import fitz

SOURCE = Path(__file__).resolve().parents[1]
# Format: (original width in pt, revised width in pt, original sRGB colour,
# expected paths). The preview streams express distances at a 10× scale.
SPECIMEN = [
    (.78, .48, (142, 231, 246), 3),
    (1.22, .66, (255, 195, 109), 3),
    (1.68, 1.00, (21, 32, 44), 3),
    (2.12, 1.18, (21, 32, 44), 3),
]
FIELD = [
    (1.00, .62, (132, 218, 240), 1),
    (1.00, .62, (255, 203, 115), 1),
    (1.80, 1.14, (24, 32, 50), 2),
    (.68, .45, (132, 218, 240), 2),
    (.68, .45, (255, 203, 115), 2),
    (1.16, .90, (29, 37, 55), 4),
]
NUMBER = rb'(?:\d+(?:\.\d+)?|\.\d+)'
STROKE = re.compile(
    rb'(?<![0-9.])(?P<width>'+NUMBER+rb')(?P<ops>\s+w\s+'
    rb'(?:(?:\s*\[[^\]]*\]\s+0\s+d|\s*\d+\s+[Jj])\s+)*)'
    rb'(?P<r>'+NUMBER+rb')\s+(?P<g>'+NUMBER+rb')\s+(?P<b>'+NUMBER+rb')\s+RG'
)


def edit(name, rules, scale):
    path = SOURCE / 'figures' / name
    doc = fitz.open(path)
    page = doc[0]
    before_draw = page.get_drawings()
    old_text = page.get_text()
    original_images = [(d['digest'], d['bbox']) for d in page.get_image_info(hashes=True)]
    counts = Counter()

    def replacement(match):
        width = float(match['width']) / scale
        rgb = tuple(round(float(match[key]) * 255) for key in ['r', 'g', 'b'])
        for old, new, target, _ in rules:
            if abs(width - old) < 1e-6 and max(abs(a-b) for a, b in zip(rgb, target)) <= 1:
                counts[(old, target)] += 1
                return f'{new*scale:g}'.encode() + match.group()[len(match['width']):]
        return match.group()

    for xref in page.get_contents():
        src = doc.xref_stream(xref)
        edited = STROKE.sub(replacement, src)
        if src != edited:
            doc.update_stream(xref, edited)
    expected = {(old, rgb): count for old, _, rgb, count in rules}
    assert dict(counts) == expected, (name, counts)
    with tempfile.TemporaryDirectory(dir=path.parent) as tmp:
        new_path = Path(tmp) / path.name
        doc.save(new_path, deflate=True)
        with fitz.open(new_path) as new_doc:
            new_page = new_doc[0]
            assert new_page.get_text() == old_text
            assert [(d['digest'], d['bbox']) for d in new_page.get_image_info(hashes=True)] == original_images
            new_draw = new_page.get_drawings()
            assert len(new_draw) == len(before_draw)
            assert sum(abs(a['width']-b['width']) > 1e-5 for a,b in zip(before_draw,new_draw) if a.get('width') and b.get('width')) == sum(expected.values())
            assert all(a['items'] == b['items'] for a, b in zip(before_draw,new_draw))
        doc.close()
        new_path.replace(path)
    return {'figure': name, 'changed_paths': sum(expected.values()), 'image_and_vector_geometry_unchanged': True}


if __name__ == '__main__':
    result = [
      edit(f'{stem}{suffix}.pdf', rules, scale)
      for stem, rules in [('geometry_pack_1_channel_halves', SPECIMEN), ('field_qf_shared_cervical', FIELD)]
      for suffix, scale in [('', 1), ('_preview', 10)]
    ]
    (SOURCE/'review/cervical_stroke_width_checks.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
