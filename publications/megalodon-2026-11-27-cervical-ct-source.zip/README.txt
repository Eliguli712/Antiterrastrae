Compile DebunkMeg_complete_2026-11-19.tex twice with XeLaTeX.
For the publication-resolution artwork, define FullResolutionArtwork before input:
xelatex '\def\FullResolutionArtwork{1}\input{DebunkMeg_complete_2026-11-19.tex}'
This 12-page revision includes the acquisition-plane contours and consistent cervical guides.
The previous PCA panel and raw meshes remain available in the linked gallery and earlier sources.
The figure-replay scripts use the original project inputs. The included figure PDFs are ready to compile.
