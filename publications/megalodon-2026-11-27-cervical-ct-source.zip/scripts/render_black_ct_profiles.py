"""Acquired 18 µm CT sections with optional light-background profile charts."""
import argparse
import json

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from matplotlib.collections import LineCollection
from scipy.stats import pearsonr, spearmanr

import profile_figures as src

paper, project = src.R, src.P
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--light-profiles', action='store_true')
parser.add_argument('--curvature-contours', action='store_true')
args = parser.parse_args()
light = args.light_profiles
if args.curvature_contours:
    from ct_boundary_curvature import section_arcs
lo, hi = -3292, 26623
fig = src.old.canvas(183,115)
fig.set_facecolor('black')
if light:
    from matplotlib.patches import Rectangle
    fig.add_artist(Rectangle((0,5/115),1,36/115,transform=fig.transFigure,
                             facecolor='white',edgecolor='none',zorder=-1))
style = {'text.color':'#f1f4fa','axes.labelcolor':'#f1f4fa',
         'xtick.color':'#e0ebf4','ytick.color':'#e0ebf4','axes.edgecolor':'#b8c7d1',
         'axes.facecolor':'black'}
area_colour, mean_colour, peak_colour = '#68c5f6', '#efb354', '#f49da4'
cmap = mpl.colormaps['gray'].with_extremes(bad='black')
mask_volume = np.memmap(project/'output/ct_web_2026-11-19/cache/selected_native_mask.u8',
                        dtype='u1',mode='r',shape=(2886,1903,746))
crop_origin = [392,76,76]  # acquired X, Y, Z indices of the mask region
records=[]
with mpl.rc_context(style):
    for j, row in enumerate(src.report['directions']):
        left=2+j*61
        key=row['key']
        raw=src.A[key+'_raw_maximum']
        axes=[(0,1),(0,2),(1,2)][j]
        index=row['max_native_index']
        plane = [lambda:mask_volume[index-crop_origin[2],:,:],
                 lambda:mask_volume[:,index-crop_origin[1],:],
                 lambda:mask_volume[:,:,index-crop_origin[0]]][j]()
        # This fills only the two-dimensional DISPLAY envelope to show
        # original intensity inside internal low-attenuation areas.
        foreground = np.zeros(raw.shape, dtype=bool)
        y0,x0=(crop_origin[axes[1]],crop_origin[axes[0]])
        foreground[y0:y0+plane.shape[0],x0:x0+plane.shape[1]] = plane != 0
        mask = src.ndi.binary_fill_holes(foreground)
        y,x=np.where(mask)
        ax=src.old.axmm(fig,left+6,51,49,53)
        limit_x=slice(max(0,x.min()-32),min(raw.shape[1],x.max()+33))
        limit_y=slice(max(0,y.min()-32),min(raw.shape[0],y.max()+33))
        masked=mask[limit_y,limit_x]
        section=raw[limit_y,limit_x]
        image=Image.fromarray(np.uint8(np.rint(255*np.clip((section.astype(float)-lo)/(hi-lo),0,1))*masked))
        if not light and not args.curvature_contours:
            image.save(paper/'figures'/f'figure2_{key}_native_black.png')
            image.thumbnail((1252,1252),Image.Resampling.LANCZOS)
        xx=src.origin[axes[0]]-.009
        yy=src.origin[axes[1]]-.009
        ax.imshow(image,cmap='gray',vmin=0,vmax=255,origin='lower',interpolation='none',
                  extent=(xx+limit_x.start*.018,xx+limit_x.stop*.018,
                          yy+limit_y.start*.018,yy+limit_y.stop*.018))
        record = dict(axis=row['axis'],index=index,section_shape=list(raw.shape))
        if args.curvature_contours:
            arcs = section_arcs(foreground[limit_y,limit_x], masked,
                                src.origin[list(axes)] + .018*np.array([limit_x.start,limit_y.start]))
            widths = [.63 if metrics['kind']=='silhouette' else .58 for _,_,metrics in arcs]
            ax.add_collection(LineCollection([path for red,blue,_ in arcs for path in (red,blue)],
                colors=['#f54656','#39a8f8']*len(arcs),
                linewidths=np.repeat(widths,2),zorder=3,capstyle='butt',joinstyle='round'))
            record['boundaries'] = [metrics for _,_,metrics in arcs]
        else:
            ax.contour(mask,levels=[.5],colors='#94b8ce',linewidths=.22,
                       origin='lower',extent=src.extent(raw,axes))
        for setter, coord, dim, n in [(ax.set_xlim,x,axes[0],raw.shape[1]),(ax.set_ylim,y,axes[1],raw.shape[0])]:
            setter(src.origin[dim]+max(0,coord.min()-30)*.018,src.origin[dim]+min(n,coord.max()+31)*.018)
        ax.set_xlabel('XYZ'[axes[0]]+' (LPS mm)',labelpad=1)
        ax.set_ylabel('XYZ'[axes[1]]+' (LPS mm)',labelpad=1)
        ax.tick_params(pad=1,labelsize=6)
        src.old.panel(fig,left,113,'abc'[j])
        src.old.txt(fig,left+30,112,f'{row["axis"]} = {index}  ·  Maximal section',7,ha='center',va='top')
        src.old.txt(fig,left+30,107,f'{row["max_area_mm2"]:.3f} mm²',6.4,ha='center',va='top')
        ax=src.old.axmm(fig,left+8,12,49,25)
        area=src.A[key+'_counts'].astype(float)
        mean=src.A[key+'_mean_raw']
        use=src.A[key+'_analysis_mask']
        position=src.A[key+'_LPS_mm']
        r, rho=pearsonr(area[use],mean[use]).statistic,spearmanr(area[use],mean[use]).statistic
        assert int(use.sum())==row['analysis_planes']
        assert np.isclose(r,row['Pearson_area_vs_mean_raw']) and np.isclose(rho,row['Spearman_area_vs_mean_raw'])
        scaled=np.full(len(mean),np.nan)
        scaled[use]=(mean[use]-mean[use].min())/np.ptp(mean[use])
        chart_bg, chart_ink = ('white', '#172838') if light else ('black', '#f1f4fa')
        if light:
            ax.set_facecolor(chart_bg)
            ax.spines[['left','bottom']].set_color(chart_ink)
            ax.tick_params(colors=chart_ink)
        ax.plot(position,area/area.max(),c='#1f78b2' if light else area_colour,lw=1.05,label='Area / maximum')
        ax.plot(position,scaled,c='#a65b13' if light else mean_colour,lw=.95,label='Mean intensity, scaled')
        ax.axvline(row['max_plane_LPS_mm'],color='#b23a44' if light else peak_colour,lw=.75,ls=':')
        ax.set_ylim(-.03,1.05)
        ax.set_xlabel(row['axis']+' (LPS mm)',labelpad=1,color=chart_ink)
        ax.set_ylabel('Normalised trace',labelpad=1,color=chart_ink)
        ax.tick_params(pad=1,labelsize=5.8)
        ax.grid(color='#637682',alpha=.3,lw=.4)
        ax.legend(fontsize=5,frameon=True,facecolor=chart_bg,labelcolor=chart_ink,edgecolor='none',loc='best',handlelength=1.2)
        src.old.panel(fig,left,45,'def'[j])
        src.old.txt(fig,left+32,44,f'r = {r:.3f}   ρ = {rho:.3f}   n = {use.sum():,}',6.35,ha='center',va='top')
        records.append(dict(**record,r=r,rho=rho,n=int(use.sum())))
    if args.curvature_contours:
        src.old.txt(fig,23,3.5,'18 µm  ·  Raw window [−3292, 26623]',5.8,ha='center')
        src.old.txt(fig,88,3.5,'Red: high-curvature-tail half',5.8,ha='center',color='#ff717c')
        src.old.txt(fig,150,3.5,'Blue: complementary half',5.8,ha='center',color='#61bcff')
        stem = 'geometry_pack_2_contours'
    else:
        src.old.txt(fig,91.5,1.5,'18 µm sampling   |   Shared raw window [−3292, 26623]   |   Black exterior mask',6,ha='center')
        stem = 'geometry_pack_2_acquired_alternative' if light else 'geometry_pack_2_black'
    fig.savefig(paper/'figures'/f'{stem}.pdf',dpi=600,facecolor='black')
    fig.savefig(paper/'figures'/f'{stem}.png',dpi=320,facecolor='black')
record = ('figure2_contours.json' if args.curvature_contours else
          'figure2_acquired_alternative.json' if light else 'figure2_black_CT.json')
audit = {'section_background':'black','profile_background':'white' if light else 'black',
    'raw_window':[lo,hi],'greyscale':'higher attenuation is brighter','views':records,
    'display_envelope':'Hole-filled selected specimen cross-section for display only. Original intensities in the envelope and original profiles.'}
if args.curvature_contours:
    audit['boundaries'] = ('Main display outline and enclosed mask gaps with bounding-box diagonal >=0.35 mm and area >=0.004 mm². '
                           'Original 0.018 mm mask paths split into contiguous equal-arclength halves. '
                           'Red maximises excess absolute curvature above each boundary’s 95th percentile. '
                           'Periodic Gaussian derivative scale 0.036 mm. Blue completes the path.')
(paper/'review'/record).write_text(json.dumps(audit,indent=2))
