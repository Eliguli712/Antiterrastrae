Tooth-scale Stress Localisation in a µCT-derived Otodus megalodon Model
Manuscript for review, 25 November 2026 (New York).

The source compiles with XeLaTeX and the TeX Gyre Termes, TeX Gyre Heros
and Latin Modern Mono fonts. Run the following command twice from this directory.

  xelatex -interaction=nonstopmode -halt-on-error -jobname=DebunkMeg_full '\def\FullResolutionArtwork{1}\input{DebunkMeg_complete_2026-11-19.tex}'

Opening DebunkMeg_complete_2026-11-19.tex directly uses compact artwork
for the editor preview. The reference list is in the same TeX file.

The figure assets and numerical display audits in this archive support the paper.
The plotting scripts preserve their project-relative input paths. Re-rendering
source plates requires the project's original meshes, images and field exports.
The separate jaw-connection replay archive includes the exact solver inputs
for the twelve local connection cases and their original directory structure.
