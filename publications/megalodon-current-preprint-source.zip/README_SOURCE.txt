Author manuscript in development, 25 November 2026. Main file: DebunkMeg_complete_2026-11-19.tex
Compile twice with XeLaTeX (TeX Live with TeX Gyre and Latin Modern fonts).
All referenced figure PDFs and the inline bibliography are included.
Supplementary .tex files are reference fragments, not additional main documents.
The separately linked P1/P2 ZIP supplies exact inputs, fields, source and audit.
This TeX file is an exact copy of the open document, not a separate editorial version.
HAL/arXiv deposit, metadata verification and acceptance have not been performed.
Figure 1 archive colours have their own linear MPa scale; current StVK fields are identified separately.
