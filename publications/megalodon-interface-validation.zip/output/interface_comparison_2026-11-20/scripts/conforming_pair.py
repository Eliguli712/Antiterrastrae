#!/usr/bin/env python3
"""One frozen-domain geometric bilayer: isolate refinement and interface effects."""
from pathlib import Path
import sys,json,time
import numpy as np
import pyvista as pv

R=Path(__file__).resolve().parents[1];P=R.parents[1]
sys.path.insert(0,str(P/'output/publication_validation_2026-11-12/scripts'))
import elastic_diagnostics as fe
B=fe.B;fe.R=R
(R/'data').mkdir(exist_ok=True)
RUN=R/'review/run_001';start=time.monotonic()

def fit_mesh(points,tets,phi,boundary,limit=600000):
 """Clip each tet into two convex polyhedra, using shared global edge points.

 Every polygon uses a canonical minimum-index fan, including shared parent
 faces. Interior polyhedron centres then produce conforming tetrahedra.
 """
 new=points.tolist();point_parent=[-1]*len(points);cuts={};cells=[];parents=[];tags=[]
 original={tuple(sorted(f)):i for i,f in enumerate(boundary)};boundary_map={}
 faces0=[[1,2,3],[0,3,2],[0,1,3],[0,2,1]]
 def cross(a,b,parent):
  if phi[a]==0:return int(a)
  if phi[b]==0:return int(b)
  key=tuple(sorted((int(a),int(b))))
  if key not in cuts:
   w=phi[a]/(phi[a]-phi[b]);cuts[key]=len(new);new.append(((1-w)*points[a]+w*points[b]).tolist());point_parent.append(parent)
  return cuts[key]
 def fan(ids):
  ids=list(dict.fromkeys(ids))
  if len(ids)<3:return []
  j=int(np.argmin(ids));ids=ids[j:]+ids[:j]
  return [[ids[0],ids[k],ids[k+1]] for k in range(1,len(ids)-1)]
 for parent,tet in enumerate(tets):
  vals=phi[tet];crossed=vals.min()<0<vals.max()
  if not crossed:
   cells.append(tet.tolist());parents.append(parent);tags.append(2 if vals.max()<=0 else 1)
   for loc in faces0:
    face=tet[loc];key=tuple(sorted(face));fid=original.get(key)
    if fid is not None:boundary_map[key]=fid
   continue
  cutids=[]
  for i in range(4):
   if vals[i]==0:cutids.append(int(tet[i]))
   for j in range(i):
    if vals[i]*vals[j]<0:cutids.append(cross(tet[i],tet[j],parent))
  cutids=list(dict.fromkeys(cutids));assert len(cutids) in [3,4]
  cp=np.array([new[v] for v in cutids]);normal=np.linalg.solve(points[tet[1:]]-points[tet[0]],vals[1:]-vals[0]);normal/=np.linalg.norm(normal)
  axis=cp[0]-cp.mean(0);axis/=np.linalg.norm(axis);other=np.cross(normal,axis)
  angle=np.arctan2((cp-cp.mean(0))@other,(cp-cp.mean(0))@axis)
  interface=[cutids[j] for j in np.argsort(angle)]
  for phase in [-1,1]:
   polys=[]
   for loc in faces0:
    face=tet[loc];out=[]
    for j in range(3):
     aa=int(face[j]);bb=int(face[(j+1)%3]);ina=phase*phi[aa]>=0;inb=phase*phi[bb]>=0
     if ina:out.append(aa)
     if ina!=inb:out.append(cross(aa,bb,parent))
    triangles=fan(out);polys.extend(triangles)
    fid=original.get(tuple(sorted(face)))
    if fid is not None:
     for tri in triangles:boundary_map[tuple(sorted(tri))]=fid
   polys.extend(fan(interface));verts=sorted({v for tri in polys for v in tri})
   c=len(new);new.append(np.mean([new[v] for v in verts],axis=0).tolist());point_parent.append(parent)
   for tri in polys:cells.append([c,*tri]);parents.append(parent);tags.append(2 if phase==-1 else 1)
  assert len(cells)<=limit,'Declared cell cap'
 new=np.array(new);cells=np.array(cells,np.int32);parents=np.array(parents,np.int32);tags=np.array(tags,np.uint8)
 det=np.linalg.det(new[cells[:,1:]]-new[cells[:,:1]]);assert np.min(abs(det))>1e-24
 cells[det<0]=cells[det<0][:,[1,0,2,3]]
 return new,cells,parents,tags,np.array(point_parent,np.int32),boundary_map

def main():
 # Hand-computable clipping volumes: one negative vertex gives 1/8 shell;
 # two negative vertices at symmetric half-edge intersections give 1/2.
 bp=np.array([[0.,0,0],[1,0,0],[0,1,0],[0,0,1]])
 bt=np.array([[0,1,2,3]]);bf=fe.core.boundary_faces(bp,bt)[0]
 for vals,expected in [(np.array([-.5,.5,.5,.5]),.125),(np.array([-.5,-.5,.5,.5]),.5)]:
  pp,tt,_,tag,_,_=fit_mesh(bp,bt,vals,bf);vol=abs(np.linalg.det(pp[tt[:,1:]]-pp[tt[:,:1]]))/6
  assert abs(vol.sum()-1/6)<1e-14 and abs(vol[tag==2].sum()/vol.sum()-expected)<1e-14
 a=np.load(B/'numerics/L0/solution.npz');p=a['points_m'];t=a['tets'];f=a['boundary_faces'];fixed=np.zeros(len(p),bool);fixed[a['fixed_node_indices']]=True
 surface=pv.PolyData(p,np.column_stack([np.full(len(f),3),f]).ravel())
 _,closest=surface.find_closest_cell(p,return_closest_point=True);distance=np.linalg.norm(closest-p,axis=1)
 q=(p-a['center_m'])@a['basis'];s=(q[:,1]-q[:,1].min())/np.ptp(q[:,1]);L=np.ptp(q[:,1])
 phi=np.maximum(distance-.0005,(s-.76)*L);snap=.000020;phi[abs(phi)<snap]=0
 centroid=p[t].mean(1);_,near=surface.find_closest_cell(centroid,return_closest_point=True);dc=np.linalg.norm(near-centroid,axis=1);sc=((centroid-a['center_m'])@a['basis'])[:,1];sc=(sc-q[:,1].min())/L
 parent_tag=np.where((dc<=.0005)&(sc<=.76),2,1).astype(np.uint8)
 pp,tt,parent,fitted_tag,point_parent,boundary_map=fit_mesh(p,t,phi,f)
 assert len(pp)<=220000 and len(tt)<=600000
 ff,area,normal=fe.core.boundary_faces(pp,tt)
 assert {tuple(sorted(v)) for v in ff}==set(boundary_map),'Boundary mismatch or internal cracks'
 fid=np.array([boundary_map[tuple(sorted(v))] for v in ff]);loaded=np.isin(fid,a['loaded_face_indices'])
 force=np.zeros_like(pp)
 for j in range(3):np.add.at(force,ff[loaded,j],-1e6*area[loaded,None]*normal[loaded]/3)
 fixed2=np.zeros(len(pp),bool);fixed2[:len(p)]=fixed
 # Shell cuts are crownward, outside the original rigid root-cap subcomplex.
 assert not np.any(fixed[t[np.unique(parent[np.arange(len(tt))>=0])]].all(1)&((phi[t[np.unique(parent)]]<0).any(1)))
 for i in range(len(p),len(pp)):
  if fixed[t[point_parent[i]]].all():fixed2[i]=True
 oldm=np.load(B/'numerics/L0/region_masks.npz')
 masks={k:np.isin(parent,oldm[k]) for k in fe.core.REGIONS}
 Vold=abs(np.linalg.det(p[t[:,1:]]-p[t[:,:1]]))/6
 Vnew=abs(np.linalg.det(pp[tt[:,1:]]-pp[tt[:,:1]]))/6
 accumulated=np.bincount(parent,weights=Vnew,minlength=len(t));assert np.max(abs(accumulated-Vold)/Vold)<1e-10
 np.testing.assert_allclose(force.sum(0),a['load_force_N'].sum(0) if 'load_force_N' in a else np.array([-454.8720000002047,-109.65090194945735,-13.381870660905854]),rtol=1e-10,atol=1e-9)
 base_fixed=fe.fixed_experiment
 def same_domain(points,cells,**_):
  if len(points)==len(p):
   faces,ar,no=fe.core.boundary_faces(p,t);mark=np.zeros(len(faces),bool);mark[a['loaded_face_indices']]=True;fo=np.zeros_like(p)
   for j in range(3):np.add.at(fo,faces[mark,j],-1e6*ar[mark,None]*no[mark]/3)
   return dict(faces=faces,areas=ar,normals=no,fixed=fixed,loaded=mark,force=fo,masks={k:np.isin(np.arange(len(t)),oldm[k]) for k in fe.core.REGIONS},parent=np.arange(len(t)))
  return dict(faces=ff,areas=area,normals=normal,fixed=fixed2,loaded=loaded,force=force,masks=masks,parent=parent)
 fe.fixed_experiment=same_domain
 construction=dict(nodes=len(pp),tetrahedra=len(tt),original_tetrahedra=len(t),interface='Nodal piecewise-affine level set of max(distance-0.5 mm, L*(s-.76)); values within 20 um of zero snapped to zero.',same_boundary=True,maximum_parent_volume_relative_error=float(np.max(abs(accumulated-Vold)/Vold)),source_material='Geometric candidate only, not independently identified EDJ.',coarse_shell_volume_fraction=float(Vold[parent_tag==2].sum()/Vold.sum()),fitted_shell_volume_fraction=float(Vnew[fitted_tag==2].sum()/Vnew.sum()))
 np.savez_compressed(R/'data/conforming_mesh.npz',points_m=pp,tets=tt,parent_L0=parent,phase_fitted=fitted_tag,phase_parent_centroid=parent_tag[parent],level_set_nodes=phi,point_parent=point_parent)
 rows=[]
 for name,points,cells,tags in [('coarse_centroid',p,t,parent_tag),('refined_parent_centroid',pp,tt,parent_tag[parent]),('interface_fitted',pp,tt,fitted_tag)]:
  result=fe.solve(name,points,cells,E=np.where(tags==2,100e9,30e9),nu=.25,tag=tags)
  fields=np.load(R/'data'/name/'fields.npz');epsstress=fields['stress_Pa'];u=fields['displacement_m'];gg,vv=fe.basis_data(points,cells);G=np.einsum('eai,eaj->eij',u[cells],gg);eps=(G+G.transpose(0,2,1))/2
  result['elastic_energy_J']=float(np.einsum('eij,eij,e->',epsstress,eps,vv))/2;rows.append(result)
 result=dict(status='completed',assertion_tested='Three same-domain cases: coarse centroid labels; fitted mesh with inherited parent-centroid labels; same fitted mesh with interface labels. The last pair has identical DOF, boundary/load/support and region unions.',construction=construction,cases=rows,interface_pair_Q95_change_percent={k:100*(rows[2]['regions'][j]['Q95_MPa']/rows[1]['regions'][j]['Q95_MPa']-1) for j,k in enumerate(fe.core.REGIONS)},scope='One L0 geometric-candidate interface experiment, not actual tissue identification or a fine A3 interface-convergence claim.',runtime_seconds=time.monotonic()-start)
 (RUN/'results.json').write_text(json.dumps(result,indent=2));(R/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))

if __name__=='__main__':main()
