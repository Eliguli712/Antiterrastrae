from pathlib import Path
import json,hashlib
import numpy as np

R=Path(__file__).resolve().parents[1];P=R.parents[1]
mesh=np.load(R/'data/conforming_mesh.npz');p=mesh['points_m'];t=mesh['tets'];parent=mesh['parent_L0'];point_parent=mesh['point_parent']
base=np.load(P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0/solution.npz');bp=base['points_m'];bt=base['tets']
rows=[]
for name in ['coarse_centroid','refined_parent_centroid','interface_fitted']:
 path=R/'data'/name/'fields.npz';a=np.load(path);pp=a['points_m'];tt=a['tets'];u=a['displacement_m'];X=pp[tt[:,1:]]-pp[tt[:,:1]]
 G=np.linalg.solve(X,u[tt[:,1:]]-u[tt[:,:1]]).transpose(0,2,1);eps=(G+G.transpose(0,2,1))/2
 la=a['lambda_Pa'];mu=a['mu_Pa'];sig=la[:,None,None]*np.trace(eps,axis1=1,axis2=2)[:,None,None]*np.eye(3)+2*mu[:,None,None]*eps;vol=abs(np.linalg.det(X))/6
 grad=np.empty((len(tt),4,3));grad[:,1:]=np.linalg.inv(X).transpose(0,2,1);grad[:,0]=-grad[:,1:].sum(1)
 fi=np.zeros_like(pp);local=np.einsum('eij,eaj,e->eai',sig,grad,vol)
 for j in range(4):np.add.at(fi,tt[:,j],local[:,j])
 fixed=a['fixed_nodes'];free=np.ones(len(pp),bool);free[fixed]=False;force=a['force_N'];res=fi-force
 rel=float(np.linalg.norm(res[free])/np.linalg.norm(force[free]));stress=float(np.linalg.norm(sig-a['stress_Pa'])/np.linalg.norm(sig));energy=float(np.einsum('eij,eij,e->',sig,eps,vol))/2
 assert max(rel,stress)<2e-6
 rows.append(dict(name=name,independent_force_residual=rel,tensor_relative_difference=stress,elastic_energy_J=energy,sha256=hashlib.file_digest(path.open('rb'),'sha256').hexdigest()))

coarse=np.load(R/'data/coarse_centroid/fields.npz');refined=np.load(R/'data/refined_parent_centroid/fields.npz');ub=coarse['displacement_m'];uf=refined['displacement_m']
embedded=np.empty_like(p);embedded[:len(bp)]=ub
indices=np.arange(len(bp),len(p));owners=point_parent[indices];X=bp[bt[owners,1:]]-bp[bt[owners,:1]]
tail=np.linalg.solve(X.transpose(0,2,1),(p[indices]-bp[bt[owners,0]])[:,:,None])[:,:,0]
assert tail.min()>-1e-10 and tail.sum(1).max()<1+1e-10
weights=np.column_stack([1-tail.sum(1),tail]);embedded[indices]=np.einsum('ea,eai->ei',weights,ub[bt[owners]])
X=p[t[:,1:]]-p[t[:,:1]];difference=uf-embedded
G=np.linalg.solve(X,difference[t[:,1:]]-difference[t[:,:1]]).transpose(0,2,1);eps=(G+G.transpose(0,2,1))/2
la=refined['lambda_Pa'];mu=refined['mu_Pa'];vol=abs(np.linalg.det(X))/6;sig=la[:,None,None]*np.trace(eps,axis1=1,axis2=2)[:,None,None]*np.eye(3)+2*mu[:,None,None]*eps
gap=float(np.einsum('eij,eij,e->',sig,eps,vol))/2;identity=abs(rows[1]['elastic_energy_J']-rows[0]['elastic_energy_J']-gap)/rows[1]['elastic_energy_J']
assert identity<1e-7 and gap>0
out=dict(status='passed',independent_cases=rows,nested_same_material_half_energy_gap_J=gap,nested_energy_identity_relative_error=identity,relative_discrete_energy_norm_gap_percent=float(100*np.sqrt(gap/rows[1]['elastic_energy_J'])),same_space_interface_energy_change_percent=100*(rows[2]['elastic_energy_J']/rows[1]['elastic_energy_J']-1),non_claims=['The nested discrete energy gap is not a certified continuum error upper bound.','The final pair changes geometric phase labels on exactly the same mesh; it does not identify a biological EDJ.'])
(R/'review/independent_pair_readback.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
