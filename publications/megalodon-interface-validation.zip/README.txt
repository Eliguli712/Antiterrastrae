Finite numerical validation, 20 November 2026.
Preserve the supplied directory tree and use the extracted root as cwd.

Candidate interface and root-support finite comparison.
The exact original L0 inputs, clipping/solving code, three resulting fields,
conforming mesh, run contract, before/after input hashes and independent
tensor/force/energy audits are supplied. Nodal level-set values within 20 um
of zero are snapped to zero; this is not a 20 um biological-interface accuracy.
The last two cases share all mesh/DOFs/loads/supports. Only phase labels change.
The same-material refinement gives a nested discrete energy identity, not a
continuum upper error bound. No histological EDJ or A3 interface limit is claimed.
Root-cap and six Robin cases are existing solved-case summaries with source
hashes, not new experimental attachment calibration. Their large linear motions
are applicability diagnostics. Robin raw fields are not duplicated in this ZIP.
To inspect the independent readback, run scripts/independent_pair_readback.py
under output/interface_comparison_2026-11-20/ in the extracted tree.
To recompute solves, preserve this ZIP, use a fresh extracted working copy and
move its generated output/interface_comparison_2026-11-20/data/ and results.json
aside first. Recreate the review/run_001 directory. Then run
  python3 output/interface_comparison_2026-11-20/scripts/conforming_pair.py
The preserved audit manifest is the executed seeded run, not a claim that a
new replay is byte-identical on every platform.

The local-mesh summary includes saved A2/A3 size/energy diagnostics. Replaying that separate diagnostic needs the large original A2/A3 fields, identified by hash; those are not duplicated here.
