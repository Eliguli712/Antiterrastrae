Finite numerical validation, 20 November 2026.
Preserve the supplied directory tree and use the extracted root as cwd.

Two-pitch threshold contrasts, with the two missing coarse controls.
Exact native-derived 72 um occupancy arrays, the T100 0.576 mm baseline field,
two new 0.576 mm fields, all six case summaries, code and independent readback
are supplied. Occupancy arrays retain 0--64 selected native-voxel counts; they
are not raw attenuation CT. The original full-volume reconstruction audit is
included. Original DICOM files, lossless native masks and three 0.288 mm FE
fields are not duplicated here; their summaries/source hashes identify them.
This archive replays the two added solves and six-case summary comparison; it
is not a self-contained reconstruction of the original attenuation data.
The fixed lattice uses 50% material occupancy, coarse enclosed-void fill and the
largest connected solid. Changed threshold domains use the same geometric
windows, not identical physical tetrahedron unions. Fine native pores are not
resolved mechanically. Two pitches show small contrasts but sign changes;
they do not establish an asymptotic threshold-difference limit.
For readback run:
  python3 output/threshold_pair_2026-11-20/scripts/independent_readback.py
To replay the two added solves, preserve this ZIP, move the extracted generated
output/threshold_pair_2026-11-20/data/ aside, recreate review/run_001, then run:
  python3 output/threshold_pair_2026-11-20/scripts/complete_threshold_pair.py
The old 0.576 mm baseline is preserved separately and is not overwritten.

The local-mesh summary includes saved A2/A3 size/energy diagnostics. Replaying that separate diagnostic needs the large original A2/A3 fields, identified by hash; those are not duplicated here.
