#!/usr/bin/env python3
"""Conforming six-tet voxel solids: fixed, auditable geometry-sensitivity grid."""
from pathlib import Path
import json,time
import numpy as np
from scipy import ndimage as ndi
import elastic_diagnostics as fe
R=fe.R;folder=R/'data/thresholds';gate=json.loads((R/'review/threshold_reconstruction.json').read_text());assert gate['status']=='passed'
records=[];start=time.monotonic()
for name,k in [('T100',8),('T095',4),('T100',4),('T105',4)]:
 a=np.load(folder/(name+'_occupancy64_72um.npy'),mmap_mode='r');pads=tuple((0,(-n)%k) for n in a.shape);counts=np.pad(a,pads).reshape((a.shape[0]+pads[0][1])//k,k,(a.shape[1]+pads[1][1])//k,k,(a.shape[2]+pads[2][1])//k,k).sum((1,3,5),dtype=np.uint32);binary=counts>=32*k**3;filled=ndi.binary_fill_holes(binary);labels,n=ndi.label(filled);sizes=np.bincount(labels.ravel());sizes[0]=0;solid=labels==sizes.argmax();iz,iy,ix=np.where(solid);nz,ny,nx=solid.shape;h=.072*k
 corners=np.array([[0,0,0],[0,0,1],[0,1,1],[0,1,0],[1,0,0],[1,0,1],[1,1,1],[1,1,0]])
 cell=np.column_stack([iz,iy,ix]);node=cell[:,None,:]+corners[None];flat=(node[:,:,0]*(ny+1)+node[:,:,1])*(nx+1)+node[:,:,2];used,inv=np.unique(flat,return_inverse=True);nodes=inv.reshape(-1,8).astype(np.int32)
 zz=used//((ny+1)*(nx+1));yy=(used//(nx+1))%(ny+1);xx=used%(nx+1);p=(np.column_stack([xx,yy,zz])*h-.009)*.001
 local=np.array([[0,1,2,6],[0,2,3,6],[0,3,7,6],[0,7,4,6],[0,4,5,6],[0,5,1,6]])
 t=nodes[:,local].reshape(-1,4);assert len(t)<1800000
 volume=abs(np.linalg.det(p[t[:,1:]]-p[t[:,:1]]))/6;np.testing.assert_allclose(volume,h**3*1e-9/6,rtol=1e-10,atol=1e-24)
 native=next(x for x in gate['cases'] if x['case']==name)
 geometry=dict(case=name,FE_grid_pitch_mm=h,hexahedra=len(cell),tetrahedra=len(t),native_volume_mm3=native['volume_mm3'],solid_reference_volume_mm3=float(volume.sum()*1e9),native_to_solid_volume_change_percent=float(100*(volume.sum()*1e9/native['volume_mm3']-1)),source='Exact native 4^3 occupancy counts aggregated to one fixed lattice; 50% occupancy; fill enclosed coarse voids; largest coarse face-connected solid.',domain_scope='Explicit stepped solid-reference boundary; no native pore-resolving or smooth-surface convergence claim. Cubes split by a shared 0--6 diagonal into six conforming tetrahedra.')
 print('Audited geometry',geometry,flush=True)
 del counts,binary,filled,labels,solid,a,node,flat,used,nodes
 result=fe.solve(f'grid_{name}_h{str(h).replace(".","p")}',p,t,frozen=False);result['geometry']=geometry;(R/'data'/result['name']/'results.json').write_text(json.dumps(result,indent=2));records.append(result)
result=dict(status='passed',cases=records,runtime_seconds=time.monotonic()-start,scope='Native segmentation effects compared at identical 0.288 mm FE voxel pitch; a 0.576 mm T100 control separately measures representation sensitivity. These grids differ from the fixed-domain Table 9 proxy.')
(R/'review/threshold_grid_run_001/results.json').write_text(json.dumps(result,indent=2));(R/'review/threshold_grid_fea.json').write_text(json.dumps(result,indent=2))
