#!/usr/bin/env python3
"""P1 elasticity with element-wise materials and optional Robin attachment."""
from pathlib import Path
import os,sys,json,time,gc
os.environ.setdefault('OPENBLAS_NUM_THREADS','2');os.environ.setdefault('OMP_NUM_THREADS','2')
import numpy as np
from scipy.sparse import coo_matrix,diags
from scipy.sparse.linalg import cg
R=Path(__file__).resolve().parents[1];P=R.parents[1]
B=P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31'
sys.path.insert(0,str(B/'vendor'));sys.path.insert(0,str(B/'numerics'))
import pyamg,solver_core as core,high_resolution as hi
I=np.eye(3)

def basis_data(p,t):
 edge=p[t[:,1:]]-p[t[:,:1]];inv=np.linalg.inv(edge);g=np.empty((len(t),4,3));g[:,1:]=inv.transpose(0,2,1);g[:,0]=-g[:,1:].sum(1)
 V=abs(np.linalg.det(edge))/6;assert V.min()>1e-24
 return g,V

def assemble(p,t,g,V,la,mu):
 n=len(t);rr=np.empty(n*144,np.int32);cc=np.empty(n*144,np.int32);dd=np.empty(n*144)
 for start in range(0,n,12000):
  sl=slice(start,min(start+12000,n));a=g[sl];d=(3*t[sl,:,None]+np.arange(3)).reshape(-1,12).astype(np.int32)
  K=la[sl,None,None,None,None]*np.einsum('eai,ebk->eaibk',a,a)
  K+=mu[sl,None,None,None,None]*np.einsum('eak,ebi->eaibk',a,a)
  K+=mu[sl,None,None,None,None]*np.einsum('eab,ik->eaibk',np.einsum('eaj,ebj->eab',a,a),I)
  K*=V[sl,None,None,None,None];K=K.reshape(-1,12,12)
  dest=slice(start*144,sl.stop*144);dd[dest]=K.ravel();rr[dest]=np.broadcast_to(d[:,:,None],K.shape).ravel();cc[dest]=np.broadcast_to(d[:,None,:],K.shape).ravel()
 A=coo_matrix((dd,(rr,cc)),shape=(3*len(p),3*len(p))).tocsr();del rr,cc,dd;gc.collect();return A

def fixed_experiment(p,t,frozen=True):
 a=np.load(B/'numerics/L0/solution.npz');bp=a['points_m'];bt=a['tets'];center=a['center_m'];basis=a['basis'];bf,ba,bn=core.boundary_faces(bp,bt);bq=(bp-center)@basis;surface=bq[np.unique(bf)]
 f,area,normal=core.boundary_faces(p,t);q=(p-center)@basis;ns,nr,nz=core.geometric_coordinates(q,surface);side=q[:,0]>=0;root_end=np.where(side,bq[bq[:,0]>=0,1].max(),bq[bq[:,0]<0,1].max());smax=core.geometric_coordinates(np.column_stack([np.zeros(len(p)),root_end,np.zeros(len(p))]),surface)[0];cap=(ns>=.80)&(ns>=smax-.04)
 if frozen:
  parent=hi.locate(p[t].mean(1),bp,bt);base=np.load(B/'numerics/L0/region_masks.npz');masks={k:np.isin(parent,base[k]) for k in core.REGIONS}
  parentf=hi.locate_faces(p[f].mean(1),bp,bf);mark=np.zeros(len(bf),bool);mark[a['loaded_face_indices']]=True;loaded=mark[parentf]
 else:
  s,r,z=core.geometric_coordinates(q[t].mean(1),surface);masks=core.masks_from_geometry(s,r,z);fs,fr,_=core.geometric_coordinates(q[f].mean(1),surface);loaded=(fs>=.18)&(fs<=.64)&(abs(fr)<=.75)&((normal@basis[:,2])>=.5);parent=np.full(len(t),-1,np.int32)
 force=np.zeros_like(p)
 for j in range(3):np.add.at(force,f[loaded,j],-1e6*area[loaded,None]*normal[loaded]/3)
 return dict(faces=f,areas=area,normals=normal,fixed=cap,loaded=loaded,force=force,masks=masks,parent=parent,center=center,basis=basis,surface_q=surface)

def solve(name,p,t,*,frozen=True,E=None,nu=.25217391304347825,foundation=None,tag=None,initial=None):
 out=R/'data'/name;out.mkdir(exist_ok=False);start=time.monotonic();np.random.seed(20261112)
 def log(text):
  print(name,text,flush=True)
  with (out/'progress.txt').open('a') as f:f.write(str(text)+'\n')
 data=fixed_experiment(p,t,frozen=frozen);g,V=basis_data(p,t)
 if E is None:la=np.full(len(t),29e9);mu=np.full(len(t),28.5e9)
 else:
  E=np.broadcast_to(E,(len(t),));la=E*nu/((1+nu)*(1-2*nu));mu=E/(2*(1+nu))
 log(('assembling',len(p),len(t)));K=assemble(p,t,g,V,la,mu);force=data['force'];spring=np.zeros(len(p));cap=data['fixed']
 if foundation is not None:
  f=data['faces'];selected=cap[f].all(1)
  for j in range(3):np.add.at(spring,f[selected,j],foundation*data['areas'][selected]/3)
  assert spring.sum()>0;K=K+diags(np.repeat(spring,3));free=np.arange(3*len(p))
 else:free=np.setdiff1d(np.arange(3*len(p)),(3*np.flatnonzero(cap)[:,None]+np.arange(3)).ravel())
 A=K[free][:,free].tocsr();rhs=force.ravel()[free];q=(p-p.mean(0))/np.ptp(p,axis=0).max();modes=np.zeros((len(p),3,6));modes[:,:,:3]=I
 for j in range(3):modes[:,:,j+3]=np.cross(I[j],q)
 log(('AMG',A.nnz));ml=pyamg.smoothed_aggregation_solver(A.tobsr(blocksize=(3,3)),B=modes.reshape(-1,6)[free],symmetry='symmetric',presmoother=('block_gauss_seidel',{'sweep':'symmetric'}),postsmoother=('block_gauss_seidel',{'sweep':'symmetric'}),max_coarse=250,max_levels=12)
 count=[0]
 def cb(x):
  count[0]+=1
  if count[0]%100==0:log(('CG',count[0]))
 x0=None
 if initial is not None:x0=initial.ravel()[free]
 uf,status=cg(A,rhs,x0=x0,M=ml.aspreconditioner(),rtol=2e-10,atol=0,maxiter=2000,callback=cb);assert status==0,status
 u=np.zeros(3*len(p));u[free]=uf;u=u.reshape(-1,3);res=(K@u.ravel()).reshape(-1,3)-force
 rel=np.linalg.norm(res.ravel()[free])/np.linalg.norm(rhs);assert rel<2e-7
 reaction=-spring[:,None]*u if foundation is not None else np.where(cap[:,None],res,0)
 balance=np.linalg.norm(reaction.sum(0)+force.sum(0))/np.linalg.norm(force.sum(0));moment=np.linalg.norm((np.cross(p,force)+np.cross(p,reaction)).sum(0))/(np.linalg.norm(force.sum(0))*np.ptp(p,axis=0).max());work=float((u*force).sum());energy=float(u.ravel()@(K@u.ravel()));assert max(balance,moment,abs(energy-work)/abs(work))<2e-6
 sig=np.empty((len(t),3,3));vm=np.empty(len(t));principal=np.empty((len(t),3));fint=np.zeros_like(p)
 for starti in range(0,len(t),20000):
  sl=slice(starti,min(starti+20000,len(t)));G=np.einsum('eai,eaJ->eiJ',u[t[sl,1:]]-u[t[sl,:1]],g[sl,1:]);eps=.5*(G+G.transpose(0,2,1));sigma=la[sl,None,None]*np.trace(eps,axis1=1,axis2=2)[:,None,None]*I+2*mu[sl,None,None]*eps;sig[sl]=sigma;dev=sigma-np.trace(sigma,axis1=1,axis2=2)[:,None,None]*I/3;vm[sl]=np.sqrt(1.5*np.sum(dev**2,(1,2)));principal[sl]=np.linalg.eigvalsh(sigma)
  local=np.einsum('eij,eaj,e->eai',sigma,g[sl],V[sl])
  for j in range(4):np.add.at(fint,t[sl,j],local[:,j])
 independent=fint+spring[:,None]*u-force;readback=float(np.linalg.norm(independent.ravel()[free])/np.linalg.norm(rhs));assert readback<2e-6
 rows=[]
 for region,m in data['masks'].items():
  assert m.any();q=core.volume_quantiles(vm[m],V[m])/1e6
  qt=core.volume_quantiles(np.maximum(principal[m,2],0),V[m])/1e6;qc=core.volume_quantiles(np.maximum(-principal[m,0],0),V[m])/1e6
  rows.append(dict(region=region,cells=int(m.sum()),volume_mm3=float(V[m].sum()*1e9),Q90_MPa=float(q[0]),Q95_MPa=float(q[1]),Q99_MPa=float(q[2]),principal_tension_Q95_MPa=float(qt[1]),principal_compression_Q95_MPa=float(qc[1])))
 fields=dict(points_m=p,tets=t,displacement_m=u,stress_Pa=sig,principal_stresses_Pa=principal,von_mises_Pa=vm,volumes_m3=V,force_N=force,spring_N_per_m=spring,fixed_nodes=np.flatnonzero(cap) if foundation is None else np.array([],np.int32),parent_L0=data['parent'],boundary_faces=data['faces'],loaded_faces=np.flatnonzero(data['loaded']),lambda_Pa=la,mu_Pa=mu)
 if tag is not None:fields['material_tag']=tag
 np.savez_compressed(out/'fields.npz',**fields)
 result=dict(status='passed',name=name,nodes=len(p),tetrahedra=len(t),region_convention='Frozen L0 physical cell unions' if frozen else 'Fixed L0 coordinate windows intersected with changed geometry',volume_mm3=float(V.sum()*1e9),loaded_area_mm2=float(data['areas'][data['loaded']].sum()*1e6),foundation_N_per_m3=foundation,free_residual=float(rel),independent_force_readback=readback,force_balance=float(balance),reference_moment_balance=float(moment),work_energy_error=float(abs(energy-work)/abs(work)),peak_MPa=float(vm.max()/1e6),max_displacement_mm=float(np.linalg.norm(u,axis=1).max()*1000),iterations=count[0],regions=rows,runtime_seconds=time.monotonic()-start)
 if tag is not None:result['material2_volume_fraction']=float(V[tag==2].sum()/V.sum())
 (out/'results.json').write_text(json.dumps(result,indent=2));log(result);return result
