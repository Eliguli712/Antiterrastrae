from pathlib import Path
import hashlib,json
import numpy as np

R=Path(__file__).resolve().parents[1];records=[]
for name in ['grid_T095_h0p576','grid_T105_h0p576']:
 path=R/'data'/name/'fields.npz';a=np.load(path);p=a['points_m'];t=a['tets'];u=a['displacement_m'];force=a['force_N'];fixed=a['fixed_nodes']
 X=p[t[:,1:]]-p[t[:,:1]];G=np.linalg.solve(X,u[t[:,1:]]-u[t[:,:1]]).transpose(0,2,1);eps=(G+G.transpose(0,2,1))/2
 sig=a['lambda_Pa'][:,None,None]*np.trace(eps,axis1=1,axis2=2)[:,None,None]*np.eye(3)+2*a['mu_Pa'][:,None,None]*eps
 g=np.empty((len(t),4,3));g[:,1:]=np.linalg.inv(X).transpose(0,2,1);g[:,0]=-g[:,1:].sum(1);V=abs(np.linalg.det(X))/6
 local=np.einsum('eij,eaj,e->eai',sig,g,V);fi=np.zeros_like(p)
 for j in range(4):np.add.at(fi,t[:,j],local[:,j])
 free=np.ones(len(p),bool);free[fixed]=False;r=fi-force
 residual=float(np.linalg.norm(r[free])/np.linalg.norm(force[free]));stress=float(np.linalg.norm(sig-a['stress_Pa'])/np.linalg.norm(sig))
 reaction=np.zeros_like(p);reaction[fixed]=r[fixed]
 balance=float(np.linalg.norm(force.sum(0)+reaction.sum(0))/np.linalg.norm(force.sum(0)))
 moment=float(np.linalg.norm(np.cross(p,force+reaction).sum(0))/(np.linalg.norm(force.sum(0))*np.ptp(p,axis=0).max()))
 assert max(residual,stress,balance,moment)<2e-6
 records.append(dict(case=name,tetrahedra=len(t),tensor_relative_difference=stress,free_force_residual=residual,net_force_error=balance,reference_moment_error=moment,sha256=hashlib.file_digest(path.open('rb'),'sha256').hexdigest()))
(R/'review/independent_readback.json').write_text(json.dumps(dict(status='passed',cases=records),indent=2));print(json.dumps(records,indent=2))
