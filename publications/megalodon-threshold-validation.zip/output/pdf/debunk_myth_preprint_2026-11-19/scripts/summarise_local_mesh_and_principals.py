#!/usr/bin/env python3
"""Read-only finest P1 local sizes and independent new-case eigenspectra."""
from pathlib import Path
import csv
import hashlib
import json
import numpy as np

N = Path(__file__).resolve().parents[1]
P = N.parents[2]
D = P / 'output/publication_validation_2026-11-12'
B = P / 'output/pdf/debunk_myth_full_reconstruction_2026-10-31'
OUT = N / 'numerics/local_mesh_readback'
OUT.mkdir(exist_ok=True)
regions = np.load(B / 'numerics/L0/region_masks.npz')
names = ['R0', 'RA', 'RB', 'Rtip', 'Rcr', 'Rroot']


def wq(values, weights, q):
    order = np.argsort(values)
    cumulative = np.cumsum(weights[order], dtype=np.longdouble)
    return values[order[np.searchsorted(cumulative, np.array(q) * cumulative[-1])]]


rows, diagnostics = [], []
for case in ['local_A2', 'local_A3']:
    path = D / 'data' / case / 'fields.npz'
    a = np.load(path)
    p, t, V, parent = [a[k] for k in ['points_m', 'tets', 'volumes_m3', 'parent_L0']]
    edges = np.zeros(len(t))
    for j in range(4):
        for k in range(j):
            edges = np.maximum(edges, np.linalg.norm(p[t[:, j]] - p[t[:, k]], axis=1))
    stress, principal = a['stress_Pa'], a['principal_stresses_Pa']
    eigen_error = float(np.max(abs(np.linalg.eigvalsh(stress) - principal))
                        / max(np.max(abs(principal)), 1.))
    assert eigen_error < 2e-10
    u, force = a['displacement_m'], a['force_N']
    energy = float(np.sum(u * force) / 2)
    assert energy > 0
    for name in names:
        mask = np.isin(parent, regions[name])
        h = wq(edges[mask] * 1000, V[mask], [.1, .5, .9])
        qplus = wq(np.maximum(principal[mask, -1], 0) / 1e6, V[mask], [.95])[0]
        rows.append(dict(case=case, region=name, cells=int(mask.sum()),
                         volume_mm3=float(V[mask].sum() * 1e9), h10_mm=h[0],
                         h50_mm=h[1], h90_mm=h[2], tensile_Q95_MPa=qplus))
    diagnostics.append(dict(case=case, tetrahedra=len(t), elastic_energy_J=energy,
                            stored_principal_relative_error=eigen_error,
                            sha256=hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()))

new_cases = [(P / 'output/interface_comparison_2026-11-20', c) for c in
             ['coarse_centroid', 'refined_parent_centroid', 'interface_fitted']]
new_cases += [(P / 'output/threshold_pair_2026-11-20', c) for c in
              ['grid_T095_h0p576', 'grid_T105_h0p576']]
principal_checks = []
for folder, case in new_cases:
    path = folder / 'data' / case / 'fields.npz'
    a = np.load(path)
    p, t, u, stored = [a[k] for k in ['points_m', 'tets', 'displacement_m', 'principal_stresses_Pa']]
    X = p[t[:, 1:]] - p[t[:, :1]]
    G = np.linalg.solve(X, u[t[:, 1:]] - u[t[:, :1]]).transpose(0, 2, 1)
    strain = (G + G.transpose(0, 2, 1)) / 2
    stress = (a['lambda_Pa'][:, None, None] * np.trace(strain, axis1=1, axis2=2)[:, None, None]
              * np.eye(3) + 2 * a['mu_Pa'][:, None, None] * strain)
    error = float(np.max(abs(np.linalg.eigvalsh(stress) - stored)) / max(np.max(abs(stored)), 1.))
    assert error < 2e-6
    principal_checks.append(dict(case=case, tetrahedra=len(t), independent_principal_relative_error=error,
                                 sha256=hashlib.file_digest(path.open('rb'), 'sha256').hexdigest()))
with (OUT / 'A2_A3_region_local_sizes.csv').open('w') as f:
    writer = csv.DictWriter(f, fieldnames=rows[0].keys())
    writer.writeheader()
    writer.writerows(rows)
result = dict(status='passed', finest_meshes=diagnostics, new_case_principal_checks=principal_checks,
              new_case_tetrahedra=sum(r['tetrahedra'] for r in principal_checks),
              definition='Volume-weighted percentiles of each tetrahedron maximum edge length; same frozen L0 physical region unions.',
              non_claims=['Direct stored-field diagnostics do not establish an A3 P2 or continuum error bound.',
                          'Energy changes across A2/A3 are not a nested-space error identity.'])
(OUT / 'results.json').write_text(json.dumps(result, indent=2))
(N / 'review/local_mesh_readback_run_001/results.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
