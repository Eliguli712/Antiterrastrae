#!/usr/bin/env python3
"""Independent P1 tetrahedral elasticity solve and a provenance-aware Table 9 audit.

Run from the package root: python3 scripts/recalculate.py --output run
No COMSOL license is needed. Original regional masks are NOT reconstructed.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import platform
import re
import time
from pathlib import Path

import meshio
import numpy as np
import scipy
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from scipy.sparse.linalg import splu

ROOT = Path(__file__).resolve().parents[1]
QS = np.array([0.90, 0.95, 0.99])
REGIONS = ['R0', 'RA', 'RB', 'Rtip', 'Rcr', 'Rroot']
LABELS = ['Central crown interior', 'Cutting-edge side A', 'Cutting-edge side B',
          'Macroscopic apical tip', 'Geometric transition band', 'Root-side interior band']
ORIGINAL = [
    ['R0', .78, .89, .97, .89], ['Rmes', 17.2, 21.8, 24.3, 21.8],
    ['Rdis', 16.5, 20.9, 23.7, 20.9], ['Rtip', 38.6, 46.2, 51.4, 46.2],
    ['Rcr', 11.4, 14.7, 17.2, 14.7], ['Rroot', .28, .47, .69, .47],
]


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def write_csv(path, rows):
    with open(path, 'w', newline='', encoding='utf8') as f:
        w = csv.DictWriter(f, list(rows[0])); w.writeheader(); w.writerows(rows)


def quantiles(values):
    """NumPy's linear/type-7 sample quantile, checked by an independent sort."""
    values = np.asarray(values)
    got = np.quantile(values, QS, method='linear')
    s = sorted(float(x) for x in values)
    independent = []
    for q in QS:
        h = (len(s)-1)*float(q); j = math.floor(h); k = math.ceil(h)
        independent.append(s[j] + (h-j)*(s[k]-s[j]))
    np.testing.assert_allclose(got, independent, rtol=5e-15, atol=1e-10)
    assert np.all(np.diff(got) >= 0) and got[-1] <= max(s)
    return got


def volume_quantiles(values, volumes):
    """Volume-weighted inverse empirical CDF; not the primary table convention."""
    order = np.argsort(values, kind='stable')
    cdf = np.cumsum(volumes[order]); cdf /= cdf[-1]
    return values[order[np.searchsorted(cdf, QS, side='left')]]


def constitutive(lam, mu):
    c = np.zeros((6, 6)); c[:3, :3] = lam
    c[np.arange(3), np.arange(3)] += 2*mu
    c[3:, 3:] = np.eye(3)*mu
    return c


def element_matrices(points, tets, c):
    x = points[tets]
    m = np.concatenate([np.ones((len(tets), 4, 1)), x], axis=2)
    det = np.linalg.det(x[:, 1:] - x[:, :1])
    vol = np.abs(det)/6
    if np.any(vol <= 1e-24):
        raise ValueError('Degenerate or numerically zero-volume tetrahedron')
    g = np.linalg.inv(m)[:, 1:, :].transpose(0, 2, 1)
    b = np.zeros((len(tets), 6, 12))
    for a in range(4):
        gx, gy, gz = g[:, a].T
        b[:, 0, 3*a] = gx; b[:, 1, 3*a+1] = gy; b[:, 2, 3*a+2] = gz
        b[:, 3, 3*a] = gy; b[:, 3, 3*a+1] = gx
        b[:, 4, 3*a+1] = gz; b[:, 4, 3*a+2] = gy
        b[:, 5, 3*a] = gz; b[:, 5, 3*a+2] = gx
    ke = np.einsum('eji,jk,ekl,e->eil', b, c, b, vol, optimize=True)
    return b, vol, ke


def boundary_faces(points, tets):
    loc = np.array([[1, 2, 3], [0, 3, 2], [0, 1, 3], [0, 2, 1]])
    faces = tets[:, loc].reshape(-1, 3)
    keys = np.sort(faces, axis=1)
    _, idx, counts = np.unique(keys, axis=0, return_index=True, return_counts=True)
    if np.any(counts > 2):
        raise ValueError('Nonmanifold volume mesh')
    owner = idx[counts == 1]//4; faces = faces[idx[counts == 1]].copy()
    xyz = points[faces]
    cross = np.cross(xyz[:, 1]-xyz[:, 0], xyz[:, 2]-xyz[:, 0])
    inward = np.einsum('ij,ij->i', cross, points[tets[owner]].mean(1)-xyz.mean(1)) > 0
    faces[inward] = faces[inward][:, [0, 2, 1]]
    cross[inward] *= -1
    area = np.linalg.norm(cross, axis=1)/2
    return faces, area, cross/(2*area[:, None])


def coordinate_frame(points, tets=None):
    if tets is None:
        ctr = points.mean(0)
        covariance = np.cov((points-ctr).T)
    else:
        # Exact solid-volume moments avoid bias from locally dense mesh vertices.
        x=points[tets]; volumes=np.abs(np.linalg.det(x[:,1:]-x[:,:1]))/6
        ctr=np.average(x.mean(1),axis=0,weights=volumes)
        summed=x.sum(1)
        moment=(np.einsum('eai,eaj->eij',x,x)+np.einsum('ei,ej->eij',summed,summed))/20
        covariance=np.einsum('e,eij->ij',volumes,moment)/volumes.sum()-np.outer(ctr,ctr)
    vals, vec = np.linalg.eigh(covariance)
    y = vec[:, np.argmax(vals)]
    if y[2] < 0: y *= -1  # root end in the positive original-z direction
    z = vec[:, np.argmin(vals)]
    if z[0] < 0: z *= -1  # positive original-x thickness face, NOT verified labial
    x = np.cross(y, z); x /= np.linalg.norm(x)
    z = np.cross(x, y)
    basis = np.column_stack([x, y, z])
    return ctr, basis


def geometric_coordinates(q, surface_q, bins=40):
    ymin, ymax = surface_q[:, 1].min(), surface_q[:, 1].max()
    s = (q[:, 1]-ymin)/(ymax-ymin)
    sy = (surface_q[:, 1]-ymin)/(ymax-ymin)
    centers, lo, hi = [], [], []
    for a in np.linspace(0, 1, bins+1)[:-1]:
        use = (sy >= a) & (sy <= a+1/bins)
        if use.sum() >= 3:
            centers.append(a+.5/bins)
            lo.append(surface_q[use, 0].min()); hi.append(surface_q[use, 0].max())
    left, right = np.interp(s, centers, lo), np.interp(s, centers, hi)
    r = (2*q[:, 0]-left-right)/np.maximum(right-left, 1e-12)
    zmid = .5*(surface_q[:, 2].min()+surface_q[:, 2].max())
    zeta = (q[:, 2]-zmid)/(.5*np.ptp(surface_q[:, 2]))
    return s, r, zeta


def masks_from_geometry(s, r, zeta, edge_start=.78):
    return {
        'R0': (.25 <= s) & (s <= .55) & (np.abs(r) <= .35) & (np.abs(zeta) <= .5),
        'RA': (.12 < s) & (s < .64) & (r <= -edge_start),
        'RB': (.12 < s) & (s < .64) & (r >= edge_start),
        'Rtip': s <= .12,
        'Rcr': (.64 <= s) & (s <= .76),
        'Rroot': (.78 <= s) & (s <= .84),
    }


def benchmark(c):
    # Five tetrahedra fill a cube; affine displacements give exact constant strain.
    p = np.array([[0,0,0],[1,0,0],[1,1,0],[0,1,0],
                  [0,0,1],[1,0,1],[1,1,1],[0,1,1]], dtype=float)
    t = np.array([[0,1,3,4],[1,2,3,6],[1,3,4,6],[1,4,5,6],[3,4,6,7]])
    b, v, ke = element_matrices(p, t, c)
    np.testing.assert_allclose(v.sum(), 1, rtol=1e-14)
    a = np.array([[.001,.0002,0],[.0003,-.0004,.0001],[0,.0001,.0007]])
    u = p@a.T+np.array([.03,-.01,.02])
    strain = np.array([a[0,0],a[1,1],a[2,2],a[0,1]+a[1,0],
                       a[1,2]+a[2,1],a[0,2]+a[2,0]])
    eps = np.einsum('eij,ej->ei', b, u[t].reshape(-1,12))
    np.testing.assert_allclose(eps, np.broadcast_to(strain, eps.shape), rtol=1e-12, atol=1e-16)
    rigid = np.cross(np.array([.04,-.02,.01]), p) + np.array([.02,.01,-.03])
    rigid_strain = np.einsum('eij,ej->ei', b, rigid[t].reshape(-1,12))
    assert np.max(np.abs(rigid_strain)) < 1e-15
    faces, areas, normals = boundary_faces(p,t)
    np.testing.assert_allclose((areas[:,None]*normals).sum(0), 0, atol=1e-14)
    # Constant-stress traction patch test, independently assembled on cube faces.
    sig = c@strain
    tensor = np.array([[sig[0],sig[3],sig[5]],[sig[3],sig[1],sig[4]],[sig[5],sig[4],sig[2]]])
    f = np.zeros_like(p)
    for j in range(3): np.add.at(f, faces[:,j], areas[:,None]*(normals@tensor.T)/3)
    fu = np.zeros_like(p)
    local = np.einsum('eij,ej->ei',ke,u[t].reshape(-1,12)).reshape(-1,4,3)
    for j in range(4): np.add.at(fu,t[:,j],local[:,j])
    err = np.linalg.norm(fu-f)/np.linalg.norm(f)
    assert err < 1e-12
    return {'affine_traction_patch_relative_error': float(err), 'rigid_strain_max': float(np.abs(rigid_strain).max())}


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--output', default='run'); args=ap.parse_args()
    out=ROOT/args.output; out.mkdir(parents=True, exist_ok=True)
    cfg=json.loads((ROOT/'calculation_config.json').read_text())
    started=time.perf_counter()
    original_audit=[]; archived=[]
    for row in ORIGINAL:
        original_audit.append(dict(region=row[0], Q90_MPa=row[1], Q95_MPa=row[2], Q99_MPa=row[3],
                                   SAF95=row[4], arithmetic_SAF_equals_Q95=row[2]==row[4],
                                   original_region_value_status='not_reproduced_missing_original_masks_and_pressure_export'))
    for path in sorted((ROOT/'data/stress_exports').glob('*.txt')):
        data=np.loadtxt(path,comments='%'); stress=data[:,3]
        assert data.shape[1] == 4 and np.all(np.isfinite(data)) and np.all(stress>=0)
        header=path.read_text().splitlines()[:9]
        nodes=int(re.search(r'Nodes:\s+(\d+)', '\n'.join(header)).group(1))
        assert nodes==len(data)
        q=quantiles(stress)/1e6
        archived.append(dict(export=path.name,samples=len(data),Q90_MPa=q[0],Q95_MPa=q[1],Q99_MPa=q[2],
                             max_MPa=stress.max()/1e6,sha256=sha256(path),
                             original_Q_values_exceeding_export_max=int(sum(x>stress.max()/1e6 for r in ORIGINAL for x in r[1:4]))))
    write_csv(out/'archived_field_quantiles.csv',archived)
    write_csv(out/'original_table9_audit.csv',original_audit)

    mesh_path=ROOT/cfg['mesh']; mesh=meshio.read(mesh_path)
    tets=np.vstack([c.data for c in mesh.cells if c.type=='tetra']).astype(np.int64)
    # Node connectivity is insufficient for elastic stability: point/edge hinges
    # can have rigid rotations. Retain the largest FACE-connected solid component.
    all_faces=np.sort(tets[:,[[1,2,3],[0,2,3],[0,1,3],[0,1,2]]].reshape(-1,3),axis=1)
    _,inv,counts=np.unique(all_faces,axis=0,return_inverse=True,return_counts=True)
    if np.any(counts>2): raise ValueError('Nonmanifold input tetrahedral faces')
    order=np.argsort(inv,kind='stable'); end=np.cumsum(counts)[counts==2]
    pairs=np.column_stack([order[end-2]//4,order[end-1]//4])
    fg=coo_matrix((np.ones(len(pairs)),pairs.T),shape=(len(tets),len(tets))).tocsr()
    components,component_labels=connected_components(fg,directed=False)
    keep=component_labels==np.argmax(np.bincount(component_labels))
    vx=mesh.points[tets]; source_volumes=np.abs(np.linalg.det(vx[:,1:]-vx[:,:1]))/6
    excluded={'input_face_components':int(components),'input_tetrahedra':len(tets),'excluded_tetrahedra':int((~keep).sum()),
              'excluded_original_element_indices_0based':np.flatnonzero(~keep).tolist(),
              'excluded_volume_fraction':float(source_volumes[~keep].sum()/source_volumes.sum())}
    np.save(out/'kept_original_element_indices.npy',np.flatnonzero(keep))
    tets=tets[keep]
    used=np.unique(tets); remap=np.full(len(mesh.points),-1); remap[used]=np.arange(len(used))
    points=np.asarray(mesh.points[used],float)*cfg['coordinate_scale_to_m']; tets=remap[tets]
    edges=tets[:,[[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]]].reshape(-1,2)
    graph=coo_matrix((np.ones(len(edges)),(edges[:,0],edges[:,1])),shape=(len(points),len(points))).tocsr()
    ncomp,_=connected_components(graph,directed=False)
    if ncomp != 1: raise ValueError(f'{ncomp} disconnected volume components')
    c=constitutive(cfg['lambda_Pa'],cfg['mu_Pa'])
    checks=benchmark(c)
    b, volumes, ke=element_matrices(points,tets,c)
    dofs=(3*tets[:,:,None]+np.arange(3)).reshape(-1,12)
    rows=np.broadcast_to(dofs[:,:,None],ke.shape).reshape(-1)
    cols=np.broadcast_to(dofs[:,None,:],ke.shape).reshape(-1)
    k=coo_matrix((ke.reshape(-1),(rows,cols)),shape=(3*len(points),3*len(points))).tocsr()
    del rows,cols,ke
    symmetry=(k-k.T); checks['stiffness_symmetry_max_relative']=float(abs(symmetry).max()/abs(k).max())
    assert checks['stiffness_symmetry_max_relative'] < 1e-12
    faces,areas,normals=boundary_faces(points,tets)
    ctr,basis=coordinate_frame(points,tets)
    q=(points-ctr)@basis; cq=q[tets].mean(1); fq=q[faces].mean(1)
    surface_q=q[np.unique(faces)]
    s,r,zeta=geometric_coordinates(cq,surface_q)
    ns,nr,nz=geometric_coordinates(q,surface_q)
    fs,fr,fz=geometric_coordinates(fq,surface_q)
    masks=masks_from_geometry(s,r,zeta)
    for name,mask in masks.items():
        if mask.sum()<20: raise ValueError(f'Insufficient samples in {name}: {mask.sum()}')
    assert np.max(np.stack(list(masks.values())).sum(0))==1
    loaded=(fs>=.18)&(fs<=.64)&(np.abs(fr)<=.75)&((normals@basis[:,2])>=.5)
    if loaded.sum()<20: raise ValueError('Insufficient loaded boundary faces')
    force=np.zeros((len(points),3))
    face_force=-cfg['pressure_Pa']*areas[loaded,None]*normals[loaded]
    for j in range(3): np.add.at(force,faces[loaded,j],face_force/3)
    results=[]; sensitivities=[]; main_vm=None; main_u=None
    np.savez_compressed(out/'region_masks.npz',**{n:np.flatnonzero(m) for n,m in masks.items()})
    # Masks are saved before any stress solution is calculated.
    # Cap each root lobe relative to its own geometric endpoint. A single global
    # height threshold can clamp only the taller lobe in this asymmetric tooth.
    side=q[:,0]>=0
    root_end=np.where(side, ns[side].max(), ns[~side].max())
    for cap_depth in cfg['root_cap_depth_sensitivity']:
        fixed=(ns>=.80)&(ns>=root_end-cap_depth)
        assert np.any(fixed&side) and np.any(fixed&~side)
        # The root-region stress statistic must exclude fully clamped elements.
        assert not np.any(np.all(fixed[tets],axis=1)&masks['Rroot'])
        fix_dof=(3*np.flatnonzero(fixed)[:,None]+np.arange(3)).ravel()
        free=np.setdiff1d(np.arange(3*len(points)),fix_dof)
        solver=splu(k[free][:,free].tocsc(),permc_spec='COLAMD')
        u=np.zeros(k.shape[0]); u[free]=solver.solve(force.ravel()[free])
        # Refine the direct solve when small elements make cancellation visible.
        for _ in range(5):
            delta=force.ravel()[free]-(k@u)[free]
            if np.linalg.norm(delta)/np.linalg.norm(force)<1e-10: break
            u[free]+=solver.solve(delta)
        residual=k@u-force.ravel(); reaction=residual.reshape(-1,3)
        rel=float(np.linalg.norm(residual[free])/np.linalg.norm(force))
        resultant=force.sum(0); react= reaction[fixed].sum(0)
        torque=np.cross(points,force).sum(0)+np.cross(points[fixed],reaction[fixed]).sum(0)
        force_err=float(np.linalg.norm(resultant+react)/np.linalg.norm(force.sum(0)))
        torque_scale=np.linalg.norm(resultant)*np.ptp(points,axis=0).max()
        torque_err=float(np.linalg.norm(torque)/torque_scale)
        energy=.5*float(u@(k@u)); work=.5*float(u@force.ravel())
        energy_err=abs(energy-work)/abs(work)
        print(f'validation root-cap depth={cap_depth}: residual={rel:.6g}, force={force_err:.6g}, torque={torque_err:.6g}, energy={energy_err:.6g}',flush=True)
        assert max(rel,force_err,torque_err,energy_err)<1e-7
        stress=np.einsum('ij,ej->ei',c,np.einsum('eij,ej->ei',b,u[dofs]))
        sx,sy,sz,txy,tyz,txz=stress.T
        vm=np.sqrt(.5*((sx-sy)**2+(sy-sz)**2+(sz-sx)**2)+3*(txy**2+tyz**2+txz**2))
        assert np.all(np.isfinite(vm)) and np.all(vm>=0)
        for name,label in zip(REGIONS,LABELS):
            mask=masks[name]; vals=quantiles(vm[mask])/1e6
            wq=volume_quantiles(vm[mask],volumes[mask])/1e6
            sensitivities.append(dict(cap_depth_fraction=cap_depth,region=name,Q90_MPa=vals[0],Q95_MPa=vals[1],Q99_MPa=vals[2],
                                      volume_weighted_Q95_MPa=wq[1]))
            if cap_depth==cfg['root_cap_depth_fraction']:
                results.append(dict(region=name,label=label,elements=int(mask.sum()),volume_mm3=float(volumes[mask].sum()*1e9),
                                    Q90_MPa=vals[0],Q95_MPa=vals[1],Q99_MPa=vals[2],SAF95=vals[1]/(cfg['pressure_Pa']/1e6),
                                    volume_weighted_Q90_MPa=wq[0],volume_weighted_Q95_MPa=wq[1],volume_weighted_Q99_MPa=wq[2]))
        print(f'root-cap depth={cap_depth}: free DOF={len(free)}; residual={rel:.3g}; max VM={vm.max()/1e6:.6g} MPa',flush=True)
        checks[f'capdepth_{cap_depth}']={'relative_free_residual':rel,'force_balance_error':force_err,'torque_balance_error':torque_err,
                                 'energy_identity_error':energy_err,'fixed_nodes':int(fixed.sum()),'strain_energy_J':energy,
                                 'reaction_N':react.tolist(),'max_displacement_m':float(np.linalg.norm(u.reshape(-1,3),axis=1).max())}
        if cap_depth==cfg['root_cap_depth_fraction']:
            main_vm=vm; main_u=u.reshape(-1,3)
            # A second linear-system solve checks, rather than assumes, pressure scaling.
            u2=solver.solve(2*force.ravel()[free]); checks['double_pressure_displacement_error']=float(np.linalg.norm(u2-2*u[free])/np.linalg.norm(2*u[free]))
            assert checks['double_pressure_displacement_error']<1e-12
        del solver
    assert main_vm is not None
    write_csv(out/'table9_region_quantiles.csv',results)
    write_csv(out/'boundary_sensitivity.csv',sensitivities)
    mask_sens=[]
    for threshold in [.70,.78,.86]:
        for name,mask in masks_from_geometry(s,r,zeta,threshold).items():
            mask_sens.append(dict(edge_threshold=threshold,region=name,elements=int(mask.sum()),Q95_MPa=quantiles(main_vm[mask])[1]/1e6))
    write_csv(out/'mask_sensitivity.csv',mask_sens)
    field=np.column_stack([np.arange(len(tets)),(points[tets].mean(1))*1000,volumes*1e9,main_vm/1e6])
    np.savetxt(out/'fresh_element_stress.csv',field,delimiter=',',header='element_id_0based,x_mm,y_mm,z_mm,volume_mm3,von_mises_MPa',comments='',fmt=['%d','%.12g','%.12g','%.12g','%.12g','%.12g'])
    np.savez_compressed(out/'solution.npz',points_m=points,tets=tets,displacement_m=main_u,
                        element_von_mises_Pa=main_vm,volumes_m3=volumes,boundary_faces=faces,
                        loaded_face_indices=np.flatnonzero(loaded),fixed_node_indices=np.flatnonzero((ns>=.80)&(ns>=root_end-cfg['root_cap_depth_fraction'])),
                        centroid_geometry=np.column_stack([s,r,zeta]),basis=basis,center_m=ctr)
    info={'assertion_tested':'Independent linear-elastic 1 MPa pressure solve on a fixed archived tetrahedral mesh; new geometry-only regional sample percentiles; archived field audit',
          'status':'completed','original_table9_reproduction':'not_reproducible: original region masks, pressure export and command absent',
          'new_calculation':'new linear-elastic proxy experiment, not a reproduction of the original study',
          'mesh_sha256':sha256(mesh_path),'mask_sha256':sha256(out/'region_masks.npz'),
          'nodes':len(points),'tetrahedra':len(tets),'boundary_triangles':len(faces),'connected_components':ncomp,'mesh_cleanup':excluded,
          'volume_mm3':float(volumes.sum()*1e9),'minimum_element_volume_mm3':float(volumes.min()*1e9),
          'loaded_faces':int(loaded.sum()),'loaded_area_mm2':float(areas[loaded].sum()*1e6),'net_force_N':force.sum(0).tolist(),
          'config':cfg,'checks':checks,'archived_exports':archived,'table9':results,
          'old_SAF95_to_R0_ratios':{r[0]:r[2]/.89 for r in ORIGINAL},
          'old_illustrative_critical_pressure_MPa':.8/(52*math.sqrt(math.pi*.0005)),
          'runtime_seconds':time.perf_counter()-started,
          'software':{'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'meshio':meshio.__version__},
          'limitations':['single mesh; no mesh convergence demonstrated','P1 constant element stress; no nodal smoothing',
                         'proxy masks are not original anatomical masks; A/B not identified as mesial/distal',
                         'positive thickness face not independently identified as labial','macroscopic apex mask is not a serration-tip process zone',
                         'linear elastic homogeneous material, not validated fossil-tissue constitutive law',
                         'uniform sample percentiles are not volume-weighted continuum quantiles','no fracture or biological bite prediction']}
    (out/'audit_results.json').write_text(json.dumps(info,indent=2))
    print(json.dumps({'table9':results,'checks':checks,'runtime_seconds':info['runtime_seconds']},indent=2))


if __name__=='__main__': main()
