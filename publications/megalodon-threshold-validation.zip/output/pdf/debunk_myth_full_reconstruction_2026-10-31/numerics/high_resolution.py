#!/usr/bin/env python3
"""Three-mesh, calibrated-domain numerical evidence for the reconstructed paper.

The archived closed-solid domain is recalibrated in Z by 18/16. It is NOT the
native pore-resolving CT domain. Region unions and the loaded surface patch are
frozen on L0; child cells/faces inherit the same physical regions across meshes.
"""
from __future__ import annotations
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import argparse,csv,gc,hashlib,json,platform,sys,time
from pathlib import Path
import numpy as np
import scipy
from scipy.sparse import coo_matrix,diags
from scipy.sparse.linalg import cg,splu
from scipy.spatial import cKDTree

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'vendor'))
import pyamg
import solver_core as core


def savecsv(path,rows):
    with path.open('w',newline='') as stream:
        w=csv.DictWriter(stream,list(rows[0]));w.writeheader();w.writerows(rows)


def hashfile(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


def locate(points,base_points,base_tets):
    """Checked barycentric point-location, with no nearest-cell extrapolation."""
    xyz=base_points[base_tets];origin=xyz[:,0]
    inverse=np.linalg.inv((xyz[:,1:]-xyz[:,:1]).transpose(0,2,1))
    tree=cKDTree(xyz.mean(1));out=np.full(len(points),-1,dtype=np.int32)
    for k in [16,64,256,1024]:
        pending=np.flatnonzero(out<0)
        for ix in np.array_split(pending,max(1,int(np.ceil(len(pending)/1024)))):
            if not len(ix):continue
            _,near=tree.query(points[ix],k=min(k,len(xyz)))
            local=np.einsum('nkij,nkj->nki',inverse[near],points[ix,None]-origin[near])
            valid=(local.min(2)>=-1e-8)&(local.sum(2)<=1+1e-8)
            hit=valid.any(1);out[ix[hit]]=near[hit,valid[hit].argmax(1)]
        if np.all(out>=0):break
    if np.any(out<0):raise RuntimeError(f'{sum(out<0)} child cell centroids not in the original domain')
    return out


def locate_faces(points,base_points,base_faces):
    xyz=base_points[base_faces];a=xyz[:,0];v0=xyz[:,1]-a;v1=xyz[:,2]-a
    n=np.cross(v0,v1);n/=np.linalg.norm(n,axis=1)[:,None]
    d00=np.einsum('ij,ij->i',v0,v0);d01=np.einsum('ij,ij->i',v0,v1);d11=np.einsum('ij,ij->i',v1,v1)
    det=d00*d11-d01*d01;tree=cKDTree(xyz.mean(1));out=np.full(len(points),-1,dtype=np.int32)
    for k in [16,64,256,1024]:
        pending=np.flatnonzero(out<0)
        for ix in np.array_split(pending,max(1,int(np.ceil(len(pending)/1024)))):
            if not len(ix):continue
            _,near=tree.query(points[ix],k=min(k,len(xyz)))
            d=points[ix,None]-a[near]
            dot0=np.einsum('nki,nki->nk',d,v0[near]);dot1=np.einsum('nki,nki->nk',d,v1[near])
            u=(d11[near]*dot0-d01[near]*dot1)/det[near]
            v=(d00[near]*dot1-d01[near]*dot0)/det[near]
            plane=np.abs(np.einsum('nki,nki->nk',d,n[near]))
            valid=(u>=-1e-7)&(v>=-1e-7)&(u+v<=1+1e-7)&(plane<1e-10)
            hit=valid.any(1);out[ix[hit]]=near[hit,valid[hit].argmax(1)]
        if np.all(out>=0):break
    if np.any(out<0):raise RuntimeError(f'{sum(out<0)} exterior triangles not in the frozen surface')
    return out


def assemble(p,t,c):
    n=len(t);entries=n*144
    rows=np.empty(entries,np.int32);cols=np.empty(entries,np.int32);data=np.empty(entries,np.float64)
    volume=np.empty(n);h=np.empty(n)
    for start in range(0,n,16000):
        stop=min(n,start+16000);part=t[start:stop]
        _,vol,ke=core.element_matrices(p,part,c)
        dofs=(3*part[:,:,None]+np.arange(3)).reshape(-1,12).astype(np.int32)
        sl=slice(start*144,stop*144)
        rows[sl]=np.broadcast_to(dofs[:,:,None],ke.shape).reshape(-1)
        cols[sl]=np.broadcast_to(dofs[:,None,:],ke.shape).reshape(-1);data[sl]=ke.reshape(-1)
        volume[start:stop]=vol
        x=p[part];h[start:stop]=np.linalg.norm(x[:,:,None]-x[:,None,:],axis=-1).max((1,2))
    k=coo_matrix((data,(rows,cols)),shape=(3*len(p),3*len(p))).tocsr()
    del rows,cols,data;gc.collect()
    return k,volume,h


def recover_vm(p,t,c,u):
    vm=np.empty(len(t))
    for start in range(0,len(t),16000):
        stop=min(len(t),start+16000);part=t[start:stop]
        b,_,_=core.element_matrices(p,part,c)
        dofs=(3*part[:,:,None]+np.arange(3)).reshape(-1,12)
        stress=np.einsum('ij,ej->ei',c,np.einsum('eij,ej->ei',b,u[dofs]))
        x,y,z,xy,yz,xz=stress.T
        vm[start:stop]=np.sqrt(.5*((x-y)**2+(y-z)**2+(z-x)**2)+3*(xy**2+yz**2+xz**2))
    assert np.isfinite(vm).all() and np.all(vm>=0)
    return vm


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--level',type=int,choices=[0,1,2],required=True)
    args=ap.parse_args();level=args.level;dest=ROOT/'numerics'/f'L{level}';dest.mkdir(exist_ok=True)
    if (dest/'summary.json').exists():raise FileExistsError('Completed result exists; choose a fresh run directory.')
    start=time.monotonic()
    cfg=json.loads((ROOT/'numerics/calculation_contract.json').read_text())
    before={str(p.relative_to(ROOT)):hashfile(p) for p in [Path(__file__),ROOT/'numerics/solver_core.py',ROOT/'numerics/calculation_contract.json',ROOT/'numerics'/f'mesh_L{level}.npz']}
    m=np.load(ROOT/'numerics'/f'mesh_L{level}.npz');p=m['points_m'];t=m['tets'].astype(np.int32)
    base=np.load(ROOT/'numerics/mesh_L0.npz');bp=base['points_m'];bt=base['tets']
    bf,ba,bn=core.boundary_faces(bp,bt)
    center,basis=core.coordinate_frame(bp,bt);bq=(bp-center)@basis
    surface=bq[np.unique(bf)];bs,br,bz=core.geometric_coordinates(bq[bt].mean(1),surface)
    base_masks=core.masks_from_geometry(bs,br,bz)
    fs,fr,fz=core.geometric_coordinates(bq[bf].mean(1),surface)
    patch=(fs>=.18)&(fs<=.64)&(np.abs(fr)<=.75)&((bn@basis[:,2])>=.5)
    parent=np.arange(len(t),dtype=np.int32) if level==0 else locate(p[t].mean(1),bp,bt)
    masks={name:mask[parent] for name,mask in base_masks.items()}
    faces,areas,normals=core.boundary_faces(p,t)
    face_parent=np.arange(len(faces),dtype=np.int32) if level==0 else locate_faces(p[faces].mean(1),bp,bf)
    loaded=patch[face_parent]
    q=(p-center)@basis;ns,nr,nz=core.geometric_coordinates(q,surface);side=q[:,0]>=0
    root_end=np.where(side,bq[bq[:,0]>=0,1].max(),bq[bq[:,0]<0,1].max())
    smax=core.geometric_coordinates(np.column_stack([np.zeros(len(p)),root_end,np.zeros(len(p))]),surface)[0]
    cap=(ns>=.80)&(ns>=smax-.04)
    c=core.constitutive(cfg['lambda_Pa'],cfg['mu_Pa'])
    checks=core.benchmark(c)
    print(f'L{level}: {len(p)} nodes, {len(t)} tetrahedra. Assembling.',flush=True)
    k,volumes,h=assemble(p,t,c)
    force=np.zeros((len(p),3))
    face_force=-cfg['pressure_Pa']*areas[loaded,None]*normals[loaded]
    for j in range(3):np.add.at(force,faces[loaded,j],face_force/3)
    reference=-cfg['pressure_Pa']*(ba[patch,None]*bn[patch]).sum(0)
    assert np.linalg.norm(force.sum(0)-reference)/np.linalg.norm(reference)<1e-9
    assert abs(areas[loaded].sum()-ba[patch].sum())/ba[patch].sum()<1e-9
    fixed=(3*np.flatnonzero(cap)[:,None]+np.arange(3)).ravel()
    free=np.setdiff1d(np.arange(3*len(p)),fixed)
    a=k[free][:,free].tocsr();b=force.ravel()[free]
    print(f'L{level}: free DOF={len(free)}, nonzeros={a.nnz}. Solving.',flush=True)
    residuals=[]
    if level==0:
        solver=splu(a.tocsc());uf=solver.solve(b)
        for _ in range(4):
            delta=b-a@uf
            if np.linalg.norm(delta)/np.linalg.norm(b)<1e-10:break
            uf+=solver.solve(delta)
        method='SuperLU direct + residual refinement'
    else:
        xyz=(p-center)/np.ptp(p,axis=0).max()
        candidate=np.zeros((len(p),3,6))
        candidate[:,:,:3]=np.eye(3)[None]
        for j in range(3):candidate[:,:,j+3]=np.cross(np.eye(3)[j],xyz)
        candidate=candidate.reshape(-1,6)[free]
        print('Building six-rigid-mode algebraic multigrid.',flush=True)
        ml=pyamg.smoothed_aggregation_solver(a.tobsr(blocksize=(3,3)),B=candidate,
            symmetry='symmetric',presmoother=('block_gauss_seidel',{'sweep':'symmetric'}),
            postsmoother=('block_gauss_seidel',{'sweep':'symmetric'}),max_coarse=250,max_levels=12)
        prec=ml.aspreconditioner(cycle='V')
        def callback(x):
            value=float(np.linalg.norm(b-a@x)/np.linalg.norm(b));residuals.append(value)
            if len(residuals)%20==0:print(f'L{level} CG iter={len(residuals)}, relres={value:.3e}',flush=True)
        uf,status=cg(a,b,M=prec,rtol=1e-10,atol=0,maxiter=800,callback=callback)
        if status!=0:raise RuntimeError(f'CG did not converge, status={status}')
        method='CG + smoothed-aggregation AMG with six rigid modes'
    u=np.zeros(3*len(p));u[free]=uf
    r=k@u-force.ravel();react=r.reshape(-1,3)[cap]
    rel=float(np.linalg.norm(r[free])/np.linalg.norm(force))
    forceerr=float(np.linalg.norm(force.sum(0)+react.sum(0))/np.linalg.norm(force.sum(0)))
    torque=np.cross(p,force).sum(0)+np.cross(p[cap],react).sum(0)
    torqueerr=float(np.linalg.norm(torque)/(np.linalg.norm(force.sum(0))*np.ptp(p,axis=0).max()))
    en=float(u@(k@u));work=float(u@force.ravel());energyerr=abs(en-work)/abs(work)
    if max(rel,forceerr,torqueerr,energyerr)>2e-7:raise RuntimeError(f'Equilibrium checks failed: {rel,forceerr,torqueerr,energyerr}')
    print('Recovering full element stresses.',flush=True)
    vm=recover_vm(p,t,c,u);rows=[]
    for name,label in zip(core.REGIONS,core.LABELS):
        use=masks[name];wq=core.volume_quantiles(vm[use],volumes[use])/1e6
        nq=core.quantiles(vm[use])/1e6
        rows.append(dict(level=level,region=name,label=label,elements=int(use.sum()),volume_mm3=float(volumes[use].sum()*1e9),
            Q90_MPa=wq[0],Q95_MPa=wq[1],Q99_MPa=wq[2],SAF95=wq[1]/(cfg['pressure_Pa']/1e6),
            equal_element_Q90_MPa=nq[0],equal_element_Q95_MPa=nq[1],equal_element_Q99_MPa=nq[2]))
    savecsv(dest/'region_quantiles.csv',rows)
    np.savez_compressed(dest/'solution.npz',points_m=p,tets=t,displacement_m=u.reshape(-1,3),
        element_von_mises_Pa=vm,volumes_m3=volumes,parent_L0=parent,boundary_faces=faces,
        loaded_face_indices=np.flatnonzero(loaded),fixed_node_indices=np.flatnonzero(cap),basis=basis,center_m=center)
    np.savez_compressed(dest/'region_masks.npz',**{n:np.flatnonzero(v) for n,v in masks.items()})
    checks.update(relative_residual=rel,force_balance_error=forceerr,torque_balance_error=torqueerr,energy_identity_error=energyerr)
    summary=dict(level=level,nodes=len(p),tetrahedra=len(t),free_dof=len(free),volume_mm3=float(volumes.sum()*1e9),
        h_max_mm=float(h.max()*1000),h_volume_mean_mm=float(np.average(h,weights=volumes)*1000),
        loaded_area_mm2=float(areas[loaded].sum()*1e6),net_force_N=force.sum(0).tolist(),fixed_nodes=int(cap.sum()),
        max_displacement_mm=float(np.linalg.norm(u.reshape(-1,3),axis=1).max()*1000),max_stress_MPa=float(vm.max()/1e6),
        strain_energy_J=.5*en,method=method,iterations=len(residuals),checks=checks,table9=rows,
        input_hashes_before=before,input_hashes_after={p:hashfile(ROOT/p) for p in before},
        runtime_seconds=time.monotonic()-start,software=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,pyamg=pyamg.__version__),
        status='completed',contract=cfg)
    assert summary['input_hashes_before']==summary['input_hashes_after']
    summary['output_hashes']={str(p.relative_to(ROOT)):hashfile(p) for p in dest.iterdir() if p.is_file() and p.name!='summary.json'}
    (dest/'summary.json').write_text(json.dumps(summary,indent=2))
    print(json.dumps({'level':level,'rows':rows,'checks':checks,'seconds':summary['runtime_seconds']},indent=2),flush=True)


if __name__=='__main__':main()
