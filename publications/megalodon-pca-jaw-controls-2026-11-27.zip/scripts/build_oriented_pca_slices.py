"""Generate plane-on sweeps and audit them against the saved native wall cuts."""
import argparse
import csv
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

import numpy as np
from PIL import Image, ImageDraw, ImageFont

PROJECT = Path(__file__).resolve().parents[3]
NATIVE = Path(__file__).resolve().parents[1]
SOURCES = PROJECT / "output/current_native74_stress_2026-11-20/cache"
CATALOGUE = PROJECT / "output/pdf/debunk_myth_preprint_2026-11-19/numerics/coupled_ct_submodels/native-microtubes-fine.json"
FRAMES, FPS = 300, 25
WIDTH, HEIGHT = 1920, 1080
PLOT_W, PLOT_H = 1320, 780
LEFT, TOP = 68, 182
BG, PAPER, CALLOUT = "#0d1d28", "#f1eee5", "#67e2df"
ORIGINAL_COLOUR, FINE_COLOUR = "#d52d37", "#147aca"


def digest(path):
    with path.open("rb") as data:
        return hashlib.file_digest(data, "sha256").hexdigest()


def references(path):
    data = np.genfromtxt(path, delimiter=",", names=True)
    if len(data) != FRAMES:
        raise ValueError("Original cut schedule must contain 300 frames")
    return data


def ffmpeg(*args, **kwargs):
    return subprocess.run(["ffmpeg", "-hide_banner", "-v", "error", "-y", *args], check=True, **kwargs)


def project_traces(traces, center, basis):
    ids, starts, ends = [], [], []
    for trace in traces:
        path = (np.asarray(trace["points_registered_native_xyz_mm"]) - center) @ basis
        ids.extend([trace["id"]] * (len(path) - 1))
        starts.extend(path[:-1])
        ends.extend(path[1:])
    return np.asarray(ids), np.asarray(starts), np.asarray(ends)


def mark_crossings(frame, cut, segments):
    ids, a, b = segments
    has_crossing = (a[:,2] < cut) != (b[:,2] < cut)
    a, b = a[has_crossing], b[has_crossing]
    fraction = (cut - a[:,2]) / (b[:,2] - a[:,2])
    points = a + fraction[:,None] * (b - a)
    residual = float(np.max(np.abs(points[:,2] - cut), initial=0))
    if residual > 1e-10:
        raise ValueError("Candidate point lies off its display plane")
    return points[:,:2], list(zip([frame]*len(points), ids[has_crossing], points[:,0], points[:,1])), residual


def build(axis, center, traces, original_ids, rasterizer, output):
    number = axis["axis"]
    basis = np.column_stack((axis["u"], axis["v"], axis["normal"]))
    if not np.allclose(basis.T @ basis, np.eye(3), atol=1e-12, rtol=0):
        raise ValueError("Invalid PCA frame")
    reference = references(NATIVE / f"review/movie-maximum-area/pca-{number}.csv")
    lo_u, hi_u = axis["u_range_mm"]
    lo_v, hi_v = axis["v_range_mm"]
    center_u, center_v = (lo_u+hi_u)/2, (lo_v+hi_v)/2
    scale = min((PLOT_W-30)/(hi_u-lo_u), (PLOT_H-30)/(hi_v-lo_v))
    prefix = f"Native74_twocolour_PCA_axis_{number}"
    config = output / f"{prefix}_frame.txt"
    cfg = [*center, *axis["normal"], *axis["u"], *axis["v"], center_u, center_v, scale]
    config.write_text(" ".join(f"{v:.17g}" for v in cfg))
    raw_csv = output / f"{prefix}_cuts.csv"
    segments = project_traces(traces, center, basis)
    maximum = int(np.argmax(np.abs(reference["signed_area_mm2"])))
    fonts = {size: ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial.ttf", size)
             for size in (20, 24, 28, 32, 51)}
    bold = ImageFont.truetype("/System/Library/Fonts/Supplemental/Arial Bold.ttf", 28)
    video = output / f"{prefix}.mp4"
    reverse = output / f"{prefix}_reverse.mp4"
    poster = output / f"{prefix}_largest.png"
    encode = ["ffmpeg", "-hide_banner", "-v", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24",
              "-s", f"{WIDTH}x{HEIGHT}", "-framerate", str(FPS), "-i", "pipe:0",
              "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p",
              "-movflags", "+faststart", str(video)]
    labels = (("PCA 2", "+PCA 3"), ("PCA 3", "−PCA 1"), ("PCA 2", "−PCA 1"))
    horizontal, vertical = labels[number-1]
    marker_counts, original_counts, trace_audit, raster_areas = [], [], [], []
    max_residual = 0.0
    with subprocess.Popen([
        str(rasterizer), str(SOURCES/"vertices.f64"), str(SOURCES/"triangles.u32"), str(config), str(raw_csv)
    ], stdout=subprocess.PIPE) as raster, subprocess.Popen(encode, stdin=subprocess.PIPE) as writer:
        for frame, (cut, area) in enumerate(zip(reference["offset_mm"], reference["signed_area_mm2"])):
            data = raster.stdout.read(PLOT_W*PLOT_H)
            if len(data) != PLOT_W*PLOT_H:
                raise RuntimeError(f"Incomplete native slice at PCA {number} frame {frame}")
            mask = Image.frombytes("L", (PLOT_W, PLOT_H), data)
            raster_areas.append(mask.histogram()[255]/scale**2)
            image = Image.new("RGB", (WIDTH, HEIGHT), BG)
            image.paste(PAPER, (LEFT, TOP, LEFT+PLOT_W, TOP+PLOT_H), mask)
            outline = ImageDraw.Draw(image)
            outline.rectangle((LEFT, TOP, LEFT+PLOT_W, TOP+PLOT_H), outline="#314752", width=2)
            uv, rows, residual = mark_crossings(frame, cut, segments)
            marker_counts.append(len(rows))
            original_counts.append(sum(row[1] in original_ids for row in rows))
            trace_audit.extend(rows)
            max_residual = max(max_residual, residual)
            for (_, trace_id, _, _), (px, py) in zip(rows, uv):
                x = LEFT+PLOT_W*.5+(px-center_u)*scale
                y = TOP+PLOT_H*.5-(py-center_v)*scale
                if trace_id in original_ids:
                    outline.ellipse((x-5,y-5,x+5,y+5), outline=ORIGINAL_COLOUR, width=3)
                else:
                    outline.rectangle((x-4,y-4,x+4,y+4), outline=FINE_COLOUR, width=2)
            outline.text((LEFT, 39), f"Inside the tooth · PCA {number}", font=fonts[51], fill=PAPER)
            outline.text((LEFT, 110), f"Oriented slice normal to PCA {number}", font=fonts[28], fill="#b7ced7")
            x = 1440
            outline.text((x, 192), "PLANE POSITION", font=bold, fill=CALLOUT)
            outline.text((x, 243), f"{cut:+.4f} mm", font=fonts[51], fill=PAPER)
            outline.text((x, 313), "From material voxel centroid", font=fonts[24], fill="#b7ced7")
            outline.text((x, 373), f"Frame {frame+1:03d} / {FRAMES}", font=fonts[28], fill=PAPER)
            outline.text((x, 425), f"Material area {abs(area):.2f} mm²", font=fonts[28], fill=PAPER)
            outline.rectangle((x, 519, x+23, 537), fill=PAPER)
            outline.text((x+35, 513), "Native material section", font=fonts[24], fill=PAPER)
            outline.ellipse((x+4, 573, x+20, 589), outline=ORIGINAL_COLOUR, width=3)
            outline.text((x+35, 567), f"Original set: {original_counts[-1]}", font=fonts[24], fill=PAPER)
            outline.rectangle((x+4, 617, x+20, 633), outline=FINE_COLOUR, width=3)
            outline.text((x+35, 611), f"Fine extension: {len(rows)-original_counts[-1]}", font=fonts[24], fill=PAPER)
            outline.text((x, 672), "Candidate trace crossings.", font=fonts[24], fill="#b7ced7")
            outline.text((x, 712), "Symbols are enlarged.", font=fonts[24], fill="#b7ced7")
            outline.line((x, 880, x+50, 880), fill=CALLOUT, width=3)
            outline.line((x, 880, x, 830), fill=CALLOUT, width=3)
            outline.polygon(((x+50,880),(x+39,875),(x+39,885)), fill=CALLOUT)
            outline.polygon(((x,830),(x-5,841),(x+5,841)), fill=CALLOUT)
            outline.text((x+62, 866), "+"+horizontal, font=fonts[20], fill=PAPER)
            outline.text((x-4, 791), vertical, font=fonts[20], fill=PAPER)
            ruler_x, ruler_y = LEFT, 1016
            ruler_end = ruler_x+10*scale
            outline.line((ruler_x,ruler_y,ruler_end,ruler_y), fill=PAPER, width=3)
            for tick in (ruler_x,ruler_end):
                outline.line((tick,ruler_y-8,tick,ruler_y+8), fill=PAPER, width=3)
            outline.text((ruler_end+15, ruler_y-15), "10 mm", font=fonts[24], fill=PAPER)
            outline.text((LEFT+430, ruler_y-16), "18 µm native CT · 74,293,846 source triangles · tissue identity unverified",
                         font=fonts[23] if 23 in fonts else fonts[24], fill="#b7ced7")
            writer.stdin.write(image.tobytes())
            if frame == maximum:
                image.save(poster, optimize=True)
                mask.save(output / f"{prefix}_material.png", optimize=True)
        writer.stdin.close()
        if raster.wait() or writer.wait():
            raise RuntimeError(f"Producer failed for PCA {number}")
    new = references(raw_csv)
    if not np.array_equal(new["segments"], reference["segments"]):
        raise ValueError("Native segment count differs from archived cut schedule")
    np.testing.assert_allclose(new["offset_mm"], reference["offset_mm"], rtol=0, atol=1e-12)
    np.testing.assert_allclose(new["signed_area_mm2"], reference["signed_area_mm2"], rtol=0, atol=1e-10)

    with gzip.open(output/f"{prefix}_crossings.csv.gz", "wt", newline="") as file:
        csv_writer = csv.writer(file)
        csv_writer.writerow(["forward_frame_0based","candidate_trace_id","u_mm","v_mm","catalogue_group"])
        csv_writer.writerows([*row, "original" if row[1] in original_ids else "fine"]
                             for row in trace_audit)
    ffmpeg("-i", str(video), "-vf", "reverse", "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
           "-pix_fmt", "yuv420p", "-movflags", "+faststart", str(reverse))
    for src in (video, reverse):
        ffmpeg("-i", str(src), "-filter_complex_threads", "1", "-filter_complex",
               "fps=12.5,scale=960:-2:flags=lanczos,split[p][q];[p]palettegen=max_colors=96[k];[q][k]paletteuse=dither=none",
               "-loop", "0", str(src.with_suffix(".gif")))
        fields = subprocess.check_output(["ffprobe","-v","error","-select_streams","v:0","-show_entries",
                                          "stream=width,height,nb_frames,avg_frame_rate","-of","json",str(src)])
        field = json.loads(fields)["streams"][0]
        if (int(field["nb_frames"]), field["width"], field["height"], field["avg_frame_rate"]) != (FRAMES, WIDTH, HEIGHT, "25/1"):
            raise ValueError("Encoded frame count, pixel grid or frame rate is incorrect")
    comparable = np.abs(reference["signed_area_mm2"]) > 10
    return {
        "axis": number, "normal": axis["normal"], "u": axis["u"], "v": axis["v"], "pixels_per_mm": scale,
        "asset_names": {"mp4":video.name, "reverse_mp4":reverse.name, "gif":video.with_suffix(".gif").name,
                        "reverse_gif":reverse.with_suffix(".gif").name, "poster":poster.name},
        "forward_sha256": digest(video), "reverse_sha256": digest(reverse), "poster_sha256":digest(poster),
        "bytes":video.stat().st_size, "reverse_bytes":reverse.stat().st_size,
        "max_frame": maximum, "max_area_mm2": abs(float(reference[maximum]["signed_area_mm2"])),
        "max_offset_mm": float(reference[maximum]["offset_mm"]),
        "max_original_crossings": original_counts[maximum],
        "max_fine_crossings": marker_counts[maximum] - original_counts[maximum],
        "plot_center_uv_mm": [center_u, center_v],
        "trace_intersections_by_source_frame":marker_counts, "total_candidate_trace_crossings":len(trace_audit),
        "maximum_trace_plane_residual_mm":max_residual,
        "maximum_raster_area_difference_mm2": float(np.max(np.abs(np.asarray(raster_areas)[comparable]-np.abs(reference["signed_area_mm2"][comparable])))),
        "exact_schedule_and_segment_counts_match":True
    }


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rasterizer", type=Path)
    parser.add_argument("output", type=Path)
    args=parser.parse_args()
    args.output.mkdir(exist_ok=True, parents=True)
    frame=json.loads((NATIVE/"prepared/axis-media/pca-sections.json").read_text())
    catalogue=json.loads(CATALOGUE.read_text())
    traces=catalogue["traces"]
    original_ids = {trace["id"] for trace in traces if "envelope_diagonal_mm" not in trace}
    if len(original_ids) != catalogue["survey"]["earlier_subset_traces"]:
        raise ValueError("Original catalogue group does not match the archive")
    audit={"schema":"native-74m-oriented-pca-slices/2", "source_triangles":74293846,
           "native_pitch_um":18, "frames_per_mp4":300, "gif_frames":150, "fps":25,
           "center_scanner_mm":frame["center_scanner_mm"], "candidate_traces":len(traces),
           "candidate_trace_catalogue_sha256":digest(CATALOGUE),
           "interpretation":"Plane intersections with segmented cavity centreline polylines. Red rings mark the original catalogue subset and blue squares mark its fine-envelope extension. Symbol sizes are illustrative. Tissue identity and porosity during life are unverified.",
           "axes":[]}
    for axis in frame["axes"]:
        audit["axes"].append(build(axis,np.asarray(frame["center_scanner_mm"]),traces,original_ids,args.rasterizer,args.output))
        (args.output/"oriented_pca_audit.json").write_text(json.dumps(audit,indent=2)+"\n")
        print(f"PCA {axis['axis']} geometry, frame schedule and video verified", flush=True)

if __name__=="__main__":
    main()
