// Rasterise the oriented plane intersections of the unchanged native mesh.
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <vector>
#include <sys/mman.h>
#include <fcntl.h>
#include <unistd.h>

constexpr uint64_t vertices_count = 37951699;
constexpr uint64_t faces_count = 74293846;
constexpr int width = 1320;
constexpr int height = 780;
constexpr int frames = 300;

struct Projection { double u, v; float q; };
struct Point { double u, v; };
struct Segment { float x0, y0, x1, y1; };

template <class T>
const T* map_file(const char* name, size_t entries) {
    const int fd = open(name, O_RDONLY);
    if (fd < 0) throw std::runtime_error("Cannot open native geometry");
    const size_t bytes = entries * sizeof(T);
    if (lseek(fd, 0, SEEK_END) != static_cast<off_t>(bytes)) {
        close(fd);
        throw std::runtime_error("Unexpected native geometry size");
    }
    void* address = mmap(nullptr, bytes, PROT_READ, MAP_PRIVATE, fd, 0);
    close(fd);
    if (address == MAP_FAILED) throw std::runtime_error("Cannot map native geometry");
    return static_cast<const T*>(address);
}

double project(const double* value, const double* origin, const double* direction) {
    double result = 0;
    for (int k = 0; k < 3; ++k) result += (value[k] - origin[k]) * direction[k];
    return result;
}

int main(int argc, char** argv) {
    if (argc != 5) return 1;
    const auto* vertices = map_file<double>(argv[1], vertices_count * 3);
    const auto* faces = map_file<uint32_t>(argv[2], faces_count * 3);
    std::ifstream cfg(argv[3]);
    double origin[3], normal[3], u[3], v[3], uc, vc, scale;
    for (auto* vector : {origin, normal, u, v})
        for (int k = 0; k < 3; ++k) cfg >> vector[k];
    cfg >> uc >> vc >> scale;
    if (!cfg || scale <= 0) throw std::runtime_error("Invalid oriented plane frame");

    std::vector<Projection> projections(vertices_count);
    float minq = std::numeric_limits<float>::max(), maxq = -minq;
    for (uint64_t i = 0; i < vertices_count; ++i) {
        const auto* point = vertices + i * 3;
        const auto q = static_cast<float>(project(point, origin, normal));
        projections[i] = {project(point, origin, u), project(point, origin, v), q};
        minq = std::min(minq, q);
        maxq = std::max(maxq, q);
    }
    // Same Float32 limits and 300 frame locations as the original clipping movies.
    const double lower = minq - .018f;
    const double upper = maxq + .018f;
    const double step = (upper - lower) / (frames - 1);
    std::array<std::vector<Segment>,frames> bins;
    std::array<long double,frames> twice_area{};
    for (uint64_t i = 0; i < faces_count; ++i) {
        const auto* f = faces + i * 3;
        const std::array<Projection,3> tri{projections[f[0]], projections[f[1]], projections[f[2]]};
        const auto [a, b] = std::minmax({tri[0].q, tri[1].q, tri[2].q});
        int first = std::max(0, int(std::floor((a-lower)/step)));
        const int last = std::min(frames-1, int(std::ceil((b-lower)/step)));
        for (int n = first; n <= last; ++n) {
            const double cut = lower + n * step;
            if (cut <= a || cut > b) continue;
            Point from{}, to{};
            for (int e = 0; e < 3; ++e) {
                const auto s = tri[e], t = tri[(e+1)%3];
                if ((s.q < cut) == (t.q < cut)) continue;
                const double fpart = (cut-s.q) / (static_cast<double>(t.q)-s.q);
                const Point point{s.u + fpart*(t.u-s.u), s.v + fpart*(t.v-s.v)};
                if (s.q < cut) from = point;
                else to = point;
            }
            twice_area[n] += from.u*to.v-from.v*to.u;
            bins[n].push_back({
                float(width*.5 + (from.u-uc)*scale), float(height*.5 - (from.v-vc)*scale),
                float(width*.5 + (to.u-uc)*scale), float(height*.5 - (to.v-vc)*scale)
            });
        }
    }

    std::ofstream csv(argv[4]);
    csv << "frame,offset_mm,signed_area_mm2,segments\n" << std::setprecision(17);
    std::vector<int32_t> changes(width*height);
    std::vector<uint8_t> pixels(width*height);
    for (int n = 0; n < frames; ++n) {
        std::fill(changes.begin(), changes.end(), 0);
        for (const auto& seg : bins[n]) {
            const auto [ymin,ymax] = std::minmax(seg.y0,seg.y1);
            const int first = std::max(0, int(std::ceil(ymin-.5f)));
            const int last = std::min(height, int(std::ceil(ymax-.5f)));
            for (int y = first; y < last; ++y) {
                const auto x = seg.x0 + (y+.5f-seg.y0)*(seg.x1-seg.x0)/(seg.y1-seg.y0);
                const int col = std::max(0, int(std::ceil(x-.5f)));
                if (col < width) changes[y*width+col] += seg.y1 > seg.y0 ? 1 : -1;
            }
        }
        for (int y = 0; y < height; ++y) {
            int winding = 0;
            for (int x = 0; x < width; ++x) {
                const int offset = y*width+x;
                winding += changes[offset];
                pixels[offset] = winding ? 255 : 0;
            }
            if (winding) throw std::runtime_error("Unclosed section in raster bounds");
        }
        std::cout.write(reinterpret_cast<const char*>(pixels.data()), pixels.size());
        if (!std::cout) return 2;
        csv << n << ',' << lower + n*step << ',' << double(twice_area[n]*.5L) << ',' << bins[n].size() << '\n';
    }
    std::cerr << "Intersected " << faces_count << " source faces across " << frames << " cuts\n";
}
