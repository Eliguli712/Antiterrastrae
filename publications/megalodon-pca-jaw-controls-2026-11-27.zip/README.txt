Megalodon native sections and jaw-support controls — 27 November 2026

Use the CSV positions and directions with the native source CT mesh:
https://github.com/Eliguli712/Antiterrastrae/releases/download/megalodon-ct-18um/Megalodon_FullCT_Native_Internal_74M_18um.3mf
Per-frame crossing sheets carry zero-based frame numbers. The manuscript uses one-based numbers.
Two colours identify source catalogue groups. They have no histological interpretation.
Python figure replay from this ZIP: python scripts/plot_pca_trace_sections.py pca atlas.pdf
Required packages: NumPy, Pillow and Matplotlib. The original rasterizer and movie-production
script use the project's native binary mesh, original PCA schedule, catalogue and FFmpeg.

The cervical fit is a two-dimensional annotation in the calibrated tooth frontal frame.
The CSV is the evaluated trace. The JSON records the manually selected landmarks, screen-to-frame
transform, RMS errors and source hashes. The original annotation and plates live in the author
workspace. The trace did not modify the A3 solve, constraint masks or region definitions.

The jaw common domain contains the cast L2 volume mesh, the exact 1 kPa vector and both
lateral patches. The supplied comparison script reuses elastic_diagnostics.py, solver_core.py
and high_resolution.py in the original project. The legacy J0 displacement reference comes
from output/ct_fea_calibrated_2026-11-08/data/jaw_L2_full_1kPa/fields.npz.
summary.json gives input SHA-256, actual load paths and independent force/energy checks.
These support patches and springs are matched engineering controls, not functional joints.
