Compile DebunkMeg_complete_2026-11-19.tex twice with XeLaTeX.
For the publication-resolution artwork:
xelatex '\def\FullResolutionArtwork{1}\input{DebunkMeg_complete_2026-11-19.tex}'

The included typeset artwork compiles without access to the CT or FE meshes.
The figure replay scripts use the original analysis workspace and inputs documented in the methods. Figure 2 and Figure 4 numerical and display audits are in review/.
The Print Axis render takes a directory containing the 50.stl and 100.stl oriented assemblies, their supplied manufacturing JSON, and an output directory. The download URLs are on the study website. The script verifies each binary STL by SHA-256.
