# Matched supports, window size and cavity shape
Eliguli Han · 27 November 2026

The bundle contains exact replay inputs for the new experiments. The original
whole-tooth fields, CT archives and earlier reproduction code retain their
separate publication records. Extract the ZIP into an empty working
directory, preserving its paths. The archived runs used Python 3.13 and the
dependencies in requirements.txt. The window solve compiles a local C++17
operator using the existing macOS/POSIX build recipe.

Run the following from the extracted bundle root.

    P=output/pdf/debunk_myth_preprint_2026-11-19
    export OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2
    python "$P/scripts/matched_cap_refinement.py" --meshes L0 L1 L2 --output replay/cap_h.json
    python "$P/scripts/matched_cap_order.py" --p1 replay/cap_h.json --output replay/cap_p.json
    python "$P/scripts/cavity_window_shape_controls.py" --retain-nearby --output replay/cavities.json
    python "$P/scripts/plot_matched_controls.py" replay/controls-plate.pdf

The archived JSON contains unrounded stresses, region and collar definitions,
balance and work checks, and provenance. The two cap studies used 78.1 and
98.0 seconds on the recorded arm64 macOS host. The apex response changes by
more under mesh refinement than under the tested cap shifts. This contrast
limits the ordering of effects to each region. The cavity comparison applies
to one transition cavity and one transferred affine field. The retained-neighbour
series changes the window boundary and the included void neighbourhood.
Each series keeps matching collar cells for all window sizes.

## Figure 7 and Table 10 check

The broad-footprint row is 1.47, 1.42, 1.42, 1.86, 1.43 and 1.44 in the
six-region order used in the paper. Readback from the supplied table of solver
outputs gives the broad-apex/baseline ratio
1.0913132543780883 / 0.5865949690602663 = 1.860420412616883.
The printed Figure 7 value is 1.86. The candidate A3 shell/core-to-homogeneous
changes from full-precision fields are +101.1820% at the apex and +84.9714% at
margin A. Computing the apex change from the two rounded printed stresses
gives a slightly different percentage.

## Figure, source and audit

The PDF companion gives the main comparisons. Its editable TeX and vector
artwork are included. The two documentation files beside the numeric records
give solver, placement and quantile details. SHA256SUMS.json verifies archive
contents. The whole-domain porous problem and anatomical assignment of the
segmented cavities remain unresolved.
