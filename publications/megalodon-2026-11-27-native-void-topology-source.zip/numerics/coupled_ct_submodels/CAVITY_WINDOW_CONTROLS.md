# Local cavity window and shape controls

Run from the project root with the existing NumPy, SciPy and PyVista Python environment and a C++17 compiler.

```sh
python3 output/pdf/debunk_myth_preprint_2026-11-19/scripts/cavity_window_shape_controls.py --retain-nearby
```

The replay reads `Rcr.npz` and `coupling.json` from this directory. It uses the matrix-free solver and C++ source beside the replay script. The output is `cavity_window_shape_controls.json`. Use `--output PATH` to write a separate replay and preserve the supplied record. The inputs are the saved native binary CT crop and fitted A3 displacement gradient. No whole-tooth solve or full CT volume load is needed.

The selected native cavity is the six-connected component associated with trace 28. It contains 1,126 voxels at 18 µm pitch. All cubes share the same affine displacement gradient, Young's modulus of 20 GPa and Poisson ratio of 0.28. Original voxels are used unchanged within the three nested crops. The filled comparison is the exact affine solution. Stress quantiles are weighted by the equal volumes of the intact collar cells within 36 µm of the void. Stresses are evaluated at cell centres.

| Crop side (mm) | Isolated CT cavity Q95 (MPa) | All segmented voids retained Q95 (MPa) |
| --- | ---: | ---: |
| 1.008 | 5.56931 | 5.56493 |
| 1.296 | 5.62282 | 5.63011 |
| 1.584 | 5.64235 | 5.65436 |

The isolated series holds the selected cavity and its 3,160 collar cells fixed. Its largest-to-smallest difference is +1.312%. The all-void series retains the same 3,141 intact collar cells and changes both outer boundary placement and the inclusion of neighbouring voids. Its largest-to-smallest difference is +1.607%. These are finite-window changes at fixed voxel pitch.

In the common 1.296 mm cube, distance ranking selects 1,126 voxels for each synthetic control. The sphere uses Euclidean distance from the native cavity centroid. The ellipsoid uses the native cavity covariance. The volumetric discretisation and their respective 36 µm collar definitions are shared. The synthetic and native collars have different geometries and sample counts.

| Isolated geometry | Collar cells | Q95 (MPa) | Increase over filled (%) |
| --- | ---: | ---: | ---: |
| Original segmented cavity | 3,160 | 5.62282 | 41.24 |
| Voxelised sphere | 1,126 | 5.90931 | 48.44 |
| Covariance-oriented voxelised ellipsoid | 1,631 | 6.14608 | 54.38 |

The filled value is 3.98101 MPa in all eight runs. All relative free-force residuals are below 1.93 × 10⁻⁷. The JSON retains unrounded stresses, signed porous-minus-filled collar mean differences, paired MSEs, input checksums, clearances and solver checks. The stresses and rankings apply to this cavity, discretisation, imposed gradient and collar statistic.
