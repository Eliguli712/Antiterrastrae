# Matched bilateral root-cap sensitivity

Run from the project root using Python with NumPy, SciPy and PyAMG (5.4.1
in the verification run). The script reuses the project stiffness,
physical-volume quantile and parent-cell transfer routines.

```sh
P=output/pdf/debunk_myth_preprint_2026-11-19
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 python "$P/scripts/matched_cap_refinement.py" \
  --meshes L0 L1 L2 --output /tmp/matched_cap_refinement.json
OPENBLAS_NUM_THREADS=2 OMP_NUM_THREADS=2 python "$P/scripts/matched_cap_order.py" \
  --p1 "$P/numerics/matched_cap_refinement.json" --output /tmp/matched_cap_order.json
```

Retain the original project-relative paths for
`output/publication_validation_2026-11-12/scripts/elastic_diagnostics.py`
and the following files under
`output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/`:

- `solver_core.py` and `high_resolution.py`
- `L0/solution.npz`, `L1/solution.npz`, `L2/solution.npz`
- `L0/region_masks.npz` and `sensitivity/cases.csv`

The same-L0 order replay also imports `scripts/p1_p2_common_domain_v2.py`
from the paper directory and uses the archived baseline quadrature
verification at `numerics/p1_p2_common_domain/results.json`.

The nine linear displacement cases retain one calibrated polyhedron,
the L0 pressure footprint and six frozen physical regions. Each refinement
represents its own nodal evaluation of the same three geometric root-cap
rules. Each cap depth is a fraction of the common 51.585795 mm longitudinal
span. Both cap sides use their own L0 endpoint. Root Q95 is the first
stress sample reaching 95% of the root-region physical volume. Within-mesh
support change is relative to cap depth 0.04 on the same mesh. Fixed-rule
mesh change uses the coarser mesh as denominator. The reported additive
interaction is the fine-mesh support contrast in MPa minus its coarse-mesh
counterpart. These are finite design effects.

The same L0 tetrahedra and pressure footprint are also solved with quadratic
displacement and zero displacements on the same fixed subcomplex. An edge
node is fixed if both of its endpoints were fixed. The volume quantile
uses positive 343-point quadrature. The 125-to-343-point differences appear
separately in the result JSON. Independent stress assembly recovers the
free-DOF residual, resultant force balance, moment balance and work-energy
identity for each case.
