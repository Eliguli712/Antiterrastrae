#!/usr/bin/env python3
"""Find finer tubular candidates using verified native-mask slabs."""
from collections import Counter
import csv
import json
import sys
import numpy as np

from coupled_ct_submodels import CT, INTERACTIVE, OUT, TRACES

sys.path.insert(0, str(INTERACTIVE/"scripts"))
import trace_tubular_cavities as trace


class ReadOnlySlabs:
    def __init__(self):
        self.ct = CT()

    def __getitem__(self, slab):
        low = np.asarray([s.start for s in slab])[::-1]
        high = np.asarray([s.stop for s in slab])[::-1]
        return self.ct.window(low, high-low)


def main():
    native = ReadOnlySlabs()
    trace.MIN_TUBE_SPAN = .108
    lower = .126
    archive = json.loads(TRACES.read_text())
    with (INTERACTIVE/"review/microtubes/inner-shells.csv").open() as source:
        envelopes = list(csv.DictReader(source))
    original = {r["mesh_component"]:r for r in archive["traces"]}
    rows = []
    for row in envelopes:
        mid = (float(row["max_z"])+float(row["min_z"]))/2
        span = np.linalg.norm([float(row[f"max_{a}"])-float(row[f"min_{a}"]) for a in "xyz"])
        if span >= lower and int(row["mesh_component"]) not in original:
            rows.append((mid,span,row))
    updated, rejected = [], Counter()
    for i,(_,span,row) in enumerate(sorted(rows,key=lambda v:v[0])):
        if i%250==0:
            print(i,len(rows),len(updated),flush=True)
        # Prioritise verified candidates smaller than the former envelope filter.
        if span >= .30:
            continue
        component,reason = trace.fit_component(native,row)
        if component is None:
            rejected[reason]+=1
            continue
        cavity,base,fit=component
        result,reason=trace.principal_trace(cavity)
        if result is None:
            rejected[reason]+=1
            continue
        centerline,path,chord,diam,elongation,count,points=result
        coords=(centerline+base)[:,::-1]
        assert np.all(cavity[tuple(centerline.T)])
        absolute=np.round(trace.ORIGIN+coords*trace.SPACING,5)
        updated.append(dict(mesh_component=int(row["mesh_component"]),mask_component_voxels=count,
                       trace_length_mm=round(path,5),trace_chord_mm=round(chord,5),
                       median_native_diameter_mm=round(diam,5),variance_ratio_first_to_second=round(elongation,5),
                       bounding_fit_sum_abs_mm=round(fit,5),selected_skeleton_component_voxels=points,
                       envelope_diagonal_mm=float(span),points_registered_native_xyz_mm=absolute.tolist()))
    updated.sort(key=lambda it:-it["trace_length_mm"])
    assert updated, "No fine trace candidates passed all native-mask checks"
    def canonical_path(row):
        xyz = tuple(map(tuple,row["points_registered_native_xyz_mm"]))
        return min(xyz,xyz[::-1])
    ids = set(original)
    final=archive["traces"].copy()
    paths={canonical_path(row) for row in final}
    for row in updated:
        path=canonical_path(row)
        if row["mesh_component"] not in ids and path not in paths:
            ids.add(row["mesh_component"])
            paths.add(path)
            final.append(row)
    for i,row in enumerate(final,1):
        row["id"]=i
    survey=archive["survey"]
    survey["earlier_subset_traces"]=len(original)
    survey["additional_fine_candidates"]=len(final)-len(original)
    survey["minimum_small_envelope_diagonal_mm"]=lower
    survey["minimum_small_trace_chord_mm"]=trace.MIN_TUBE_SPAN
    survey["small_envelope_maximum_diagonal_mm"]=.30
    survey["small_envelope_rejections"]=rejected
    survey["traces_displayed"]=len(final)
    survey["display_selection"]="Preserved original selected paths plus all accepted fine-envelope paths."
    archive["traces"]=final
    archive["display"]="Measured median discrete diameter with a floor of two native voxels; paths keep native sampling."
    archive["interpretation"]="Geometric candidates in preserved CT. Closed cavities only; the method cannot identify biological canals, tissue or all voids."
    out = OUT/"native-microtubes-fine.json"
    out.write_text(json.dumps(archive,ensure_ascii=False,separators=(",",":"))+"\n")
    summary=dict(original=len(original),added=len(final)-len(original),total=len(final),
                 min_chord_mm=min(r["trace_chord_mm"] for r in final),min_diameter_mm=min(r["median_native_diameter_mm"] for r in final))
    print(json.dumps(summary,indent=2))


if __name__=="__main__":
    main()
