// Action of the consistent StVK reference tangent on a P1 displacement.
#include <algorithm>
#include <cstdint>

extern "C" void stvk_jacobian(
    const int32_t *cells, const double *g, const double *v, const double *lam,
    const double *mu, const double *F, const double *S, const double *u,
    double *out, int64_t elements, int64_t nodes) {
    std::fill(out,out+3*nodes,0.);
    for (int64_t e=0; e<elements; ++e) {
        const int32_t *t=cells+4*e;
        const double *shape=g+12*e;
        const double *f=F+9*e;
        const double *s=S+9*e;
        double grad[3][3] = {};
        for (int a=1;a<4;++a)
            for (int i=0;i<3;++i)
                for (int j=0;j<3;++j)
                    grad[i][j]+=(u[3*t[a]+i]-u[3*t[0]+i])*shape[3*a+j];
        double dE[3][3] = {};
        for (int i=0;i<3;++i)
            for (int j=0;j<3;++j)
                for (int k=0;k<3;++k)
                    dE[i][j]+=.5*(f[3*k+i]*grad[k][j]+f[3*k+j]*grad[k][i]);
        const double trace=lam[e]*(dE[0][0]+dE[1][1]+dE[2][2]);
        double dS[3][3], dP[3][3]={};
        for (int i=0;i<3;++i)
            for (int j=0;j<3;++j)
                dS[i][j]=2*mu[e]*dE[i][j]+(i==j?trace:0.);
        for (int i=0;i<3;++i)
            for (int j=0;j<3;++j)
                for (int k=0;k<3;++k)
                    dP[i][j]+=grad[i][k]*s[3*k+j]+f[3*i+k]*dS[k][j];
        for (int a=0;a<4;++a)
            for (int i=0;i<3;++i)
                out[3*t[a]+i]+=v[e]*(dP[i][0]*shape[3*a]+dP[i][1]*shape[3*a+1]+dP[i][2]*shape[3*a+2]);
    }
}
