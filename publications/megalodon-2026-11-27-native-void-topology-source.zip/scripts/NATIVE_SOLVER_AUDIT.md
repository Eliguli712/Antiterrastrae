# Native CT evidence and solver checks

Run from the project root with Python 3.11 or newer. `--verify-components`
requires NumPy. `--rerun-synthetic` requires NumPy and SciPy.

```sh
python3 output/pdf/debunk_myth_preprint_2026-11-19/scripts/audit_native_solver.py \
  archive --verify-mask --verify-components --verify-surfaces --rerun-synthetic
```

The `archive` command compares the native and optimised topology reports with
the feasibility record and re-derives the displacement DOF lower bounds. Each
selected voxel has a distinct low-index corner, so the Q1 lower bound is
three DOFs per selected voxel before applying constraints. The optional mask
check streams the original MetaImage payload and compares both SHA-256 values,
grid dimensions and the count of occupied voxels. The surface archive check
matches the 74M and 32M 3MF file checksums to their original export records.
The optional component check
recomputes the strict volume sieve from the complete component table. These
inward surface components describe the thresholded fossil geometry. The audit
contains comparative histology sources and records the absence of a
specimen-specific tissue assignment. The synthetic rerun stages the original
two modules in a temporary folder and compares four fresh linear-elastic solves
with their archived results.

## Preserved inputs

- `output/native_domain_module_2026-11-24/source/feasibility.json`
- `output/native_domain_module_2026-11-24/review/synthetic_kernel_validation.json`
- `full_3D/ct_internal_reconstruction/native_topology_report.json`
- `full_3D/ct_internal_reconstruction/reconstructed_topology_report.json`
- For `--verify-mask`, save the [public mask](https://github.com/Eliguli712/Antiterrastrae/releases/download/megalodon-ct-18um/Megalodon_FullCT_SpecimenMask_18um.mha) as `full_3D/Megalodon_FullCT_SpecimenMask_18um.mha`.
- For `--verify-components`, `full_3D/ct_internal_reconstruction/validation_data/native_component_metrics.npz`.
- For `--verify-surfaces`, preserve `native_export_report.json` and `reconstructed_export_report.json` under `full_3D/ct_internal_reconstruction/`. Save the [native 74M 3MF](https://github.com/Eliguli712/Antiterrastrae/releases/download/megalodon-ct-18um/Megalodon_FullCT_Native_Internal_74M_18um.3mf) and [optimised 32M 3MF](https://github.com/Eliguli712/Antiterrastrae/releases/download/megalodon-ct-18um/Megalodon_FullCT_Internal_32M_18um.3mf) under `full_3D/`.
- For `--rerun-synthetic`, `smoke_validation.py` and `elasticity.py` under `output/native_domain_module_2026-11-24/module/`.

Passing the checks confirms agreement with these archived representations. A
production boundary-conforming model still requires embedding, shell
containment, positive element volumes, non-overlapping cells and readback of the
material and void domain. Before accepting an approximate representation, report
the voxel connectivity convention, exterior-connected paths and closed cavities,
component-wise volume changes, resolved minimum throat sizes and any omitted
features. The native and optimised surfaces have equal recorded component counts
and Euler characteristics with different enclosed void volumes.

## Matched-solver comparison

Use `benchmark reference.json candidate.json` after exporting both solutions to
the same frame, sign convention and volume-weighted physical sample IDs. Both
manifests use `"schema": "elastic-solver-benchmark/1"`, `backend`, `version`,
`problem` and `samples` records containing `path` (relative to the manifest) and
`sha256`, and a `performance` object with `active_dofs`, `ranks`, `hardware`,
`peak_aggregate_RAM_bytes`, `mesh_seconds`, `setup_seconds`, `solve_seconds` and
`normalized_equilibrium_residual`. Count active DOFs after imposing essential
constraints and record the hardware and RAM measurement definition in `hardware`.
The residual is a free-DOF imbalance norm divided by the applied load norm. The
shared problem document should pin geometry, coordinates and weights, load,
support and constitutive properties. The field export header is

```text
sample_id,volume_mm3,ux_m,uy_m,uz_m,sxx_pa,syy_pa,szz_pa,sxy_pa,sxz_pa,syz_pa
```

Specify all four relative limits before running the comparison using
`--displacement-l2`, `--stress-frobenius-l2`, `--von-mises-q95` and
`--equilibrium-residual`. The first two are volume-weighted field errors and
count both off-diagonal tensor entries in the stress norm. Q95 uses cumulative
volume. A valid comparison exits 1 when any limit fails. Unreadable or
incompatible input exits 2. Retain the input files and JSON report per run.

The comparison is independent of the choice of solver. Distributed MFEM is
the proposed voxel route. LANL SM-FMM is a separate research route whose cavity
traction and boundary representation must be checked on matching problems.
FastBEM is an optional linear homogeneous isotropic boundary reference. None
of these three backends was run on the whole fossil in this audit.
