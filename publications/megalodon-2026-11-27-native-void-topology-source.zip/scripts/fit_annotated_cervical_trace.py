#!/usr/bin/env python3
"""Register the marked frontal panel and fit the supplied dark trace."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
from tempfile import TemporaryDirectory

import fitz
import matplotlib
matplotlib.use("Agg")
from matplotlib import patheffects
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from scipy.interpolate import UnivariateSpline
from scipy.ndimage import binary_fill_holes
from scipy.optimize import least_squares

# Pixel landmarks manually digitised along the centre of the dark user stroke.
LANDMARKS = np.array([
    (289, 581), (303, 595), (324, 601), (348, 610), (370, 617), (392, 621),
    (406, 624), (413, 635), (420, 620), (429, 630), (455, 632), (481, 631),
    (505, 632), (516, 628), (524, 623), (535, 632), (546, 648), (560, 651),
    (580, 650), (600, 656), (615, 648), (631, 633), (648, 628), (671, 619),
    (692, 615), (715, 610), (733, 602), (750, 582), (768, 571), (793, 563),
    (808, 560), (819, 544), (838, 530), (852, 515), (862, 507), (868, 512),
    (862, 535), (867, 539), (880, 531), (889, 507), (900, 483), (915, 465),
    (928, 450), (933, 440),
], dtype=float)
# Collapse the locally doubled-back annotation to a single-valued curve.
# Median target landmarks near x=862--870 retain its centre without a loop.
FIT_LANDMARKS = np.vstack([LANDMARKS[:34], [862, 521], [871, 535], LANDMARKS[38:]])
PAPER = Path(__file__).resolve().parents[1]
ART = PAPER / "figures"
STEM = "review_base_field_qf_shared_cervical"
ALPHA = ART / "field_qf_shared_cervical_A3.png"
PX_PER_MM, NATIVE_X0, NATIVE_Y0 = 29., 900., 748.


def digest(path):
    with path.open("rb") as source:
        return hashlib.file_digest(source, "sha256").hexdigest()


def edges(mask, rows):
    use = mask[rows]
    return np.vstack([use.argmax(axis=1), mask.shape[1] - 1 - use[:, ::-1].argmax(axis=1)])


def register(source):
    native = np.asarray(Image.open(ALPHA).getchannel("A")) > 120
    annotated = np.asarray(Image.open(source).convert("RGB"), dtype=np.int16)
    assert annotated.shape[:2] == (1374, 1288)
    saturated = np.ptp(annotated, axis=2) > 24
    mask = np.zeros(saturated.shape, dtype=bool)
    mask[210:939, 256:958] = saturated[210:939, 256:958]
    mask = binary_fill_holes(mask)
    rows = np.arange(245, 910)
    assert mask[rows].any(axis=1).all()
    native_rows = np.flatnonzero(native.any(axis=1))
    original = edges(native, native_rows)
    observed = edges(mask, rows)
    # Screenshot's calibrated -10, 0 and +10 mm tick positions.
    sx, x0 = np.polyfit([-10, 0, 10], [419.5, 615.5, 810.5], 1)

    def residual(parameters):
        y0, sy = parameters
        coordinates = (rows - y0) / sy * PX_PER_MM + NATIVE_Y0
        projected = np.array([np.interp(coordinates, native_rows, edge) for edge in original])
        return (x0 + (projected - NATIVE_X0) * sx / PX_PER_MM - observed).ravel()

    registration = least_squares(residual, [670, 19.55], bounds=([640, 18], [700, 21]),
                                 loss="soft_l1", f_scale=2)
    y0, sy = registration.x
    outline_rms_px = float(np.sqrt(np.mean(residual(registration.x)**2)))
    assert outline_rms_px < 2
    return x0, y0, sx, sy, outline_rms_px


def overlay(x, y, suffix):
    def inch(mm): return mm / 25.4
    with TemporaryDirectory() as working:
        figure = plt.figure(figsize=(inch(121), inch(128)))
        ax = figure.add_axes([83 / 121, 86 / 128, 28 / 121, 34 / 128])
        ax.set(xlim=(-18.5, 18.5), ylim=(-27, 23), aspect="equal")
        ax.set_axis_off()
        line, = ax.plot(x, y, c="#1f181b", lw=.95)
        line.set_path_effects([patheffects.withStroke(linewidth=1.65, foreground="#fcf4df")])
        layer = Path(working) / "overlay.pdf"
        figure.savefig(layer, transparent=True)
        plt.close(figure)
        with fitz.open(ART / f"{STEM}{suffix}.pdf") as plate, fitz.open(layer) as vector:
            plate[0].show_pdf_page(plate[0].rect, vector, 0)
            updated = ART / f"field_qf_annotated_cervical{suffix}.pdf"
            plate.save(updated, deflate=True, garbage=4)
        return updated


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("annotation", type=Path)
    args = parser.parse_args()
    x0, y0, sx, sy, outline_rms = register(args.annotation)
    sample = np.column_stack(((FIT_LANDMARKS[:, 0] - x0) / sx,
                              (y0 - FIT_LANDMARKS[:, 1]) / sy))
    assert np.all(np.diff(sample[:, 0]) > 0)
    smoothing_mm = .17
    fit = UnivariateSpline(*sample.T, s=len(sample) * smoothing_mm**2)
    x = np.linspace(sample[0, 0], sample[-1, 0], 1025)
    y = fit(x)
    residual = fit(sample[:, 0]) - sample[:, 1]
    outputs = [overlay(x, y, suffix) for suffix in ("", "_preview")]
    out = PAPER / "numerics"
    csv_path = out / "annotated_cervical_trace.csv"
    with csv_path.open("w") as stream:
        rows = csv.writer(stream)
        rows.writerow(["transverse_mm", "longitudinal_mm"])
        rows.writerows(zip(x, y))
    audit = {
        "annotation_sha256": digest(args.annotation), "silhouette_sha256": digest(ALPHA),
        "purpose": "Frontal annotation fit only. The original photograph traces, 3D display regions and A3 finite-element labels and solution are unchanged.",
        "registration": {"zero_px": [x0, y0], "px_per_mm": [sx, sy],
                         "lateral_outline_RMS_px": outline_rms},
        "black_landmarks_px": LANDMARKS.tolist(), "fitted_landmarks_px": FIT_LANDMARKS.tolist(),
        "smoothing_target_mm": smoothing_mm, "longitudinal_fit_RMS_mm": float(np.sqrt(np.mean(residual**2))),
        "sampled_range_mm": {"transverse": [float(x.min()), float(x.max())],
                              "longitudinal": [float(y.min()), float(y.max())]},
        "figure_sha256": {item.name: digest(item) for item in outputs},
    }
    (out / "annotated_cervical_trace.json").write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps(audit["registration"], indent=2), audit["longitudinal_fit_RMS_mm"])


if __name__ == "__main__":
    main()
