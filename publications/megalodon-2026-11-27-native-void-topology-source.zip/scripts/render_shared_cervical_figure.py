"""Trace the photographed cervical band and display it on the native geometry.

The normalized photographic traces are applied to the native frontal silhouette.
Extending the curves through depth gives a reproducible 3D display guide.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
from tempfile import TemporaryDirectory

import fitz
import matplotlib as mpl
import matplotlib.patheffects as effects
from matplotlib.colors import to_rgb
import matplotlib.pyplot as plt
import meshio
import numpy as np
from PIL import Image
from scipy.interpolate import PchipInterpolator
from scipy.ndimage import gaussian_filter1d
from scipy.spatial import cKDTree
import trimesh

import render_native_field_plates as old
import revise_figures as layout
from photographic_cervical_guides import POINTS

PAPER, PROJECT, FIGURES = old.PAPER, old.PROJECT, old.FIGURES
REVIEW = PAPER / 'review'
STEM = 'field_qf_shared_cervical'
WIDTH, HEIGHT = 1800, 1600
TRACE_COLORS = ('#84daf0', '#ffcb73')
PHOTO_TIPS = (25, 1105)
COLORS = np.array([to_rgb(s) for s in ('#6587ad', '#bd8345', '#6f507f')])
PHOTO_ENDS = {
    'colour_break': ((177, 702), (872, 695)),
    'ridge_ends': ((183, 756), (933, 791)),
}
POSE = PROJECT / 'output/jaw_tooth_transfer_2026-11-22/data_v3/registration.npz'
JAW = PROJECT / 'applied_forces/custom_solver/great_white_jaw_fullres_gmsh_alg1_tet_vol.msh'


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def smoothstep(x):
    x = np.clip(x, 0, 1)
    return x*x*(3-2*x)


class CervicalGuide:
    def __init__(self):
        self.image_path = FIGURES / 'specimen_photo_b_matte.png'
        self.silhouette_path = FIGURES / 'field4_A3_native.png'
        mask = np.array(Image.open(self.silhouette_path).getchannel('A')) > 0
        rows = np.flatnonzero(mask.any(1))
        left = np.argmax(mask[rows], axis=1)
        right = WIDTH-1-np.argmax(mask[rows, ::-1], axis=1)
        self.axial_y = ((748-(rows+.5))/old.SCALE)[::-1]
        self.left = ((gaussian_filter1d(left.astype(float), 2)+.5-900)/old.SCALE)[::-1]
        self.right = ((gaussian_filter1d(right.astype(float), 2)+.5-900)/old.SCALE)[::-1]
        self.points = {}
        self.curves = []
        for key, ends in PHOTO_ENDS.items():
            points = np.vstack((ends[0], POINTS['b'][key], ends[1]))
            fraction = (points[-1, 0]-points[::-1, 0])/np.ptp(points[:, 0])
            height = (points[::-1, 1]-PHOTO_TIPS[0])/(PHOTO_TIPS[1]-PHOTO_TIPS[0])
            y = self.axial_y[0]+height*np.ptp(self.axial_y)
            self.points[key] = points
            self.curves.append(PchipInterpolator(fraction, y))
        u = np.linspace(0, 1, 4001)
        separation = self.curves[1](u)-self.curves[0](u)
        assert np.all(separation > 1)
        self.separation = [float(separation.min()), float(separation.max())]

    def edges(self, y):
        return np.interp(y, self.axial_y, self.left), np.interp(y, self.axial_y, self.right)

    def offsets(self, local):
        y = local[:, 1]
        left, right = self.edges(y)
        u = np.clip((local[:, 0]-left)/np.maximum(right-left, .02), 0, 1)
        return y-self.curves[0](u), y-self.curves[1](u)

    def traces(self):
        u = np.linspace(0, 1, 501)
        for i, curve in enumerate(self.curves):
            y = curve(u)
            left, right = self.edges(y)
            yield left+(right-left)*u, y, TRACE_COLORS[i]

    def paint(self, local):
        crown, root = self.offsets(local)
        colour = COLORS[0]+smoothstep((crown+.08)/.16)[:, None]*(COLORS[1]-COLORS[0])
        colour += smoothstep((root+.08)/.16)[:, None]*(COLORS[2]-COLORS[1])
        for value, dye in zip((crown, root), TRACE_COLORS):
            ink = (1-smoothstep(np.abs(value)/.22))[:, None]
            colour += ink*(to_rgb(dye)-colour)
        return colour


def stress_inputs():
    with np.load(old.BASELINE / 'L0/solution.npz') as baseline:
        center, basis = baseline['center_m']*1000, baseline['basis']
    with np.load(old.VALIDATION / 'local_A3/fields.npz') as fine:
        points, tets, faces = fine['points_m'], fine['tets'], fine['boundary_faces']
        nodal = old.volume_average(tets, points, fine['volumes_m3'], fine['von_mises_Pa']/1e6)
        boundary = np.unique(faces)
        fixed = np.zeros(len(points), dtype=bool)
        fixed[fine['fixed_nodes']] = True
        pressure = faces[fine['loaded_faces']]
        cap = faces[fixed[faces].all(axis=1)]
        markers = [(points[triangle].mean(1)*1000-center)@basis for triangle in (pressure, cap)]
    return center, basis, cKDTree(points[boundary]*1000), nodal[boundary], markers


def bounded_value(tree, nodal, position):
    distance, nearest = tree.query(position, k=8, workers=3)
    weights = 1/np.maximum(distance, 1e-8)**2
    blend = smoothstep((distance[:, 0]-1.35)/1.15)
    weights[:, 4:] *= blend[:, None]
    weights[:, :4] *= 1-smoothstep((distance[:, :4]-2.2)/.3)*(1-blend[:, None])
    samples = nodal[nearest]
    scalar = np.sum(weights*samples, axis=1)/np.sum(weights, axis=1)
    assert np.isfinite(scalar).all()
    assert np.all(scalar >= samples.min(1)-1e-10) and np.all(scalar <= samples.max(1)+1e-10)
    return scalar, distance[:, 0]


def assembly_camera(center):
    look = np.array([-600., 740., -970.])
    look /= np.linalg.norm(look)
    horizontal = np.cross(look, [0, 0, 1])
    horizontal /= np.linalg.norm(horizontal)
    vertical = np.cross(horizontal, look)
    camera = np.stack((horizontal, vertical, look), axis=1)
    def camera_xy(positions):
        q = (positions-center) @ camera
        return np.c_[900+q[:, 0]*20., 750-q[:, 1]*20., q[:, 2]]
    return camera_xy, look


def render(guide, center, basis, tree, nodal):
    count = old.TOOTH_VERTICES
    vertices = np.memmap(old.CACHE/'vertices.f64', '<f8', mode='r', shape=(count, 3))
    faces = np.memmap(old.CACHE/'triangles.u32', '<u4', mode='r', shape=(old.TOOTH_FACES, 3))
    normals = np.memmap(PROJECT/'output/scale_acrylic_2026-11-20/data/normals.f32',
                        '<f4', mode='r', shape=(count, 3))
    chart = mpl.colormaps['turbo']
    support, outside = 0, 0
    labels = np.zeros(3, dtype=np.int64)
    seen = np.zeros(len(vertices), dtype=bool)
    stats = {}
    with np.load(POSE) as registration:
        rotation = registration['reference_rotation'].copy()
        rotation_center = registration['tooth_root_centre_m']*1000
        destination = registration['reference_location_m']*1000
    camera, look = assembly_camera(destination)
    jaw = meshio.read(JAW)
    jaw_vertices, jaw_faces = jaw.points, jaw.cells_dict['triangle']
    assert len(jaw_faces) == 1_009_016
    jaw_normals = trimesh.Trimesh(jaw_vertices, jaw_faces, process=False).vertex_normals
    with TemporaryDirectory() as folder:
        temporary = Path(folder)
        renderer = temporary/'raster'
        subprocess.run(['clang++', '-O3', '-std=c++17', str(PAPER/'scripts/native_figure8_raster.cpp'),
                        '-o', str(renderer)], check=True)
        d, e = temporary/'main', temporary/'fit'
        d.mkdir()
        e.mkdir()
        with (subprocess.Popen([str(renderer), str(d)], stdin=subprocess.PIPE, stderr=subprocess.PIPE) as main,
              subprocess.Popen([str(renderer), str(e)], stdin=subprocess.PIPE, stderr=subprocess.PIPE) as fit):
            for start in range(0, len(jaw_faces), 250_000):
                faceset = jaw_faces[start:start+250_000]
                ids, local_indices = np.unique(faceset, return_inverse=True)
                shade = .56+.44*np.clip(jaw_normals[ids] @ (-look), 0, 1)
                colour = shade[:, None]*np.array([.78, .72, .61])
                old.send(fit, 0, camera(jaw_vertices[ids]), colour, local_indices.reshape(-1, 3))
            for start in range(0, len(faces), 630_000):
                face_batch = faces[start:start+630_000]
                indices, local_faces = np.unique(face_batch, return_inverse=True)
                local_faces = local_faces.reshape(-1, 3)
                xyz = vertices[indices]
                local = (xyz-center)@basis
                new = ~seen[indices]
                a, b = guide.offsets(local[new])
                labels += [(a < 0).sum(), ((a >= 0)&(b < 0)).sum(), (b >= 0).sum()]
                seen[indices] = True
                rgb = guide.paint(local)
                surface_normal = normals[indices]@basis
                front = old.tooth_view(local)
                shade = .76+.24*np.clip(surface_normal[:, 2], 0, 1)
                old.send(main, 0, front, rgb*shade[:, None], local_faces)
                value, distance = bounded_value(tree, nodal, xyz)
                support += int((distance[new] <= 1.5).sum())
                outside += int((distance[new] > 1.5).sum())
                old.send(main, 1, front, chart(old.MAP_NORM(np.maximum(value, .5)))[:, :3], local_faces)
                shade = .69+.31*np.clip((surface_normal@old.OBLIQUE)[:, 2], 0, 1)
                old.send(main, 2, old.tooth_view(local, oblique=True), rgb*shade[:, None], local_faces)
                in_jaw = (xyz-rotation_center)@rotation.T+destination
                jaw_shade = .75+.25*np.clip((normals[indices]@rotation.T)@(-look), 0, 1)
                old.send(fit, 0, camera(in_jaw), rgb*jaw_shade[:, None], local_faces)
                if start % 6_300_000 == 0:
                    print('Native triangles', start, flush=True)
            outputs = (
                (main, d, ('conditions', 'A3', 'oblique'), [len(faces)]*3),
                (fit, e, ('jaw',), [len(faces)+len(jaw_faces), 0, 0]),
            )
            for process, folder, names, expected in outputs:
                process.stdin.close()
                log = process.stderr.read().decode()
                assert process.wait() == 0, log
                assert list(map(int, re.findall(r'triangles submitted (\d+)', log))) == expected, log
                for i, label in enumerate(names):
                    raster = Image.frombytes('RGBA', (WIDTH, HEIGHT),
                                             (folder/f'native_figure8_{i}.rgba').read_bytes())
                    raster.save(FIGURES/f'{STEM}_{label}.png')
                stats[names[0]] = log.splitlines()
    assert seen.all() and int(labels.sum()) == len(vertices)
    return dict(crown_transition_root_native_vertices=labels.tolist(),
                stress_projection_within_1p5_mm=support, stress_projection_beyond_1p5_mm=outside,
                rasterisation=stats, full_native_faces_each_tooth_map=int(len(faces)),
                source_jaw_faces=int(len(jaw_faces)))


def plot_photo(axis, guide):
    image = Image.open(guide.image_path)
    axis.imshow(image, interpolation='none')
    for i, points in enumerate(guide.points.values()):
        x = np.linspace(points[0, 0], points[-1, 0], 501)
        y = PchipInterpolator(*points.T)(x)
        line = axis.plot(x, y, color=TRACE_COLORS[i], lw=1, ls='--' if i == 0 else '-')[0]
        line.set_path_effects([effects.withStroke(linewidth=1.8, foreground='#182032')])
        axis.scatter(points[[0, -1], 0], points[[0, -1], 1], color=TRACE_COLORS[i],
                     edgecolor='#182032', linewidth=.5, s=9, zorder=6)
    axis.set(xlim=(image.width-12, 48), ylim=(370, 970))
    axis.set_axis_off()


def plot_guides(axis, guide):
    for i, (x, y, colour) in enumerate(guide.traces()):
        line = axis.plot(x, y, color=colour, lw=.68, ls='--' if i == 0 else '-')[0]
        line.set_path_effects([effects.withStroke(linewidth=1.16, foreground='#1d2537')])


def picture(axis, name, native=False, images=None, preview=False):
    image = (images[name].copy() if images is not None and name in images
             else Image.open(FIGURES/f'{STEM}_{name}.png'))
    if not native and name != 'jaw':
        image = image.crop(image.getbbox())
    if preview:
        image.thumbnail((650, 650), Image.Resampling.LANCZOS)
    if native:
        axis.imshow(image, extent=(-900/old.SCALE, 900/old.SCALE,
                                   (748-1600)/old.SCALE, 748/old.SCALE),
                    origin='upper', interpolation='none')
        axis.set(xlim=(-18.5, 18.5), ylim=(-27, 23))
    else:
        axis.imshow(image, interpolation='none')
        axis.set_axis_off()


def sample_markers(points, number):
    order = np.lexsort((points[:, 1], points[:, 0]))
    take = ((np.arange(number)+.5)*len(order)/number).astype(int)
    return points[order[take]]


def compose(guide, markers=None, *, destination=None, images=None, foreground=None, preview=False, legend_text=None):
    fig = layout.canvas(121, 128)
    for index, title in enumerate(('Photo transition', 'Load / fixation', 'A3 equivalent stress')):
        x = [7, 46, 83][index]
        axis = layout.axmm(fig, x, 86, 28, 34)
        layout.panel(fig, x-5, 126, 'abc'[index])
        layout.txt(fig, x+13, 125.5, title, 6.1, va='top', ha='center')
        if not index:
            plot_photo(axis, guide)
            layout.txt(fig, 20, 85.6, 'Root up', 4.9, ha='center')
            layout.txt(fig, 20, 82.7, 'Dashed: colour break', 4.8, color='#187890', ha='center')
            layout.txt(fig, 20, 79.8, 'Solid: ridge ends', 4.8, color='#845107', ha='center')
            continue
        picture(axis, ('conditions', 'A3')[index-1], native=True, preview=preview)
        axis.set_xticks([-10, 0, 10])
        axis.set_xlabel('Transverse (mm)', labelpad=.9)
        axis.tick_params(labelsize=5.5, pad=1, labelleft=index == 1)
        if foreground is not None:
            foreground(axis, index)
        if index == 1:
            axis.set_ylabel('Longitudinal (mm)', labelpad=1)
        plot_guides(axis, guide)
        if index == 1 and markers is not None:
            for data, amount, shape in zip(markers, (22, 10), ('o', 'x')):
                p = sample_markers(data, amount)
                axis.scatter(p[:, 0], p[:, 1], c='#fcf8f1', s=7 if shape == 'o' else 12,
                             marker=shape, linewidths=.55, zorder=5)
    scale = fig.colorbar(mpl.cm.ScalarMappable(norm=old.MAP_NORM, cmap='turbo'),
                         cax=layout.axmm(fig, 111.5, 90, 1.4, 24), extend='both')
    scale.set_ticks([1, 10, 100])
    scale.ax.tick_params(labelsize=5.5, pad=1)
    layout.txt(fig, 115.3, 117, 'MPa', 5.3, ha='center')
    legend_line = ('B: blue load and red fixed faces. B--E: black display-guide fit.'
                   if foreground is not None else
                   'B: open circles pressure, crosses fixation (sampled centroids)')
    layout.txt(fig, 77, 78.2, legend_text or legend_line, 5.2, ha='center')
    layout.panel(fig, 2, 76, 'd')
    layout.txt(fig, 26, 75.7, 'Oblique native surface', 6.2, va='top', ha='center')
    picture(layout.axmm(fig, 1, 38, 48, 34), 'oblique', images=images, preview=preview)
    legend = layout.axmm(fig, 49, 43, 30, 27)
    for row, (label, colour) in enumerate(zip(('Root', 'Cervical band', 'Crown'), COLORS[::-1])):
        yp = .83-.24*row
        legend.plot([.06], [yp], marker='s', c=colour, ms=4)
        legend.text(.17, yp, label, fontsize=5.6, va='center')
    legend.set(xlim=(0, 1), ylim=(0, 1))
    legend.set_axis_off()
    layout.txt(fig, 63, 40, 'Photo-normalized display guide', 4.7, ha='center')
    values = json.loads((old.VALIDATION/'local_A3/results.json').read_text())['regions']
    layout.txt(fig, 99, 74, 'Frozen A3 FE summaries', 6.1, ha='center')
    layout.txt(fig, 112, 69, r'$Q_{0.95}$ (MPa)', 5.6, ha='right')
    for i, (label, item) in enumerate(zip(layout.LABELS, values)):
        yp = 66-4.1*i
        layout.txt(fig, 89, yp, label, 5.8)
        layout.txt(fig, 112, yp, f"{item['Q95_MPa']:.3f}", 5.8, ha='right')
    layout.panel(fig, 1, 35.8, 'e')
    layout.txt(fig, 17, 35.5, 'Fitted jaw seat', 5.9, ha='center', va='top')
    picture(layout.axmm(fig, 1, 4, 31.5, 28), 'jaw', images=images, preview=preview)
    layout.txt(fig, 17, 2.5, 'Curved guide on the fitted tooth', 4.7, ha='center')
    with TemporaryDirectory() as folder:
        chart = Path(folder)/'chart.pdf'
        fig.savefig(chart)
        plt.close(fig)
        with fitz.open(chart) as base, fitz.open(FIGURES/'jaw_calibration_refinement_points.pdf') as strip:
            page = base[0]
            clip = fitz.Rect(33*72/25.4, 0, strip[0].rect.width, strip[0].rect.height)
            page.show_pdf_page(fitz.Rect(clip.x0, page.rect.height-clip.height, clip.x1, page.rect.height),
                               strip, 0, clip=clip)
            base.save(destination or FIGURES/f'{STEM}.pdf', garbage=4, deflate=True)
    if destination is None:
        with fitz.open(FIGURES/f'{STEM}.pdf') as document:
            document[0].get_pixmap(matrix=fitz.Matrix(2.7, 2.7)).save(FIGURES/f'{STEM}.png')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compose-only', action='store_true')
    args = parser.parse_args()
    guide = CervicalGuide()
    center, basis, tree, nodal, markers = stress_inputs()
    audit = REVIEW/f'{STEM}.json'
    result = json.loads(audit.read_text()) if args.compose_only else render(guide, center, basis, tree, nodal)
    compose(guide, markers)
    result.update(
        photographic_landmarks_px={key: points.tolist() for key, points in guide.points.items()},
        orientation='The root-up photograph reverses photo x for transverse trace coordinates.',
        photographic_apex_outer_root_rows_px=PHOTO_TIPS,
        guide_separation_mm=guide.separation,
        method='PCHIP of normalized photo traces. Normalized native x uses per-row frontal silhouette width, smoothed by a Gaussian of two raster pixels. Normalized y uses the apex-to-basal range. Curves extend through depth in the native local frame; the saved pose carries them onto the fitted tooth.',
        scope='Reproducible normalized display correspondence, with no calibrated photo–CT registration or tissue-interface assignment. Fixed/load markers use actual A3 face centroids. The table uses the original frozen FE regions.',
        stress_colour='Volume-weighted recovered A3 nodal stress, smoothly blended inverse-distance projection and bounded continuation. No field or solve input was changed.',
        inputs_sha256={x.name: sha(x) for x in (guide.image_path, guide.silhouette_path,
                                                POSE, old.VALIDATION/'local_A3/fields.npz')},
        figure_sha256=sha(FIGURES/f'{STEM}.pdf'))
    audit.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()
