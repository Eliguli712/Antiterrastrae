#!/usr/bin/env python3
"""Draw the fitted Figure 4 display guide in its registered model views."""
import json
from pathlib import Path
import re
import subprocess
from tempfile import TemporaryDirectory

import matplotlib.patheffects as effects
from matplotlib.colors import to_rgb
import meshio
import numpy as np
from PIL import Image, ImageDraw
import trimesh

import render_native_field_plates as native
import render_shared_cervical_figure as shared


FIT = native.NUMERICS / "annotated_cervical_trace.csv"
SOURCE = native.VALIDATION / "local_A3/fields.npz"
STEM = "field_qf_consistent_cervical"
GUIDE = "#211c20"
GUIDE_HALO = "#fcf4df"
LOAD = "#164e92"
FIXED = "#a32755"


def membership_masks(center, basis):
    """Raster unions of projected A3 triangles selected by the saved masks."""
    with np.load(SOURCE) as fine:
        vertices = (fine["points_m"] * 1000 - center) @ basis
        faces = fine["boundary_faces"]
        fixed = np.isin(faces, fine["fixed_nodes"]).all(axis=1)
        footprints = (faces[fine["loaded_faces"]], faces[fixed])
    assert not np.intersect1d(footprints[0].ravel(), footprints[1].ravel()).size
    projected = native.tooth_view(vertices)[:, :2]
    masks = []
    for faceset in footprints:
        mask = Image.new("1", (shared.WIDTH, shared.HEIGHT))
        draw = ImageDraw.Draw(mask)
        for points in projected[faceset]:
            draw.polygon(tuple(map(tuple, points)), fill=1)
        masks.append(np.asarray(mask))
    assert all(mask.any() for mask in masks)
    return masks, [len(faceset) for faceset in footprints]


def guide_ink(local, rgb, trace):
    x, y = local[:, :2].T
    distance = np.abs(y - np.interp(x, trace[:, 0], trace[:, 1]))
    at_ends = np.minimum(x - trace[0, 0], trace[-1, 0] - x)
    clip = shared.smoothstep(at_ends / .14)
    # Widths are in the registered longitudinal coordinate. Interpolate the
    # line's two edges to avoid the rendering quantisation of voxel stair steps.
    halo = (clip * (1 - shared.smoothstep((distance - .26) / .19)))[:, None]
    dark = (clip * (1 - shared.smoothstep((distance - .14) / .14)))[:, None]
    coated = rgb + halo * (to_rgb(GUIDE_HALO) - rgb)
    return coated + dark * (to_rgb(GUIDE) - coated)


def render_native_guide(guide, center, basis, trace, ink=guide_ink):
    count = native.TOOTH_VERTICES
    vertices = np.memmap(native.CACHE / "vertices.f64", "<f8", mode="r", shape=(count, 3))
    faces = np.memmap(native.CACHE / "triangles.u32", "<u4", mode="r", shape=(native.TOOTH_FACES, 3))
    normals = np.memmap(native.PROJECT / "output/scale_acrylic_2026-11-20/data/normals.f32",
                        "<f4", mode="r", shape=(count, 3))
    with np.load(shared.POSE) as pose:
        rotation = pose["reference_rotation"]
        rotation_center = pose["tooth_root_centre_m"] * 1000
        destination = pose["reference_location_m"] * 1000
    camera, look = shared.assembly_camera(destination)
    jaw = meshio.read(shared.JAW)
    jaw_faces = jaw.cells_dict["triangle"]
    assert len(jaw_faces) == 1_009_016
    jn = trimesh.Trimesh(jaw.points, jaw_faces, process=False).vertex_normals
    with TemporaryDirectory() as working:
        directory = Path(working)
        binary = directory / "raster"
        subprocess.run(["clang++", "-O3", "-std=c++17",
                        str(native.PAPER / "scripts/native_figure8_raster.cpp"), "-o", str(binary)],
                       check=True)
        with subprocess.Popen([str(binary), working], stdin=subprocess.PIPE,
                              stderr=subprocess.PIPE) as renderer:
            for start in range(0, len(jaw_faces), 250_000):
                group = jaw_faces[start:start+250_000]
                ids, indices = np.unique(group, return_inverse=True)
                shade = .56 + .44 * np.clip(jn[ids] @ (-look), 0, 1)
                rgb = shade[:, None] * np.array([.78, .72, .61])
                native.send(renderer, 1, camera(jaw.points[ids]), rgb, indices.reshape(-1, 3))
            for start in range(0, len(faces), 630_000):
                group = faces[start:start+630_000]
                ids, indices = np.unique(group, return_inverse=True)
                indices = indices.reshape(-1, 3)
                xyz, normal = vertices[ids], normals[ids]
                local = (xyz-center) @ basis
                rgb = guide.paint(local)
                shade = .69 + .31 * np.clip((normal @ basis @ native.OBLIQUE)[:, 2], 0, 1)
                native.send(renderer, 0, native.tooth_view(local, oblique=True),
                            ink(local, rgb * shade[:, None], trace), indices)
                shade = .75 + .25 * np.clip((normal @ rotation.T) @ (-look), 0, 1)
                world = (xyz-rotation_center) @ rotation.T + destination
                native.send(renderer, 1, camera(world), ink(local, rgb * shade[:, None], trace),
                            indices)
            renderer.stdin.close()
            log = renderer.stderr.read().decode()
            assert renderer.wait() == 0, log
            counts = list(map(int, re.findall(r"triangles submitted (\d+)", log)))
            assert counts == [len(faces), len(faces)+len(jaw_faces), 0], log
        images = {name: Image.frombytes("RGBA", (shared.WIDTH, shared.HEIGHT),
                                      (directory / f"native_figure8_{i}.rgba").read_bytes())
                  for i, name in enumerate(("oblique", "jaw"))}
    return images, counts


def main():
    with np.load(native.BASELINE / "L0/solution.npz") as baseline:
        center, basis = baseline["center_m"] * 1000, baseline["basis"]
    trace = np.loadtxt(FIT, delimiter=",", skiprows=1)
    guide = shared.CervicalGuide()
    masks, counts = membership_masks(center, basis)
    assert np.all(np.diff(trace[:, 0]) > 0)
    images, rendered = render_native_guide(guide, center, basis, trace)
    scale = native.SCALE
    xx = (np.arange(shared.WIDTH) + .5 - 900) / scale
    yy = (748 - np.arange(shared.HEIGHT) - .5) / scale

    def foreground(axis, index):
        if index == 1:
            for mask, rgb in zip(masks, (LOAD, FIXED), strict=True):
                # Antialias the displayed pixel mask by drawing a vector level
                # contour at 0.5. Triangle membership is independent of ink.
                axis.contourf(xx, yy, mask, levels=[.5, 1.5], colors=[rgb], alpha=.26,
                              zorder=2.6)
                line = axis.contour(xx, yy, mask, levels=[.5], colors=[rgb], linewidths=.68,
                                    zorder=2.7)
                line.set_path_effects([effects.withStroke(linewidth=1.15, foreground="#fffaf0")])
        line, = axis.plot(*trace.T, c=GUIDE, lw=.92, zorder=4)
        line.set_path_effects([effects.withStroke(linewidth=1.6, foreground=GUIDE_HALO)])

    dest = native.FIGURES / f"{STEM}.pdf"
    for preview in (False, True):
        target = native.FIGURES / f"{STEM}_preview.pdf" if preview else dest
        shared.compose(guide, destination=target, images=images, foreground=foreground, preview=preview)
    (native.REVIEW / f"{STEM}.json").write_text(json.dumps({
        "front_guide": str(FIT.relative_to(native.PAPER)),
        "front_guide_mapping": "Calibrated black fit in the same transverse/longitudinal coordinates in b and c. Its depth-extruded display surface is drawn on the visible native model in d and with the original fitted jaw transform in e.",
        "photo": "The two independently digitised photographic observations are shown in a. They remain the coloured display-band limits and are distinct from the black frontal annotation.",
        "boundaries": "Panel b shows the exact archived loaded triangles and exterior triangles whose three nodes were fixed, projected normal to the frontal view. The 29 pixels/mm outline is a raster union over the projected triangles.",
        "projected_A3_face_counts": {"pressure": counts[0], "fixed": counts[1]},
        "native_raster_face_counts": {"oblique": rendered[0], "tooth_and_jaw": rendered[1]},
        "source_sha256": {"A3_field_read_only": shared.sha(SOURCE),
                          "black_trace": shared.sha(FIT),
                          "figure": shared.sha(dest)},
        "scope": "Display-guide rendering and annotations only. The A3 equivalent-stress image, fields, loads, clamps and six frozen summaries are inherited without recalculation.",
    }, indent=2) + "\n")
    print(f"Figure 4 rendered to {dest}", flush=True)


if __name__ == "__main__":
    main()
