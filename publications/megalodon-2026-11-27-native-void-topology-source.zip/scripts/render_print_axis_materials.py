"""Render the audited Print Axis manufacturing assemblies with display finishes."""
import hashlib, json, sys
from pathlib import Path

import numpy as np
import pyvista as pv
from PIL import Image, ImageDraw, ImageFont

source = Path(sys.argv[1])
meta = json.loads(Path(sys.argv[2]).read_text())
dest = Path(sys.argv[3])
dest.mkdir(exist_ok=True, parents=True)
pv.OFF_SCREEN = True
font = "/System/Library/Fonts/Supplemental/Georgia.ttf"

# An analytic studio environment supplies broad highlights on nickel and steel.
# This is display lighting on the manufacturing geometry.
u, v = np.meshgrid(np.linspace(-np.pi, np.pi, 512), np.linspace(0, np.pi, 256))
sky = np.full(u.shape+(3,), 27.0)
for azimuth, incline, width, strength, rgb in [
    (-1.8, .65, .32, 208, [1, .93, .82]),
    (.7, .95, .52, 143, [.77, .87, 1]),
    (2.34, 1.52, .25, 130, [1, 1, .98])
]:
    angle = np.arccos(np.clip(np.cos(v)*np.cos(incline)+np.sin(v)*np.sin(incline)*np.cos(u-azimuth),-1,1))
    sky += np.exp(-(angle / width)**4)[..., None]*strength*np.array(rgb)
env_file=source/"studio_environment.png"
Image.fromarray(np.uint8(np.clip(sky,0,255))).save(env_file)
environment=pv.read_texture(env_file)
environment.interpolate=True
environment.mipmap=True

def rgb(position, case):
    x, y, z = position.T
    # The upper seating mould and the lower support retain distinct base
    # colours. Contrast is strongest at the exterior mechanical junctions.
    side = np.maximum(abs(x),abs(y))/41
    center = np.exp(-1.8*side**2)
    metal = np.array([74,86,96])+center[:, None]*np.array([65,69,72])
    shade = .5+.5*np.sin(.162*x-.104*y+.075*z)*np.cos(.09*x+.155*y)
    fossil = np.array([37,33,31])+shade[:,None]*np.array([46,31,17])
    # The cap begins the distinct cast zone. Follow the assembly's vertical
    # shoulder and leave polished side spheres in the lower frame.
    shoulder = .0012*(x*x+y*y)
    seam = np.clip((z - (77 + shoulder))/3,0,1)
    seam=seam**2*(3-2*seam)
    return np.uint8(metal*(1-seam[:,None])+fossil*seam[:,None]), seam

for case in meta["cases"]:
    if case["part"]!="assembly":
        continue
    size=case["size_mm"]
    path=source/f"{size}.stl"
    assert hashlib.file_digest(path.open("rb"), "sha256").hexdigest()==case["exported_SHA256"]
    mesh=pv.read(path)
    assert mesh.n_cells==case["STL_export_triangle_count"]
    xyz=(mesh.points-np.array(case["placement_translation_mm"]))@np.array(case["rotation_matrix_column_vector"])
    colour, seam = rgb(xyz,case)
    panel=Image.new("RGB",(2100,1200),"#e9eff2")
    draw=ImageDraw.Draw(panel)
    for k, (label, positions, height) in enumerate([
        ("Upright",xyz,case["original_Z_height_mm"]),
        ("Minimum height",mesh.points,case["width_mm"])
    ]):
        parts=mesh.copy()
        positions=positions.copy()
        positions[:,2]-=positions[:,2].min()
        parts.points=positions
        parts["Finish"]=colour
        cast_cells=seam[parts.faces.reshape(-1,4)[:,1:]].mean(axis=1)>.6
        cast=parts.extract_cells(cast_cells).extract_surface(algorithm="dataset_surface")
        support=parts.extract_cells(~cast_cells).extract_surface(algorithm="dataset_surface")
        pl=pv.Plotter(off_screen=True,window_size=(1020,990))
        pl.set_background("#e9eff2")
        pl.set_environment_texture(environment)
        for surface,metalness,roughness in [(support,.73,.29),(cast,.04,.83)]:
            pl.add_mesh(surface,scalars="Finish",rgb=True,pbr=True,metallic=metalness,
                roughness=roughness,smooth_shading=True,show_scalar_bar=False)
        ctr=np.asarray(parts.center)
        extent=max(parts.length,140)
        pl.camera_position=[ctr+extent*np.array([.76,-1.8,.67]),ctr,(0,0,1)]
        pl.enable_parallel_projection()
        pl.camera.parallel_scale=extent*.4
        pl.enable_anti_aliasing("ssaa")
        image=pl.screenshot(return_img=True)
        pl.close()
        left=15+k*1050
        panel.paste(Image.fromarray(image),(left,120))
        draw.text((left+510,59),label,font=ImageFont.truetype(font,44),fill="#183542",anchor="mm")
        draw.text((left+510,1145),f"{height:.3f} mm build height",
                  font=ImageFont.truetype(font,37),fill="#183542",anchor="mm")
    panel.save(dest/f"{size}mm-assembly-materials.webp",quality=95,method=6)
    print(size,mesh.n_cells,flush=True)
