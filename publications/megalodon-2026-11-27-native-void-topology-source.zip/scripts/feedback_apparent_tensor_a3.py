#!/usr/bin/env python3
"""Paired A3 sensitivity to a finite-window apparent porous stiffness insertion."""
import json
from pathlib import Path
import sys

import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import cg

from coupled_ct_submodels import CT, OUT, BASE, ROOT, strain_to_stress, mises

VALID = ROOT/"output/publication_validation_2026-11-12"
SOURCE = VALID/"data/bilayer_A3_0p5mm/fields.npz"
sys.path.insert(0,str(VALID/"scripts"))
import elastic_diagnostics as elast
import pyamg


def kelvin():
    basis=np.zeros((6,3,3))
    for i in range(3):
        basis[i,i,i]=1.
    for row,(i,j) in enumerate(((1,2),(0,2),(0,1)),3):
        basis[row,i,j]=basis[row,j,i]=1/np.sqrt(2)
    return basis


def update(t,g,v,ids,basis,delta,shape):
    e = np.einsum("rij,eaj->erai",basis,g[ids]).reshape(len(ids),6,12)
    k = ((e.swapaxes(1,2)@delta@e)*v[ids,None,None])
    dof = (3*t[ids,:,None]+np.arange(3)).reshape(len(ids),12)
    i = np.broadcast_to(dof[:,:,None],k.shape).ravel()
    j = np.broadcast_to(dof[:,None,:],k.shape).ravel()
    return coo_matrix((k.ravel(),(i,j)),shape=shape).tocsr()


def q95(values, weights):
    s=values.argsort()
    cumulative=np.cumsum(weights[s],dtype=np.longdouble)
    return float(values[s[np.searchsorted(cumulative,.95*cumulative[-1])]])


def main():
    record=json.loads((OUT/"transition_apparent_tensor.json").read_text())
    assert record["status"]=="passed_six_affine_KUBC_tests"
    ct=CT()
    corner=(ct.origin+(np.asarray(record["crop_start_xyz"])-.5)*ct.pitch)/1000
    size=record["side_mm"]/1000
    with np.load(SOURCE) as a:
        p,t,force,fixed,lam,mu,parents=(a[k] for k in ("points_m","tets","force_N","fixed_nodes","lambda_Pa","mu_Pa","parent_L0"))
        initial=a["displacement_m"]
        center=p[t].mean(1)
        ids=np.flatnonzero((center>=corner).all(1)&(center<corner+size).all(1)&(a["material_tag"]==1))
    assert len(ids)>3
    g,v=elast.basis_data(p,t)
    basis=kelvin()
    # Core coefficients are identical on eligible elements.
    assert np.ptp(lam[ids])==0 and np.ptp(mu[ids])==0
    m=mu[ids[0]]
    l=lam[ids[0]]
    trace=np.r_[np.ones(3),np.zeros(3)]
    original=2*m*np.eye(6)+l*np.outer(trace,trace)
    filled=np.einsum("aij,bij->ab",basis,strain_to_stress(basis))*1e6
    porous=np.asarray(record["stiffness_MPa"])*1e6
    K=elast.assemble(p,t,g,v,lam,mu)
    free_mask=np.ones_like(force,dtype=bool)
    free_mask[fixed]=False
    free=np.flatnonzero(free_mask)
    Kf=K[free][:,free].tocsr()
    x=(p-p.mean(0))/np.ptp(p,axis=0).max()
    modes=np.zeros((len(p),3,6))
    modes[:,:,:3]=np.eye(3)
    for j,i in enumerate(np.eye(3)):
        modes[:,:,j+3]=np.cross(i,x)
    ml=pyamg.smoothed_aggregation_solver(Kf.tobsr(blocksize=(3,3)),
                                        B=modes.reshape(-1,6)[free],symmetry="symmetric")
    M=ml.aspreconditioner()
    stats={}
    u0=initial[free_mask]
    print(f"Applies matched stiffness updates to {len(ids)} core cells.",flush=True)
    with np.load(BASE/"region_masks.npz") as a:
        frozen={k:np.isin(parents,a[k]) for k in a.files}
    for name,c in (("filled_inclusion",filled),("porous_inclusion",porous)):
        correction=update(t,g,v,ids,basis,c-original,K.shape)
        operator=Kf+correction[free][:,free]
        sol,code=cg(operator,force[free_mask],x0=u0,M=M,rtol=2e-10,atol=0,maxiter=800)
        assert code==0
        u=np.zeros_like(force)
        u[free_mask]=sol
        u0=sol
        strain=np.einsum("eai,eaj->eij",u[t[:,1:]]-u[t[:,:1]],g[:,1:])
        strain=(strain+strain.swapaxes(1,2))*.5
        sig=2*mu[:,None,None]*strain+lam[:,None,None]*np.trace(strain,axis1=1,axis2=2)[:,None,None]*np.eye(3)
        sig[ids]=np.einsum("aij,ab,eb->eij",basis,c,np.einsum("bij,eij->eb",basis,strain[ids]))
        residual=np.linalg.norm((operator@sol)-force[free_mask])/np.linalg.norm(force[free_mask])
        readback=np.zeros_like(force)
        for j, e in enumerate(t.T):
            np.add.at(readback,e,np.einsum("eij,ej,e->ei",sig,g[:,j],v))
        error=np.linalg.norm((readback-force)[free_mask])/np.linalg.norm(force[free_mask])
        computed_energy=np.einsum("eij,eij,e->",sig,strain,v)
        energy_error=abs(computed_energy-np.sum(force*u))/abs(computed_energy)
        assert max(residual,error,energy_error)<2e-7
        vm=mises(sig)/1e6
        stats[name]=dict(residual=float(residual),independent_readback=float(error),energy_work_error=float(energy_error),
                         regional_Q95_MPa={k:q95(vm[r],v[r]) for k,r in frozen.items()},
                         inclusion_Q95_MPa=q95(vm[ids],v[ids]),inclusion_mean_strain=np.average(strain[ids],axis=0,weights=v[ids]).tolist())
        print(name,json.dumps(stats[name]),flush=True)
    summary=dict(status="passed",parent="A3 linear candidate bilayer pressure case",tetrahedra=len(t),displacement_dof=p.size,
                 modified_core_cells=len(ids),modified_volume_mm3=float(v[ids].sum()*1e9),
                 only_change="The same candidate core cells take either the matched solid or the finite-window porous Kelvin tensor.",
                 cases=stats,scope="Single selected local insertion and one feedback step. Biological materials, full-tooth homogenisation and full native porous mechanics remain unresolved.")
    (OUT/"a3_tensor_feedback.json").write_text(json.dumps(summary,indent=2)+"\n")


if __name__=="__main__":
    main()
