"""Split each enclosed CT contour into two equal-length geometric halves."""
import numpy as np
from scipy.ndimage import distance_transform_edt, map_coordinates
from skimage.measure import find_contours


def split_gap_boundaries(gap_mask, specimen_envelope, y_mm, z_mm, pitch_mm):
    """Use distance from the envelope to designate the inward half.

    Each candidate split is anchored at a polygon vertex or its antipode in
    arclength. Score both contiguous halves by mean envelope distance.
    This is a geometric label on one slice, without temporal assumptions.
    """
    distance = distance_transform_edt(specimen_envelope, sampling=pitch_mm)
    inward_paths, outward_paths, records = [], [], []
    for contour in find_contours(gap_mask, .5, fully_connected='high'):
        if not np.array_equal(contour[0], contour[-1]):
            raise ValueError('Expected a closed enclosed-gap contour')
        segment = np.linalg.norm(np.diff(contour, axis=0), axis=1)*pitch_mm
        assert (segment > 0).all()
        s = np.r_[0, np.cumsum(segment)]
        perimeter = s[-1]
        half = perimeter/2
        depth = map_coordinates(distance, contour.T, order=1, mode='nearest')
        # Append a second circuit so a half may cross the beginning of the contour.
        doubled_s = np.r_[s[:-1], s+perimeter]
        doubled_depth = np.r_[depth[:-1], depth]
        doubled_points = np.vstack((contour[:-1], contour))
        ds = np.diff(doubled_s)
        cumulative = np.r_[0, np.cumsum(ds*(doubled_depth[1:]+doubled_depth[:-1])/2)]

        def integral(position):
            j = np.clip(np.searchsorted(doubled_s, position, side='right')-1, 0, len(ds)-1)
            x = position-doubled_s[j]
            slope = (doubled_depth[j+1]-doubled_depth[j])/ds[j]
            return cumulative[j]+doubled_depth[j]*x+slope*x*x/2

        candidates = np.unique(np.r_[s[:-1], (s[:-1]-half) % perimeter])
        integral_half = integral(candidates+half)-integral(candidates)
        start = candidates[np.argmax(integral_half)]

        def arc(a, b):
            x = np.r_[a, doubled_s[(doubled_s > a) & (doubled_s < b)], b]
            rc = np.column_stack([np.interp(x, doubled_s, doubled_points[:, i]) for i in range(2)])
            return np.column_stack((y_mm[0]+pitch_mm*rc[:, 1], z_mm[0]+pitch_mm*rc[:, 0]))

        inward = arc(start, start+half)
        outward = arc(start+half, start+perimeter)
        lengths = np.array([np.linalg.norm(np.diff(p, axis=0), axis=1).sum() for p in (inward, outward)])
        np.testing.assert_allclose(lengths, half, atol=2e-12, rtol=1e-11)
        inward_mean = float(np.max(integral_half)/half)
        outward_mean = float((integral(perimeter)-np.max(integral_half))/half)
        assert inward_mean+1e-11 >= outward_mean
        inward_paths.append(inward)
        outward_paths.append(outward)
        records.append((perimeter, inward_mean, outward_mean))
    return inward_paths, outward_paths, np.asarray(records)


def pack_paths(paths):
    """Flat polyline coordinates and the offsets delimiting the individual arcs."""
    return np.concatenate(paths), np.r_[0, np.cumsum([len(p) for p in paths])]
