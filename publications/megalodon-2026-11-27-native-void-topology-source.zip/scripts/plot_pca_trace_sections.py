#!/usr/bin/env python3
"""Render the gallery's largest audited PCA sections for the manuscript."""
import argparse
import csv
import gzip
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from PIL import Image
import numpy as np

COLOURS = {"original": "#d52d37", "fine": "#147aca"}
SYMBOLS = {"original": "o", "fine": "s"}


def draw(ax, source, entry):
    stem = f"Native74_twocolour_PCA_axis_{entry['axis']}"
    mask = np.asarray(Image.open(source / f"{stem}_material.png").convert("L"))
    ny, nx = mask.shape
    scale = entry["pixels_per_mm"]
    u, v = entry["plot_center_uv_mm"]
    extent = (u - nx / (2 * scale), u + nx / (2 * scale),
              v - ny / (2 * scale), v + ny / (2 * scale))
    yy, xx = (mask > 127).nonzero()
    ax.imshow(mask, cmap="gray", vmin=0, vmax=267, extent=extent, interpolation="none")
    with gzip.open(source / f"{stem}_crossings.csv.gz", "rt") as stream:
        rows = [row for row in csv.DictReader(stream)
                if int(row["forward_frame_0based"]) == entry["max_frame"]]
    for name, colour in COLOURS.items():
        group = [row for row in rows if row["catalogue_group"] == name]
        assert len(group) == entry[f"max_{name}_crossings"]
        ax.scatter([float(r["u_mm"]) for r in group], [float(r["v_mm"]) for r in group],
                   s=8 if name == "original" else 5, facecolors="none", edgecolors=colour,
                   linewidths=.62, marker=SYMBOLS[name])
    ax.set(xlim=(extent[0] + xx.min() / scale - .8, extent[0] + (xx.max() + 1) / scale + .8),
           ylim=(extent[3] - (yy.max() + 1) / scale - .8, extent[3] - yy.min() / scale + .8),
           xlabel="$u$ (mm)", ylabel="$v$ (mm)")
    ax.set_title(f"PCA {entry['axis']}  •  frame {entry['max_frame'] + 1}/300",
                 fontsize=8.1, loc="left", pad=12)
    ax.text(.5, 1.025, f"{entry['max_area_mm2']:,.2f} mm²  ·  "
            f"{entry['max_original_crossings']}/{entry['max_fine_crossings']} crossings",
            transform=ax.transAxes, ha="center", fontsize=6.5)
    ax.tick_params(labelsize=6, length=2, pad=1.5)
    ax.xaxis.label.set_fontsize(6.2)
    ax.yaxis.label.set_fontsize(6.2)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("media_directory", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    audit = json.loads((args.media_directory / "oriented_pca_audit.json").read_text())
    fig, axes = plt.subplots(1, 3, figsize=(7.12, 1.85),
                             gridspec_kw={"width_ratios": [1, 1, 1.22]})
    fig.subplots_adjust(left=.065, right=.99, top=.80, bottom=.30, wspace=.34)
    for ax, entry in zip(axes, audit["axes"], strict=True):
        draw(ax, args.media_directory, entry)
    symbols = [Line2D([], [], marker=SYMBOLS[group], markeredgecolor=colour,
                      markerfacecolor="none", linestyle="none", markersize=4.8)
               for group, colour in COLOURS.items()]
    fig.legend(symbols, ["Original trace subset", "Fine-envelope extension"],
               loc="lower center", bbox_to_anchor=(.5, -.025), frameon=False, ncol=2, fontsize=7.2)
    fig.savefig(args.output, dpi=400)


if __name__ == "__main__":
    main()
