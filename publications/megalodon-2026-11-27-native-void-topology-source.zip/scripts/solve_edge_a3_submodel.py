#!/usr/bin/env python3
"""A3 tooth-only submodel of the margin-A oblique tied-jaw load case."""
import json
from pathlib import Path
import sys

import numpy as np
import pyvista as pv
from scipy.sparse.linalg import cg

PAPER = Path(__file__).resolve().parents[1]
PROJECT = PAPER.parents[2]
VALIDATION = PROJECT / "output/publication_validation_2026-11-12"
BASE = PROJECT / "output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0"
TRANSFER = PROJECT / "output/jaw_tooth_transfer_2026-11-22"
OUT = PAPER / "numerics/margin_a30_a3"
sys.path.insert(0, str(VALIDATION/"scripts"))
import elastic_diagnostics as elast
import pyamg


def face_integrals(tris):
    vector = np.cross(tris[:,1]-tris[:,0], tris[:,2]-tris[:,0])*.5
    area = np.linalg.norm(vector,axis=1)
    return area, area @ tris.mean(1)


def phase_traction(p, f, base, patch, direction):
    base_points, base_faces = base["points_m"],base["boundary_faces"]
    original = pv.PolyData(base_points,
        np.column_stack((np.full(len(base_faces),3),base_faces)).ravel())
    parents, closest = original.find_closest_cell(p[f].mean(1),return_closest_point=True)
    use = np.isin(parents,patch)
    f = f[use]
    old_tri = base_points[base_faces[patch]]
    new_tri = p[f]
    old_area, old_first = face_integrals(old_tri)
    new_area, new_first = face_integrals(new_tri)
    np.testing.assert_allclose(new_area.sum(),old_area.sum(),rtol=1e-10)
    np.testing.assert_allclose(new_first,old_first,rtol=1e-10)
    assert np.linalg.norm(closest[use]-new_tri.mean(1),axis=1).max()<1e-9
    # Check that every selected fine face is inside its actual L0 parent face.
    parent_tri = base_points[base_faces[parents[use]]]
    basis = parent_tri[:,1:] - parent_tri[:,:1]
    metric = basis @ basis.swapaxes(1,2)
    delta = new_tri - parent_tri[:,:1]
    local = np.linalg.solve(metric, (basis @ delta.swapaxes(1,2))).swapaxes(1,2)
    np.testing.assert_allclose(local @ basis,delta,atol=1e-9,rtol=0)
    assert local.min()>-1e-7 and local.sum(axis=-1).max()<1+1e-7
    field = np.zeros_like(p)
    for corner in f.T:
        np.add.at(field, corner, new_area[:,None]*direction/(3*new_area.sum()))
    np.testing.assert_allclose(field.sum(0),direction,atol=1e-12)
    np.testing.assert_allclose(np.cross(p,field).sum(0),
                               np.cross(old_first/old_area.sum(),direction),atol=1e-12)
    return field, len(f), float(new_area.sum()*1e6)


def main():
    OUT.mkdir(exist_ok=True)
    base = np.load(BASE/"solution.npz")
    a = np.load(VALIDATION/"data/local_A3/fields.npz")
    reg = np.load(TRANSFER/"data_v3/registration.npz")
    archived = json.loads((TRANSFER/"edge_data/results.json").read_text())
    case = next(r for r in archived["cases"] if r["name"]=="RA_pose0_oblique30_tied")
    patch = np.load(TRANSFER/"edge_data/unit_response_basis.npz")["patch_face_ids_RA"]
    p,t,f,fixed = (a[k] for k in ("points_m","tets","boundary_faces","fixed_nodes"))
    force, nfaces, area = phase_traction(p,f,base,patch,np.array(case["direction_body"]))
    center, basis = base["center_m"],base["basis"]
    classification = ((p[fixed]-center)@basis[:,0]>=0).astype(int)
    root = np.array(case["root_generalised_displacement_m"]).reshape(2,6)[classification]
    radius = p[fixed]-reg["root_centres_tooth_m"][classification]
    u = np.zeros_like(p)
    u[fixed] = root[:,:3] + np.cross(root[:,3:]/float(reg["rotation_length_m"]),radius)
    g,v = elast.basis_data(p,t)
    lam,mu = a["lambda_Pa"],a["mu_Pa"]
    matrix = elast.assemble(p,t,g,v,lam,mu)
    free_mask = np.ones_like(p,dtype=bool)
    free_mask[fixed] = False
    free = np.flatnonzero(free_mask)
    ag = matrix[free][:,free].tocsr()
    rhs = (force.ravel()-matrix@u.ravel())[free]
    x = (p-p.mean(0)) / np.ptp(p,axis=0).max()
    modes = np.zeros((len(p),3,6))
    modes[:,:,:3] = np.eye(3)
    for i,axis in enumerate(np.eye(3)):
        modes[:,:,3+i] = np.cross(axis,x)
    print("AMG",ag.shape,ag.nnz,flush=True)
    hierarchy = pyamg.smoothed_aggregation_solver(ag.tobsr(blocksize=(3,3)),
                        B=modes.reshape(-1,6)[free],symmetry="symmetric")
    sol,code = cg(ag,rhs,M=hierarchy.aspreconditioner(),rtol=2e-13,maxiter=2400)
    assert code==0,code
    u[free_mask] = sol
    del ag, hierarchy
    grad = np.einsum("eai,eaj->eij",u[t[:,1:]]-u[t[:,:1]],g[:,1:])
    strain = (grad+grad.swapaxes(1,2))/2
    stress = 2*mu[:,None,None]*strain+lam[:,None,None]*np.trace(strain,axis1=1,axis2=2)[:,None,None]*np.eye(3)
    tension = np.maximum(np.linalg.eigvalsh(stress)[:,-1],0)
    internal = np.zeros_like(p)
    for j,indices in enumerate(t.T):
        np.add.at(internal,indices,np.einsum("eij,ej,e->ei",stress,g[:,j],v))
    reaction = internal-force
    direct = (matrix@u.ravel()).reshape(-1,3)-force
    np.testing.assert_allclose(direct,reaction,atol=2e-8,rtol=1e-8)
    residual = float(np.linalg.norm(reaction[free_mask])/np.linalg.norm(rhs))
    external = force.copy()
    external[fixed] += reaction[fixed]
    force_defect = float(np.linalg.norm(external.sum(0)))
    moment_defect = float(np.linalg.norm(np.cross(p,external).sum(0)))
    energy_error = float(abs(np.einsum("ij,ij->",u,internal-external) /
                             np.einsum("ij,ij->",u,internal)))
    print(residual,force_defect,moment_defect,energy_error,flush=True)
    # The original coupled unit-margin benchmark uses 2e-5 for work/energy.
    # Distinct absolute force and moment tests also guard the prescribed-root solve.
    assert max(residual,force_defect,moment_defect)<1e-6 and energy_error<2e-5
    records = {}
    with np.load(BASE/"region_masks.npz") as masks:
        parents = a["parent_L0"]
        for key in masks.files:
            idx = np.flatnonzero(np.isin(parents,masks[key]))
            idx = idx[tension[idx].argsort()]
            c = np.cumsum(v[idx],dtype=np.longdouble)
            records[key] = float(tension[idx[np.searchsorted(c,.95*c[-1])]]/1e6)
    np.savez_compressed(OUT/"field.npz",points_m=p,tets=t,boundary_faces=f,
                        volumes_m3=v,tension_Pa_per_N=tension,displacement_m=u,
                        force_N=force,fixed_nodes=fixed)
    result = dict(status="passed", case=case["name"], model="Prescribed-root A3 submodel",
                  total_dof=p.size,free_dof=len(free),tetrahedra=len(t),
                  faces=nfaces,patch_area_mm2=area,root_kinematics_generalised=case["root_generalised_displacement_m"],
                  force_error_N=force_defect,moment_error_N_m=moment_defect,readback=residual,
                  energy_work_error=energy_error,tensile_Q95_MPa_per_N=records,
                  scope="Exact load patch transfer. Root motions from coupled L0; no fine-mesh reaction feedback into jaw.")
    (OUT/"results.json").write_text(json.dumps(result,indent=2)+"\n")
    print(json.dumps(result),flush=True)


if __name__=="__main__":
    main()
