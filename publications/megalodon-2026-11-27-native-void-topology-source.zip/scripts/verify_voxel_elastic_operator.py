#!/usr/bin/env python3
"""Independent explicit-connectivity check of the matrix-free voxel kernel."""
import json
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import spsolve

from coupled_ct_submodels import (
    OFFSETS, OUT, compile_operator, shape_gradient, solve_mask, stiffness,
    strain_to_stress,
)


def main():
    OUT.mkdir(exist_ok=True)
    kernel = compile_operator()
    n = 8
    mask = np.ones((n-1,)*3, dtype=bool)
    mask[2:4, 3, 3] = False
    kel, _ = stiffness()
    # Build a conventional sparse element matrix from explicit connectivity.
    grid = np.arange(n**3).reshape((n,)*3)
    vertices = np.argwhere(mask)[:,None]+OFFSETS
    conn = grid[tuple(vertices.transpose(2,0,1))]
    dofs = (3*conn[:,:,None]+np.arange(3)).reshape(-1,24)
    rows = np.broadcast_to(dofs[:,:,None],(len(dofs),24,24))
    cols = np.broadcast_to(dofs[:,None,:],rows.shape)
    vals = np.broadcast_to(kel,rows.shape)
    K = coo_matrix((vals.ravel(), (rows.ravel(), cols.ravel())),
                   shape=(3*n**3,)*2).tocsr()
    rng = np.random.default_rng(712)
    sample = rng.standard_normal((n,n,n,3))
    interior = np.zeros((n,n,n,3), dtype=bool)
    interior[1:-1, 1:-1, 1:-1] = True
    explicit = (K@sample.ravel()).reshape(sample.shape)[interior]
    kel, stencil = stiffness()
    missing = (np.argwhere(~mask)@np.array([n*n,n,1])).astype(np.int32)
    actual = np.empty_like(sample)
    kernel(n,sample,actual,stencil,kel,missing,len(missing),2,True)
    error = np.linalg.norm(actual[interior]-explicit)/np.linalg.norm(explicit)
    assert error < 1e-13
    grad = np.array([[2e-4,1e-5,1e-6],[0.,-1e-5,2e-6],[1e-6,4e-5,8e-5]])
    xyz = np.indices((n,n,n))[::-1].transpose(1,2,3,0)
    affine = ((xyz-(n-1)/2)@grad.T).ravel()
    free = np.flatnonzero(interior)
    explicit_u = affine.copy()
    explicit_u[free] -= spsolve(K[free][:,free],(K@affine)[free])
    matrix_free,_,checks = solve_mask(mask,grad,kernel,2)
    displacement_error = np.linalg.norm(matrix_free.ravel()-explicit_u) / np.linalg.norm(explicit_u)
    assert displacement_error < 1e-7
    readback = matrix_free.reshape(-1,3)[conn].swapaxes(1,2)@shape_gradient([.5,.5,.5])
    assert np.isfinite(strain_to_stress(readback)).all()
    record=dict(status="passed",explicit_element_operator_relative_error=error,
                explicit_displacement_relative_error=displacement_error,checks=checks)
    (OUT/"operator_check.json").write_text(json.dumps(record,indent=2)+"\n")
    print(json.dumps(record,indent=2))


if __name__=="__main__":
    main()
