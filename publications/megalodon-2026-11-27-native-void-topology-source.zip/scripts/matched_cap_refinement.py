#!/usr/bin/env python3
"""Cross fixed cap depths with P1 mesh resolution on one tooth proxy."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import platform
import sys
from time import monotonic
import numpy as np
from scipy.sparse.linalg import cg

PAPER = Path(__file__).resolve().parents[1]
PROJECT = PAPER.parents[2]
VALIDATION = PROJECT / "output/publication_validation_2026-11-12"
sys.path.insert(0, str(VALIDATION / "scripts"))
import elastic_diagnostics as fe

DEPTHS = (0.03, 0.04, 0.05)
LAM, MU = 29e9, 28.5e9
PRESSURE = 1e6


def file_sha256(path):
    with path.open("rb") as reader:
        return hashlib.file_digest(reader, "sha256").hexdigest()


def compare_cases(results):
    index = {(r["mesh"], r["cap_depth"]): r for r in results}
    meshes = sorted({r["mesh"] for r in results})
    rows = []
    for region in fe.core.REGIONS:
        j = {mesh: {depth: index[mesh, depth]["regions"][region]["von_mises_Q95_MPa"]
                    for depth in DEPTHS} for mesh in meshes}
        row = {
            "region": region,
            "Q95_MPa": j,
            "within_mesh_support_change_percent": {
                m: {str(d): 100 * (j[m][d] / j[m][0.04] - 1)
                    for d in (0.03, 0.05)} for m in meshes},
            "fixed_rule_mesh_change_percent": {},
            "additive_interaction_MPa": {},
        }
        for coarse, fine in zip(meshes, meshes[1:]):
            label = f"{coarse}_to_{fine}"
            row["fixed_rule_mesh_change_percent"][label] = {
                str(d): 100 * (j[fine][d] / j[coarse][d] - 1) for d in DEPTHS
            }
            row["additive_interaction_MPa"][label] = {
                str(d): (j[fine][d] - j[fine][0.04]) - (j[coarse][d] - j[coarse][0.04])
                for d in (0.03, 0.05)
            }
        rows.append(row)
    return rows


def readback(p, t, g, volume, u):
    stress = np.empty((len(t), 3, 3))
    internal = np.zeros_like(p)
    strain_energy = 0.
    for start in range(0, len(t), 20000):
        sl = slice(start, start+20000)
        c = t[sl]
        grad = np.einsum("eai,eaj->eij", u[c[:,1:]]-u[c[:,:1]], g[sl,1:])
        strain = (grad + grad.transpose(0, 2, 1)) / 2
        sigma = (LAM * np.trace(strain, axis1=1, axis2=2)[:,None,None] * np.eye(3)
                 + 2 * MU * strain)
        stress[sl] = sigma
        strain_energy += 0.5 * np.einsum("eij,eij,e->", stress[sl], strain, volume[sl])
        forces = np.einsum("eij,eaj,e->eai", sigma, g[sl], volume[sl])
        for a in range(4):
            np.add.at(internal, c[:,a], forces[:,a])
    return stress, internal, strain_energy


def solve_mesh(mesh, parent_reference, archived_l0):
    input_path = fe.B/f"numerics/{mesh}/solution.npz"
    with np.load(input_path) as obj:
        p, t = obj["points_m"], obj["tets"]
        archived_nodes = obj["fixed_node_indices"]
        archived_loaded_faces = obj["loaded_face_indices"]
    t = t.astype(np.int32, copy=False)
    data = fe.fixed_experiment(p, t)
    np.testing.assert_array_equal(np.flatnonzero(data["fixed"]), archived_nodes)
    np.testing.assert_array_equal(np.flatnonzero(data["loaded"]), archived_loaded_faces)
    force = data["force"]
    area = float(data["areas"][data["loaded"]].sum() * 1e6)
    resultant = force.sum(axis=0)
    moment = np.cross(p, force).sum(axis=0)
    np.testing.assert_allclose(area, parent_reference["loaded_area_mm2"], atol=1e-7, rtol=0)
    np.testing.assert_allclose(resultant, parent_reference["load_resultant_N"], atol=2e-8, rtol=0)
    np.testing.assert_allclose(moment, parent_reference["load_moment_Nm"], atol=1e-9, rtol=0)
    q = (p-data["center"]) @ data["basis"]
    bq = parent_reference["q"]
    bpos = bq[:,0] >= 0
    ns, _, _ = fe.core.geometric_coordinates(q, data["surface_q"])
    base_s, _, _ = fe.core.geometric_coordinates(bq, data["surface_q"])
    smax = np.where(q[:,0] >= 0, base_s[bpos].max(), base_s[~bpos].max())
    g, volume = fe.basis_data(p, t)
    masks = data["masks"]
    region_volume = {r: volume[mask].sum() for r, mask in masks.items()}
    for r, v in region_volume.items():
        np.testing.assert_allclose(v, parent_reference["region_volume_m3"][r], rtol=2e-10, atol=1e-16)
    K = fe.assemble(p, t, g, volume, np.full(len(t), LAM), np.full(len(t), MU))
    print(f"{mesh} assembled {len(t):,} cells and {K.nnz:,} nonzeros", flush=True)

    extent = np.ptp(p, axis=0).max()
    normalized = (p - p.mean(axis=0)) / extent
    modes = np.zeros((len(p), 3, 6))
    modes[:,:,:3] = np.eye(3)
    for direction, axis in enumerate(np.eye(3)):
        modes[:,:,3 + direction] = np.cross(axis, normalized)
    total_dof = p.size
    results = []
    for depth in DEPTHS:
        start = monotonic()
        cap = (ns >= .8) & (ns >= smax-depth)
        if depth == .04:
            np.testing.assert_array_equal(cap, data["fixed"])
        free = np.repeat(~cap, 3)
        reduced = K[free,:][:,free].tocsr()
        rhs = force.ravel()[free]
        np.random.seed(20261127)
        amg = fe.pyamg.smoothed_aggregation_solver(
            reduced.tobsr(blocksize=(3,3)), B=modes.reshape(-1,6)[free],
            symmetry="symmetric", max_levels=12, max_coarse=250,
            presmoother=("block_gauss_seidel", {"sweep":"symmetric"}),
            postsmoother=("block_gauss_seidel", {"sweep":"symmetric"}),
        )
        iterations = []
        uf, info = cg(reduced, rhs, M=amg.aspreconditioner(), rtol=2e-10,
                      atol=0, maxiter=2000, callback=lambda _: iterations.append(1))
        if info:
            raise RuntimeError(f"{mesh} cap={depth} CG failed, info {info}")
        relres = np.linalg.norm(reduced @ uf - rhs) / np.linalg.norm(rhs)
        del reduced, amg
        u = np.zeros(total_dof)
        u[free] = uf
        u = u.reshape(-1, 3)
        sigma, internal, energy = readback(p, t, g, volume, u)
        readback_residual = (internal - force).ravel()
        readback_error = np.linalg.norm(readback_residual[free]) / np.linalg.norm(rhs)
        reaction = readback_residual.reshape(-1,3)[cap]
        balance = np.linalg.norm(resultant + reaction.sum(axis=0)) / np.linalg.norm(resultant)
        moment_error = np.linalg.norm(moment + np.cross(p[cap], reaction).sum(axis=0)) / (np.linalg.norm(resultant) * extent)
        work = float(np.einsum("ij,ij->", u, force))
        work_error = abs(2*energy-work)/abs(work)
        checks = dict(linear_free_residual=float(relres), stress_readback_free_residual=float(readback_error),
                      force_balance=float(balance), moment_balance=float(moment_error), work_energy=float(work_error))
        if max(checks.values()) > 2e-7:
            raise RuntimeError(f"{mesh} cap={depth}: failed discrete balance checks {checks}")
        dev = sigma - np.trace(sigma, axis1=1, axis2=2)[:,None,None]*np.eye(3)/3
        vm = np.sqrt(1.5*np.einsum("eij,eij->e",dev,dev))/1e6
        tensile = np.maximum(np.linalg.eigvalsh(sigma)[:,-1], 0)/1e6
        regions = {}
        for r, keep in masks.items():
            q95 = float(fe.core.volume_quantiles(vm[keep],volume[keep])[1])
            regions[r] = {"von_mises_Q95_MPa": q95,
                          "principal_tension_Q95_MPa": float(fe.core.volume_quantiles(tensile[keep],volume[keep])[1])}
            if mesh == "L0":
                np.testing.assert_allclose(q95, archived_l0[depth,r], atol=2e-5, rtol=1e-7)
        results.append({
            "mesh": mesh, "cap_depth": depth, "cells": len(t),
            "fixed_nodes": int(np.count_nonzero(cap)), "free_dofs": int(np.count_nonzero(free)),
            "cg_iterations": len(iterations), "strain_energy_J": float(energy),
            "max_displacement_mm": float(np.linalg.norm(u, axis=1).max()*1e3),
            "loaded_area_mm2": area, "resultant_N": resultant.tolist(),
            "rootward_span_mm": float(np.ptp(data["surface_q"][:,1])*1e3),
            "regions": regions, "checks": checks, "solve_seconds": monotonic()-start,
        })
        print(f"{mesh} depth={depth:.2f}: root {regions['Rroot']['von_mises_Q95_MPa']:.6f} MPa; "
              f"max readback discrepancy {max(checks.values()):.3g}", flush=True)
        del sigma, vm, dev, tensile, internal
    return results, input_path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--meshes", nargs="+", choices=("L0","L1","L2"), default=("L0","L1"))
    parser.add_argument("--output", type=Path, required=True)
    options = parser.parse_args()
    start = monotonic()
    base_path = fe.B/"numerics/L0/solution.npz"
    mask_path = fe.B/"numerics/L0/region_masks.npz"
    sweep_path = fe.B/"numerics/sensitivity/cases.csv"
    with np.load(base_path) as base, np.load(mask_path) as masks:
        p, t = base["points_m"], base["tets"]
        data = fe.fixed_experiment(p, t)
        _, v = fe.basis_data(p, t)
        parent = {
            "q": (p-data["center"]) @ data["basis"],
            "loaded_area_mm2": data["areas"][data["loaded"]].sum()*1e6,
            "load_resultant_N": data["force"].sum(0),
            "load_moment_Nm": np.cross(p,data["force"]).sum(0),
            "region_volume_m3": {r: v[masks[r]].sum() for r in fe.core.REGIONS},
        }
    ids = {"capdepth_0.03": .03, "bilateral_+0": .04, "capdepth_0.05": .05}
    with sweep_path.open(newline="") as reader:
        reference = {(ids[row["case"]], row["region"]): float(row["Q95_MPa"])
                     for row in csv.DictReader(reader) if row["case"] in ids}
    cases, inputs = [], [base_path, mask_path, sweep_path]
    for mesh in sorted(set(options.meshes)):
        results, source = solve_mesh(mesh, parent, reference)
        cases.extend(results)
        inputs.append(source)
        report = {
            "status": "passed",
            "experiment": "Cross P1 refinement with the geometric bilateral cap-depth rule on the same calibrated tooth proxy and L0 region unions",
            "scope": "Conditional finite contrasts. Re-evaluating the nodal cap rule on refined meshes changes the represented Dirichlet set. No continuum error bound or calibrated anatomical attachment.",
            "lambda_Pa": LAM, "mu_Pa": MU, "normal_pressure_Pa": PRESSURE,
            "runtime_seconds": monotonic()-start,
            "software": {"python":sys.version.split()[0], "numpy":np.__version__, "pyamg":fe.pyamg.__version__},
            "host": platform.platform(),
            "input_sha256": {str(path.relative_to(PROJECT)):file_sha256(path) for path in sorted(set(inputs))},
            "cases": cases, "contrasts": compare_cases(cases),
        }
        options.output.parent.mkdir(parents=True, exist_ok=True)
        tmp = options.output.with_suffix(".tmp")
        tmp.write_text(json.dumps(report, indent=2)+"\n")
        tmp.replace(options.output)


if __name__ == "__main__":
    main()
