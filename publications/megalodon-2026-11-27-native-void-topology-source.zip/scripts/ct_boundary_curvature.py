"""Balance native mask boundaries by arc length, placing red at curvature tails."""

import numpy as np
from scipy.ndimage import gaussian_filter1d
from skimage.measure import find_contours


PITCH_MM = 0.018
CURVATURE_SIGMA_MM = 0.036
CURVATURE_TAIL_QUANTILE = 0.95
MIN_DIAGONAL_MM = 0.35
MIN_AREA_MM2 = 0.004


def signed_area(points):
    return 0.5 * (points[:-1, 0] @ points[1:, 1] - points[1:, 0] @ points[:-1, 1])


def split_at_curvature_tail(points):
    """Split a closed polyline at the maximum tail-weight semicircuit."""
    distance = np.r_[0., np.cumsum(np.linalg.norm(np.diff(points, axis=0), axis=1))]
    perimeter = distance[-1]
    half = perimeter / 2
    count = 2 * int(np.ceil(half / PITCH_MM))
    pitch = perimeter / count
    sample_distance = np.arange(count) * pitch

    def sample(s, distances, contour):
        return np.column_stack([np.interp(s, distances, column) for column in contour.T])

    sampled = sample(sample_distance, distance, points)
    sigma = CURVATURE_SIGMA_MM / pitch
    tangent = gaussian_filter1d(sampled, sigma, order=1, axis=0, mode='wrap') / pitch
    second = gaussian_filter1d(sampled, sigma, order=2, axis=0, mode='wrap') / pitch**2
    numerator = np.abs(tangent[:, 0] * second[:, 1] - tangent[:, 1] * second[:, 0])
    curvature = numerator / np.maximum(np.linalg.norm(tangent, axis=1)**3, 1e-12)
    tail_threshold = float(np.quantile(curvature, CURVATURE_TAIL_QUANTILE))
    excess = np.maximum(0., curvature - tail_threshold)
    cumulative = np.r_[0., np.cumsum(np.tile(excess, 2))]
    red_index = int(np.argmax(cumulative[count//2:count//2+count] - cumulative[:count]))
    start = sample_distance[red_index]
    doubled_s = np.r_[distance[:-1], distance + perimeter]
    doubled_points = np.vstack((points[:-1], points))

    def arc(a, b):
        positions = np.r_[a, doubled_s[(doubled_s > a) & (doubled_s < b)], b]
        return sample(positions, doubled_s, doubled_points)

    red, blue = arc(start, start + half), arc(start + half, start + perimeter)
    red_length, blue_length = [float(np.linalg.norm(np.diff(a, axis=0), axis=1).sum()) for a in (red, blue)]
    np.testing.assert_allclose((red_length, blue_length), half, rtol=1e-11, atol=2e-12)
    red_tail = float(np.roll(excess, -red_index)[:count//2].sum())
    return red, blue, dict(
        perimeter_mm=float(perimeter), red_length_mm=red_length, blue_length_mm=blue_length,
        curvature_samples=count, curvature_tail_threshold_mm_inv=tail_threshold,
        red_tail_weight_fraction=red_tail / float(excess.sum()) if excess.any() else None,
    )


def section_arcs(specimen, envelope, origin_mm):
    """Trace the main section silhouette and display-resolvable enclosed gaps."""
    exterior = find_contours(np.pad(envelope, 1), .5, fully_connected='high')
    internal = find_contours(np.pad(envelope & ~specimen, 1), .5, fully_connected='low')
    outlines = [('silhouette', max(exterior, key=lambda a: abs(signed_area(a))))]
    outlines.extend(('enclosed section gap', path) for path in internal)
    arcs = []
    for kind, path in outlines:
        points = (path[:, ::-1] - 1) * PITCH_MM + origin_mm
        if not np.array_equal(points[0], points[-1]):
            raise ValueError('Expected a closed boundary after padding the section')
        diagonal = float(np.linalg.norm(np.ptp(points, axis=0)))
        area = float(abs(signed_area(points)))
        if kind != 'silhouette' and (diagonal < MIN_DIAGONAL_MM or area < MIN_AREA_MM2):
            continue
        red, blue, metrics = split_at_curvature_tail(points)
        arcs.append((red, blue, dict(kind=kind, diagonal_mm=diagonal, area_mm2=area, **metrics)))
    return arcs
