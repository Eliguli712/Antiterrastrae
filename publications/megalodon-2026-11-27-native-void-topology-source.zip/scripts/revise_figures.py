#!/usr/bin/env python3
"""Publication plates from recorded photographs, archived views and numerical arrays.

Only presentation changes occur here. No stress solution, CT voxel or source
photograph is modified. All SVG text remains editable (raster source images are
embedded). Camera-specific COMSOL JPEGs retain their native pixels and legends.
"""
from pathlib import Path
import hashlib, json, re, shutil, os
import numpy as np
from PIL import Image
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, LogNorm, FuncNorm
from matplotlib.collections import PolyCollection
from matplotlib.patches import PathPatch, Polygon
from matplotlib.path import Path as MPath
from matplotlib.ticker import LogLocator, NullFormatter

R=Path(__file__).resolve().parents[1]
P=Path(os.environ.get('FEA_MEG_ROOT',str(R.parents[2])))
F=R/'figures'; V=R/'svg'; REVIEW=R/'review'
B=R.parent/'debunk_myth_full_reconstruction_2026-10-31'
if not B.exists():B=R/'supporting_baseline'
MM=1/25.4
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],
    'font.size':6.5,'axes.labelsize':6.5,'axes.titlesize':7,
    'xtick.labelsize':6,'ytick.labelsize':6,'legend.fontsize':6,
    'axes.linewidth':.55,'lines.linewidth':.7,'xtick.major.width':.5,
    'ytick.major.width':.5,'xtick.major.size':2,'ytick.major.size':2,
    'axes.spines.top':False,'axes.spines.right':False,
    'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
INK='#193d4c'; BLUE='#287eab'; ORANGE='#c27629'; RED='#ba433c'
REGIONS=['R0','RA','RB','Rtip','Rcr','Rroot']
LABELS=[r'$R_0$',r'$R_A$',r'$R_B$',r'$R_{\rm tip}$',r'$R_{\rm cr}$',r'$R_{\rm root}$']
COLORS=['#109b99','#435a9c','#6ab645','#db4545','#a365b2','#dda00d']

def canvas(w,h):
    fig=plt.figure(figsize=(w*MM,h*MM),facecolor='white')
    fig._mm=(w,h)
    return fig

def axmm(fig,x,y,w,h):
    fw,fh=fig._mm
    return fig.add_axes([x/fw,y/fh,w/fw,h/fh])

def txt(fig,x,y,s,size=6.5,**kw):
    fw,fh=fig._mm
    return fig.text(x/fw,y/fh,s,fontsize=size,**kw)

def panel(fig,x,y,s):txt(fig,x,y,s,size=8,weight='bold',va='top')

def picture(ax,path):
    # PDF/SVG backends embed the native raster rather than an upsampled copy.
    ax.imshow(Image.open(path),interpolation='none');ax.set_axis_off()

def save(fig,name):
    # Fixed canvas, so stated physical dimensions and final point sizes agree.
    fig.savefig(F/(name+'.pdf'),dpi=600)
    fig.savefig(F/(name+'.png'),dpi=450)
    fig.savefig(V/(name+'.svg'),dpi=600)
    plt.close(fig)

landmarks={
 'a':{'apex':(527,205),'neck':[(302,653),(395,615),(479,574),(533,548),(578,563),(622,613),(649,673)],
      'defect':[(405,370),(420,390),(426,440),(410,490),(390,510),(373,490),(365,456)]},
 'b':{'apex':(612,225),'neck':[(230,910),(322,850),(450,765),(585,709),(690,734),(812,806),(929,899),(981,950)],
      'defect':[(293,600),(269,622),(257,661),(246,693)]}}
CROPS={'a':(146,183,722,976),'b':(79,191,1066,1321)}

def outline(ax,key,labels=True):
    # Recover the original image-derived path; no new segmentation is inferred.
    old=(V/f'photograph_outline_{key}.svg').read_text()
    d=re.search(r'<path d="([^"]+)"',old).group(1)
    poly=np.array([[float(a),float(b)] for a,b in re.findall(r'([\d.]+),([\d.]+)',d)])
    x0,y0,x1,y1=CROPS[key]; cw,ch=x1-x0,y1-y0
    scale=min(270/cw,350/ch);ox=25+(270-cw*scale)/2;oy=45
    def tr(coords):
        c=np.asarray(coords,float)
        return np.column_stack([ox+(c[:,0]-x0)*scale,oy+(c[:,1]-y0)*scale])
    neck=tr(landmarks[key]['neck']); defect=tr(landmarks[key]['defect'])
    apex=tr([landmarks[key]['apex']])[0]
    patch=Polygon(poly,closed=True,facecolor='#e5eef0',edgecolor=INK,linewidth=.65)
    ax.add_patch(patch)
    root=Polygon(np.vstack([neck,[[330,440],[-10,440]]]),closed=True,facecolor='#ddc7b1',edgecolor='none')
    root.set_clip_path(patch);ax.add_patch(root)
    ax.plot(neck[:,0],neck[:,1],ls=(0,(3,2)),c='#555555',lw=.7)
    ax.plot(defect[:,0],defect[:,1],ls=(0,(2,1)),c=RED,lw=1)
    ax.plot(*apex,marker='^',ms=3,mfc=INK,mec=INK,clip_on=False)
    if labels:
        ax.text(193,173,'Crown',ha='center',fontsize=5.8,color=INK)
        ax.text(172,330,'Root',ha='center',fontsize=5.8,color=INK)
        ax.annotate('Cusp',apex,xytext=(245,40),fontsize=5.6,ha='center',arrowprops=dict(arrowstyle='-',lw=.5,color=INK))
        target=defect[len(defect)//2]
        ax.annotate('Defect',target,xytext=(10,190),fontsize=5.6,color=RED,
                    arrowprops=dict(arrowstyle='-',lw=.5,color=RED))
    ax.set(xlim=(-10,330),ylim=(430,15),aspect='equal');ax.axis('off')

def figure1():
    # Specimen originals, appearance exports, photographic anatomy and notebook.
    fig=canvas(183,94)
    for i,(file,title) in enumerate([('specimen_photo_a_bordercrop.png','a  Photograph'),
                                     ('specimen_photo_b_bordercrop.png','b  Photograph'),
                                     ('intro_render_frame.png','c  Recovered frame')]):
        x=i*30.5
        picture(axmm(fig,x,47,29,43),F/file)
        txt(fig,x,92,title,6.5,va='top')
    for j,title in enumerate(['Front','Oblique','Reverse*']):
        x=96+j*29
        picture(axmm(fig,x,69,26,19),F/f'appearance_natural_{j}.png')
        picture(axmm(fig,x,46,26,19),F/f'appearance_reference_{j}.png')
        txt(fig,x+13,91,title,6.2,ha='center')
    txt(fig,94,66,'Natural appearance',5.8)
    txt(fig,94,43.5,'Reference colour (no stress field)   * inferred appearance',5.8)
    for i,key in enumerate(['a','b']):
        outline(axmm(fig,i*27,5,26,36),key)
        txt(fig,i*27+13,42,'d'+str(i+1)+'  Outline '+key,6.3,ha='center',va='top')
    for i in range(2):
        x=56+i*47
        picture(axmm(fig,x,12,46,24),F/f'notebook_delta_kappa{i+1}_dorsal_up.png')
        txt(fig,x+23,39,r'e'+str(i+1)+r'  Notebook $\Delta\kappa_'+str(i+1)+'$',6.4,ha='center')
    info=json.loads((REVIEW/'notebook_curvature_provenance.json').read_text())
    tau=info['display']['asinh_scale']; lim=info['display']['symmetric_99percent_limit']
    norm=FuncNorm((lambda v:np.arcsinh(v/tau),lambda v:tau*np.sinh(v)),vmin=-lim,vmax=lim)
    cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap='RdBu_r'),cax=axmm(fig,65,10,77,2.3),orientation='horizontal')
    cb.set_ticks([-3000,-100,0,100,3000]);cb.ax.tick_params(labelsize=5.5,pad=1)
    txt(fig,103,1.2,r'$\Delta\kappa$: inverse source units; asinh scale',5.6,ha='center')
    picture(axmm(fig,153,5,28,33),F/'jaw_geometry_constraint_reference.png')
    txt(fig,167,41,'f  Jaw reference',6.2,ha='center',va='top')
    save(fig,'geometry_pack_1_specimen')
    # Standalone fully editable outlines at a comfortable inspection size.
    for key in ['a','b']:
        fig=canvas(55,70);outline(axmm(fig,0,0,55,70),key)
        save(fig,f'photograph_outline_annotated_{key}')
    (REVIEW/'photographic_anatomy_annotations.json').write_text(json.dumps({
        'source_pixel_landmarks':landmarks,'source_pixel_crops':CROPS,
        'rule':'Manual external photographic appearance landmarks; original extracted contour retained.',
        'neck':'Gross crown/root appearance division; not a segmented internal EDJ.',
        'defect':'Visible margin defect; cause, chronology and propagation plane unclassified.',
        'failure_limit':'No dentinal interface or internal failure path is inferred.'},indent=2))

def figure2():
    # 183 mm, 5–7 pt type and 8 pt bold panel letters. Editable axes and bars.
    fig=canvas(183,155)
    a=np.load(R/'numerics/curvature_study/native_midpoint_sections.npz')
    D=R/'numerics/ct_section_source'
    if not D.exists():D=P/'full_3D/ct_internal_reconstruction/validation_data'
    native=np.load(D/'native_sections.npz');j=list(native['indices']).index(1500)
    xt=[4,40,76,112,148]; width=30
    for k,(key,title) in enumerate([('axial','Axial'),('coronal','Coronal'),('sagittal','Sagittal')]):
        ax=axmm(fig,xt[k]+4,116,width-4,30);im=a[key]
        ax.imshow(im,cmap=ListedColormap(['white','#30383c']),origin='lower',vmin=0,vmax=1,
                  extent=[0,im.shape[1]*.018,0,im.shape[0]*.018],interpolation='nearest')
        ax.set_xlabel('mm',labelpad=1);ax.set_ylabel('mm',labelpad=1)
        ax.tick_params(pad=1);panel(fig,xt[k],152,'abc'[k]);txt(fig,xt[k]+17,151,title,6.5,ha='center',va='top')
    ax=axmm(fig,xt[3]+4,116,width-4,30);im=native['raw'][j]
    ax.imshow(im,cmap='gray',origin='lower',vmin=0,vmax=20000,
              extent=[0,im.shape[1]*.018,0,im.shape[0]*.018],interpolation='nearest')
    ax.set_xlabel('mm',labelpad=1);ax.set_ylabel('mm',labelpad=1);ax.tick_params(pad=1)
    panel(fig,xt[3],152,'d');txt(fig,xt[3]+18,151,'Raw CT / z1500',6.5,ha='center',va='top')
    picture(axmm(fig,xt[4]+2,115,30,31),F/'archived_wireframe_white.png')
    panel(fig,xt[4],152,'e');txt(fig,xt[4]+18,151,'Tetrahedral wire',6.5,ha='center',va='top')
    txt(fig,8,108.5,'Native 18 μm sections',6,color=INK)
    txt(fig,112,108.5,'Grey values: scanner units',6,color=INK)
    cut=(slice(905,1105),slice(297,497));ref=~native['occupancies'][j][cut]
    extent=[297*.018,497*.018,905*.018,1105*.018]
    for k,(file,title) in enumerate([('supplied','Filled: 0 / 479'),('native','Native: 479 / 479'),('reconstructed','32M: 474 / 479')]):
        x=8+k*61
        ax=axmm(fig,x+7,75,35,28)
        im=np.load(D/(file+'_sections.npz'))['occupancies'][j][cut]
        ax.imshow(im,cmap=ListedColormap(['white','#ccd2d6']),origin='lower',extent=extent,vmin=0,vmax=1,interpolation='nearest')
        if file=='supplied':ax.contour(ref,levels=[.5],colors=RED,linewidths=.45,origin='lower',extent=extent)
        ax.set_xlabel('X (mm)',labelpad=1);ax.set_ylabel('Y (mm)',labelpad=1);ax.tick_params(pad=1)
        ax.plot([5.58,6.08],[16.48]*2,c=RED,lw=1.1)
        ax.text(5.58,16.60,'0.5 mm',fontsize=5.5,color=RED)
        panel(fig,x-4,105,'fgh'[k]);txt(fig,x+24,105,title,6.6,ha='center',va='top')
    # A nonblank filled panel explicitly visualises the missing voids.
    txt(fig,8,65.5,'Red outlines: reference voids filled in legacy representation',6,color=RED)
    data=np.load(R/'numerics/geometry_pairs/paired_points.npz')
    x=data['source_mm'];y=data['closest_mm'];delta=(y-x)*1000;dist=data['distance_mm']*1000
    pairs=[(0,1),(0,2),(1,2)]
    for k,(i,jj) in enumerate(pairs):
        left=9+k*61
        ax=axmm(fig,left+4,39,44,20)
        sel=np.arange(0,len(x),20)
        ax.scatter(x[sel,i],x[sel,jj],s=1.5,c=BLUE,linewidths=0,rasterized=True)
        ax.scatter(y[sel,i],y[sel,jj],s=3,facecolors='none',edgecolors=ORANGE,linewidths=.25,rasterized=True)
        idx=np.argsort(dist)[-18:]
        ax.quiver(x[idx,i],x[idx,jj],(y-x)[idx,i]*300,(y-x)[idx,jj]*300,
                  angles='xy',scale_units='xy',scale=1,color=RED,width=.005)
        # Equal physical aspect and a deliberate common empty margin for labels.
        ax.set_aspect('equal',adjustable='box');ax.set_xlabel('XYZ'[i]+' (mm)',labelpad=1)
        ax.set_ylabel('XYZ'[jj]+' (mm)',labelpad=1);ax.tick_params(pad=1)
        panel(fig,left-5,62,'ijk'[k]);txt(fig,left+27,62,'XYZ'[i]+'XYZ'[jj]+'; arrows ×300',6.5,ha='center',va='top')
        ax=axmm(fig,left+4,10,44,19)
        ax.scatter(np.maximum(abs(delta[:,i]),.001),np.maximum(abs(delta[:,jj]),.001),
                   s=.4,c=BLUE,alpha=.35,linewidths=0,rasterized=True)
        ax.set(xscale='log',yscale='log',xlim=(.0007,15),ylim=(.0007,15))
        ax.set_xlabel(r'$|\Delta '+'XYZ'[i]+r'|$ (μm)',labelpad=1)
        ax.set_ylabel(r'$|\Delta '+'XYZ'[jj]+r'|$ (μm)',labelpad=1)
        ax.set_xticks([.001,.1,10]);ax.set_yticks([.001,.1,10]);ax.tick_params(pad=1)
        ax.xaxis.set_minor_formatter(NullFormatter());ax.yaxis.set_minor_formatter(NullFormatter())
        ax.grid(alpha=.15,lw=.4,which='major');panel(fig,left-5,31,'lmn'[k])
    txt(fig,91.5,.6,'n = 10,000   |   r > 0.99999995   |   RMS 1.330 μm   |   p99 4.530 μm   |   max 8.956 μm   |   log floor 0.001 μm',6,ha='center')
    save(fig,'geometry_pack_2_reconstruction')
    (REVIEW/'figure2_design_specification.json').write_text(json.dumps({
        'canvas_mm':[183,155],'font':'Arial','type_size_pt':'5.5–7; panel letters 8 bold',
        'format':'PDF/SVG editable axes, labels, line work and scale bars; scientific images native data.',
        'new_colour_palette':['#287eab','#c27629','#ba433c'],
        'guideline_sources':['https://www.nature.com/nature/for-authors/final-submission',
          'https://research-figure-guide.nature.com/figures/preparing-figures-our-specifications/'],
        'no_claim':'No journal acceptance or certification is implied.'},indent=2))

def figure5():
    sources=[('holo_std1.jpg','std1'),('holo_neohook.jpg','Neo-Hookean'),
             ('holo_ogden.jpg','Ogden'),('holo_stdnh.jpg','std_nh'),
             ('holo_mr2.jpg','MR2'),('comsol_mr5.jpg','MR5')]
    fig=canvas(183,132)
    manifest=[]
    for k,(name,label) in enumerate(sources):
        path=P/'pde_paths'/name; target=R/'source'/name;shutil.copy2(path,target)
        im=Image.open(path);col=k%3;row=k//3;x=col*61;y=67 if row==0 else 2
        picture(axmm(fig,x+.6,y,59.8,60.8),target)
        panel(fig,x+1,y+63.5,'abcdef'[k]);txt(fig,x+7,y+63.5,label+' / archived export',6.8,va='top')
        manifest.append({'panel':'abcdef'[k],'archived_label':label,'source':str(path),
            'source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'source_pixels':list(im.size),'crop':None,'image_pixels_changed':False})
    save(fig,'jaw_comsol_3x2')
    (REVIEW/'figure5_original_exports.json').write_text(json.dumps({'images':manifest,
      'orientation':'Original anterior-oblique views; MR5 retains its slightly different native camera.',
      'legends':'Native von Mises Pa colourbars, multipliers, grid and axes retained independently.',
      'not_a_recompute':'Archived images, not new solves or six independently calibrated material laws.',
      'export_attempt':'Unified-camera read-only export failed with FlexNet -88,309; see logs.',
      'ct_scope':'No jaw CT volume identified; separate jaw surface is not labelled a CT scan.'},indent=2))

def figure4_and_6():
    S=[json.loads((B/f'numerics/L{i}/summary.json').read_text()) for i in range(3)]
    a=np.load(B/'numerics/L2/solution.npz');p=a['points_m'];t=a['tets']
    q=(p-a['center_m'])@a['basis']*1000;faces=a['boundary_faces']
    local=np.array([[1,2,3],[0,3,2],[0,1,3],[0,2,1]])
    allfaces=t[:,local].reshape(-1,3)
    _,idx,cnt=np.unique(np.sort(allfaces,axis=1),axis=0,return_index=True,return_counts=True)
    owner=idx[cnt==1]//4
    assert np.array_equal(np.sort(allfaces[idx[cnt==1]],axis=1),np.sort(faces,axis=1))
    vm=a['element_von_mises_Pa']/1e6;surf=q[faces];order=np.argsort(surf[:,:,2].mean(1))
    cent=q[t].mean(1);masks=np.load(B/'numerics/L2/region_masks.npz')
    fig=canvas(121,91)
    axs=[axmm(fig,9+37*i,48,29,36) for i in range(3)]
    for i,ax in enumerate(axs):
        ax.set_aspect('equal');ax.set(xlim=(q[:,0].min()-1,q[:,0].max()+1),ylim=(q[:,1].min()-1,q[:,1].max()+1))
        ax.set_xlabel('Transverse (mm)',labelpad=1)
        if i==0:ax.set_ylabel('Longitudinal (mm)',labelpad=1)
        else:ax.set_yticklabels([])
        ax.tick_params(pad=1,labelsize=5.5)
        panel(fig,2+39*i,89,'abc'[i]);txt(fig,20+39*i,88,['Region masks','Load / support','L2 stress'][i],6.4,ha='center',va='top')
    axs[0].scatter(cent[::20,0],cent[::20,1],s=.12,c='#dfe1e5',rasterized=True,linewidths=0)
    for j,key in enumerate(REGIONS):
        use=masks[key];use=use[::max(1,len(use)//8000)]
        axs[0].scatter(cent[use,0],cent[use,1],s=.15,color=COLORS[j],rasterized=True,linewidths=0)
    for label,(xx,yy) in zip(LABELS,[(0,-4),(-12,-2),(11,0),(0,-23),(0,7),(0,12.5)]):
        axs[0].text(xx,yy,label,fontsize=5.4,color='white',weight='bold',ha='center',va='center')
    axs[1].add_collection(PolyCollection(surf[order,:,:2],facecolors='#dfe1e5',edgecolors='none',rasterized=True))
    axs[1].add_collection(PolyCollection(surf[a['loaded_face_indices'],:,:2],facecolors='#2879bb',edgecolors='none',rasterized=True))
    fid=a['fixed_node_indices'];axs[1].scatter(q[fid,0],q[fid,1],c='#c92f40',s=.25,rasterized=True,linewidths=0)
    norm=LogNorm(.5,500)
    pc=PolyCollection(surf[order,:,:2],array=vm[owner][order],cmap='turbo',norm=norm,edgecolors='none',rasterized=True)
    axs[2].add_collection(pc)
    cb=fig.colorbar(pc,cax=axmm(fig,113.2,53,1.2,25),extend='both')
    cb.set_ticks([1,10,100],labels=['1','10','100']);cb.ax.tick_params(labelsize=5.5,pad=1)
    txt(fig,115.7,80,'MPa',5.5,ha='center')
    txt(fig,60,40.5,'Blue: 1 MPa pressure    Red: bilateral fixed caps',5.8,ha='center')
    picture(axmm(fig,1,3,38,31),F/'qf_full32m_front.png')
    picture(axmm(fig,42,3,35,31),F/'qf_full32m_oblique.png')
    panel(fig,1,37,'d');txt(fig,40,36,'Full 32M surface / regional reference',6.4,ha='center',va='top')
    q95=np.array([r['Q95_MPa'] for r in S[2]['table9']])
    colors=plt.colormaps['turbo'](LogNorm(.4,300)(q95))
    legend=axmm(fig,80,2,40,31);legend.axis('off')
    for i,(label,val,color) in enumerate(zip(LABELS,q95,colors)):
        yy=.92-i*.157;legend.plot([.03],[yy],marker='s',c=color,ms=4)
        legend.text(.12,yy,label+'  '+f'{val:.3f}',fontsize=6,va='center')
    legend.set(xlim=(0,1),ylim=(0,1));txt(fig,100,36,r'$Q_{0.95}$ (MPa); numeric $Q_F$',5.8,ha='center',va='top')
    save(fig,'field_fullresolution_qf')
    # A narrow, vertically stacked convergence reference for the adjacent column.
    fig=canvas(58,91);ax=axmm(fig,11,47,44,36)
    x=np.array([s['tetrahedra'] for s in S])
    for j in range(6):
        ax.plot(x,[s['table9'][j]['Q95_MPa'] for s in S],'-o',c=COLORS[j],ms=2,label=LABELS[j],lw=.7)
    ax.set(xscale='log',yscale='log');ax.set_xlabel('Tetrahedral elements',labelpad=1)
    ax.set_ylabel(r'$Q_{0.95}$ (MPa)',labelpad=1);ax.grid(alpha=.17,lw=.4)
    ax.set_xticks([1e5,1e6]);ax.set_yticks([1,10,100]);ax.tick_params(pad=1)
    ax.legend(ncol=3,fontsize=5.3,loc='lower right',columnspacing=.6,handlelength=1)
    panel(fig,1,89,'a');txt(fig,30,88,'Fixed-domain refinement',6.5,ha='center',va='top')
    ax=axmm(fig,11,9,44,25)
    change=np.array([abs(S[2]['table9'][i]['Q95_MPa']-S[1]['table9'][i]['Q95_MPa'])/S[2]['table9'][i]['Q95_MPa']*100 for i in range(6)])
    ax.bar(range(6),change,color=COLORS,width=.7)
    ax.axhline(2,ls='--',c='#333333',lw=.65)
    ax.set_xticks(range(6),LABELS,fontsize=5.3);ax.set_ylabel('L1–L2 change (%)',labelpad=1)
    ax.set(ylim=(0,7.1));ax.tick_params(pad=1)
    for i,v in enumerate(change):ax.text(i,v+.15,f'{v:.2f}',ha='center',fontsize=5.3)
    panel(fig,1,39,'b');txt(fig,31,38,'Five regions below 2%',6.5,ha='center',va='top')
    txt(fig,31,1,'Dashed line: descriptive 2% threshold',5.5,ha='center')
    save(fig,'mesh_convergence_vertical')
    np.savez_compressed(R/'numerics/figure4_6_readback.npz',q95_MPa=q95,last_step_relative_percent=change,elements=x)

def figure7():
    import csv
    records=list(csv.DictReader((B/'numerics/sensitivity/cases.csv').open()))
    caseids=list(dict.fromkeys(r['case'] for r in records))
    values=np.array([[float(next(r['Q95_MPa'] for r in records if r['case']==case and r['region']==key))
                      for key in REGIONS] for case in caseids])
    ratio=values/values[caseids.index('bilateral_+0')]
    fig=canvas(90,76);ax=axmm(fig,26,9,49,64)
    im=ax.imshow(ratio,aspect='auto',cmap='coolwarm',vmin=.5,vmax=1.5,interpolation='nearest')
    ax.set_xticks(range(6),LABELS,fontsize=5.8)
    ax.set_yticks(range(len(caseids)),[c.replace('_',' ') for c in caseids],fontsize=5.8)
    ax.tick_params(length=0,pad=2);ax.set_xlabel('Geometric region (L0)',fontsize=6.5,labelpad=2)
    for i in range(len(caseids)):
        for j in range(6):ax.text(j,i,f'{ratio[i,j]:.2f}',ha='center',va='center',fontsize=5.5)
    cb=fig.colorbar(im,cax=axmm(fig,78,25,2,35),extend='both')
    cb.set_ticks([.5,1,1.5]);cb.ax.tick_params(labelsize=5.8,pad=1)
    cb.set_label(r'$Q_{0.95}$/L0 baseline',fontsize=6.2,labelpad=1)
    save(fig,'sensitivity_compact')

if __name__=='__main__':
    for name,fn in [('Figure 1',figure1),('Figure 2',figure2),('Figure 5',figure5),('Figures 4 and 6',figure4_and_6),('Figure 7',figure7)]:
        print('Building '+name,flush=True);fn()
    print('Completed authentic-source figure revision.',flush=True)
