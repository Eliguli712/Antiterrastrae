#!/usr/bin/env python3
"""Project audited L2 jaw fields onto the registered full source surface."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib as mpl

mpl.use('Agg')
import matplotlib.pyplot as plt
import meshio
import numpy as np
from PIL import Image
import pyvista as pv
from scipy.spatial import cKDTree
from trimesh.triangles import points_to_barycentric
from vtkmodules.vtkCommonCore import reference
from vtkmodules.vtkCommonDataModel import vtkStaticCellLocator

import revise_figures as layout


PAPER = Path(__file__).resolve().parents[1]
PROJECT = PAPER.parents[2]
FIGURES = PAPER / 'figures'
FINE = PROJECT / 'output/ct_fea_calibrated_2026-11-08'
SOURCE = PROJECT / 'applied_forces/custom_solver/great_white_jaw_fullres_gmsh_alg1_tet_vol.msh'
NARROW = FINE / 'data/jaw_L2_narrow_local'
WIDE = FINE / 'data/jaw_L2_wide_local'
NEO_HOOKEAN = PROJECT / 'output/jaw_full_stvk_2026-11-20/data/L2_10kPa_NH_polish'
CAMERA = [(700, -750, 900), (0, 0, 0), (0, 1, 0)]
BOUNDS = [(0.001, 100.0), (1e-5, 1.0)]
TICKS = [[0.001, 0.1, 10, 100], [1e-5, 1e-3, 0.1, 1]]
SUPPORT = '#b92378'
ANCHOR = '#651444'
UNMAPPED = '#aa83c6'
TRACTION = '#1661bb'
BODY = '#e2ae61'
PALETTE = mpl.colors.ListedColormap(mpl.colormaps['turbo'](np.linspace(.07, .95, 256)))


def boundary_mesh(points, faces):
    return pv.PolyData(points, np.column_stack([np.full(len(faces), 3), faces]).ravel())


def nearest_boundary(locator, points):
    """Return exact nearest boundary triangle and closest point, in source units."""
    closest = np.empty_like(points)
    triangle = np.empty(len(points), dtype=np.int32)
    distance = np.empty(len(points))
    surface_point = [0., 0., 0.]
    cell, sub, d2 = reference(0), reference(0), reference(0.)
    for index, point in enumerate(points):
        locator.FindClosestPoint(point, surface_point, cell, sub, d2)
        closest[index] = surface_point
        triangle[index] = cell
        distance[index] = d2
    return closest, triangle, np.sqrt(distance)


def invariant(tensor, factor):
    trace = np.trace(tensor, axis1=1, axis2=2)
    dev = tensor - trace[:, None, None] * np.eye(3) / 3
    return np.sqrt(factor * np.einsum('eij,eij->e', dev, dev))


def audit_case(case, reference, law):
    points = reference['points_m']
    tets = reference['tets']
    # The neo-Hookean archive omits the redundant boundary connectivity.
    # Identical ordered vertices and volume cells identify that boundary.
    keys = ['points_m', 'tets', 'fixed_node_indices']
    keys.extend(key for key in ('boundary_faces', 'boundary_owner') if key in case.files)
    for key in keys:
        np.testing.assert_array_equal(case[key], reference[key])
    linear = law == 'linear'
    prefix = 'linear_' if linear else ''
    displacement = case[prefix + 'displacement_m']
    fixed_error = np.abs(displacement[case['fixed_node_indices']]).max()
    assert fixed_error < 1e-12
    green = (np.zeros(len(tets), dtype=bool) if linear else
             np.ones(len(tets), dtype=bool) if law == 'neo_hookean' else
             case['green_or_linear_flag'].astype(bool))
    strain = np.empty((len(tets), 3, 3))
    for start in range(0, len(tets), 100_000):
        cell = tets[start:start + 100_000]
        edges = (points[cell[:, 1:]] - points[cell[:, :1]]).transpose(0, 2, 1)
        delta_u = (displacement[cell[:, 1:]] - displacement[cell[:, :1]]).transpose(0, 2, 1)
        gradient = delta_u @ np.linalg.inv(edges)
        value = (gradient + gradient.transpose(0, 2, 1)) * .5
        use_green = green[start:start + len(cell)]
        terms = gradient[use_green]
        value[use_green] += .5 * terms.transpose(0, 2, 1) @ terms
        strain[start:start + len(cell)] = value
    stress = case['linear_stress_Pa' if linear else 'cauchy_stress_Pa']
    vm = invariant(stress, 1.5)
    eq = invariant(strain, 2 / 3)
    saved_vm = case[prefix + 'von_mises_Pa']
    saved_eq = case[prefix + 'equivalent_strain']
    np.testing.assert_allclose(vm, saved_vm, rtol=6e-7, atol=1e-7)
    np.testing.assert_allclose(eq, saved_eq, rtol=6e-7, atol=1e-11)
    return [vm / 1e6, eq], {
        'law': law,
        'max_fixed_motion_m': float(fixed_error),
        'max_VM_difference_Pa': float(abs(vm - saved_vm).max()),
        'max_equivalent_strain_difference': float(abs(eq - saved_eq).max()),
    }


def recovered_field(field, tets, volumes, node_weight, surface_triangles, barycentric):
    """Volume-weighted recovery at FE nodes, then barycentric surface transfer."""
    weighted = volumes * field
    total = sum(np.bincount(tets[:, corner], weights=weighted, minlength=len(node_weight))
                for corner in range(4))
    nodal = total / node_weight
    return nodal, np.einsum('ij,ij->i', nodal[surface_triangles], barycentric)


def render(poly, support, unsupported, anchors, filename, values=None, row=0, loaded=None,
           colour_footprint=False):
    view = pv.Plotter(off_screen=True, window_size=(2050, 1930))
    view.set_background('white')
    lighting = dict(ambient=.88, diffuse=.18, smooth_shading=True, show_scalar_bar=False)
    if values is None:
        view.add_mesh(poly, color=BODY, **lighting)
    else:
        lo, hi = BOUNDS[row]
        poly.point_data['rgb'] = (255 * PALETTE(mpl.colors.LogNorm(lo, hi, clip=True)(values))[:, :3]).astype('uint8')
        view.add_mesh(poly, scalars='rgb', rgb=True, **lighting)
    overlays = [(loaded, TRACTION), (unsupported, UNMAPPED), (support, SUPPORT)]
    if colour_footprint and values is not None:
        # The fixed-face trace marks constrained displacement. Its interior
        # and the continuation beyond the cutoff retain the scalar colours.
        overlays = []
    for subset, color in overlays:
        if subset is not None and subset.n_cells:
            actor = view.add_mesh(subset, color=color, **lighting)
            # Categorical footprint is coplanar with the source jaw by construction.
            actor.mapper.SetResolveCoincidentTopologyToPolygonOffset()
            actor.mapper.SetRelativeCoincidentTopologyPolygonOffsetParameters(-6, -12)
    if support.n_cells:
        edge = support.extract_feature_edges(boundary_edges=True, non_manifold_edges=False,
                                             feature_edges=False, manifold_edges=False)
        if edge.n_cells:
            view.add_mesh(edge, color=ANCHOR, line_width=1.6, lighting=False)
    for anchor in anchors:
        tip = anchor + [0, -13, 0]
        view.add_lines(np.array([anchor, tip]), color=ANCHOR, width=3)
        view.add_lines(np.array([tip + [-5, 0, 0], tip + [5, 0, 0]]), color=ANCHOR, width=3)
    view.camera_position = CAMERA
    view.enable_parallel_projection()
    view.reset_camera()
    image = np.asarray(view.screenshot(return_img=True))[:, :, :3]
    view.close()
    yy, xx = np.where(np.any(image < 247, axis=2))
    raster = Image.fromarray(image[max(0, yy.min() - 18):yy.max() + 19,
                                   max(0, xx.min() - 18):xx.max() + 19])
    raster.save(FIGURES / filename, optimize=True)
    return raster


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--colour-footprint', action='store_true')
    parser.add_argument('--smooth-footprint', action='store_true')
    options = parser.parse_args()
    colour_footprint = options.colour_footprint or options.smooth_footprint
    with SOURCE.open('rb') as stream:
        source_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
    metadata = json.loads((FINE / 'review/mesh_run_001/mesh_validation.json').read_text())
    assert source_hash == metadata['source_sha256']
    original = meshio.read(SOURCE)
    xyz, faces = original.points, original.cells_dict['triangle']
    assert (len(xyz), len(faces)) == (504_500, 1_009_016)
    reference = np.load(NARROW / 'fields.npz')
    points = reference['points_m'] * 1000
    boundary_faces = reference['boundary_faces']
    tets = reference['tets']
    volumes = reference['volumes_m3']
    fixed = np.zeros(len(points), dtype=bool)
    fixed[reference['fixed_node_indices']] = True
    fixed_face = fixed[boundary_faces].all(1)
    load_y = json.loads((NARROW / 'results.json').read_text())['loaded_centroid_Y_above_m'] * 1000
    loaded_face = points[boundary_faces, 1].mean(1) >= load_y
    assert not np.any(fixed_face & loaded_face)

    locator = vtkStaticCellLocator()
    locator.SetDataSet(boundary_mesh(points, boundary_faces))
    locator.BuildLocator()
    # One reconstructed voxel diagonal limits display extrapolation.
    transfer_limit = np.sqrt(3) * metadata['geometry']['pitch_mm']
    nearest, vertex_face, vertex_dist = nearest_boundary(locator, xyz)
    source_centre = xyz[faces].mean(1)
    _, near_face, face_dist = nearest_boundary(locator, source_centre)
    print('Finished full-source closest-face transfer.', flush=True)
    source_triangles = boundary_faces[vertex_face]
    barycentric = points_to_barycentric(points[source_triangles], nearest)
    assert np.isfinite(barycentric).all() and barycentric.min() >= -1e-6
    barycentric = np.clip(barycentric, 0., 1.)
    barycentric /= barycentric.sum(1)[:, None]
    mapped = (face_dist <= transfer_limit) & (vertex_dist[faces] <= transfer_limit).all(1)
    support_faces = mapped & fixed_face[near_face]
    traction_faces = mapped & loaded_face[near_face]
    xyz_centre = xyz.mean(0)
    poly = boundary_mesh(xyz - xyz_centre, faces)
    def source_patch(mask):
        indices, local_faces = np.unique(faces[mask], return_inverse=True)
        return boundary_mesh(xyz[indices] - xyz_centre, local_faces.reshape(-1, 3))

    support = source_patch(support_faces)
    unsupported = None if colour_footprint else source_patch(~mapped)
    loaded = None if colour_footprint else source_patch(traction_faces)
    if colour_footprint:
        overlaid_vertices = fixed_face[vertex_face]
        if options.smooth_footprint:
            # Approximate the seam distance on the original surface. The ramp
            # starts outside the cap and has zero derivatives at its endpoints.
            edges = np.concatenate((faces[:, [0,1]], faces[:, [1,2]], faces[:, [2,0]]))
            mixed_edges = edges[overlaid_vertices[edges[:,0]] != overlaid_vertices[edges[:,1]]]
            seam = xyz[mixed_edges].mean(1)
            assert len(seam)>20
            seam_distance = cKDTree(seam).query(xyz, workers=4)[0]
            signed_distance = np.where(overlaid_vertices, seam_distance, -seam_distance)
            ramp = np.clip((signed_distance+2.)/8.,0.,1.)
            fraction = ramp*ramp*(3-2*ramp)
            overlaid_vertices = fraction>0
            fraction = fraction[overlaid_vertices]
        free_boundary = np.unique(boundary_faces)
        free_boundary = free_boundary[~fixed[free_boundary]]
        distance, queried = cKDTree(points[free_boundary]).query(xyz[overlaid_vertices], k=8, workers=4)
        continuation_nodes = free_boundary[queried]
        continuation_weights = 1/np.maximum(distance, 1e-6)**2
        continuation_weights /= continuation_weights.sum(1, keepdims=True)
        np.testing.assert_allclose(continuation_weights.sum(1), 1)
    # Mark the inferior edge of the corresponding source footprint, closest to
    # the same locations picked on the FE fixed surface.
    fixed_centres = points[boundary_faces[fixed_face]].mean(1)
    columns = np.linspace(fixed_centres[:, 0].min(), fixed_centres[:, 0].max(), 9)[1:-1]
    support_centres = source_centre[support_faces]
    source_tree = cKDTree(support_centres)
    anchors = []
    for column in columns:
        candidates = fixed_centres[np.abs(fixed_centres[:, 0] - column) < 8]
        if len(candidates):
            target = candidates[np.argmin(candidates[:, 1])]
            _, index = source_tree.query(target)
            anchors.append(support_centres[index] - xyz_centre)
    if not colour_footprint:
        render(poly, support, unsupported, anchors, 'jaw_native_constraints.png', loaded=loaded)

    weights = sum(np.bincount(tets[:, corner], weights=volumes, minlength=len(points))
                  for corner in range(4))
    assert (weights > 0).all()
    figure = layout.canvas(183, 90)
    titles = ['Linear elasticity', 'Linear bulk / narrow StVK', 'Full neo-Hookean',
              'Linear equivalent strain', 'Mixed-model equivalent strain', 'Green–Lagrange equivalent strain']
    cases = [('linear', NARROW), ('narrow', NARROW), ('neo_hookean', NEO_HOOKEAN), ('wide', WIDE)]
    checks = []
    for column, (law, folder) in enumerate(cases):
        with np.load(folder / 'fields.npz') as case:
            fields, check = audit_case(case, reference, law)
        check['source'] = str((folder / 'fields.npz').relative_to(PROJECT))
        checks.append(check)
        for row, field in enumerate(fields[:1] if law == 'wide' else fields):
            nodal, values = recovered_field(field, tets, volumes, weights, source_triangles, barycentric)
            if colour_footprint:
                sources = nodal[continuation_nodes]
                continued = np.einsum('ij,ij->i', sources, continuation_weights)
                continued = np.clip(continued, sources.min(1), sources.max(1))
                if options.smooth_footprint:
                    # This blend belongs to the logarithmic display and leaves
                    # the original solver values and stress invariants intact.
                    floor = BOUNDS[row][0]
                    a = np.log(np.maximum(values[overlaid_vertices],floor))
                    b = np.log(np.maximum(continued,floor))
                    continued = np.exp(a+fraction*(b-a))
                values[overlaid_vertices] = continued
            assert np.isfinite(values).all() and (values >= 0).all()
            tag = 'vm' if row == 0 else 'strain'
            suffix = '_smooth' if options.smooth_footprint else '_colour' if colour_footprint else ''
            image = render(poly, support, unsupported, anchors, f'jaw_{law}_native_{tag}{suffix}.png',
                           values, row, colour_footprint=colour_footprint)
            print('Rendered', law, tag, image.size, flush=True)
            if law == 'wide':
                continue
            if not colour_footprint:
                image.thumbnail((1040, 810), Image.Resampling.LANCZOS)
            x, y = 61 * column, 48 if row == 0 else 5
            axis = layout.axmm(figure, x + 1, y, 51, 36)
            axis.imshow(image, interpolation='none')
            axis.set_axis_off()
            letter = 3 * row + column
            layout.panel(figure, x + 1, y + 40, 'abcdef'[letter])
            layout.txt(figure, x + 28, y + 39, titles[letter], 6, ha='center', va='top')
            norm = mpl.colors.LogNorm(*BOUNDS[row])
            bar = figure.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=PALETTE),
                                  cax=layout.axmm(figure, x + 53, y + 6, 1.4, 26), extend='both')
            bar.set_ticks(TICKS[row])
            bar.ax.tick_params(labelsize=5, pad=1)
            layout.txt(figure, x + 54, y + 33, 'MPa' if row == 0 else 'strain', 5, ha='center')
    legend = ('Magenta outline: fixed footprint  |  Blended colour is a display continuation' if options.smooth_footprint else
              'Magenta outline: fixed footprint shown with continuous colour from adjacent free boundary'
              if colour_footprint else 'Magenta: transferred fixed footprint   |   Lavender: outside transfer range')
    layout.txt(figure, 91.5, 1.15, legend, 6, ha='center')
    stem = 'jaw_native_3x2_smooth' if options.smooth_footprint else 'jaw_native_3x2_colour' if colour_footprint else 'jaw_native_3x2'
    figure.savefig(FIGURES / f'{stem}.pdf', dpi=550)
    figure.savefig(FIGURES / f'{stem}.png', dpi=320)
    plt.close(figure)
    report = dict(
        status='passed', source_geometry=str(SOURCE.relative_to(PROJECT)), source_geometry_sha256=source_hash,
        source_triangles=len(faces), source_vertices=len(xyz),
        FE_boundary_triangles=len(boundary_faces), FE_tetrahedra=len(tets),
        FE_fixed_nodes=int(fixed.sum()), FE_fixed_triangles=int(fixed_face.sum()),
        FE_loaded_triangles=int(loaded_face.sum()), transfer_distance_limit_source_units=transfer_limit,
        source_vertex_distance_quantiles_source_units=np.quantile(vertex_dist, [0, .5, .9, .99, 1]).tolist(),
        source_face_distance_quantiles_source_units=np.quantile(face_dist, [0, .5, .9, .99, 1]).tolist(),
        source_triangles_mapped=int(mapped.sum()), source_triangles_unmapped=int((~mapped).sum()),
        source_projected_fixed_faces=int(support_faces.sum()),
        source_projected_loaded_faces=int(traction_faces.sum()), anchor_marks=len(anchors),
        support_colour=SUPPORT, unknown_colour=UNMAPPED, loaded_colour=TRACTION,
        field_recovery='Volume-weighted scalar recovery to FE nodes, followed by bounded barycentric interpolation at closest FE boundary points. '
        + ('Fixed footprint colours continue the scalar from eight nearest free FE boundary nodes with bounded inverse-square weights. '
           'Other vertices retain the same closest-face colours, including display-only continuation beyond the distance cutoff. '
           'The fixed footprint is indicated by an outline and anchors.' if colour_footprint else
           'Source cells are coloured only if the centroid and all vertices meet the distance cutoff.'),
        scope='Every source triangle is rendered at its undeformed coordinates. The contact model and the FE mesh remain unchanged.',
        checks=checks,
    )
    if colour_footprint:
        report['display_only_fixed_vertices'] = int(overlaid_vertices.sum())
    if options.smooth_footprint:
        report['display_blend'] = dict(source_units_outside=2.,source_units_inside=6.,
                                      weighting='Cubic smoothstep in signed distance to the source-mesh seam; blend in log colour coordinate.',
                                      display_only_vertices=int(overlaid_vertices.sum()))
        report.pop('display_only_fixed_vertices')
    filename = 'jaw_native_smooth_readback.json' if options.smooth_footprint else 'jaw_native_colour_readback.json' if colour_footprint else 'jaw_native_readback.json'
    (PAPER / 'review' / filename).write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
