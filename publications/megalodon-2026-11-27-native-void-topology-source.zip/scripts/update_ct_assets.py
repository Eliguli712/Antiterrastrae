#!/usr/bin/env python3
"""Figures from observed photographs, normalized CT and newly equilibrated FEA."""
from pathlib import Path
import sys,json,shutil
import numpy as np
import pyvista as pv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm,Normalize,FuncNorm,ListedColormap
from PIL import Image
R=Path(__file__).resolve().parents[1];P=R.parents[2];T=P/'output/ct_fea_2026-11-08';F=R/'figures'
sys.path.insert(0,str(R/'scripts'))
import revise_figures as old
old.R=R;old.F=F;old.V=R/'svg';old.REVIEW=R/'review'
plt.rcParams.update({'svg.fonttype':'none','pdf.fonttype':42})

def trim(im):
    mask=np.any(im[:,:,:3]<247,axis=2);y,x=np.where(mask)
    return im[max(0,y.min()-10):y.max()+11,max(0,x.min()-10):x.max()+11]

def render(poly,values,name,camera,up=(0,1,0),clim=None,log=False,cmap='turbo',ghost=None):
    poly.cell_data['field']=values
    view=pv.Plotter(off_screen=True,window_size=(1400,1250));view.set_background('white')
    if ghost is not None:view.add_mesh(ghost,color='#cbd1d6',opacity=.20,show_scalar_bar=False)
    view.add_mesh(poly,scalars='field',cmap=cmap,clim=clim,log_scale=log,lighting=False,show_scalar_bar=False)
    view.camera_position=[camera,(0,0,0),up];view.enable_parallel_projection();view.reset_camera();view.render()
    Image.fromarray(trim(view.screenshot(return_img=True))).save(F/(name+'.png'));view.close()

def render_fields():
    a=np.load(T/'data/tooth_stvk_l1/fields.npz');ref=np.load(P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L1/solution.npz')
    q=(a['points_m']-ref['center_m'])@ref['basis']*1000;q[:,:2]*=-1
    faces=a['boundary_faces'];owner=a['boundary_owner'];poly=pv.PolyData(q,np.column_stack([np.full(len(faces),3),faces]).ravel())
    vm=a['von_mises_Pa'][owner]/1e6
    for j,camera in enumerate([(0,0,150),(100,20,140),(0,0,-150)]):
        render(poly,vm,f'stvk_tooth_view_{j}',camera,clim=(.1,300),log=True)
    longitudinal=ref['basis'][:,1];signed=np.einsum('i,eij,j->e',longitudinal,a['cauchy_stress_Pa'],longitudinal)[owner]/1e6
    limit=float(np.quantile(abs(signed),.99))
    u=a['displacement_m']@ref['basis']*1000;u[:,:2]*=-1
    deformed=pv.PolyData(q+10*u,np.column_stack([np.full(len(faces),3),faces]).ravel())
    tau=.01*limit
    render(deformed,np.arcsinh(signed/tau),'stvk_tooth_signed_deformed',(100,5,150),clim=(-np.arcsinh(limit/tau),np.arcsinh(limit/tau)),cmap='RdBu_r',ghost=poly)
    results={'tooth_signed_limit_MPa':limit,'tooth_signed_asinh_scale_MPa':tau,'deformation_display_multiplier':10,'tooth_stress_colouring':'Actual L1 StVK Cauchy stress, no original PBR false colour used.'}
    for key in ['jaw','jaw_edge_stvk','jaw_full_stvk']:
        if not (T/'data'/key/'fields.npz').exists():continue
        b=np.load(T/'data'/key/'fields.npz');p=b['points_m']*1000;p-=p.mean(0);f=b['boundary_faces'];owner=b['boundary_owner']
        poly=pv.PolyData(p,np.column_stack([np.full(len(f),3),f]).ravel());cam=(700,-750,900)
        if key=='jaw_edge_stvk':
            for j,(field,tag) in enumerate([('linear_von_mises_Pa','linear_vm'),('von_mises_Pa','edge_vm'),('linear_equivalent_strain','linear_strain'),('equivalent_strain','edge_strain')]):
                vals=b[field][owner]/1e6 if 'Pa' in field else b[field][owner]
                render(poly,vals,'jaw_'+tag,cam,clim=(.001,10) if 'vm' in tag else (1e-5,.1),log=True)
        elif key=='jaw_full_stvk':
            render(poly,b['von_mises_Pa'][owner]/1e6,'jaw_full_vm',cam,clim=(.001,10),log=True)
            render(poly,b['equivalent_strain'][owner],'jaw_full_strain',cam,clim=(1e-5,.1),log=True)
    (R/'review/current_field_display.json').write_text(json.dumps(results,indent=2))

GROOVES={
 'a':[[(473,336),(474,402),(481,468),(489,550)],[(508,278),(514,361),(521,445),(530,536)],[(543,302),(547,378),(557,453),(569,552)]],
 'b':[[(473,444),(485,522),(502,606),(521,735)],[(537,353),(548,449),(566,548),(582,707)],[(597,313),(608,422),(629,545),(650,711)],[(656,392),(677,499),(699,607),(725,752)]]}
def photographic_drawing(ax,key):
    old.outline(ax,key);ax.patches[0].set_facecolor('#76959f')
    x0,y0,x1,y1=old.CROPS[key];s=min(270/(x1-x0),350/(y1-y0));ox=25+(270-(x1-x0)*s)/2
    for path in GROOVES[key]:
        p=np.array(path);x=ox+(p[:,0]-x0)*s;y=45+(p[:,1]-y0)*s
        ax.plot(x,y,c='white',lw=.65,alpha=.95)
    for text in ax.texts:
        if text.get_text()=='Crown':text.set_color('white')

def figure1():
    fig=old.canvas(183,94)
    for i,(file,title) in enumerate([('specimen_photo_a_bordercrop.png','a  Photograph'),('specimen_photo_b_bordercrop.png','b  Photograph'),('intro_render_frame.png','c  Recovered frame')]):
        x=i*30.5;old.picture(old.axmm(fig,x,47,29,43),F/file);old.txt(fig,x,92,title,6.5,va='top')
    for j,title in enumerate(['Front','Oblique','Reverse*']):
        x=96+j*29;old.picture(old.axmm(fig,x,69,26,19),F/f'appearance_natural_{j}.png');old.txt(fig,x+13,91,title,6.2,ha='center')
        old.picture(old.axmm(fig,96+j*26,46,22,18),F/f'stvk_tooth_view_{j}.png')
    old.txt(fig,94,66,'Photograph-referenced appearance (* inferred reverse)',5.7)
    old.txt(fig,94,43.5,r'Computed StVK $\sigma_{\rm vM}$ (MPa), log scale',5.8)
    cb=fig.colorbar(plt.cm.ScalarMappable(norm=LogNorm(.1,300),cmap='turbo'),cax=old.axmm(fig,177,49,1.3,14));cb.set_ticks([.1,10,300],labels=['0.1','10','300']);cb.ax.yaxis.set_ticks_position('left');cb.ax.tick_params(labelsize=5,pad=1)
    for i,key in enumerate(['a','b']):
        photographic_drawing(old.axmm(fig,i*27,5,26,36),key);old.txt(fig,i*27+13,42,'d'+str(i+1)+'  Surface traces',6.1,ha='center',va='top')
    # Same physical source units on both sides; no sign or histogram balancing.
    ax=old.axmm(fig,57,17,44,18);im=Image.open(F/'notebook_delta_kappa1_dorsal_up.png');ax.imshow(im,interpolation='none')
    ax.set_xticks([0,(im.width-1)/2,im.width-1],['−1','0','+1']);ax.set_yticks([]);ax.tick_params(labelsize=5.5,pad=1,length=2)
    ax.set_xlabel('Centred normalized display axis',fontsize=5,labelpad=1)
    old.txt(fig,79,39,r'e1  Notebook $\Delta\kappa_1$',6.3,ha='center')
    meta=json.loads((P/'output/pdf/debunk_myth_figures_v2_2026-11-01/review/notebook_curvature_provenance.json').read_text());tau=meta['display']['asinh_scale'];lim=meta['display']['symmetric_99percent_limit']
    norm=FuncNorm((lambda x:np.arcsinh(x/tau),lambda x:tau*np.sinh(x)),vmin=-lim,vmax=lim)
    cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap='RdBu_r'),cax=old.axmm(fig,61,9,37,1.6),orientation='horizontal');cb.set_ticks([-3000,0,3000]);cb.ax.tick_params(labelsize=5,pad=1)
    old.txt(fig,79,1.5,'Inverse source units; symmetric asinh',5,ha='center')
    old.picture(old.axmm(fig,106,6,31,29),F/'stvk_tooth_signed_deformed.png');old.txt(fig,122,39,'e2  Finite deformation',6.1,ha='center')
    old.txt(fig,120,3,'u ×10 display',5.5,ha='center')
    limits=json.loads((R/'review/current_field_display.json').read_text());limit=limits['tooth_signed_limit_MPa'];tau=limits['tooth_signed_asinh_scale_MPa']
    norm=FuncNorm((lambda x:np.arcsinh(x/tau),lambda x:tau*np.sinh(x)),vmin=-limit,vmax=limit)
    cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap='RdBu_r'),cax=old.axmm(fig,139,12,1.3,19));cb.set_ticks([-limit,0,limit],labels=[f'{-limit:.0f}','0',f'{limit:.0f}']);cb.ax.tick_params(labelsize=5,pad=1);old.txt(fig,140,33,r'$\sigma_{ll}$ MPa',5.3,ha='center')
    old.picture(old.axmm(fig,153,8,28,28),F/'jaw_full_vm.png');old.txt(fig,167,41,'f  StVK jaw FEA',6.2,ha='center',va='top')
    old.txt(fig,167,5,'E = 150 MPa; ν = 0.3',5.2,ha='center');old.txt(fig,167,1,'Traction = 10 kPa',5.2,ha='center')
    old.save(fig,'geometry_pack_1_specimen')
    (R/'review/observed_surface_striations.json').write_text(json.dumps({'source_pixel_paths':GROOVES,'method':'Manual traces of photograph-visible longitudinal surface striations, not a histological measurement.','age_interpretation':'Growth increments, senescence rings, chronological ages and tissue interfaces are unvalidated. No invented ring arcs added.'},indent=2))

def figure5():
    fig=old.canvas(183,98)
    names=['linear_vm','edge_vm','full_vm','linear_strain','edge_strain','full_strain']
    titles=['Linear elasticity','Linear bulk / StVK edge band','Full StVK','Linear equivalent strain','Mixed-model equivalent strain','StVK equivalent strain']
    for i,(name,title) in enumerate(zip(names,titles)):
        x=61*(i%3);y=52 if i<3 else 4
        old.picture(old.axmm(fig,x+1,y,53,39),F/f'jaw_{name}.png');old.panel(fig,x+1,y+44,'abcdef'[i]);old.txt(fig,x+28,y+44,title,6.1,ha='center',va='top')
        norm=LogNorm(.001,10) if i<3 else LogNorm(1e-5,.1)
        cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap='turbo'),cax=old.axmm(fig,x+55,y+5,1.4,29));cb.ax.tick_params(labelsize=5.2,pad=1)
        cb.set_ticks([.001,.1,10] if i<3 else [1e-5,1e-3,.1]);old.txt(fig,x+55,y+36,'MPa' if i<3 else 'strain',5.4,ha='center')
    old.save(fig,'jaw_comsol_3x2')

def figure2():
    fig=old.canvas(183,155);a=np.load(R/'numerics/curvature_study/native_midpoint_sections.npz')
    D=R/'numerics/ct_section_source';native=np.load(D/'native_sections.npz');j=list(native['indices']).index(1500)
    for k,(key,title) in enumerate([('axial','Axial'),('coronal','Coronal'),('sagittal','Sagittal')]):
        x=2+k*30.5;ax=old.axmm(fig,x+5,116,23,30);im=a[key]
        ax.imshow(im,cmap=ListedColormap(['white','#30383c']),origin='lower',vmin=0,vmax=1,extent=[0,im.shape[1]*.018,0,im.shape[0]*.018],interpolation='nearest')
        ax.set_xlabel('mm',labelpad=1);ax.set_ylabel('mm',labelpad=1);ax.tick_params(pad=1,labelsize=5.5);old.panel(fig,x,152,'abc'[k]);old.txt(fig,x+17,151,title,6.1,ha='center',va='top')
    for k in [3,4]:
        x=2+k*30.5;ax=old.axmm(fig,x+5,116,23,30)
        if k==3:im=native['raw'][j];title='Raw Z1500'
        else:im=np.load(T/'data/maximum_area_native_sagittal.npz')['raw'];title='Raw X749'
        lo,hi=json.loads((T/'data/ct_contract.json').read_text())['display_window_raw']
        ax.imshow(im,cmap='gray',origin='lower',vmin=lo,vmax=hi,extent=[0,im.shape[1]*.018,0,im.shape[0]*.018],interpolation='nearest')
        ax.set_xlabel('mm',labelpad=1);ax.set_ylabel('mm',labelpad=1);ax.tick_params(pad=1,labelsize=5.5);old.panel(fig,x,152,'de'[k-3]);old.txt(fig,x+17,151,title,6.1,ha='center',va='top')
    old.picture(old.axmm(fig,155,116,27,30),F/'archived_wireframe_white.png');old.panel(fig,154,152,'f');old.txt(fig,169,151,'Mesh wire',6.1,ha='center',va='top')
    old.txt(fig,8,108.5,'Native 18 μm sections; raw intensities in scanner units',6,color=old.INK)
    cut=(slice(905,1105),slice(297,497));ref=~native['occupancies'][j][cut];extent=[297*.018,497*.018,905*.018,1105*.018]
    for k,(file,title) in enumerate([('supplied','Filled: 0 / 479'),('native','Native: 479 / 479'),('reconstructed','32M: 474 / 479')]):
        x=8+k*61;ax=old.axmm(fig,x+7,75,35,28);im=np.load(D/(file+'_sections.npz'))['occupancies'][j][cut]
        ax.imshow(im,cmap=ListedColormap(['white','#ccd2d6']),origin='lower',extent=extent,vmin=0,vmax=1,interpolation='nearest')
        if file=='supplied':ax.contour(ref,levels=[.5],colors=old.RED,linewidths=.45,origin='lower',extent=extent)
        ax.set_xlabel('X (mm)',labelpad=1);ax.set_ylabel('Y (mm)',labelpad=1);ax.tick_params(pad=1);ax.plot([5.58,6.08],[16.48]*2,c=old.RED,lw=1.1);ax.text(5.58,16.60,'0.5 mm',fontsize=5.5,color=old.RED)
        old.panel(fig,x-4,105,'ghi'[k]);old.txt(fig,x+24,105,title,6.6,ha='center',va='top')
    old.txt(fig,8,65.5,'Red outlines: reference voids filled in legacy representation',6,color=old.RED)
    pairs=np.load(R/'numerics/geometry_pairs/paired_points.npz');x=pairs['source_mm'];y=pairs['closest_mm'];delta=(y-x)*1000;dist=pairs['distance_mm']*1000
    for k,(i,jj) in enumerate([(0,1),(0,2),(1,2)]):
        left=9+k*61;ax=old.axmm(fig,left+4,39,44,20);sel=np.arange(0,len(x),20)
        ax.scatter(x[sel,i],x[sel,jj],s=1.5,c=old.BLUE,linewidths=0,rasterized=True);ax.scatter(y[sel,i],y[sel,jj],s=3,facecolors='none',edgecolors=old.ORANGE,linewidths=.25,rasterized=True)
        idx=np.argsort(dist)[-18:];ax.quiver(x[idx,i],x[idx,jj],(y-x)[idx,i]*300,(y-x)[idx,jj]*300,angles='xy',scale_units='xy',scale=1,color=old.RED,width=.005)
        ax.set_aspect('equal',adjustable='box');ax.set_xlabel('XYZ'[i]+' (mm)',labelpad=1);ax.set_ylabel('XYZ'[jj]+' (mm)',labelpad=1);ax.tick_params(pad=1)
        old.panel(fig,left-5,62,'jkl'[k]);old.txt(fig,left+27,62,'XYZ'[i]+'XYZ'[jj]+'; arrows ×300',6.5,ha='center',va='top')
        ax=old.axmm(fig,left+4,10,44,19);ax.scatter(np.maximum(abs(delta[:,i]),.001),np.maximum(abs(delta[:,jj]),.001),s=.4,c=old.BLUE,alpha=.35,linewidths=0,rasterized=True)
        ax.set(xscale='log',yscale='log',xlim=(.0007,15),ylim=(.0007,15));ax.set_xlabel(r'$|\Delta '+'XYZ'[i]+r'|$ (μm)',labelpad=1);ax.set_ylabel(r'$|\Delta '+'XYZ'[jj]+r'|$ (μm)',labelpad=1)
        ax.set_xticks([.001,.1,10]);ax.set_yticks([.001,.1,10]);ax.tick_params(pad=1);ax.grid(alpha=.15,lw=.4);old.panel(fig,left-5,31,'mno'[k])
    old.txt(fig,91.5,.6,'n = 10,000 | r > 0.99999995 | RMS 1.330 μm | p99 4.530 μm | max 8.956 μm | log floor 0.001 μm',6,ha='center')
    old.save(fig,'geometry_pack_2_reconstruction')

def diagnostics():
    fig=old.canvas(183,76);gs=fig.add_gridspec(1,3,left=.06,right=.98,bottom=.2,top=.9,wspace=.46)
    C=json.loads((T/'data/ct_contract.json').read_text());D=np.load(T/'data/maximum_area_native_sagittal.npz');raw=D['raw'];ax=fig.add_subplot(gs[0]);lo,hi=C['display_window_raw']
    ax.imshow(raw,origin='lower',cmap='gray',vmin=lo,vmax=hi,extent=[0,raw.shape[1]*.018,0,raw.shape[0]*.018]);ax.set(xlabel='Y (mm)',ylabel='Z (mm)',title='Native maximum-area direction')
    data=np.load(T/'data/stress_volume_plot_data.npz');vm=data['von_mises_MPa'];valid=data['valid'];origin=data['origin_xyz_mm'];h=.12;ix=int(round((749*.018-origin[0])/h));ax=fig.add_subplot(gs[1]);im=vm[:,:,ix].copy();im[valid[:,:,ix]==0]=np.nan
    pic=ax.imshow(im,origin='lower',cmap='turbo',norm=LogNorm(.1,300),extent=[origin[1],origin[1]+im.shape[1]*h,origin[2],origin[2]+im.shape[0]*h]);ax.set(xlabel='Y (mm)',ylabel='Z (mm)',title='StVK FE stress samples');fig.colorbar(pic,ax=ax,fraction=.045,pad=.02,label='MPa')
    ax=fig.add_subplot(gs[2]);ref=np.load(P/'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L1/solution.npz');lin=np.linalg.norm(ref['displacement_m'],axis=1).max()*1000
    for key,style in [('tooth_stvk','--'),('tooth_stvk_l1','-')]:
        r=json.loads((T/'data'/key/'results.json').read_text());x=np.array([s['load_factor'] for s in r['load_steps']]);y=np.array([s['max_displacement_mm'] for s in r['load_steps']]);ax.plot(x,y,'o'+style,label='StVK '+('L1' if key.endswith('l1') else 'L0'),ms=3)
    ax.plot([0,1],[0,lin],':',c='#444444',label='Linear L1');ax.set(xlabel='Reference pressure (MPa)',ylabel='Maximum displacement (mm)',title='Solved nonlinear pressure mapping');ax.legend(fontsize=5.8);ax.grid(alpha=.15)
    old.save(fig,'native_CT_StVK_volume_and_scaling')

if __name__=='__main__':
    render_fields();figure1();figure2();figure5();diagnostics();print('Updated scientific figure assets complete.',flush=True)
