#!/usr/bin/env python3
"""Calibrated CT panels and sign-preserving, two-sided notebook colour ranges."""
from pathlib import Path
import argparse, copy, hashlib, json, re, sys
import numpy as np
import pyvista as pv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import FuncNorm, ListedColormap, LogNorm
from PIL import Image
import fitz
import revise_figures as old
import update_ct_assets as previous

R=Path(__file__).resolve().parents[1]
P=R.parents[2]
D=P/'output/ct_fea_calibrated_2026-11-08'
T=P/'output/ct_fea_2026-11-08'
F=R/'figures'
ORIGIN=np.array([4.176,.198,16.818])
MASK_ORIGIN=np.array([11.232,1.566,18.186])
old.R=R;old.F=F;old.V=R/'svg';old.REVIEW=R/'review'


def sha(p):
    with Path(p).open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()


def notebook():
    src=P/'output/pdf/debunk_myth_figures_v2_2026-11-01/numerics/notebook_curvature_differences.npz'
    a=np.load(src);d=a['delta_kappa1'];v=a['vertices'];faces=a['faces']
    negative=float(np.quantile(-d[d<0],.99));positive=float(np.quantile(d[d>0],.99))
    scale=np.where(d<0,.01*negative,.01*positive)
    mapped=np.arcsinh(d/scale)
    q=np.column_stack([-v[:,2],v[:,1],v[:,0]])
    q-=(q.min(0)+q.max(0))/2  # rigid camera placement only; no coordinate normalization
    poly=pv.PolyData(q,np.column_stack([np.full(len(faces),3),faces]).ravel())
    poly['display']=mapped
    view=pv.Plotter(off_screen=True,window_size=(2100,800));view.set_background('white')
    limit=float(np.arcsinh(100.))
    view.add_mesh(poly,scalars='display',cmap='RdBu_r',clim=(-limit,limit),
                  lighting=False,show_scalar_bar=False)
    view.camera_position=[(0,0,80),(0,0,0),(0,1,0)]
    view.enable_parallel_projection();view.camera.parallel_scale=5.4;view.render()
    im=view.screenshot(return_img=True);view.close()
    mask=np.any(im[:,:,:3]<245,axis=2);yy,xx=np.where(mask)
    Image.fromarray(im).crop((max(0,int(xx.min())-20),max(0,int(yy.min())-20),
                            min(im.shape[1],int(xx.max())+21),min(im.shape[0],int(yy.max())+21))).save(F/'notebook_delta_kappa1_balanced.png')
    info=dict(source=str(src),source_sha256=sha(src),negative_99percent_magnitude=negative,
              positive_99percent_magnitude=positive,negative_vertices=int((d<0).sum()),
              positive_vertices=int((d>0).sum()),zero_vertices=int((d==0).sum()),
              rule='Separate signed-side 99th-percentile asinh display limits; zero and every raw sign/value retained. No scalar offset, sign rebalancing or normalized spatial axes.',
              display_orientation='Rigid (-Z,Y,X); dorsal +Y upward.',
              colour_transform='asinh(d/(0.01*Lsign)); both signed-side limits map to +/-asinh(100).',
              raw_units='Inverse notebook source units; not anatomically calibrated.')
    (R/'review/notebook_balanced_colour.json').write_text(json.dumps(info,indent=2))


def colour_norm():
    a=json.loads((R/'review/notebook_balanced_colour.json').read_text())
    neg=a['negative_99percent_magnitude'];pos=a['positive_99percent_magnitude']
    def forward(x):
        z=np.asarray(x);return np.arcsinh(z/np.where(z<0,.01*neg,.01*pos))
    def inverse(x):
        z=np.asarray(x);return np.sinh(z)*np.where(z<0,.01*neg,.01*pos)
    return FuncNorm((forward,inverse),vmin=-neg,vmax=pos),neg,pos


def figure1():
    assert (F/'jaw_fine_full_vm.png').exists(), 'Render the executed finer jaw fields first.'
    fig=old.canvas(183,94)
    for i,(file,title) in enumerate([('specimen_photo_a_bordercrop.png','a  Photograph'),
                                   ('specimen_photo_b_bordercrop.png','b  Photograph'),
                                   ('intro_render_frame.png','c  Recovered frame')]):
        x=i*30.5;old.picture(old.axmm(fig,x,47,29,43),F/file);old.txt(fig,x,92,title,6.5,va='top')
    for j,title in enumerate(['Front','Oblique','Reverse*']):
        x=96+j*29
        old.picture(old.axmm(fig,x,69,26,19),F/f'appearance_natural_{j}.png')
        old.picture(old.axmm(fig,x,46,26,19),F/f'appearance_reference_{j}.png')
        old.txt(fig,x+13,91,title,6.2,ha='center')
    old.txt(fig,94,66,'Natural appearance (* inferred reverse)',5.7)
    old.txt(fig,94,43.5,'Paper-image colour reference; appearance data',5.7)
    for i,key in enumerate(['a','b']):
        previous.photographic_drawing(old.axmm(fig,i*27,5,26,36),key)
        old.txt(fig,i*27+13,42,'d'+str(i+1)+'  Surface traces',6.1,ha='center',va='top')
    old.picture(old.axmm(fig,56,15,46,22),F/'notebook_delta_kappa1_balanced.png')
    old.txt(fig,79,39,r'e1  Notebook $\Delta\kappa_1$',6.3,ha='center')
    norm,neg,pos=colour_norm()
    cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap='RdBu_r'),
                   cax=old.axmm(fig,60,9,39,1.6),orientation='horizontal')
    cb.set_ticks([-neg,-100,0,100,pos],labels=[f'{-neg:.0f}','-100','0','100',f'{pos:.0f}'])
    cb.ax.tick_params(labelsize=4.9,pad=1)
    old.txt(fig,79,1.5,'Inverse source units; signed-side asinh',5,ha='center')
    old.picture(old.axmm(fig,106,6,31,29),F/'stvk_tooth_signed_deformed.png')
    old.txt(fig,122,39,'e2  Finite deformation',6.1,ha='center')
    old.txt(fig,120,3,'u ×10 display',5.5,ha='center')
    limits=json.loads((R/'review/current_field_display.json').read_text())
    limit=limits['tooth_signed_limit_MPa'];tau=limits['tooth_signed_asinh_scale_MPa']
    norm=FuncNorm((lambda x:np.arcsinh(x/tau),lambda x:tau*np.sinh(x)),vmin=-limit,vmax=limit)
    cb=fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap='RdBu_r'),cax=old.axmm(fig,139,12,1.3,19))
    cb.set_ticks([-limit,0,limit],labels=[f'{-limit:.0f}','0',f'{limit:.0f}'])
    cb.ax.tick_params(labelsize=5,pad=1);old.txt(fig,140,33,r'$\sigma_{ll}$ MPa',5.3,ha='center')
    old.picture(old.axmm(fig,153,8,28,28),F/'jaw_fine_full_vm.png')
    kind=json.loads((R/'review/finer_jaw_display.json').read_text())['third_law']
    old.txt(fig,167,41,'f  Full StVK jaw' if kind=='full' else 'f  Wide-band jaw FEA',6,ha='center',va='top')
    old.txt(fig,167,5,'E = 150 MPa; ν = 0.3',5.2,ha='center')
    old.txt(fig,167,1,'Traction = 10 kPa',5.2,ha='center')
    fig.set_size_inches(183/25.4,90/25.4)
    old.save(fig,'geometry_pack_1_specimen')


def extent(origin,shape):
    return [origin[0]-.009,origin[0]+(shape[1]-.5)*.018,
            origin[1]-.009,origin[1]+(shape[0]-.5)*.018]


def equivalent_time(axis,index):
    return index*3049/({'X':1675,'Y':2027,'Z':3049}[axis]*25)


def figure2():
    fig=old.canvas(183,155)
    a=np.load(R/'numerics/curvature_study/native_midpoint_sections.npz')
    source=R/'numerics/ct_section_source'
    native=np.load(source/'native_sections.npz');j=list(native['indices']).index(1500)
    descriptors=[('axial','Axial mask','Z',1519,[0,1]),
                 ('coronal','Coronal mask','Y',1027,[0,2]),
                 ('sagittal','Sagittal mask','X',765,[1,2])]
    records=[]
    for k,(key,title,axis,index,indices) in enumerate(descriptors):
        x=2+k*30.5;ax=old.axmm(fig,x+5,118,23,25);im=a[key]
        ax.imshow(im,cmap=ListedColormap(['white','#30383c']),origin='lower',vmin=0,vmax=1,
                  extent=extent(MASK_ORIGIN[indices],im.shape),interpolation='nearest')
        ax.set_xlabel('XYZ'[indices[0]]+' (mm)',labelpad=1);ax.set_ylabel('XYZ'[indices[1]]+' (mm)',labelpad=1)
        ax.tick_params(pad=1,labelsize=5.2)
        mm=ORIGIN['XYZ'.index(axis)]+index*.018;tm=equivalent_time(axis,index)
        old.panel(fig,x,153,'abc'[k]);old.txt(fig,x+16,152,title,6,ha='center',va='top')
        old.txt(fig,x+16,147.5,f'{axis}={mm:.3f} mm',5.3,ha='center',va='top')
        old.txt(fig,x+16,108.0,f't ≈ {tm:.2f} s',5.2,ha='center')
        records.append(dict(panel='abc'[k],native_plane_index=index,axis=axis,LPS_mm=mm,equivalent_playback_s=tm))
    for k in [3,4]:
        x=2+k*30.5;ax=old.axmm(fig,x+5,118,23,25)
        if k==3:
            im=native['raw'][j];title='Raw Z1500';axis='Z';index=1500;inds=[0,1];origin=MASK_ORIGIN[inds]
        else:
            im=np.load(T/'data/maximum_area_native_sagittal.npz')['raw'];title='Max-area X749';axis='X';index=749;inds=[1,2];origin=ORIGIN[inds]
        lo,hi=json.loads((T/'data/ct_contract.json').read_text())['display_window_raw']
        ax.imshow(im,cmap='gray',origin='lower',vmin=lo,vmax=hi,
                  extent=extent(origin,im.shape),interpolation='nearest')
        ax.set_xlabel('XYZ'[inds[0]]+' (mm)',labelpad=1);ax.set_ylabel('XYZ'[inds[1]]+' (mm)',labelpad=1)
        ax.tick_params(pad=1,labelsize=5.2)
        mm=ORIGIN['XYZ'.index(axis)]+index*.018;tm=equivalent_time(axis,index)
        old.panel(fig,x,153,'de'[k-3]);old.txt(fig,x+16,152,title,6,ha='center',va='top')
        old.txt(fig,x+16,147.5,f'{axis}={mm:.3f} mm',5.3,ha='center',va='top')
        old.txt(fig,x+16,108.0,f't ≈ {tm:.2f} s',5.2,ha='center')
        records.append(dict(panel='de'[k-3],native_plane_index=index,axis=axis,LPS_mm=mm,equivalent_playback_s=tm))
    old.picture(old.axmm(fig,155,115,27,29),F/'archived_wireframe_white.png')
    old.panel(fig,154,153,'f');old.txt(fig,169,152,'Mesh connectivity',6,ha='center',va='top')
    old.txt(fig,169,147.5,'Source geometry',5.3,ha='center',va='top')
    cut=(slice(905,1105),slice(297,497));ref=~native['occupancies'][j][cut]
    box=[MASK_ORIGIN[0]+(297-.5)*.018,MASK_ORIGIN[0]+(497-.5)*.018,
         MASK_ORIGIN[1]+(905-.5)*.018,MASK_ORIGIN[1]+(1105-.5)*.018]
    for k,(file,title) in enumerate([('supplied','Solid reference: 0 / 479'),('native','Native: 479 / 479'),('reconstructed','32M: 474 / 479')]):
        x=8+k*61;ax=old.axmm(fig,x+7,75,35,28)
        im=np.load(source/(file+'_sections.npz'))['occupancies'][j][cut]
        ax.imshow(im,cmap=ListedColormap(['white','#ccd2d6']),origin='lower',extent=box,vmin=0,vmax=1,interpolation='nearest')
        if file=='supplied':ax.contour(ref,levels=[.5],colors=old.RED,linewidths=.45,origin='lower',extent=box)
        ax.set_xlabel('X (mm)',labelpad=1);ax.set_ylabel('Y (mm)',labelpad=1);ax.tick_params(pad=1)
        ax.plot([16.81,17.31],[18.05]*2,c=old.RED,lw=1.1);ax.text(16.81,18.17,'0.5 mm',fontsize=5.5,color=old.RED)
        old.panel(fig,x-4,105,'ghi'[k]);old.txt(fig,x+24,105,title,6.2,ha='center',va='top')
    old.txt(fig,8,65.5,'Red outlines identify reference void locations; all spatial axes use DICOM LPS mm',5.8,color=old.RED)
    pairs=np.load(R/'numerics/geometry_pairs/paired_points.npz')
    x=pairs['source_mm']+ORIGIN;y=pairs['closest_mm']+ORIGIN
    delta=(y-x)*1000;dist=pairs['distance_mm']*1000
    for k,(i,jj) in enumerate([(0,1),(0,2),(1,2)]):
        left=9+k*61;ax=old.axmm(fig,left+4,39,44,20);sel=np.arange(0,len(x),20)
        ax.scatter(x[sel,i],x[sel,jj],s=1.5,c=old.BLUE,linewidths=0,rasterized=True)
        ax.scatter(y[sel,i],y[sel,jj],s=3,facecolors='none',edgecolors=old.ORANGE,linewidths=.25,rasterized=True)
        idx=np.argsort(dist)[-18:]
        ax.quiver(x[idx,i],x[idx,jj],(y-x)[idx,i]*300,(y-x)[idx,jj]*300,
                  angles='xy',scale_units='xy',scale=1,color=old.RED,width=.005)
        ax.set_aspect('equal',adjustable='box');ax.set_xlabel('XYZ'[i]+' (mm)',labelpad=1);ax.set_ylabel('XYZ'[jj]+' (mm)',labelpad=1);ax.tick_params(pad=1)
        # Two separated physical ticks remain legible on the narrow equal-aspect projections.
        ax.set_xticks([15,25] if i==0 else [10,30])
        old.panel(fig,left-5,62,'jkl'[k]);old.txt(fig,left+27,62,'XYZ'[i]+'XYZ'[jj]+'; arrows ×300',6.5,ha='center',va='top')
        ax=old.axmm(fig,left+4,10,44,19)
        ax.scatter(np.maximum(abs(delta[:,i]),.001),np.maximum(abs(delta[:,jj]),.001),s=.4,c=old.BLUE,alpha=.35,linewidths=0,rasterized=True)
        ax.set(xscale='log',yscale='log',xlim=(.0007,15),ylim=(.0007,15))
        ax.set_xlabel(r'$|\Delta '+'XYZ'[i]+r'|$ (μm)',labelpad=1);ax.set_ylabel(r'$|\Delta '+'XYZ'[jj]+r'|$ (μm)',labelpad=1)
        ax.set_xticks([.001,.1,10]);ax.set_yticks([.001,.1,10]);ax.tick_params(pad=1);ax.grid(alpha=.15,lw=.4)
        old.panel(fig,left-5,31,'mno'[k])
    old.txt(fig,91.5,.6,'n = 10,000 | r > 0.99999995 | RMS 1.330 μm | p99 4.530 μm | max 8.956 μm | log floor 0.001 μm',6,ha='center')
    fig.set_size_inches(183/25.4,145/25.4)
    old.save(fig,'geometry_pack_2_reconstruction')
    (R/'review/figure2_calibration.json').write_text(json.dumps(dict(
        panels=records,origin_LPS_mm=ORIGIN.tolist(),mask_origin_LPS_mm=MASK_ORIGIN.tolist(),
        voxel_center_axes=True,raw_Z1500_direct_DICOM_readback='Exact cropped pixel agreement at source Z=1500, not Z=1576.',
        playback_clock='f/25 seconds; approximate equivalent times for native Y/X planes, not acquisition times.',
        paired_positions='Source image-index positions translated to LPS; distances and correlations unchanged.'),indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['imaging','figure1'],default='imaging');args=parser.parse_args()
    if args.stage=='imaging':notebook();figure2()
    else:figure1()
