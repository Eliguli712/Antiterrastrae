#!/usr/bin/env python3
"""Render the verified cap, window, and cavity-shape experiments."""
import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator

PAPER = Path(__file__).resolve().parents[1]
plt.rcParams.update({
    "font.family": "serif", "font.serif": ["STIXGeneral", "DejaVu Serif"],
    "font.size": 9, "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": 0.72, "axes.labelcolor": "#263748", "xtick.color": "#263748",
    "ytick.color": "#263748", "text.color": "#162734", "pdf.fonttype": 42,
})
BLUE, TEAL, OCHRE, RED = "#25567c", "#187d79", "#b57a30", "#9d4d3f"


def mark(ax, title):
    ax.set_title(title, loc="left", fontweight="bold", pad=11)
    ax.grid(axis="y", color="#e0e6e7", linewidth=.6)
    ax.set_axisbelow(True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    cap = json.loads((PAPER/"numerics/matched_cap_refinement.json").read_text())
    cavity = json.loads((PAPER/"numerics/coupled_ct_submodels/cavity_window_shape_controls.json").read_text())
    if cap["status"] != "passed" or cavity["status"] != "verified" or len(cap["cases"]) != 9:
        raise ValueError("The recorded experiment is incomplete.")
    root = next(item for item in cap["contrasts"] if item["region"] == "Rroot")
    case = cavity["cases"]
    iso = [row for row in case if row["name"] == "CT window"]
    retained = [row for row in case if row["name"] == "CT window with neighbouring voids"]
    small = next(row for row in iso if row["side_voxels"] == 72)
    sphere = next(row for row in case if row["name"] == "sphere")
    ellipsoid = next(row for row in case if row["name"] == "ellipsoid")
    fig, axes = plt.subplots(1, 3, figsize=(10.0, 3.2))
    fig.subplots_adjust(left=.067,right=.985,top=.82,bottom=.245,wspace=.37)
    ax = axes[0]
    for mesh, colour, marker in zip(("L0","L1","L2"),(BLUE,TEAL,RED),("o","s","^")):
        levels = root["Q95_MPa"][mesh]
        ax.plot([.03,.04,.05],[levels[k] for k in ("0.03","0.04","0.05")], label=mesh,
                color=colour, marker=marker, markersize=4, linewidth=1.2)
    mark(ax, "a   Cap rule × mesh")
    ax.set_xlabel("Relative root-cap depth")
    ax.set_ylabel("Root von Mises Q95 (MPa)")
    ax.set_xticks([.03,.04,.05])
    ax.legend(frameon=False,loc="lower left")
    ax = axes[1]
    for rows, colour, label, marker in ((iso,BLUE,"Isolated CT void","o"), (retained,TEAL,"With neighbouring voids","s")):
        ax.plot([r["side_mm"] for r in rows], [r["porous_vm_q95_MPa"] for r in rows], color=colour,
                label=label, marker=marker, linewidth=1.2, markersize=4)
    mark(ax, "b   Window size")
    ax.set_xlabel("Cube side (mm)")
    ax.set_ylabel("Collar von Mises Q95 (MPa)")
    ax.xaxis.set_major_locator(FixedLocator([1.008,1.296,1.584]))
    ax.set_ylim(5.548,5.683)
    ax.legend(frameon=False,loc="upper left", fontsize=8)
    ax = axes[2]
    values = [small["filled_vm_MPa"], small["porous_vm_q95_MPa"], sphere["porous_vm_q95_MPa"], ellipsoid["porous_vm_q95_MPa"]]
    ax.bar(range(4), values, width=.65, color=["#a5b5ba", BLUE, TEAL, OCHRE])
    for i, value in enumerate(values):
        ax.text(i,value+.1,f"{value:.2f}",ha="center",va="bottom",fontsize=8)
    mark(ax, "c   Matched-volume shapes")
    ax.set_xticks(range(4),["Filled","Native","Sphere","Ellipsoid"],rotation=20,ha="right")
    ax.set_ylabel("Collar von Mises Q95 (MPa)")
    ax.set_ylim(0,7.1)
    fig.text(.066,.943,"Matched root-support and cavity controls",fontsize=16,fontweight="bold")
    fig.text(.066,.055,"Same 1 MPa crown load in (a). Same 18 µm sampling and A3 affine displacement driver in (b,c).",
             fontsize=8.5)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    fig.savefig(args.output,metadata={"Title":"Matched root-support and cavity controls","Author":"Eliguli Han"})


if __name__ == "__main__":
    main()
