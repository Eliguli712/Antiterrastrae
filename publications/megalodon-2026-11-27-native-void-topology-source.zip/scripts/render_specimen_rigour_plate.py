"""Compose Figure 1 with maximal acquired CT contours and an illustrative scale."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.colors import FuncNorm, ListedColormap
from matplotlib.patches import Rectangle
import numpy as np
from PIL import Image
import pyvista as pv
from scipy import ndimage

from calibrated_figures import colour_norm
import revise_figures as layout
from photographic_cervical_guides import photo_axes, record as cervical_record
from split_ct_channel_contours import pack_paths, split_gap_boundaries


PAPER = Path(__file__).resolve().parents[1]
PROJECT = PAPER.parents[2]
FIGURES = PAPER / "figures"
REVIEW = PAPER / "review"
REPORT_NAME = "figure1_channel_halves_review.json"
FIGURE_NAME = "geometry_pack_1_channel_halves"
SPACING = .018
X_INDEX = 749
MASK_SHAPE = (2886, 1903, 746)
SCAN_ORIGIN = np.array([4.176, .198, 16.818])
MASK_ORIGIN = np.array([11.232, 1.566, 18.186])
WINDOW = (-3292, 26623)
MINIMUM_PIXELS = 4
SPIKE_MAD_MULTIPLIER = 3
# The archived photo-B margin annotation uses RGB (23, 100, 219).
BLUE = "#1764db"
RED = "#d72840"
INK = "#173b56"


def sha256(path):
    with path.open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def component_filter(mask):
    labels, count = ndimage.label(mask, structure=np.ones((3, 3), bool))
    sizes = np.bincount(labels.ravel(), minlength=count + 1)
    sizes[0] = 0
    return sizes[labels] >= MINIMUM_PIXELS, sizes[sizes >= MINIMUM_PIXELS]


def select_annotated_scan():
    source = PROJECT / "output/ct_profiles_2026-11-09/data/native_profiles_and_maximum_sections.npz"
    cache = PROJECT / "output/ct_web_2026-11-19/cache"
    raw_source = cache / "native_specimen_crop.i16"
    mask_source = cache / "selected_native_mask.u8"
    offset = np.rint((MASK_ORIGIN - SCAN_ORIGIN) / SPACING).astype(int)
    np.testing.assert_allclose(SCAN_ORIGIN + offset * SPACING, MASK_ORIGIN, atol=1e-12)
    crop_index = X_INDEX - offset[0]
    scanner = np.memmap(raw_source, dtype="<i2", mode="r", shape=MASK_SHAPE)
    mask = np.memmap(mask_source, dtype="u1", mode="r", shape=MASK_SHAPE)
    raw = np.array(scanner[:, :, crop_index])
    material = np.array(mask[:, :, crop_index], dtype=bool)
    with np.load(source) as acquired:
        selected = acquired["sagittal_raw_maximum"]
    np.testing.assert_array_equal(raw, selected[
        offset[2]:offset[2]+raw.shape[0], offset[1]:offset[1]+raw.shape[1],
    ])
    envelope = ndimage.binary_fill_holes(material, structure=np.ones((3, 3), bool))
    gaps, gap_sizes = component_filter(envelope & ~material)
    rows, columns = np.where(envelope)
    y0, y1 = max(0, columns.min() - 16), min(len(material[0]), columns.max() + 17)
    z0, z1 = max(0, rows.min() - 16), min(len(material), rows.max() + 17)
    region = np.s_[z0:z1, y0:y1]
    raw, material, gaps, envelope = [item[region] for item in (raw, material, gaps, envelope)]
    neighborhood = ndimage.minimum_filter(material, size=5)
    neighborhood &= ndimage.binary_dilation(gaps, iterations=12)
    residual = raw.astype(float) - ndimage.median_filter(raw, size=5)
    median = float(np.median(residual[neighborhood]))
    sigma = float(1.4826 * np.median(np.abs(residual[neighborhood] - median)))
    assert sigma > 0
    spike_masks = []
    spike_components = []
    for sign in (-1, 1):
        selected_spikes, sizes = component_filter(
            neighborhood & (sign * (residual - median) > SPIKE_MAD_MULTIPLIER * sigma)
        )
        spike_masks.append(selected_spikes)
        spike_components.append(len(sizes))
    spikes = np.logical_or(*spike_masks)
    assert np.any(spikes) and not np.any(spikes & gaps)

    ym = MASK_ORIGIN[1] + np.arange(y0, y1) * SPACING
    zm = MASK_ORIGIN[2] + np.arange(z0, z1) * SPACING
    extent = (ym[0] - SPACING/2, ym[-1] + SPACING/2, zm[0] - SPACING/2, zm[-1] + SPACING/2)
    inward, outward, arc_records = split_gap_boundaries(gaps, envelope, ym, zm, SPACING)
    inward_coords, inward_offsets = pack_paths(inward)
    outward_coords, outward_offsets = pack_paths(outward)
    numbers = PAPER / "numerics/figure1_d2_native_channel_halves.npz"
    np.savez_compressed(numbers, signed16=raw, selected_material=material, enclosed_low_attenuation=gaps,
                        display_envelope=envelope, negative_spikes=spike_masks[0], positive_spikes=spike_masks[1],
                        Y_mm=ym, Z_mm=zm, source_X_index=X_INDEX, source_spacing_mm=SPACING,
                        inward_YZ_mm=inward_coords, inward_offsets=inward_offsets, outward_YZ_mm=outward_coords,
                        outward_offsets=outward_offsets, perimeter_and_mean_depth_mm=arc_records)
    record = {
        "source": str(source.relative_to(PROJECT)),
        "source_profiles_sha256": sha256(source),
        "full_maximal_sagittal_plane_shape_ZY": list(selected.shape),
        "slice_registration_readback": "All registered raw crop pixels equal the exact archived acquired X plane.",
        "source_X_index": X_INDEX,
        "X_LPS_mm": float(SCAN_ORIGIN[0] + X_INDEX * SPACING),
        "voxel_pitch_mm": SPACING,
        "crop_in_mask_ZY": [int(z0), int(z1), int(y0), int(y1)],
        "native_crop_shape_ZY": list(raw.shape),
        "absolute_LPS_edge_extent_YZ_mm": extent,
        "display_limits_raw": WINDOW,
        "display_exterior_only": "Black outside selected specimen envelope; no interpolated or denoised scan values.",
        "gap_count": len(gap_sizes),
        "gap_pixels": int(gap_sizes.sum()),
        "minimum_gap_and_spike_pixels": MINIMUM_PIXELS,
        "gap_rule": "8-connected enclosed background of selected mask on this acquired plane.",
        "spike_rule": "Absolute signed16 residual from the 5x5 in-material local median, "
                      "centred by the eligible-pixel residual median, above 3 times its MAD scale. "
                      "Eligible matrix pixels within 12 four-neighbour steps of displayed gaps; "
                      "positive and negative connected components are filtered independently.",
        "residual_median_raw_units": median,
        "MAD_scale_raw_units": sigma,
        "eligible_residual_pixels": int(neighborhood.sum()),
        "spike_components_negative_positive": spike_components,
        "spike_pixels": int(spikes.sum()),
        "numeric_masks_sha256": sha256(numbers),
        "colour_halves": {
            "loops": len(arc_records),
            "total_inward_arclength_mm": float(arc_records[:, 0].sum()/2),
            "total_outward_arclength_mm": float(arc_records[:, 0].sum()/2),
            "median_inward_minus_outward_depth_mm": float(np.median(arc_records[:, 1]-arc_records[:, 2])),
            "blue": BLUE,
            "red": RED,
            "blue_source": "Archival photograph B margin stroke RGB (23, 100, 219).",
            "definition": "Equal polygon arclength per contour; inward half maximizes mean distance to external specimen envelope among vertex-anchored or antipodal splits.",
        },
        "scope": "Geometric contour halves; no inferred growth direction, tissue identity, connected three-dimensional channel network, or flow.",
    }
    return (raw, envelope, gaps, ym, zm, extent, inward, outward), record


def ct_axes(ax, data, full_detail=False):
    raw, envelope, _, _, _, extent, inward, outward = data
    display = np.ma.array(raw, mask=~envelope)
    gray = matplotlib.colormaps["gray"].with_extremes(bad="#07121c")
    ax.imshow(display, cmap=gray, vmin=WINDOW[0], vmax=WINDOW[1], origin="lower",
              extent=extent, interpolation="none")
    stroke = .42 if full_detail else .16
    ax.add_collection(LineCollection(inward, colors=BLUE, linewidths=stroke, zorder=3))
    ax.add_collection(LineCollection(outward, colors=RED, linewidths=stroke, zorder=3))
    ax.set(xlabel="Y (mm)", ylabel="Z (mm)", xlim=extent[:2], ylim=extent[2:])
    if not full_detail:
        ax.xaxis.label.set_size(4.5)
        ax.yaxis.label.set_size(4.5)
        ax.tick_params(labelsize=4.5, length=1.6, pad=1)
        ax.xaxis.labelpad = 1
        ax.yaxis.labelpad = 1


def detailed_ct_plate(data, record):
    _, _, gaps, ym, zm, _, _, _ = data
    local = ndimage.uniform_filter(gaps.astype(float), size=160)
    zi, yi = np.unravel_index(local.argmax(), local.shape)
    radius = 2.1
    yrange = [ym[yi] - radius, ym[yi] + radius]
    zrange = [zm[zi] - radius, zm[zi] + radius]
    fig, axes = plt.subplots(ncols=2, figsize=(8.0, 6.1), gridspec_kw={"width_ratios": [1, 1.15]})
    fig.subplots_adjust(left=.09, right=.97, top=.86, bottom=.215, wspace=.26)
    for ax in axes:
        ct_axes(ax, data, full_detail=True)
        ax.tick_params(labelsize=8)
        ax.xaxis.label.set_size(9)
        ax.yaxis.label.set_size(9)
    axes[1].set(xlim=yrange, ylim=zrange)
    axes[0].add_patch(plt.Rectangle((yrange[0], zrange[0]), 2*radius, 2*radius,
                                   color="#ffc54e", fill=False, linewidth=.7))
    axes[0].set_title("Complete maximal acquired X section", fontsize=10)
    axes[1].set_title("Outlines at increased display magnification", fontsize=10)
    fig.suptitle("Internal features on the native 18 μm grid  |  X = 17.658 mm (LPS)",
                 fontsize=13, weight="bold", y=.96)
    fig.text(.09, .111, "Blue  |  Inward half of each low-attenuation outline", color=BLUE, fontsize=9)
    fig.text(.09, .078, "Red   |  Outward half, at the same contour length", color=RED, fontsize=9)
    fig.text(.09, .041, "Halves are oriented by distance to the outer silhouette. Growth direction is unmeasured.", fontsize=8)
    path = FIGURES / "Figure1_d2_native_CT_channel_halves.pdf"
    fig.savefig(path, dpi=600)
    fig.savefig(path.with_suffix(".png"), dpi=600)
    plt.close(fig)
    record["magnification_ROI_YZ_mm"] = [yrange, zrange]
    record["standalone_plate_sha256"] = sha256(path)


def notebook_plate():
    folder = PROJECT / "output/ct_profiles_2026-11-09"
    model = folder / "models/Notebook_Megalodon_no_human_raw_fields.npz"
    review = json.loads((folder / "review/model_no_human.json").read_text())
    source_height = review["human_height_source_units"]
    assumed_height_m = 1.80
    scale_bar_source_units = source_height / assumed_height_m
    with np.load(model) as archive:
        coordinates, faces, field = [archive[key] for key in ("vertices", "faces", "delta_kappa1")]
    assert len(faces) == review["retained_faces"]
    assert len(coordinates) == review["retained_vertices"]
    model_length_source_units = float(np.ptp(coordinates[:, 2]))
    assert abs(model_length_source_units - review["fish_longitudinal_length_source_units"]) < 1e-9
    model_total_length_m = model_length_source_units / scale_bar_source_units
    norm, _, _ = colour_norm()
    colour = norm(field)
    xyz = np.column_stack([-coordinates[:, 2], coordinates[:, 1], coordinates[:, 0]])
    xyz -= (xyz.min(axis=0) + xyz.max(axis=0)) / 2
    native_mesh = pv.PolyData(xyz, np.c_[np.full(len(faces), 3), faces].ravel())
    native_mesh["display"] = colour
    width, height = 3360, 1280
    parallel_scale = 5.4
    view = pv.Plotter(off_screen=True, window_size=(width, height))
    view.set_background("white")
    view.add_mesh(native_mesh, scalars="display", cmap="RdBu_r", clim=(0, 1),
                  lighting=False, show_scalar_bar=False)
    view.camera_position = [(0, 0, 80), (0, 0, 0), (0, 1, 0)]
    view.enable_parallel_projection()
    view.camera.parallel_scale = parallel_scale
    view.render()
    raster = view.screenshot(return_img=True)
    view.close()
    assert raster.shape[:2] == (height, width)
    yy, xx = np.where(np.any(raster[:, :, :3] < 245, axis=2))
    crop = (max(0, int(xx.min()) - 24), max(0, int(yy.min()) - 24),
            min(width, int(xx.max()) + 25), min(height, int(yy.max()) + 25))
    dark = Image.fromarray(raster).crop(crop)
    path = FIGURES / "notebook_delta_kappa1_no_human_full.png"
    dark.save(path)
    scale_bar_pixels = scale_bar_source_units * height / (2 * parallel_scale)
    assert 0 < scale_bar_pixels < dark.width / 4
    return path, scale_bar_pixels, {
        "source": str(model.relative_to(PROJECT)),
        "source_npz_sha256": sha256(model),
        "faces": len(faces),
        "vertices": len(coordinates),
        "assumed_human_reference_height_m": assumed_height_m,
        "archive_human_reference_height_source_units": source_height,
        "source_units_per_nominal_display_metre": scale_bar_source_units,
        "display_bar_pixels_in_original_raster": scale_bar_pixels,
        "scale_bars_m": [1, 10],
        "model_longitudinal_span_source_units": model_length_source_units,
        "illustrative_model_total_length_m": model_total_length_m,
        "length_definition": "Axial range from the rostral tip to the posterior caudal-fin tip in lateral projection.",
        "anatomical_length_reference": "10.26879/1502",
        "orientation": "Lateral orthographic (-Z,Y,X); dorsal +Y upward",
        "scope": "Illustrative model scale conditional on an assumed 1.80 m height for the removed "
                 "reference object. Curvature retains inverse source units.",
    }


def assemble(ct, notebook, scale_px, jaw, model_total_length_m, *, compact_context=False,
             deformation_image=None):
    fig = layout.canvas(183, 94)
    txt = layout.txt
    axis = layout.axmm

    def picture(name, x, y, w, h):
        layout.picture(axis(fig, x, y, w, h), FIGURES / name)

    for j, (name, title) in enumerate([
        ("specimen_photo_a_matte.png", "a  Photograph"), ("specimen_photo_b_matte.png", "b  Photograph"),
        ("intro_render_frame.png", "c  Recovered frame"),
    ]):
        left = j * 30.5
        if j < 2:
            photo_axes(axis(fig, left, 47, 29, 43), 'ab'[j])
        else:
            picture(name, left, 47, 29, 43)
        txt(fig, left, 92, title, 6.5, va="top")
    for j, title in enumerate(("Front", "Oblique", "Reverse*")):
        left = 96 + j * 29
        picture(f"appearance_natural_{j}.png", left, 69, 26, 19)
        picture(f"archive_reference_palette_view_{j}.png", left, 46, 26, 19)
        txt(fig, left+13, 91, title, 6.2, ha="center")
    txt(fig, 94, 66, "Natural appearance (* inferred reverse)", 5.7)
    txt(fig, 94, 45, "Archive σvM\n(MPa), linear", 4.7, va="top")
    palette = json.loads((PAPER / "numerics/reference_palette_512.json").read_text())
    reference_cmap = ListedColormap(np.array(palette["RGBA_8bit"]) / 255)
    bar = fig.colorbar(plt.cm.ScalarMappable(
        norm=plt.Normalize(.05676644283690944, .32688821709539363), cmap=reference_cmap),
        cax=axis(fig, 122, 44, 56, 1.1), orientation="horizontal", extend="both", extendfrac=.025)
    bar.set_ticks([.06, .10, .20, .30], labels=["0.06", "0.10", "0.20", "0.30"])
    bar.ax.tick_params(labelsize=4.6, pad=.8)
    photo_axes(axis(fig, 0, 14, 27, 24), 'b', detail=True, root_up=True)
    txt(fig, 13.5, 42, "d1  Cervical detail · root up", 5.6, ha="center", va="top")
    txt(fig, 13.5, 5.2, "Cyan: colour break", 4.6, ha="center", color="#137590")
    txt(fig, 13.5, 2.8, "Gold: ridge ends", 4.6, ha="center", color="#845107")

    txt(fig, 42, 42, "d2  Maximal acquired CT", 5.8, ha="center", va="top")
    ct_axes(axis(fig, 30.3, 9, 24.8, 29), ct)
    txt(fig, 41.7, 1.75, "Inward half", 4.5, ha="right", color=BLUE)
    txt(fig, 42.8, 1.75, "Outward half", 4.5, ha="left", color=RED)

    if compact_context:
        txt(fig, 79, 39, "e1  Body-form context", 5.8, ha="center", color=INK)
        model_ax = axis(fig, 61, 19, 36, 16)
        legend_axis = axis(fig, 64, 9, 30, 1.2)
        model_label = f"Illustrative TL {model_total_length_m:.1f} m"
        legend_label = r"Notebook $\Delta\kappa_1$ (inverse model units)"
    else:
        txt(fig, 79, 39, r"e1  Notebook $\Delta\kappa_1$", 6.3, ha="center")
        model_ax = axis(fig, 56, 17, 46, 20)
        legend_axis = axis(fig, 60, 9, 39, 1.6)
        model_label = f"Model TL {model_total_length_m:.1f} m*"
        legend_label = "Inverse source units  |  *Illustrative scale"
    layout.picture(model_ax, notebook)
    with Image.open(notebook) as model_image:
        model_width, model_height = model_image.size
    model_ax.set(xlim=(-.5, model_width-.5), ylim=(model_height+150, -.5))
    bar_y = model_height+32
    for first, length, divisions in ((model_width*.08, 10, 5),
                                     (model_width*.71, 1, 1)):
        length_px = scale_px*length
        step = length_px/divisions
        assert first+length_px < model_width
        for i in range(divisions):
            model_ax.add_patch(Rectangle((first+i*step, bar_y), step, 24,
                                         linewidth=.55, edgecolor=INK,
                                         facecolor=INK if i % 2 == 0 else "white"))
        model_ax.text(first+length_px/2, bar_y+57, f"{length} m",
                      va="top", ha="center", fontsize=5.2, color=INK)
    txt(fig, 79, 14.3, model_label, 5.5, ha="center", color=INK)
    norm, neg, pos = colour_norm()
    bar = fig.colorbar(plt.cm.ScalarMappable(norm=norm, cmap="RdBu_r"),
                       cax=legend_axis, orientation="horizontal", extend="both", extendfrac=.025)
    if compact_context:
        bar.set_ticks([-neg, 0, pos], labels=[f"{-neg:.0f}", "0", f"{pos:.0f}"])
    else:
        bar.set_ticks([-neg, -100, 0, 100, pos], labels=[f"{-neg:.0f}", "−100", "0", "100", f"{pos:.0f}"])
    bar.ax.tick_params(labelsize=4.9, pad=1)
    txt(fig, 79, 1.5, legend_label, 4.8, ha="center")

    picture(deformation_image or "stvk_tooth_signed_deformed_x2_100mm.png", 106, 6, 31, 29)
    txt(fig, 122, 39, "e2  Finite deformation", 6.1, ha="center")
    txt(fig, 120, 3, "100 mm; u ×2 display", 5.5, ha="center")
    limits = json.loads((REVIEW / "current_field_display.json").read_text())
    limit, tau = limits["tooth_signed_limit_MPa"], limits["tooth_signed_asinh_scale_MPa"]
    norm = FuncNorm((lambda x: np.arcsinh(x/tau), lambda x: tau*np.sinh(x)),
                    vmin=-limit, vmax=limit)
    bar = fig.colorbar(plt.cm.ScalarMappable(norm=norm, cmap="RdBu_r"),
                       cax=axis(fig, 139, 12, 1.3, 19), extend="both", extendfrac=.035)
    bar.set_ticks([-limit, 0, limit], labels=[f"{-limit:.0f}", "0", f"{limit:.0f}"])
    bar.ax.tick_params(labelsize=5, pad=1)
    txt(fig, 140, 33, r"$\sigma_{ll}$ MPa", 5.3, ha="center")

    picture(jaw.name, 153, 8, 28, 28)
    txt(fig, 167, 41, "f  Wide-band jaw FEA", 6, ha="center", va="top")
    txt(fig, 167, 5, "E = 150 MPa; ν = 0.3", 5.2, ha="center")
    txt(fig, 167, 1, "Traction = 10 kPa", 5.2, ha="center")
    fig.set_size_inches(183/25.4, 90/25.4)
    layout.F = FIGURES
    layout.V = PAPER / "svg"
    layout.save(fig, "geometry_pack_1_scale_context" if compact_context else FIGURE_NAME)


def archived_figure_inputs():
    """Read the verified Figure 1 crop and body render without recomputing either."""
    prior = json.loads((REVIEW / REPORT_NAME).read_text())
    scan_record = prior["d2"]
    scan = PAPER / "numerics/figure1_d2_native_channel_halves.npz"
    assert scan_record["numeric_masks_sha256"] == sha256(scan)
    with np.load(scan) as archive:
        np.testing.assert_equal(archive["source_X_index"], X_INDEX)
        np.testing.assert_equal(archive["source_spacing_mm"], SPACING)
        raw, envelope, gaps, ym, zm = [archive[key] for key in (
            "signed16", "display_envelope", "enclosed_low_attenuation", "Y_mm", "Z_mm")]
        inward, outward = [np.split(archive[f"{key}_YZ_mm"], archive[f"{key}_offsets"][1:-1])
                           for key in ("inward", "outward")]
    extent = scan_record["absolute_LPS_edge_extent_YZ_mm"]
    model_record = prior["e1"]
    body = FIGURES / "notebook_delta_kappa1_no_human_full.png"
    scale_px = model_record["display_bar_pixels_in_original_raster"]
    model_record["context_reference_doi"] = "10.26879/1502"
    model_record["inset_plot_box_width_mm"] = 36
    model_record["prior_plot_box_width_mm"] = 46
    model_record["render_sha256"] = sha256(body)
    return (raw, envelope, gaps, ym, zm, extent, inward, outward), body, scale_px, prior


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--compact-context", action="store_true",
                        help="reuse verified CT and body assets and reduce the whole-body inset")
    parser.add_argument("--deformation-image", type=Path,
                        help="alternate e2 raster on the same colour scale and deformation convention")
    options = parser.parse_args()
    jaw = FIGURES / "jaw_wide_native_vm_smooth.png"
    assert jaw.is_file(), "Render the full-source jaw field before composing Figure 1."
    if options.compact_context:
        scan, body, scale_px, report = archived_figure_inputs()
        assemble(scan, body, scale_px, jaw, report["e1"]["illustrative_model_total_length_m"],
                 compact_context=True, deformation_image=options.deformation_image)
        report["artwork_sha256"] = sha256(FIGURES / "geometry_pack_1_scale_context.pdf")
        if options.deformation_image is not None:
            source = FIGURES / options.deformation_image
            report["e2_render_sha256"] = sha256(source)
        (REVIEW / "figure1_scale_context.json").write_text(json.dumps(report, indent=2) + "\n")
        return
    scan, scan_record = select_annotated_scan()
    detailed_ct_plate(scan, scan_record)
    path, scale_px, model_record = notebook_plate()
    assemble(scan, path, scale_px, jaw, model_record["illustrative_model_total_length_m"])
    result = {
        "status": "completed",
        "d2": scan_record,
        "e1": model_record,
        "f_source": jaw.name,
        "f_source_sha256": sha256(jaw),
        "photographic_transition": cervical_record(),
        "artwork_sha256": sha256(FIGURES / f"{FIGURE_NAME}.pdf"),
    }
    (REVIEW / REPORT_NAME).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
