#!/usr/bin/env python3
"""Verify same-driver window-size and equal-volume shape controls around the Rcr CT pore."""

import argparse
import json
from pathlib import Path
import tempfile
import time

import numpy as np
from scipy import ndimage as ndi

import coupled_ct_submodels as ct_model


WINDOWS = (56, 72, 88)
REFERENCE_WINDOW = 72
COLLAR_PITCHES = 2


def enclosed_box(cavity, size):
    """Crop a concentric cubical window on the unchanged integer native grid."""
    occupied = np.argwhere(cavity)
    midpoint = (occupied.min(0) + occupied.max(0) + 1) // 2
    start = midpoint - size // 2
    end = start + size
    if np.any(start < 0) or np.any(end > cavity.shape):
        raise ValueError("Window exceeds the documented source ROI")
    box = cavity[tuple(slice(lo, hi) for lo, hi in zip(start, end))]
    if int(box.sum()) != len(occupied):
        raise ValueError("Window truncates the selected CT void")
    return box, start


def equal_volume_shapes(cavity):
    """Digitise shapes by distance rank with exactly the measured void voxel count."""
    source = np.argwhere(cavity)
    center = source.mean(0)
    eigvals, eigvecs = np.linalg.eigh(np.cov(source, rowvar=False))
    offsets = np.indices(cavity.shape, dtype=float).reshape(3, -1).T - center
    metrics = {
        "sphere": np.einsum("ij,ij->i", offsets, offsets),
        "ellipsoid": np.sum((offsets @ eigvecs) ** 2 / eigvals, axis=1),
    }
    shapes = {}
    for name, metric in metrics.items():
        fitted = np.argsort(metric, kind="stable")[:len(source)]
        shape = np.zeros(cavity.size, dtype=bool)
        shape[fitted] = True
        shapes[name] = shape.reshape(cavity.shape)
    return shapes, center, eigvals, eigvecs


def evaluate(cavity, gradient, kernel, workers, pitch, material=None):
    points = np.argwhere(cavity)
    clearance = int(min(points.min(), (np.asarray(cavity.shape) - 1 - points).min()))
    if clearance <= COLLAR_PITCHES:
        raise ValueError("Pore collar intersects a displacement boundary")
    if ndi.label(cavity, structure=ndi.generate_binary_structure(3, 1))[1] != 1:
        raise ValueError("Cavity must be one six-connected voxel component")
    if material is None:
        material = ~cavity
    if material.shape != cavity.shape or np.any(material & cavity):
        raise ValueError("Material mask must exclude the whole selected cavity")
    collar = material & (ndi.distance_transform_edt(~cavity) <= COLLAR_PITCHES + 1e-8)
    indices = np.argwhere(collar)
    begin = time.perf_counter()
    displacement, filled, checks = ct_model.solve_mask(material, gradient, kernel, workers)
    corners = indices[:, None] + ct_model.OFFSETS
    values = displacement[tuple(corners.transpose(2, 0, 1))]
    grad = values.transpose(0, 2, 1) @ ct_model.shape_gradient(np.full(3, .5))
    stress = ct_model.strain_to_stress(grad)
    filled_mises = float(ct_model.mises(filled))
    mises = ct_model.mises(stress)
    q95 = float(np.quantile(mises, .95, method="inverted_cdf"))
    principal_q95 = float(np.quantile(np.linalg.eigvalsh(stress)[:, -1], .95,
                                      method="inverted_cdf"))
    return {
        "side_voxels": cavity.shape[0],
        "side_mm": cavity.shape[0] * pitch,
        "minimum_clearance_voxels": clearance,
        "void_voxels": len(points),
        "void_volume_mm3": len(points) * pitch**3,
        "all_void_voxels": int((~material).sum()),
        "collar_cells": len(indices),
        "centroid_voxel_zyx": points.mean(0).tolist(),
        "filled_vm_MPa": filled_mises,
        "porous_vm_q95_MPa": q95,
        "q95_ratio": q95 / filled_mises,
        "porous_principal_max_q95_MPa": principal_q95,
        "collar_paired_bias_MPa": float(np.mean(mises - filled_mises)),
        "collar_paired_MSE_MPa2": float(np.mean((mises - filled_mises)**2)),
        "wall_seconds": time.perf_counter() - begin,
        **checks,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--retain-nearby", action="store_true",
                        help="Also solve the nested windows with all segmented CT voids retained")
    args = parser.parse_args()
    source_dir = ct_model.OUT
    output = args.output or source_dir / "cavity_window_shape_controls.json"
    source_path = source_dir / "Rcr.npz"
    coupling_path = source_dir / "coupling.json"
    coupling = json.loads(coupling_path.read_text())
    source_case = next(case for case in coupling["cases"] if case["name"] == "Rcr")
    gradient = np.asarray(source_case["boundary_gradient"])
    with np.load(source_path) as arrays:
        cavity = arrays["cavity"]
        original_material = arrays["mask"]
        pitch = float(arrays["voxel_pitch_mm"])
    if int(cavity.sum()) != source_case["selected_cavity_voxels"]:
        raise ValueError("Selected CT component does not match the archived solve")

    natural, common_start = enclosed_box(cavity, REFERENCE_WINDOW)
    shapes, center, eigvals, eigvecs = equal_volume_shapes(natural)
    record = {
        "status": "running",
        "description": "Archived Rcr trace 28 cavity alone; surrounding material otherwise filled. All faces driven by the same archived affine gradient. Each reported Q95 uses a two-native-voxel Euclidean collar.",
        "Rcr_archive_sha256": ct_model.digest(source_path),
        "coupling_archive_sha256": ct_model.digest(coupling_path),
        "trace_id": source_case["trace_id"],
        "pitch_mm": pitch,
        "collar_mm": COLLAR_PITCHES * pitch,
        "gradient": gradient.tolist(),
        "E_MPa": ct_model.E_MPA,
        "poisson": ct_model.NU,
        "shape_control": {
            "common_window_voxels": REFERENCE_WINDOW,
            "native_centroid_voxel_zyx": center.tolist(),
            "centred_covariance_eigenvalues_voxel2": eigvals.tolist(),
            "principal_directions_zyx_columns": eigvecs.tolist(),
            "digitisation": "Exactly the native void count. Sphere ranks Euclidean distance; ellipsoid ranks the native covariance metric. Stable row-major tie breaking.",
        },
        "cases": [],
    }

    def solve(name, void, start, kernel, material=None):
        print(f"{name} {void.shape[0]}³: {void.sum()} void voxels", flush=True)
        result = evaluate(void, gradient, kernel, args.workers, pitch, material)
        result.update(name=name, start_in_Rcr_archive_zyx=start.tolist())
        record["cases"].append(result)
        output.write_text(json.dumps(record, indent=2) + "\n")
        print(json.dumps(result), flush=True)

    # Compile into a scratch directory, preserving the archived operator binary.
    with tempfile.TemporaryDirectory(prefix="cavity-controls-") as work:
        ct_model.OUT = Path(work)
        kernel = ct_model.compile_operator()
        for size in WINDOWS:
            void, start = enclosed_box(cavity, size)
            solve("CT window", void, start, kernel)
        for name, void in shapes.items():
            solve(name, void, common_start, kernel)
        if args.retain_nearby:
            record["retained_neighbours_interpretation"] = (
                "All original segmented voids in each crop are retained. Varying the outer "
                "window perturbs the location of the prescribed affine boundary and the "
                "neighbouring voids included in the domain."
            )
            for size in WINDOWS:
                void, start = enclosed_box(cavity, size)
                extent = tuple(slice(lo, lo + size) for lo in start)
                solve("CT window with neighbouring voids", void, start, kernel,
                      original_material[extent])
    window_results = record["cases"][:len(WINDOWS)]
    if len({r["collar_cells"] for r in window_results}) != 1:
        raise ValueError("The CT window tests must retain the same collar cells")
    if args.retain_nearby:
        neighbours = record["cases"][-len(WINDOWS):]
        if len({r["collar_cells"] for r in neighbours}) != 1:
            raise ValueError("The retained-neighbour tests must retain the same collar cells")
    record["status"] = "verified"
    output.write_text(json.dumps(record, indent=2) + "\n")


if __name__ == "__main__":
    main()
