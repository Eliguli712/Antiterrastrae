#!/usr/bin/env python3
"""Same-domain P1/P2 comparison on archived straight-sided volume meshes."""
from pathlib import Path
import argparse
import hashlib
import sys, json, time, gc, csv
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import cg
from numpy.polynomial.legendre import leggauss

N = Path(__file__).resolve().parents[1]
P = N.parents[2]
B = P / 'output/pdf/debunk_myth_full_reconstruction_2026-10-31'
sys.path.insert(0, str(B / 'vendor'))
sys.path.insert(0, str(B / 'numerics'))
import pyamg
import solver_core as core

OUT = N / 'review/p1_p2_run_002'
DATA = N / 'numerics/p1_p2_common_domain'
EDGES = np.array([[0,1],[0,2],[0,3],[1,2],[1,3],[2,3]])
LA, MU = 29e9, 28.5e9
I = np.eye(3)


def gradients(g, bary):
    result = np.empty((len(g), len(bary), 10, 3))
    result[:,:,:4] = (4*bary[None,:,:,None]-1)*g[:,None]
    for k,(i,j) in enumerate(EDGES):
        result[:,:,4+k] = 4*(bary[None,:,i,None]*g[:,None,j]+bary[None,:,j,None]*g[:,None,i])
    return result


def duffy(n):
    x,w=leggauss(n);x=(x+1)/2;w=w/2
    r,s,t=np.meshgrid(x,x,x,indexing='ij');wr,ws,wt=np.meshgrid(w,w,w,indexing='ij')
    bary=np.stack([(1-r)*(1-s)*(1-t),r,(1-r)*s,(1-r)*(1-s)*t],axis=-1).reshape(-1,4)
    weights=(wr*ws*wt*(1-r)**2*(1-s)).ravel()*6
    assert np.all(weights>0) and abs(weights.sum()-1)<1e-13
    return bary,weights


def tensor(gradient):
    eps=(gradient+gradient.swapaxes(-1,-2))/2
    stress=LA*np.trace(eps,axis1=-2,axis2=-1)[...,None,None]*I+2*MU*eps
    dev=stress-np.trace(stress,axis1=-2,axis2=-1)[...,None,None]*I/3
    vm=np.sqrt(1.5*np.sum(dev*dev,axis=(-2,-1)))
    tensile=np.maximum(np.linalg.eigvalsh(stress)[...,-1],0)
    return stress,vm,tensile,eps


def wquant(v,w,probabilities=(.9,.95,.99)):
    order=np.argsort(v);cs=np.cumsum(w[order]);idx=np.searchsorted(cs,np.asarray(probabilities)*cs[-1],side='left')
    return v[order[np.minimum(idx,len(order)-1)]]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--level', choices=('L0', 'L1'), default='L0')
    parser.add_argument('--field-only', action='store_true',
                        help='Export the verified field and exact equilibrium checks for an image.')
    args = parser.parse_args()
    level = args.level
    data = DATA if level == 'L0' else N / 'numerics/p1_p2_L1_display'
    report = OUT if level == 'L0' else N / 'review/p1_p2_L1_display'
    source = B / 'numerics' / level / 'solution.npz'
    np.random.seed(20261119)
    start=time.monotonic()
    data.mkdir(exist_ok=True)
    report.mkdir(exist_ok=True)
    if level != 'L0' and (data/'solution_P2.npz').exists():
        raise FileExistsError(data/'solution_P2.npz')
    a=np.load(source);p=a['points_m'];t=a['tets'];u1=a['displacement_m']
    expected = {'L0': (55852, 13584, 90728), 'L1': (271300, 55315, 395231)}[level]
    assert (len(t),len(p))==expected[:2]
    edge=p[t[:,1:]]-p[t[:,:1]];inv=np.linalg.inv(edge);g=np.empty((len(t),4,3));g[:,1:]=inv.transpose(0,2,1);g[:,0]=-g[:,1:].sum(1);V=abs(np.linalg.det(edge))/6
    original_edges=np.sort(t[:,EDGES].reshape(-1,2),axis=1)
    edges,lookup=np.unique(original_edges,axis=0,return_inverse=True)
    nodes=np.vstack([p,p[edges].mean(1)]);conn=np.column_stack([t,len(p)+lookup.reshape(-1,6)])
    assert len(nodes)==expected[2]
    keys=edges[:,0].astype(np.int64)*len(p)+edges[:,1]
    def midpoints(face):
        fe=np.sort(face[:,[[0,1],[1,2],[2,0]]].reshape(-1,2),axis=1)
        k=fe[:,0].astype(np.int64)*len(p)+fe[:,1];where=np.searchsorted(keys,k);assert np.array_equal(keys[where],k)
        return (len(p)+where).reshape(-1,3)
    f,area,normal=core.boundary_faces(p,t)
    assert np.array_equal(f,a['boundary_faces'])
    loaded=a['loaded_face_indices'];face_mid=midpoints(f)
    force=np.zeros_like(nodes)
    for j in range(3):np.add.at(force,face_mid[loaded,j],-1e6*area[loaded,None]*normal[loaded]/3)
    if level == 'L0':
        assert abs(area[loaded].sum()*1e6-483.28672170117585)<1e-7
    force_p1 = np.zeros_like(p)
    for j in range(3):
        np.add.at(force_p1, f[loaded,j], -1e6*area[loaded,None]*normal[loaded]/3)
    np.testing.assert_allclose(force.sum(0),force_p1.sum(0),rtol=1e-12,atol=1e-8)
    np.testing.assert_allclose(np.cross(nodes,force).sum(0),np.cross(p,force_p1).sum(0),rtol=1e-11,atol=1e-9)
    print(f'{level} P2 assembly on {len(t):,} cells, {3*len(nodes):,} total DOF',flush=True)
    fixed=np.zeros(len(nodes),bool);fixed[a['fixed_node_indices']]=True;fixed[len(p):]=fixed[edges].all(1)
    # This is the same zero-displacement support subcomplex: fixed vertices and
    # their complete edges/faces/cells. It is not a new anatomical attachment.
    free=np.setdiff1d(np.arange(3*len(nodes)),(3*np.flatnonzero(fixed)[:,None]+np.arange(3)).ravel())
    alpha=.5854101966249685;beta=.1381966011250105
    bary=np.full((4,4),beta);np.fill_diagonal(bary,alpha)
    rows=np.empty(len(t)*900,np.int32);cols=np.empty_like(rows);vals=np.empty(len(t)*900)
    for begin in range(0,len(t),1500):
        sl=slice(begin,min(begin+1500,len(t)));G=gradients(g[sl],bary)
        K=LA*np.einsum('eqai,eqbk->eaibk',G,G)/4+MU*np.einsum('eqak,eqbi->eaibk',G,G)/4
        K+=MU*np.einsum('eab,ik->eaibk',np.einsum('eqaj,eqbj->eab',G,G)/4,I)
        K=(K*V[sl,None,None,None,None]).reshape(-1,30,30)
        d=(3*conn[sl,:,None]+np.arange(3)).reshape(-1,30).astype(np.int32);dest=slice(begin*900,sl.stop*900)
        rows[dest]=np.broadcast_to(d[:,:,None],K.shape).ravel();cols[dest]=np.broadcast_to(d[:,None,:],K.shape).ravel();vals[dest]=K.ravel()
    A=coo_matrix((vals,(rows,cols)),shape=(3*len(nodes),3*len(nodes))).tocsr();del rows,cols,vals,K,G;gc.collect()
    print('P2 assembled',A.shape,'nnz',A.nnz,flush=True)
    # Orthogonal, hand-computable affine traction and rigid-motion checks.
    affine=np.array([[.002,.001,-.0003],[.0002,-.001,.0001],[.0004,.0001,.0005]])
    patch=nodes@affine.T+np.array([.001,-.002,.0004]);sig=LA*np.trace(affine)*I+MU*(affine+affine.T)
    patch_force=np.zeros_like(nodes);traction=normal@sig.T
    for j in range(3):np.add.at(patch_force,face_mid[:,j],traction*area[:,None]/3)
    patch_error=np.linalg.norm(A@patch.ravel()-patch_force.ravel())/np.linalg.norm(patch_force)
    rigid=nodes@np.array([[0.,-1.,.4],[1.,0.,-.2],[-.4,.2,0.]]).T+.01
    rigid_error=np.linalg.norm(A@rigid.ravel())/(np.linalg.norm(A.data)*np.linalg.norm(rigid))
    assert patch_error<2e-10 and rigid_error<1e-12,(patch_error,rigid_error)
    embedded=np.vstack([u1,u1[edges].mean(1)])
    embedded_energy=float(embedded.ravel()@(A@embedded.ravel()))/2
    p1stress,p1vm,p1tens,p1eps=tensor(np.einsum('eai,eaj->eij',u1[t],g))
    p1_energy=float(np.sum(np.einsum('eij,eij->e',p1stress,p1eps)*V))/2
    assert abs(embedded_energy/p1_energy-1)<1e-10
    p1_load_work=float((embedded*force).sum());assert abs(p1_load_work/(2*p1_energy)-1)<1e-8
    Af=A[free][:,free].tocsr();rhs=force.ravel()[free]
    x=(nodes-nodes.mean(0))/np.ptp(nodes,axis=0).max();modes=np.zeros((len(nodes),3,6));modes[:,:,:3]=I
    for j in range(3):modes[:,:,j+3]=np.cross(I[j],x)
    print('Building P2 AMG',len(free),'free DOF',flush=True)
    ml=pyamg.smoothed_aggregation_solver(Af.tobsr(blocksize=(3,3)),B=modes.reshape(-1,6)[free],symmetry='symmetric',max_coarse=250,max_levels=12,presmoother=('block_gauss_seidel',{'sweep':'symmetric'}),postsmoother=('block_gauss_seidel',{'sweep':'symmetric'}))
    it=[0]
    def iteration(v):
        it[0]+=1
        if it[0]%100==0:print('P2 CG',it[0],flush=True)
    sol,code=cg(Af,rhs,x0=embedded.ravel()[free],M=ml.aspreconditioner(),rtol=2e-10,atol=0,maxiter=2500,callback=iteration)
    assert code==0,code
    u=np.zeros(3*len(nodes));u[free]=sol;u=u.reshape(-1,3);res=(A@u.ravel()).reshape(-1,3)-force
    residual=float(np.linalg.norm(res.ravel()[free])/np.linalg.norm(rhs));assert residual<1e-7
    reaction=np.where(fixed[:,None],res,0);resultant=force.sum(0)
    balance=float(np.linalg.norm(reaction.sum(0)+resultant)/np.linalg.norm(resultant))
    moment=float(np.linalg.norm(np.cross(nodes,force+reaction).sum(0))/(np.linalg.norm(resultant)*np.ptp(nodes,axis=0).max()))
    U2=float(u.ravel()@(A@u.ravel()))/2;work=float((u*force).sum());error=u-embedded
    gap=float(error.ravel()@(A@error.ravel()))/2
    orthogonality=float(abs(embedded.ravel()@(A@error.ravel()))/(2*U2))
    assert max(balance,moment,abs(work/(2*U2)-1),orthogonality)<2e-6
    assert abs((U2-p1_energy-gap)/U2)<2e-8
    del ml,Af;gc.collect()
    if args.field_only:
        # A separate exact tetrahedral quadrature of the recovered stress
        # repeats the force and energy readback without the stiffness matrix.
        force_check = np.zeros_like(nodes)
        recovered_energy = 0.
        for begin in range(0,len(t),4000):
            sl=slice(begin,min(begin+4000,len(t)))
            G=gradients(g[sl],bary)
            gradient=np.einsum('eai,eqaj->eqij',u[conn[sl]],G)
            sig,_,_,eps=tensor(gradient)
            recovered_energy+=float(np.einsum('eqij,eqij,e->',sig,eps,V[sl]))/8
            recovered=np.einsum('eqij,eqaj,e->eai',sig,G,V[sl])/4
            for j in range(10):
                np.add.at(force_check,conn[sl,j],recovered[:,j])
        readback=float(np.linalg.norm((force_check-force).ravel()[free])/np.linalg.norm(rhs))
        assert readback<2e-6 and abs(recovered_energy/U2-1)<1e-9
        solution=data/'solution_P2.npz'
        np.savez_compressed(solution, points_m=nodes, tets_P2=conn, displacement_m=u,
                            fixed_nodes=np.flatnonzero(fixed), load_force_N=force,
                            edge_vertex_pairs=edges, parent_P1_tets=t)
        with source.open('rb') as f_input:
            sha=hashlib.file_digest(f_input,'sha256').hexdigest()
        run=dict(status='passed',level=level,source=str(source.relative_to(P)),source_sha256=sha,
                 tetrahedra=len(t),P1_nodes=len(p),P2_nodes=len(nodes),P2_total_dof=3*len(nodes),
                 P2_free_dof=len(free),force_N=resultant.tolist(),loaded_area_mm2=float(area[loaded].sum()*1e6),
                 solve_residual=residual,force_balance=balance,moment_balance=moment,independent_force_readback=readback,
                 affine_patch_relative_error=float(patch_error),rigid_motion_error=float(rigid_error),
                 P1_energy_J=p1_energy,P2_energy_J=U2,quadrature_energy_J=recovered_energy,
                 energy_norm_gap_percent=float(100*np.sqrt(gap/U2)),Galerkin_orthogonality=orthogonality,
                 iterations=it[0],runtime_s=time.monotonic()-start)
        (data/'results.json').write_text(json.dumps(run,indent=2)+'\n')
        (report/'results.json').write_text(json.dumps(run,indent=2)+'\n')
        print(json.dumps(run,indent=2),flush=True)
        return
    masks_file=np.load(B/'numerics'/level/'region_masks.npz');masks={k:np.isin(np.arange(len(t)),masks_file[k]) for k in core.REGIONS};masks['support_adjacent']=np.isin(t,a['fixed_node_indices']).any(1)
    hm=np.linalg.norm(p[t[:,EDGES[:,0]]]-p[t[:,EDGES[:,1]]],axis=-1).max(1)*1000
    quadrature=[];last=None;finalrows=None
    for n in [3,5,7]:
        qb,qw=duffy(n);vm=np.empty((len(t),len(qw)));ten=np.empty_like(vm);energy=0.;force_check=np.zeros_like(nodes)
        for begin in range(0,len(t),500):
            sl=slice(begin,min(begin+500,len(t)));G=gradients(g[sl],qb);grad=np.einsum('eai,eqaj->eqij',u[conn[sl]],G);sig,vv,tt,eps=tensor(grad);vm[sl]=vv;ten[sl]=tt
            energy+=float(np.einsum('eqij,eqij,e,q->',sig,eps,V[sl],qw))/2
            fint=np.einsum('eqij,eqaj,e,q->eai',sig,G,V[sl],qw)
            for j in range(10):np.add.at(force_check,conn[sl,j],fint[:,j])
        readback=float(np.linalg.norm((force_check-force).ravel()[free])/np.linalg.norm(rhs));assert readback<2e-6 and abs(energy/U2-1)<1e-9
        reg=[]
        for name,mask in masks.items():
            weights=(V[mask,None]*qw).ravel();qvm=wquant(vm[mask].ravel(),weights)/1e6;qt=wquant(ten[mask].ravel(),weights)/1e6
            pvm=wquant(p1vm[mask],V[mask])/1e6;pt=wquant(p1tens[mask],V[mask])/1e6
            reg.append(dict(region=name,cells=int(mask.sum()),volume_mm3=float(V[mask].sum()*1e9),h_mm=wquant(hm[mask],V[mask],(.1,.5,.9)).tolist(),h_max_mm=float(hm[mask].max()),P1_vm_MPa=pvm.tolist(),P2_vm_MPa=qvm.tolist(),P1_tensile_MPa=pt.tolist(),P2_tensile_MPa=qt.tolist(),Q95_change_percent=float(100*(qvm[1]/pvm[1]-1))))
        current=np.array([v for row in reg for v in row['P2_vm_MPa']+row['P2_tensile_MPa']])
        change=None if last is None else float(np.max(abs(current-last)/np.maximum(abs(current),1e-8))*100)
        quadrature.append(dict(order=n,points_per_cell=len(qw),energy_J=energy,independent_force_readback=readback,max_percentile_change_percent=change));last=current;finalrows=reg
        print('P2 positive quadrature',n,'change',change,flush=True)
        del vm,ten;gc.collect()
        if n>=5 and change is not None and change<.2:break
    np.savez_compressed(data/'solution_P2.npz',points_m=nodes,tets_P2=conn,displacement_m=u,fixed_nodes=np.flatnonzero(fixed),load_force_N=force,edge_vertex_pairs=edges,parent_P1_tets=t)
    with (data/'region_mesh_sizes.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['region','cell','volume_mm3','maximum_edge_mm'])
        for name,mask in masks.items():writer.writerows((name,int(i),V[i]*1e9,hm[i]) for i in np.flatnonzero(mask))
    result=dict(status='completed',assertion_tested='One same-domain homogeneous P1/P2 pair; exact quadratic stiffness and traction; positive quadrature regional stress summaries.',mesh=f'Unchanged {level} straight-sided tetrahedral domain',tetrahedra=len(t),P1_nodes=len(p),P2_nodes=len(nodes),P2_free_dof=len(free),loaded_area_mm2=float(area[loaded].sum()*1e6),load_N=resultant.tolist(),same_support='P1 zero-displacement subcomplex; quadratic mid-edge nodes fixed iff both original vertices fixed.',lambda_Pa=LA,mu_Pa=MU,P1_energy_J=p1_energy,P2_energy_J=U2,discrete_energy_gap_J=gap,relative_energy_norm_gap_percent=float(100*np.sqrt(gap/U2)),force_balance=balance,moment_balance=moment,free_residual=residual,affine_patch_relative_error=float(patch_error),rigid_motion_error=float(rigid_error),P1_embedding_energy_relative_error=float(abs(embedded_energy/p1_energy-1)),Galerkin_orthogonality=orthogonality,iterations=it[0],quadrature=quadrature,regions=finalrows,scope='Same-polyhedron order comparison on the specified mesh. Pointwise peaks, brittle failure and the continuum error remain unresolved.',runtime_seconds=time.monotonic()-start)
    (data/'results.json').write_text(json.dumps(result,indent=2));(report/'results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
