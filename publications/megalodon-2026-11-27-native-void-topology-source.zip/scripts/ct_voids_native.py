"""Render enclosed void boundaries and section-clipped skeletons on native CT."""
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import binary_dilation, generate_binary_structure, label

PITCH = .018
INK = np.array([224, 185, 110], dtype=np.uint8)
CROSS = generate_binary_structure(2, 1)


def native_section(image, material, envelope, catalogue, axes, section, origin, crop):
    enclosed = envelope & ~material
    rim = binary_dilation(enclosed, structure=CROSS) & material
    shade = np.asarray(image).copy()
    shade[rim] = np.maximum(15, (shade[rim].astype(float) * .52)).astype(np.uint8)
    rgb = np.repeat(shade[...,None], 3, axis=-1)
    normal, = {0,1,2}.difference(axes)
    native_offset = (np.array(catalogue["original_mha_patient_offset_xyz_mm"])
                     - catalogue["registered_web_mesh_origin_xyz_mm"])
    centre = origin[normal]+PITCH*section
    plane_crop = origin[list(axes)] + PITCH*np.array(crop)
    path_mask = Image.new("1", image.size)
    paths, segments = 0, 0
    for record in catalogue["traces"]:
        points = np.asarray(record["points_registered_native_xyz_mm"])+native_offset
        mark = False
        for first, last in zip(points[:-1], points[1:]):
            a, b = first[normal]-centre, last[normal]-centre
            if min(a,b) >= PITCH/2 or max(a,b) <= -PITCH/2:
                continue
            lo,hi = sorted(((s-a)/(b-a) for s in (-PITCH/2,PITCH/2))) if a != b else (0.,1.)
            pa = first+max(lo,0)*(last-first)
            pb = first+min(hi,1)*(last-first)
            xy = np.rint((np.array([pa[list(axes)],pb[list(axes)]])-plane_crop)/PITCH).astype(int)
            draw = Image.new("1", image.size)
            ImageDraw.Draw(draw).line(list(map(tuple, xy)),fill=1,width=1)
            local = np.asarray(draw) & enclosed
            if local.any():
                path_mask.paste(1, (0,0,*image.size),Image.fromarray(local))
                segments += 1
                mark = True
        paths += mark
    active = np.asarray(path_mask)
    rgb[active] = INK
    _, connected = label(enclosed, structure=CROSS)
    return Image.fromarray(rgb), {
        "enclosed_components_4connected": int(connected),
        "enclosed_pixels": int(enclosed.sum()), "contour_pixels": int(rim.sum()),
        "verified_gold_pixels": int(active.sum()), "candidate_paths": paths,
        "candidate_segments": segments, "sampling_mm": PITCH,
    }
