"""Digitized cervical guides on the original specimen photographs.

Coordinates refer to the existing image crops, with x right and y down.
The lower trace follows the rootward ends of visible surface striations;
the crown-side trace follows the abrupt appearance change. These are
observational 2D guides and do not assign tissue or calibrate CT boundaries.
"""
import hashlib
import json
from pathlib import Path

import matplotlib.patheffects as effects
import numpy as np
from PIL import Image
from scipy.interpolate import PchipInterpolator

import revise_figures as layout


PAPER = Path(__file__).resolve().parents[1]
FIGURES = PAPER / 'figures'
COLOUR = '#8ee7f6'
ROOT = '#ffc36d'
POINTS = {
    'a': {
        'colour_break': [(160, 462), (194, 449), (235, 429), (277, 407),
                         (322, 385), (361, 363), (402, 348), (429, 345),
                         (453, 355), (473, 377)],
        'ridge_ends': [(169, 520), (192, 506), (222, 495), (258, 480),
                       (288, 469), (318, 455), (350, 444), (378, 440),
                       (410, 443), (441, 454), (468, 478)],
        'detail': (109, 318, 503, 577),
    },
    'b': {
        'colour_break': [(185, 699), (238, 661), (303, 618), (371, 567),
                         (439, 526), (504, 504), (557, 520), (619, 551),
                         (686, 582), (724, 582), (780, 622), (833, 659),
                         (859, 688)],
        'ridge_ends': [(196, 752), (242, 741), (294, 719), (345, 703),
                       (397, 676), (433, 665), (475, 650), (510, 642),
                       (550, 655), (591, 674), (635, 686), (680, 690),
                       (723, 700), (769, 719), (815, 746), (851, 761),
                       (873, 777)],
        'detail': (133, 455, 903, 822),
    },
}


def photo_axes(ax, view, detail=False, root_up=False, labels=False):
    source = FIGURES/f'specimen_photo_{view}_matte.png'
    image = Image.open(source)
    ax.imshow(image, interpolation='none')
    selection = POINTS[view]
    for key, colour, width, style in (
        ('colour_break', COLOUR, .78, (0, (2.4, 1.5))),
        ('ridge_ends', ROOT, 1.22, '-'),
    ):
        marks = np.asarray(selection[key])
        x = np.linspace(marks[0, 0], marks[-1, 0], 500)
        curve = PchipInterpolator(marks[:, 0], marks[:, 1])
        path = ax.plot(x, curve(x), color=colour, lw=width, ls=style,
                       solid_capstyle='round', zorder=4)[0]
        path.set_path_effects([effects.Stroke(linewidth=width+.9, foreground='#15202c'),
                               effects.Normal()])
    if labels and view == 'b':
        for (x, y), name in [((510, 867), 'Root'), ((502, 434), 'Crown')]:
            marker = ax.text(x, y, name, fontsize=6, color='white', weight='bold',
                             ha='center', va='center', zorder=5)
            marker.set_path_effects([effects.Stroke(linewidth=2, foreground='#132632'),
                                     effects.Normal()])
    xmin, ymin, xmax, ymax = selection['detail'] if detail else (0, 0, image.width, image.height)
    ax.set_xlim((xmax, xmin) if root_up else (xmin, xmax))
    ax.set_ylim((ymin, ymax) if root_up else (ymax, ymin))
    ax.set_axis_off()
    return source


def record():
    images = {}
    for view, selection in POINTS.items():
        colour = np.asarray(selection['colour_break'])
        ridge = np.asarray(selection['ridge_ends'])
        x = np.linspace(max(colour[0, 0], ridge[0, 0]), min(colour[-1, 0], ridge[-1, 0]), 500)
        separation = PchipInterpolator(*ridge.T)(x) - PchipInterpolator(*colour.T)(x)
        assert np.all(separation > 0), (view, separation.min())
        for mode in ('matte', 'bordercrop'):
            path = FIGURES/f'specimen_photo_{view}_{mode}.png'
            with path.open('rb') as stream:
                images[path.name] = hashlib.file_digest(stream, 'sha256').hexdigest()
    return dict(images_sha256=images, image_coordinate_landmarks=POINTS,
                image_orientation='Root-up details are 180-degree rotations in the image plane.',
                annotation='The solid guide follows visible striation ends and stays rootward of the dashed appearance break. Asymmetric curves preserve the manually digitized landmarks with PCHIP.',
                scope='Single-image feature tracing; illumination and preservation can affect appearance. No histological interface or growth chronology is inferred.')


def standalone():
    fig = layout.canvas(183, 114)
    layout.txt(fig, 91.5, 111, 'Crown–root transition on the specimen photographs',
               9, ha='center', va='top', weight='bold')
    for i, view in enumerate(('a', 'b')):
        x = i*91.5
        photo_axes(layout.axmm(fig, x+16, 45, 59.5, 57), view, labels=True)
        photo_axes(layout.axmm(fig, x+4, 10, 83.5, 28), view, detail=True, root_up=True)
        layout.panel(fig, x+6, 101, view)
        layout.txt(fig, x+45.75, 41, 'Cervical detail, root up', 6, ha='center', va='center')
    layout.txt(fig, 90, 5.5, 'Dashed cyan: abrupt colour change   ·   Solid gold: rootward ends of visible striations',
               6.4, ha='center')
    layout.txt(fig, 90, 2, 'Traces are drawn on the photograph. The furrows do not identify a histological interface.',
               5.5, ha='center')
    layout.save(fig, 'photographic_crown_root_transition')
    data = record()
    (PAPER/'review/photographic_crown_root_transition.json').write_text(json.dumps(data, indent=2)+'\n')


if __name__ == '__main__':
    standalone()
