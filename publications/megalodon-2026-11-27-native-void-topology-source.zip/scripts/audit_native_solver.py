#!/usr/bin/env python3
"""Audit archived CT evidence or compare independently exported elastic fields."""

import argparse
import csv
import hashlib
import json
import math
import shutil
import subprocess
import sys
import tempfile
import zlib
from pathlib import Path


NATIVE = Path("output/native_domain_module_2026-11-24")
TOPOLOGY = Path("full_3D/ct_internal_reconstruction")
MASK = Path("full_3D/Megalodon_FullCT_SpecimenMask_18um.mha")
GIB = 1024**3
RESIDUALS = ("residual", "independent_kernel_relative_gap", "force_balance")
FIELDS = ("ux_m", "uy_m", "uz_m", "sxx_pa", "syy_pa", "szz_pa", "sxy_pa", "sxz_pa", "syz_pa")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha256(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def topology(report):
    vertices = report["vertices"]
    faces = report["faces"]
    edges = report["unique_edges"]
    require(edges * 2 == faces * 3, "Surface incidence count does not close")
    for field in ("boundary_edges", "nonmanifold_edges", "orientation_conflict_edges",
                  "unused_vertices", "degenerate_triangles", "invalid_indices"):
        require(report[field] == 0, f"Nonzero {field} in surface report")
    outer = report["positive_volume_components"]
    inner = report["negative_volume_components"]
    require(outer == 1 and outer + inner == report["surface_components"], "Inconsistent component counts")
    return dict(vertices=vertices, faces=faces, edges=edges, euler=vertices - edges + faces,
                exterior_faces=report["largest_components"][0]["faces"],
                inward_closed_components=inner, enclosed_void_volume_mm3=report["negative_component_volume_sum_mm3"])


def check_mask(path, archived):
    encoded = sha256(path)
    require(encoded == archived["file_sha256"], "Original mask file checksum mismatch")
    decoded = hashlib.sha256()
    decoder = zlib.decompressobj()
    total = occupied = encoded_size = 0
    with path.open("rb") as stream:
        metadata = {}
        for line in iter(stream.readline, b""):
            name, value = line.decode("ascii").strip().split(" = ", 1)
            metadata[name] = value
            if name == "ElementDataFile":
                break
        require(metadata["ElementDataFile"] == "LOCAL" and metadata["CompressedData"] == "True"
                and metadata["ElementType"] == "MET_UCHAR", "Expected the original compressed uint8 MetaImage")
        require([int(x) for x in metadata["DimSize"].split()] == archived["shape_xyz"], "Mask dimensions differ")
        require([float(x) for x in metadata["ElementSpacing"].split()] == archived["native_spacing_xyz_mm"],
                "Mask spacing differs")
        for block in iter(lambda: stream.read(1024**2), b""):
            encoded_size += len(block)
            while block:
                chunk = decoder.decompress(block, 8 * 1024**2)
                decoded.update(chunk)
                count = chunk.count(1)
                require(count + chunk.count(0) == len(chunk), "Masked intensity other than 0 or 1")
                occupied += count
                total += len(chunk)
                block = decoder.unconsumed_tail
        require(decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail
                and encoded_size == int(metadata["CompressedDataSize"]), "Invalid compressed payload")
    require(decoded.hexdigest() == archived["decoded_uint8_sha256"], "Decoded mask checksum mismatch")
    require(total == archived["total_grid_voxels"] and occupied == archived["material_voxels"],
            "Mask occupancy differs from archived counts")
    return dict(file_sha256=encoded, decoded_uint8_sha256=decoded.hexdigest(),
                grid_voxels=total, material_voxels=occupied)


def check_surface(root, filename, shape, report_stem):
    path = root / "full_3D" / filename
    export = read_json(root / TOPOLOGY / f"{report_stem}_export_report.json")
    digest = sha256(path)
    require(digest == export["sha256"] and path.stat().st_size == export["bytes"],
            f"3MF bytes differ from the validated export: {filename}")
    require(all(shape[key] == export[key] for key in ("vertices", "faces")),
            f"Topology counts differ from the validated export: {filename}")
    return dict(file_sha256=digest, bytes=export["bytes"])


def synthetic(root, rerun):
    original = read_json(root / NATIVE / "review/synthetic_kernel_validation.json")
    report = original
    if rerun:
        with tempfile.TemporaryDirectory() as staging:
            module = Path(staging) / "module"
            module.mkdir()
            for name in ("smoke_validation.py", "elasticity.py"):
                shutil.copyfile(root / NATIVE / "module" / name, module / name)
            subprocess.run([sys.executable, str(module / "smoke_validation.py")], check=True,
                           stdout=subprocess.DEVNULL)
            report = read_json(Path(staging) / "review/synthetic_kernel_validation.json")
    by_case = {(case["domain"], case["height_mm"]): case for case in report["cases"]}
    cases = {(domain, height) for domain in ("filled", "preserved_cavity") for height in (50, 100)}
    require(set(by_case) == cases and len(report["cases"]) == len(by_case), "Synthetic coverage differs")
    require(report["status"] == "passed" and report["native_completed_tetrahedra"] == 0,
            "Synthetic verification status is inconsistent")
    largest = max(by_case[key][field] for key in cases for field in RESIDUALS)
    require(all(0 <= by_case[key][field] < 1e-10 for key in cases for field in RESIDUALS),
            "Synthetic residual, independent force or equilibrium limit exceeded")
    for key, row in by_case.items():
        nominal_volume = (key[1] / 1000)**3
        if key[0] == "preserved_cavity":
            nominal_volume *= 504 / 512
        require(math.isclose(row["material_volume_m3"], nominal_volume, rel_tol=1e-12),
                f"Synthetic solid volume differs for {key}")
    for domain in ("filled", "preserved_cavity"):
        low, high = (by_case[domain, h] for h in (50, 100))
        for field, factor in (("stress_max_Pa", 1), ("max_displacement_m", 2), ("energy_J", 8)):
            require(math.isclose(high[field], factor * low[field], rel_tol=1e-10),
                    f"Synthetic scaling check failed for {domain} {field}")
    if rerun:
        for row in original["cases"]:
            key = row["domain"], row["height_mm"]
            require(all(by_case[key][name] == row[name] for name in ("nodes", "tetrahedra", "boundary_triangles")),
                    f"Synthetic mesh differs from archive for {key}")
            require(all(math.isclose(by_case[key][name], row[name], rel_tol=1e-10)
                        for name in ("energy_J", "max_displacement_m", "stress_max_Pa")),
                    f"Synthetic response differs from archive for {key}")
    return dict(origin="rerun" if rerun else "archived", cases=len(by_case),
                largest_normalized_residual_or_balance=largest, backend="serial SciPy P1 tetrahedra")


def component_audit(root, native):
    import numpy as np

    path = root / TOPOLOGY / "validation_data/native_component_metrics.npz"
    with np.load(path, allow_pickle=False) as metrics:
        volumes = metrics["signed_volumes_mm3"]
        faces = metrics["face_counts"]
    require(volumes.ndim == 1 and volumes.shape == faces.shape and np.isfinite(volumes).all()
            and (faces > 0).all(), "Invalid native component arrays")
    inward = volumes < 0
    require(inward.sum() == native["inward_closed_components"] and (volumes > 0).sum() == 1
            and faces.sum() == native["faces"], "Native component array and topology totals differ")
    require(math.isclose(-volumes[inward].sum(), native["enclosed_void_volume_mm3"], rel_tol=1e-12),
            "Native component array and topology void volumes differ")
    selected = volumes < -0.001
    return dict(archive_sha256=sha256(path), strict_cutoff_mm3=.001, selected_components=int(selected.sum()),
                selected_faces=int(faces[selected].sum()), enclosed_volume_mm3=float(-volumes[selected].sum()),
                scope="Closed inward surface components. Exterior-connected spaces and tissue identity are separate.")


def archive(args):
    root = args.root.resolve()
    feasibility = read_json(root / NATIVE / "source/feasibility.json")
    mask_data = feasibility["native_mask"]
    native = topology(read_json(root / TOPOLOGY / "native_topology_report.json"))
    optimized = topology(read_json(root / TOPOLOGY / "reconstructed_topology_report.json"))
    geometry = feasibility["native_surface_topology"]
    require((native["vertices"], native["faces"], native["inward_closed_components"]) ==
            (geometry["vertices"], geometry["triangles"], geometry["negative_inner_components"]),
            "Feasibility and native topology records differ")
    require(native["inward_closed_components"] == optimized["inward_closed_components"]
            and native["euler"] == optimized["euler"], "Optimised and native coarse topology no longer agree")
    require(feasibility["status"] == "not_meshed_or_solved", "Reassess current native-volume status before publication")
    if args.verify_surfaces:
        native["verified_archive"] = check_surface(root, "Megalodon_FullCT_Native_Internal_74M_18um.3mf", native, "native")
        optimized["verified_archive"] = check_surface(root, "Megalodon_FullCT_Internal_32M_18um.3mf", optimized, "reconstructed")
    voxel_dofs = 3 * mask_data["material_voxels"]
    fraction = optimized["enclosed_void_volume_mm3"] / native["enclosed_void_volume_mm3"]
    peer_reviewed = {
        "ct_histol_comparator": "https://doi.org/10.1038/s41598-019-46081-3",
        "independent_same_species_comparator": "https://doi.org/10.7717/peerj.12775",
        "fossil_shark_tubule_infill": "https://doi.org/10.1039/C5RA11560D",
        "mfem": {"doi": "https://doi.org/10.1016/j.camwa.2026.06.026", "scope": "external rabbit femur benchmark"},
        "sm_fmm": {"doi": "https://doi.org/10.1016/j.cma.2025.118436", "scope": "external heterogeneous micromechanics tests"},
    }
    return dict(schema="native-ct-evidence/1", native=native, optimized=optimized,
                closed_void_volume_change_pct=100 * (fraction - 1),
                boundary_P1_dof_lower_bound=3 * native["vertices"],
                voxel_Q1_dof_lower_bound=voxel_dofs, voxel_Q1_single_vector_GiB=8 * voxel_dofs / GIB,
                native_boundary_embeddedness_check=geometry["full_self_intersection_audit_completed"],
                native_nested_shell_containment_check=geometry["full_nested_shell_containment_audit_completed"],
                mask=check_mask(root / MASK, mask_data) if args.verify_mask else "archived record only",
                cavity_sieve=component_audit(root, native) if args.verify_components else "not requested",
                synthetic=synthetic(root, args.rerun_synthetic), comparative_sources=peer_reviewed,
                native_solve=feasibility["status"], tissue_assignment="Requires independent specimen-specific evidence.")


def pinned_artifact(manifest, filename, field):
    entry = manifest[field]
    path = filename.parent / entry["path"]
    digest = sha256(path)
    require(digest == entry["sha256"], f"Checksum mismatch for {path}")
    return path, digest


def load_run(manifest_file):
    manifest = read_json(manifest_file)
    require(manifest["schema"] == "elastic-solver-benchmark/1", "Unsupported benchmark manifest")
    require(str(manifest["backend"]).strip() and str(manifest["version"]).strip(), "Identify backend and version")
    _, problem = pinned_artifact(manifest, manifest_file, "problem")
    table, table_digest = pinned_artifact(manifest, manifest_file, "samples")
    with table.open(newline="", encoding="utf-8") as file:
        values = {}
        for row in csv.DictReader(file):
            sample = row["sample_id"]
            weight = float(row["volume_mm3"])
            fields = tuple(float(row[name]) for name in FIELDS)
            require(sample.strip() and sample not in values and weight > 0
                    and all(math.isfinite(x) for x in (weight, *fields)), f"Invalid or duplicate sample {sample!r}")
            values[sample] = (weight, fields)
    require(len(values) >= 2, "Benchmark requires at least two matched sampling locations")
    cost = manifest["performance"]
    for field in ("active_dofs", "ranks", "peak_aggregate_RAM_bytes"):
        require(type(cost[field]) is int and cost[field] > 0, f"Missing positive measured {field}")
    for field in ("mesh_seconds", "setup_seconds", "solve_seconds", "normalized_equilibrium_residual"):
        require(math.isfinite(cost[field]) and cost[field] >= 0, f"Invalid measured {field}")
    require(cost["solve_seconds"] > 0 and isinstance(cost["hardware"], str) and cost["hardware"].strip(),
            "Benchmark requires the measured solve duration and hardware description")
    summary = {name: manifest[name] for name in ("backend", "version", "performance")}
    return summary | {"samples_sha256": table_digest}, problem, values


def von_mises(stress):
    xx, yy, zz, xy, xz, yz = stress
    return math.sqrt(((xx - yy)**2 + (yy - zz)**2 + (zz - xx)**2) / 2 + 3 * (xy**2 + xz**2 + yz**2))


def weighted_q95(weighted_values):
    threshold = .95 * sum(weight for _, weight in weighted_values)
    running = 0.
    for value, weight in sorted(weighted_values):
        running += weight
        if running >= threshold:
            return value
    raise ValueError("Cannot calculate weighted Q95 from empty or invalid samples")


def benchmark(args):
    reference, problem, ref = load_run(args.reference)
    candidate, other_problem, other = load_run(args.candidate)
    require(problem == other_problem, "Candidate and reference problem checksums differ")
    require(ref.keys() == other.keys(), "Candidate and reference sample IDs differ")
    factors = (1, 1, 1, 1, 1, 1, 2, 2, 2)
    norm_ref = [0., 0.]
    norm_error = [0., 0.]
    vms = ([], [])
    for key, (weight, expected) in ref.items():
        other_weight, observed = other[key]
        require(weight == other_weight, f"Volume weights differ for sample {key}")
        for i, (a, b, factor) in enumerate(zip(expected, observed, factors)):
            group = int(i >= 3)
            norm_ref[group] += weight * factor * a**2
            norm_error[group] += weight * factor * (a - b)**2
        vms[0].append((von_mises(expected[3:]), weight))
        vms[1].append((von_mises(observed[3:]), weight))
    require(all(norm > 0 for norm in norm_ref), "Reference fields must have nonzero displacement and stress norms")
    ref_q95, candidate_q95 = map(weighted_q95, vms)
    require(ref_q95 > 0, "Reference von Mises Q95 must be positive")
    errors = dict(displacement_l2=math.sqrt(norm_error[0] / norm_ref[0]),
                  stress_frobenius_l2=math.sqrt(norm_error[1] / norm_ref[1]),
                  von_mises_q95=abs(candidate_q95 - ref_q95) / ref_q95,
                  equilibrium_residual=max(run["performance"]["normalized_equilibrium_residual"]
                                           for run in (candidate, reference)))
    limits = {name: getattr(args, name) for name in errors}
    require(all(math.isfinite(value) and value >= 0 for value in limits.values()), "Tolerances must be finite and nonnegative")
    passed = all(value <= limits[name] for name, value in errors.items())
    return dict(schema="elastic-solver-comparison/1", passed=passed, problem_sha256=problem,
                samples=len(ref), reference=reference, candidate=candidate,
                reference_von_mises_q95_pa=ref_q95, candidate_von_mises_q95_pa=candidate_q95,
                errors=errors, acceptance_limits=limits,
                scope="Matched exported fields only. Discretisation, geometry and scaling require independent checks.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    archive_parser = commands.add_parser("archive", help="Check manuscript evidence against project reports")
    archive_parser.add_argument("--root", type=Path, default=Path.cwd())
    archive_parser.add_argument("--verify-mask", action="store_true")
    archive_parser.add_argument("--verify-components", action="store_true")
    archive_parser.add_argument("--verify-surfaces", action="store_true")
    archive_parser.add_argument("--rerun-synthetic", action="store_true")
    benchmark_parser = commands.add_parser("benchmark", help="Compare two solver exports of one pinned benchmark problem")
    benchmark_parser.add_argument("reference", type=Path)
    benchmark_parser.add_argument("candidate", type=Path)
    for option in ("displacement_l2", "stress_frobenius_l2", "von_mises_q95", "equilibrium_residual"):
        benchmark_parser.add_argument("--" + option.replace("_", "-"), type=float, required=True)
    for command in (archive_parser, benchmark_parser):
        command.add_argument("--output", type=Path)
    args = parser.parse_args()
    try:
        report = archive(args) if args.command == "archive" else benchmark(args)
        formatted = json.dumps(report, indent=2, allow_nan=False)
        if args.output is not None:
            args.output.write_text(formatted + "\n", encoding="utf-8")
    except (ImportError, KeyError, TypeError, ValueError, OverflowError, OSError, zlib.error,
            subprocess.SubprocessError) as error:
        parser.exit(2, f"Audit failed: {error}\n")
    print(formatted)
    return 0 if report.get("passed", True) else 1


if __name__ == "__main__":
    sys.exit(main())
