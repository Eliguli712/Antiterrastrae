#!/usr/bin/env python3
"""Compare support location and compliance on the existing L2 jaw mesh."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np
import pyamg
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import cg
from scipy.stats import spearmanr

PROJECT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(PROJECT / "output/publication_validation_2026-11-12/scripts"))
from elastic_diagnostics import assemble, basis_data

YOUNG = 150e6
POISSON = .3
LAME = YOUNG * POISSON / ((1 + POISSON) * (1 - 2 * POISSON))
SHEAR = YOUNG / (2 * (1 + POISSON))
EYE = np.eye(3)
TARGETS_M = np.array([[-.170, .105, -.030], [.170, .100, -.020]])
RADIUS_M = .035
KN, KT = 1e11, 2.5e10


def quantile(values, volumes, probability=.95):
    order = np.argsort(values, kind="stable")
    cumulative = np.cumsum(volumes[order])
    return float(values[order[np.searchsorted(cumulative, probability * cumulative[-1])]])


def lateral_patches(points, faces):
    triangle = points[faces]
    centroid = triangle.mean(axis=1)
    area = np.linalg.norm(np.cross(triangle[:, 1] - triangle[:, 0],
                                   triangle[:, 2] - triangle[:, 0]), axis=1) / 2
    seed = np.argmin(np.linalg.norm(centroid[:, None, :] - TARGETS_M[None], axis=2), axis=0)
    centres = centroid[seed]
    patches = [np.flatnonzero(np.linalg.norm(centroid - centre, axis=1) <= RADIUS_M)
               for centre in centres]
    assert not np.intersect1d(*patches).size
    nodal_areas = [np.bincount(faces[ids].ravel(), np.repeat(area[ids] / 3, 3),
                              minlength=len(points)) for ids in patches]
    return centres, patches, nodal_areas


def springs(nodal_areas):
    # The lateral reference direction is global X. These are engineering
    # controls with area-lumped springs and no joint/contact identification.
    diagonal = np.sum(nodal_areas, axis=0)[:, None] * np.array([KN, KT, KT])
    dof = np.flatnonzero(diagonal)
    size = diagonal.size
    return coo_matrix((diagonal.ravel()[dof], (dof, dof)), shape=(size, size)).tocsr()


def recover(points, cells, gradients, volumes, displacement):
    stress = np.empty((len(cells), 3, 3))
    internal = np.zeros_like(points)
    energy_density = np.empty(len(cells))
    for start in range(0, len(cells), 24000):
        group = slice(start, start + 24000)
        tets, g = cells[group], gradients[group]
        grad_u = np.einsum("eai,eaj->eij", displacement[tets[:, 1:]]
                           - displacement[tets[:, :1]], g[:, 1:])
        strain = (grad_u + grad_u.transpose(0, 2, 1)) / 2
        sigma = LAME * np.trace(strain, axis1=1, axis2=2)[:, None, None] * EYE + 2 * SHEAR * strain
        stress[group] = sigma
        energy_density[group] = np.einsum("eij,eij->e", sigma, strain) / 2
        local = np.einsum("eij,eaj,e->eai", sigma, g, volumes[group])
        for slot in range(4):
            np.add.at(internal, tets[:, slot], local[:, slot])
    dev = stress - np.trace(stress, axis1=1, axis2=2)[:, None, None] * EYE / 3
    vm = np.sqrt(1.5 * np.einsum("eij,eij->e", dev, dev))
    principal = np.linalg.eigvalsh(stress)
    return stress, vm, principal, energy_density, internal


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("fields", type=Path, help="Audited original L2 linear/finite-strain field NPZ")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    summary = args.output / "summary.json"
    if summary.exists():
        raise FileExistsError(summary)
    with np.load(args.fields) as source:
        p, t, faces, owner, fixed, force, old_u = (source[key] for key in (
            "points_m", "tets", "boundary_faces", "boundary_owner",
            "fixed_node_indices", "force_N", "linear_displacement_m"))
    assert len(t) == 589700
    gradients, volume = basis_data(p, t)
    np.random.seed(20261127)
    print("Assembling common jaw stiffness", flush=True)
    K = assemble(p, t, gradients, volume, np.full(len(t), LAME), np.full(len(t), SHEAR))
    centres, patches, area = lateral_patches(p, faces)
    lateral_nodes = [np.flatnonzero(a) for a in area]
    lateral = np.union1d(*lateral_nodes)
    assert not np.intersect1d(fixed, lateral).size
    assert not np.linalg.norm(force[lateral])
    support = springs(area)
    D = force.size
    span = float(np.ptp(p, axis=0).max())
    modes = np.empty((len(p), 3, 6))
    modes[:, :, :3] = EYE
    for i in range(3):
        modes[:, :, 3 + i] = np.cross(EYE[i], (p - p.mean(0)) / span)
    modes = modes.reshape(-1, 6)
    resultant = force.sum(0)
    scale = float(np.linalg.norm(resultant))
    moment = np.cross(p, force).sum(0)
    rows = []

    with (args.output / "load_provenance.json").open("w") as out:
        json.dump({
            "reference_load_Pa": 1000, "resultant_N": resultant.tolist(),
            "moment_about_source_origin_Nm": moment.tolist(), "patch_centres_m": centres.tolist(),
            "patch_target_m": TARGETS_M.tolist(), "patch_radius_m": RADIUS_M,
            "patch_area_mm2": [float(a.sum() * 1e6) for a in area],
            "patch_node_counts": [len(ids) for ids in lateral_nodes],
        }, out, indent=2)
    for name, restrained, foundation in (
        ("J0", fixed, None), ("J1", lateral, None), ("J2", np.empty(0, int), support)
    ):
        print("Solving", name, flush=True)
        restrained_dofs = (3 * restrained[:, None] + np.arange(3)).ravel()
        free = np.setdiff1d(np.arange(D), restrained_dofs)
        system = K[free][:, free].tocsr() if foundation is None else K + foundation
        preconditioner = pyamg.smoothed_aggregation_solver(
            system.tobsr(blocksize=(3, 3)), B=modes[free], symmetry="symmetric",
            presmoother=("block_gauss_seidel", {"sweep": "symmetric"}),
            postsmoother=("block_gauss_seidel", {"sweep": "symmetric"}),
            max_coarse=250, max_levels=12).aspreconditioner()
        rhs = force.ravel()[free]
        solved, status = cg(system, rhs, M=preconditioner, rtol=2e-10, atol=0, maxiter=2500)
        if status:
            raise RuntimeError(f"{name}: CG status {status}")
        u = np.zeros(D)
        u[free] = solved
        stress, vm, principal, energy_density, internal = recover(
            p, t, gradients, volume, u.reshape(-1, 3))
        spring_force = np.zeros_like(force) if foundation is None else (foundation @ u).reshape(-1, 3)
        residual = internal + spring_force - force
        reaction = -spring_force
        reaction[restrained] += residual[restrained]
        work = float(force.ravel() @ u)
        energy = float(volume @ energy_density + .5 * spring_force.ravel() @ u)
        readback = float(np.linalg.norm(residual.ravel()[free]) / np.linalg.norm(rhs))
        force_error = float(np.linalg.norm(reaction.sum(0) + resultant) / scale)
        moment_error = float(np.linalg.norm(np.cross(p, reaction).sum(0) + moment) / (scale * span))
        work_error = abs(2 * energy - work) / abs(work)
        assert max(readback, force_error, moment_error, work_error) < 2e-6
        if name == "J0":
            old_error = float(np.linalg.norm(u - old_u.ravel()) / np.linalg.norm(old_u))
            assert old_error < 2e-6
            reference_vm = vm
        q95 = quantile(vm, volume)
        hotspot = vm >= q95
        if name == "J0":
            reference_hotspot = hotspot
        row = {
            "case": name, "fixed_nodes": len(restrained), "vm_Q95_kPa": q95 / 1e3,
            "principal_tension_Q95_kPa": quantile(np.maximum(principal[:, 2], 0), volume) / 1e3,
            "principal_compression_Q95_kPa": quantile(np.maximum(-principal[:, 0], 0), volume) / 1e3,
            "max_displacement_mm": float(1e3 * np.linalg.norm(u.reshape(-1, 3), axis=1).max()),
            "max_displacement_over_span": float(np.linalg.norm(u.reshape(-1, 3), axis=1).max() / span),
            "total_energy_J": energy, "relative_field_L2_vs_J0": float(np.sqrt(
                (volume @ (vm - reference_vm)**2) / (volume @ reference_vm**2))),
            "volume_hotspot_Jaccard_vs_J0": float(
                volume[hotspot & reference_hotspot].sum() / volume[hotspot | reference_hotspot].sum()),
            "cell_rank_Spearman_vs_J0": float(spearmanr(vm, reference_vm).statistic),
            "net_reaction_N": reaction.sum(0).tolist(),
            "lateral_reactions_N": [reaction[ids].sum(0).tolist() for ids in lateral_nodes],
            "tensor_force_readback": readback, "force_balance": force_error,
            "reference_moment_balance": moment_error, "work_energy_error": work_error,
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
        np.savez_compressed(args.output / f"{name}_fields.npz", displacement_m=u.reshape(-1, 3),
                            stress_Pa=stress, von_mises_Pa=vm, reaction_N=reaction,
                            energy_density_J_m3=energy_density, fixed_nodes=restrained)
    np.savez_compressed(args.output / "common_domain.npz", points_m=p, tets=t,
                        faces=faces, face_owner=owner, volumes_m3=volume, force_N=force,
                        lateral_negative_faces=patches[0], lateral_positive_faces=patches[1],
                        lateral_negative_nodal_area_m2=area[0], lateral_positive_nodal_area_m2=area[1])
    with args.fields.open("rb") as stream:
        input_sha = hashlib.file_digest(stream, "sha256").hexdigest()
    summary.write_text(json.dumps({
        "engineering_scope": "L2 linear infinitesimal elasticity. Same load, mesh and material. Lateral patches are geometric controls.",
        "source_fields_sha256": input_sha, "nodes": len(p), "tets": len(t),
        "E_Pa": YOUNG, "nu": POISSON, "span_m": span, "kn_N_m3": KN, "kt_N_m3": KT,
        "J0_displacement_replay_error": old_error, "results": rows,
    }, indent=2) + "\n")


if __name__ == "__main__":
    main()
