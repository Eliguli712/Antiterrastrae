"""Full-native figure projections with explicit numerical provenance."""
import argparse
import json
from pathlib import Path
import struct
import subprocess
import tempfile

import fitz
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm, to_rgb
import numpy as np
from PIL import Image
from scipy.spatial import cKDTree

import revise_figures as layout
from photographic_cervical_guides import photo_axes

PAPER = Path(__file__).resolve().parents[1]
PROJECT = PAPER.parents[2]
FIGURES = PAPER / 'figures'
NUMERICS = PAPER / 'numerics'
REVIEW = PAPER / 'review'
BASELINE = PROJECT / 'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics'
VALIDATION = PROJECT / 'output/publication_validation_2026-11-12/data'
CACHE = PROJECT / 'output/current_native74_stress_2026-11-20/cache'
TOOTH_VERTICES, TOOTH_FACES = 37_951_699, 74_293_846
MAX_SUPPORT_MM = 1.5
PAINT = ['#bfaf87', '#245cbd', '#d23845']
MAP_NORM = LogNorm(.5, 500, clip=True)
UNSUPPORTED = '#d9aee3'
UNASSIGNED = '#d1bddd'
ORIENTATION = np.radians(34)
OBLIQUE = np.array([[np.cos(ORIENTATION), 0, -np.sin(ORIENTATION)],
                    [0, 1, 0], [np.sin(ORIENTATION), 0, np.cos(ORIENTATION)]])
SCALE = 29.0


def sigma_vm(gradient):
    strain = (gradient + gradient.swapaxes(-1, -2)) / 2
    deviator = strain - np.trace(strain, axis1=-2, axis2=-1)[..., None, None] * np.eye(3) / 3
    return 57e9 * np.sqrt(1.5 * np.sum(deviator ** 2, axis=(-2, -1))) / 1e6


def volume_average(tets, vertices, volume, samples):
    """Each sample row gives either cell values or the four corner values."""
    averages = np.zeros(len(vertices))
    weights = np.zeros(len(vertices))
    for corner in range(4):
        sample = samples if samples.ndim == 1 else samples[:, corner]
        np.add.at(weights, tets[:, corner], volume)
        np.add.at(averages, tets[:, corner], volume * sample)
    assert np.all(weights > 0)
    return averages / weights


def p2_at_corners(points, tets, source=NUMERICS / 'p1_p2_common_domain/solution_P2.npz'):
    with np.load(source) as result:
        connectivity = result['tets_P2']
        displacement = result['displacement_m'][connectivity]
        assert np.array_equal(connectivity[:, :4], tets)
    barycentric_grad = np.empty((len(tets), 4, 3))
    inverse = np.linalg.inv(points[tets[:, 1:]] - points[tets[:, :1]])
    barycentric_grad[:, 1:] = inverse.transpose(0, 2, 1)
    barycentric_grad[:, 0] = -barycentric_grad[:, 1:].sum(axis=1)
    samples = np.empty((len(tets), 4))
    edges = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
    for i, barycentric in enumerate(np.eye(4)):
        grad = np.empty((len(tets), 10, 3))
        grad[:, :4] = (4 * barycentric[None, :, None] - 1) * barycentric_grad
        for k, (a, b) in enumerate(edges, 4):
            grad[:, k] = 4 * (barycentric[a] * barycentric_grad[:, b] +
                              barycentric[b] * barycentric_grad[:, a])
        samples[:, i] = sigma_vm(np.einsum('eai,eaj->eij', displacement, grad))
    assert np.isfinite(samples).all()
    return samples


def interpolate(tree, values, targets):
    dist, idx = tree.query(targets, k=4, workers=4, distance_upper_bound=2.5)
    weights = 1.0 / np.maximum(dist, 1e-9) ** 2
    total = np.maximum(weights.sum(axis=1), np.finfo(float).tiny)
    if values.ndim == 2:
        observed = (values[np.minimum(idx, len(values) - 1)] * weights[:, :, None]).sum(1)
        observed /= total[:, None]
    else:
        observed = (values[np.minimum(idx, len(values) - 1)] * weights).sum(1) / total
    return observed, dist[:, 0] <= MAX_SUPPORT_MM


def stress_colours(values, supported):
    rgb = mpl.colormaps['turbo'](MAP_NORM(np.maximum(values, MAP_NORM.vmin)))[..., :3]
    rgb[~supported] = to_rgb(UNSUPPORTED)
    return rgb


def send(process, i, xyz, rgb, index):
    payload = np.column_stack((xyz, rgb)).astype('<f4')
    process.stdin.write(struct.pack('<III', i, len(payload), len(index)))
    process.stdin.write(payload.tobytes())
    process.stdin.write(index.astype('<u4').tobytes())


def tooth_view(local, oblique=False):
    xyz = local @ OBLIQUE if oblique else local
    return np.column_stack((900 + xyz[:, 0]*SCALE, 748 - xyz[:, 1]*SCALE, -xyz[:, 2]))


def load_inputs():
    with np.load(BASELINE / 'L0/solution.npz') as p1:
        center, basis = p1['center_m']*1000, p1['basis']
        points, tets = p1['points_m'], p1['tets']
        volume = p1['volumes_m3']
        p1_field = volume_average(tets, points, volume, p1['element_von_mises_Pa']/1e6)
        p2_field = volume_average(tets, points, volume, p2_at_corners(points, tets))
        boundary = np.unique(p1['boundary_faces'])
        p1_tree = cKDTree(points[boundary] * 1000)
        comparison = np.column_stack((p1_field[boundary], p2_field[boundary]))
    with np.load(VALIDATION / 'local_A3/fields.npz') as fine:
        points, tets, faces = fine['points_m'], fine['tets'], fine['boundary_faces']
        a3_field = volume_average(tets, points, fine['volumes_m3'], fine['von_mises_Pa']/1e6)
        boundary = np.unique(faces)
        a3_tree = cKDTree(points[boundary] * 1000)
        a3_nodal = a3_field[boundary]
        patches = np.zeros(len(faces), dtype=np.int8)
        patches[fine['loaded_faces']] = 1
        fixed = np.zeros(len(points), dtype=bool)
        fixed[fine['fixed_nodes']] = True
        patches[fixed[faces].all(axis=1)] = 2
        patch_tree = cKDTree(points[faces].mean(axis=1) * 1000)
        patch_counts = np.bincount(patches).tolist()
    with np.load(BASELINE / 'L2/solution.npz') as l2:
        centres = l2['points_m'][l2['tets']].mean(axis=1) * 1000
    label_tree = cKDTree(centres)
    labels = np.zeros(len(centres), dtype=np.int8)
    with np.load(BASELINE / 'L2/region_masks.npz') as masks:
        for i, region in enumerate(layout.REGIONS, 1):
            labels[masks[region]] = i
    fine_meta = json.loads((VALIDATION / 'local_A3/results.json').read_text())
    q95 = [region['Q95_MPa'] for region in fine_meta['regions']]
    return center, basis, p1_tree, comparison, a3_tree, a3_nodal, patch_tree, patches, patch_counts, label_tree, labels, q95


def render_native(center, basis, p1_tree, comparison, a3_tree, a3_nodal,
                  patch_tree, patches, label_tree, labels, q95):
    v = np.memmap(CACHE / 'vertices.f64', '<f8', mode='r', shape=(TOOTH_VERTICES, 3))
    f = np.memmap(CACHE / 'triangles.u32', '<u4', mode='r', shape=(TOOTH_FACES, 3))
    patch_palette = np.array([to_rgb(c) for c in PAINT] + [to_rgb(UNSUPPORTED)])
    region_palette = np.vstack([to_rgb(UNASSIGNED), mpl.colormaps['turbo'](LogNorm(.4, 300)(q95))[:, :3]])
    unsupported = np.zeros(3, dtype=int)
    # Each source vertex is counted once for support statistics, regardless of face sharing.
    seen = np.zeros(len(v), dtype=bool)
    assigned = np.zeros(7, dtype=int)
    records = {}
    for names, suite in [
        (('field4_condition_native', 'field4_A3_native', 'field4_region_front_native'), 'A3'),
        (('field4_region_oblique_native', 'field6_P1_native', 'field6_P2_native'), 'P12'),
    ]:
        with tempfile.TemporaryDirectory() as tmp:
            executable = Path(tmp) / 'raster'
            subprocess.run(['clang++', '-O3', '-std=c++17',
                            str(PAPER/'scripts/native_figure8_raster.cpp'), '-o', str(executable)], check=True)
            with subprocess.Popen([str(executable), tmp], stdin=subprocess.PIPE,
                                  stderr=subprocess.PIPE) as process:
                seen[:] = False
                for start in range(0, len(f), 650_000):
                    part = f[start:start + 650_000]
                    ids, ix = np.unique(part, return_inverse=True)
                    original = v[ids]
                    local = (original - center) @ basis
                    distance, closest = label_tree.query(original, workers=4)
                    region_idx = labels[closest]
                    rgb_reg = region_palette[region_idx]
                    new = ~seen[ids]
                    seen[ids] = True
                    front = tooth_view(local)
                    triangles = ix.reshape(-1, 3)
                    if suite == 'A3':
                        dist, closest = patch_tree.query(original, workers=4)
                        tags = patches[closest].copy()
                        tags[dist > MAX_SUPPORT_MM] = 3
                        rgb_cond = patch_palette[tags]
                        value, use = interpolate(a3_tree, a3_nodal, original)
                        unsupported[0] += np.count_nonzero(~use & new)
                        unsupported[1] += np.count_nonzero((tags == 3) & new)
                        assigned += np.bincount(region_idx[new], minlength=7)
                        images = [(front, rgb_cond), (front, stress_colours(value, use)),
                                  (front, rgb_reg)]
                    else:
                        fields, use = interpolate(p1_tree, comparison, original)
                        unsupported[2] += np.count_nonzero(~use & new)
                        images = [(tooth_view(local, oblique=True), rgb_reg),
                                  (front, stress_colours(fields[:, 0], use)),
                                  (front, stress_colours(fields[:, 1], use))]
                    for panel, (xyz, colour) in enumerate(images):
                        send(process, panel, xyz, colour, triangles)
                    if start % 6_500_000 == 0:
                        print(suite, start, flush=True)
                process.stdin.close()
                counts = process.stderr.read().decode()
                assert process.wait() == 0 and counts.count(str(TOOTH_FACES)) == 3, counts
            assert seen.all()
            records[suite] = counts
            for i, name in enumerate(names):
                raster = Image.frombytes('RGBA', (1800, 1600), (Path(tmp)/f'native_figure8_{i}.rgba').read_bytes())
                assert raster.getbbox()
                raster.save(FIGURES / f'{name}.png')
    return records, unsupported.tolist(), assigned.tolist()


def tooth_raster(axis, name, extent_mm=False):
    image = Image.open(FIGURES / f'{name}.png')
    if not extent_mm:
        image = image.crop(image.getbbox())
        image.thumbnail((600, 650), Image.Resampling.LANCZOS)
        axis.imshow(image, interpolation='none')
        axis.set_axis_off()
        return
    # Pixel-centre coordinates derived from the exact orthographic raster camera.
    axis.imshow(image, extent=(-900/SCALE, 900/SCALE, (748-1600)/SCALE, 748/SCALE),
                origin='upper', interpolation='none')
    axis.set(xlim=(-18.5, 18.5), ylim=(-27, 23))


def compose(q95):
    fig = layout.canvas(121, 128)
    plot_names = ('Photographic transition', 'Load / support', 'A3 projected stress')
    for i, (left, title) in enumerate(zip([9, 46, 83], plot_names)):
        ax = layout.axmm(fig, left, 86, 28, 34)
        layout.panel(fig, left-7, 126, 'abc'[i])
        layout.txt(fig, left+10, 125.5, title, 6.1, va='top', ha='center')
        if i == 0:
            photo_axes(ax, 'b', root_up=True, labels=True)
            layout.txt(fig, left+14, 83.3, 'Dashed: colour break', 4.7, ha='center', color='#187890')
            layout.txt(fig, left+14, 80.5, 'Solid: ridge ends', 4.7, ha='center', color='#845107')
            continue
        ax.set_xticks([-10, 0, 10])
        ax.set_xlabel('Transverse (mm)', labelpad=.9)
        ax.tick_params(labelsize=5.5, pad=1)
        tooth_raster(ax, ['field4_condition_native', 'field4_A3_native'][i-1], extent_mm=True)
        if i == 1:
            ax.set_ylabel('Longitudinal (mm)', labelpad=1)
        else:
            ax.tick_params(labelleft=False)
    bar = fig.colorbar(mpl.cm.ScalarMappable(norm=MAP_NORM, cmap='turbo'),
                       cax=layout.axmm(fig, 111.5, 90, 1.4, 24), extend='both')
    bar.set_ticks([1,10,100])
    bar.ax.tick_params(labelsize=5.5, pad=1)
    layout.txt(fig, 115.3, 117, 'MPa', 5.3, ha='center')
    layout.txt(fig, 78.5, 78.2,
               'Blue: pressure   Red: caps   Lilac: outside display support', 5.0, ha='center')
    for pos, name in [(1,'front'), (40,'oblique')]:
        tooth_raster(layout.axmm(fig, pos, 41, 33, 29), f'field4_region_{name}_native')
    layout.panel(fig, 2, 76.5, 'd')
    layout.txt(fig, 36, 75.9, 'Native 74M surface · frozen regions', 6.2, ha='center', va='top')
    palette = mpl.colormaps['turbo'](LogNorm(.4,300)(q95))
    legend = layout.axmm(fig, 76, 39, 43, 31)
    for row, label, value, colour in zip(range(6), layout.LABELS, q95, palette):
        yy=.93-row*.145
        legend.plot([.08],[yy],marker='s',color=colour,ms=3.9)
        legend.text(.17, yy, label + f'  {value:.3f}', fontsize=5.7, va='center')
    legend.plot([.08], [.06], marker='s', color=UNASSIGNED, ms=3.9)
    legend.text(.17, .06, 'Outside frozen regions', fontsize=5.7, va='center')
    legend.set(xlim=(0,1), ylim=(0,1))
    legend.axis('off')
    layout.txt(fig, 98, 75.9, r'A3 $Q_{0.95}$ (MPa)', 6.1, ha='center', va='top')
    layout.panel(fig, 1, 35.8, 'e')
    layout.txt(fig, 16, 35.5, 'Jaw load / support', 5.8, ha='center', va='top')
    tooth_raster(layout.axmm(fig, 1, 7, 29, 25), 'jaw_native_constraints')
    layout.txt(fig, 16, 4.5, '1,009,016 source faces', 5.0, ha='center')
    layout.txt(fig, 16, 2.3, 'Blue: load  |  Magenta: fixed', 5.0, ha='center')
    with tempfile.TemporaryDirectory() as tmp:
        left = Path(tmp) / 'left.pdf'
        fig.savefig(left, dpi=600)
        plt.close(fig)
        with fitz.open(left) as pdf, fitz.open(FIGURES/'jaw_calibration_refinement_points.pdf') as source:
            page = pdf[0]
            clip = fitz.Rect(33*72/25.4, 0, source[0].rect.width, source[0].rect.height)
            dest = fitz.Rect(clip.x0, page.rect.height-clip.height, clip.x1, page.rect.height)
            page.show_pdf_page(dest, source, 0, clip=clip)
            pdf.save(FIGURES/'field_qf_photographic_transition.pdf', garbage=4, deflate=True)
        with fitz.open(FIGURES/'field_qf_photographic_transition.pdf') as pdf:
            pdf[0].get_pixmap(matrix=fitz.Matrix(2.8,2.8)).save(FIGURES/'field_qf_photographic_transition.png')
    return


def compose_order_checks():
    fig = layout.canvas(58, 36)
    for i, name in enumerate(['P1','P2']):
        tooth_raster(layout.axmm(fig, 1.5+28.5*i, 8, 26, 22), f'field6_{name}_native')
        layout.panel(fig, 2+28.5*i, 34.5, 'cd'[i])
        layout.txt(fig, 15+28.5*i, 34.4, name+' · native projection', 5.7, ha='center',va='top')
    bar = fig.colorbar(mpl.cm.ScalarMappable(norm=MAP_NORM, cmap='turbo'),
                       cax=layout.axmm(fig, 15, 4.2, 32, 1.3), orientation='horizontal', extend='both')
    bar.set_ticks([1,10,100])
    bar.ax.tick_params(labelsize=4.6, pad=.6)
    layout.txt(fig, 13.5, 4.9, 'MPa', 4.8, ha='right')
    layout.save(fig, 'P1_P2_native_surface')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--render-existing', action='store_true',
                        help='Only reassemble existing full-resolution raster outputs')
    options = parser.parse_args()
    if options.render_existing:
        record = json.loads((REVIEW/'figure4_native_full.json').read_text())
        compose(record['q95_MPa'])
        return
    inputs = load_inputs()
    *first, patch_counts, label_tree, labels, q95 = inputs
    counts, unsupported, assigned = render_native(*first, label_tree, labels, q95)
    jaw = dict(triangles=1_009_016, source_record='review/jaw_native_readback.json',
               role='FE boundary categories transferred to the full source geometry')
    compose(q95)
    compose_order_checks()
    record = dict(native_vertices=TOOTH_VERTICES, native_faces_per_tooth_map=TOOTH_FACES,
                  display_cases={'A3': 1_739_398, 'P1': 55_852, 'P2': 55_852},
                  stress_projection='Volume-weighted mean of incident tetrahedral corner von Mises values; P2 gradient evaluated at corners. Four nearest source boundary nodes within 2.5 mm, inverse squared distances. Lavender beyond declared display cutoff (1.5 mm nearest-node distance). Display recovery only.',
                  category_projection='B: nearest labelled A3 face centre within 1.5 mm. D: frozen nearest-L2-element-centroid categories; outside all frozen regions indicated separately.',
                  outside_display_support_vertices=dict(zip(['A3','B','P1/P2'],unsupported)),
                  frozen_region_display_vertex_counts=assigned, A3_loaded_fixed_counts=patch_counts,
                  q95_MPa=q95, projected_stress_log_limits_MPa=[.5,500],
                  raster_counts=counts, jaw=jaw)
    (REVIEW/'figure4_native_full.json').write_text(json.dumps(record, indent=2))
    print(record, flush=True)


if __name__ == '__main__':
    main()
