#!/usr/bin/env python3
"""A3 strain-driven porous and filled 18 µm CT cubes with a matrix-free Q1 solve."""
import argparse
import ctypes
from functools import lru_cache
import gzip
import hashlib
from itertools import product
import json
from pathlib import Path
import subprocess
import struct

import numpy as np
import pyvista as pv
from scipy import ndimage as ndi
from scipy.fft import dstn, idstn
from scipy.sparse.linalg import LinearOperator, cg
from scipy.spatial import cKDTree

PAPER = Path(__file__).resolve().parents[1]
ROOT = PAPER.parents[2]
INTERACTIVE = ROOT / "output/native_interactive_r15_2026-11-25"
SLABS = INTERACTIVE / "review/run001/data"
TRACES = INTERACTIVE / "source-owned/design/megalodon/assets/native-microtubes.json"
BASE = ROOT / "output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L0"
A3 = ROOT / "output/publication_validation_2026-11-12/data/local_A3/fields.npz"
OUT = PAPER / "numerics/coupled_ct_submodels"
E_MPA, NU = 20_000., .28
MU, LAM = 1/(2*(1+NU)), NU/((1+NU)*(1-2*NU))
I3 = np.eye(3)
OFFSETS = np.array(list(product(range(2), repeat=3)))
REGIONS = ("R0", "RA", "RB", "Rtip", "Rcr", "Rroot")


def digest(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


class CT:
    def __init__(self):
        self.meta = json.loads((SLABS / "native-mask.json").read_text())
        self.origin = np.asarray(self.meta["scanner_origin_xyz_mm"])
        self.pitch = self.meta["native_spacing_mm"]
        self.shape = np.asarray(self.meta["native_shape_zyx"])

    @lru_cache(maxsize=3)
    def slab(self, name):
        part = next(s for s in self.meta["slabs"] if s["url"] == name)
        raw = gzip.decompress((SLABS / name).read_bytes())
        assert hashlib.sha256(raw).hexdigest() == part["decoded_sha256"]
        header_size = struct.unpack_from("<I", raw)[0]
        header = json.loads(raw[4:4+header_size])
        segment = header["segments"]["packedMask"]
        offset = 4 + (header_size+3)//4*4 + segment["offset"]
        packed = np.frombuffer(raw, dtype="u1", offset=offset, count=segment["bytes"])
        packed = packed.reshape(part["planes"], self.shape[1], header["packed_width"])
        return np.unpackbits(packed, axis=-1, count=self.shape[2], bitorder="little")

    def cube(self, low, size):
        return self.window(low, np.full(3,size))

    def window(self, low, shape):
        x, y, z = np.asarray(low)
        nx, ny, nz = np.asarray(shape)
        assert np.all(low >= 0) and np.all(low+shape <= self.shape[::-1])
        result = []
        for part in self.meta["slabs"]:
            start = part["first_z"]
            lo, hi = max(z, start), min(z+nz, start+part["planes"])
            if lo < hi:
                result.append(self.slab(part["url"])[lo-start:hi-start, y:y+ny, x:x+nx].copy())
        cube = np.concatenate(result)
        assert cube.shape == (nz,ny,nx)
        return cube.astype(bool)


class Macro:
    def __init__(self):
        with np.load(A3) as case:
            self.points = case["points_m"]
            self.tets = case["tets"]
            self.displacement = case["displacement_m"]
            self.parents = case["parent_L0"]
        self.centroids = cKDTree(self.points[self.tets].mean(1)*1000)
        self.mesh = pv.UnstructuredGrid(
            np.column_stack((np.full(len(self.tets), 4), self.tets)).ravel(),
            np.full(len(self.tets), 10, dtype=np.uint8), self.points*1000)
        with np.load(BASE/"region_masks.npz") as zones:
            self.regions = {k: zones[k] for k in REGIONS}

    def locate(self, xyz_mm):
        return np.atleast_1d(self.mesh.find_containing_cell(np.asarray(xyz_mm)))

    def sample(self, points):
        ids = self.locate(points)
        def barycentric(xyz, sample):
            edge = xyz[..., 1:, :] - xyz[..., :1, :]
            beta = np.linalg.solve(edge.swapaxes(-1,-2), (sample-xyz[...,0,:])[...,None])[...,0]
            return np.concatenate((1-beta.sum(axis=-1, keepdims=True), beta), axis=-1)
        beta = barycentric(self.points[self.tets[ids]]*1000,points)
        repair = (ids < 0) | (beta.min(axis=1) < -1e-7)
        if repair.any():
            _, nearest = self.centroids.query(points[repair],k=64)
            trials = barycentric(self.points[self.tets[nearest]]*1000,points[repair,None])
            best = np.argmax(trials.min(axis=2),axis=1)
            selection = np.arange(len(best))
            if (trials[selection,best].min(axis=1) < -1e-7).any():
                raise ValueError("A macro displacement sample is outside the certified A3 polyhedron")
            ids[repair], beta[repair] = nearest[selection,best], trials[selection,best]
        tet = self.tets[ids]
        x = self.points[tet]*1000
        u = self.displacement[tet]*1000
        sol = np.linalg.solve(x[:,1:]-x[:,:1], u[:,1:]-u[:,:1])
        return np.einsum("ni,nij->nj", beta, u), sol.swapaxes(1,2)

    def drive(self, center, side, count):
        # Exact P1 displacements at systematic cube samples. The affine transfer
        # has explicit fit error; rotational and translation modes carry no stress.
        axis = np.linspace(-side/2, side/2, count)
        positions = np.stack(np.meshgrid(axis, axis, axis, indexing="ij"), axis=-1).reshape(-1, 3)
        u, _ = self.sample(positions + center)
        fitted, *_ = np.linalg.lstsq(np.column_stack((positions, np.ones(len(u)))), u, rcond=None)
        mismatch = u - positions @ fitted[:3] - fitted[3]
        return fitted[:3].T, float(np.linalg.norm(mismatch) / np.linalg.norm(u-u.mean(axis=0)))


def shape_gradient(q):
    xyz = OFFSETS[:, ::-1]
    q = np.asarray(q)
    factors = np.where(xyz == 1, q, 1-q)
    gradient = np.empty((8, 3))
    for j in range(3):
        gradient[:, j] = (2*xyz[:, j]-1)*np.prod(factors[:, np.arange(3) != j], axis=1)
    return gradient


def stiffness():
    edge = (1 + np.array([-1., 1.])/np.sqrt(3))/2
    kel = np.zeros((8, 3, 8, 3))
    for q in product(edge, repeat=3):
        g = shape_gradient(q)
        kel += (LAM*np.einsum("ai,bj->aibj", g, g)
                + MU*np.einsum("aj,bi->aibj", g, g)
                + MU*np.einsum("ak,bk,ij->aibj", g, g, I3))/8
    stencil = np.zeros((3, 3, 3, 3, 3))
    for i, a in enumerate(OFFSETS):
        for j, b in enumerate(OFFSETS):
            stencil[tuple(b-a+1)] += kel[i, :, j, :]
    return kel.reshape(24, 24), stencil


def compile_operator():
    source = Path(__file__).with_name("voxel_elastic_operator.cpp")
    target = OUT / "voxel_elastic_operator.dylib"
    subprocess.run(["c++", "-std=c++17", "-O3", "-shared", "-pthread", "-fPIC",
                    str(source), "-o", str(target)], check=True)
    lib = ctypes.CDLL(str(target))
    op = lib.apply_voxel_elasticity
    dbl = np.ctypeslib.ndpointer(dtype=np.float64, flags="C_CONTIGUOUS")
    ints = np.ctypeslib.ndpointer(dtype=np.int32, flags="C_CONTIGUOUS")
    op.argtypes = [ctypes.c_int, dbl, dbl, dbl, dbl, ints,
                   ctypes.c_int64, ctypes.c_int, ctypes.c_bool]
    op.restype = None
    return op


def strain_to_stress(gradient):
    strain = (gradient + gradient.swapaxes(-1, -2))*.5
    return E_MPA*(2*MU*strain + LAM*np.trace(strain, axis1=-2, axis2=-1)[..., None, None]*I3)


def mises(stress):
    dev = stress - np.trace(stress, axis1=-2, axis2=-1)[..., None, None]*I3/3
    return np.sqrt(1.5*np.einsum("...ij,...ij->...", dev, dev))


def solve_mask(mask, gradient, kernel, workers):
    n = mask.shape[0]+1
    shape = (n, n, n, 3)
    interior = (slice(1,-1),)*3
    kel, stencil = stiffness()
    void = np.argwhere(~mask).astype(np.int32)
    void_flat = void @ np.array([n*n,n,1],dtype=np.int32)
    active = np.zeros(shape[:3], bool)
    for offset in OFFSETS:
        active[tuple(slice(k, k+n-1) for k in offset)] |= mask
    free = active[interior]
    xyz = np.indices(shape[:3], dtype=float)[::-1].transpose(1,2,3,0)
    affine = np.ascontiguousarray((xyz-(n-1)/2) @ gradient.T)
    del xyz
    stress_affine = strain_to_stress(gradient)

    def apply(values, include_stencil=True):
        force = np.empty(shape)
        kernel(n, values, force, stencil, kel, void_flat, len(void_flat), workers, include_stencil)
        return force

    def project(values):
        view = np.zeros(shape)
        view[interior][free] = values.reshape(-1,3)
        return view

    def extract(values):
        return values[interior][free].ravel()

    rhs = -extract(apply(affine,include_stencil=False))
    filled = np.empty(shape)
    kernel(n, affine, filled, stencil, kel, void_flat, 0, workers, True)
    assert np.linalg.norm(extract(filled)) < 1e-10*max(np.linalg.norm(rhs),1)
    operator = LinearOperator((len(rhs),len(rhs)), matvec=lambda v:extract(apply(project(v))), dtype=float)
    k = 2*(1-np.cos(np.pi*np.arange(1,n-1)/(n-1)))
    eigen = k[:,None,None] + k[None,:,None] + k[None,None,:]

    def precondition(v):
        padded = np.zeros((n-2,n-2,n-2,3))
        padded[free] = v.reshape(-1,3)
        coeff = dstn(padded, type=1, axes=(0,1,2), norm="ortho", workers=workers)
        coeff /= eigen[...,None]
        inverse = idstn(coeff, type=1, axes=(0,1,2), norm="ortho", workers=workers)
        return inverse[free].ravel()

    precond = LinearOperator(operator.shape, matvec=precondition, dtype=float)
    iters = 0

    def progress(_):
        nonlocal iters
        iters += 1
        if iters%20 == 0:
            print("ROI CG", iters, flush=True)

    solution, status = cg(operator, rhs, M=precond, atol=1e-13, rtol=2e-7,
                          maxiter=350, callback=progress)
    assert status == 0, status
    update = project(solution)
    true_residual = float(np.linalg.norm(extract(apply(affine+update)))/np.linalg.norm(rhs))
    assert true_residual < 1e-6
    work_defect = float(abs(solution @ (operator @ solution)-solution @ rhs) /
                        max(abs(solution @ rhs),1e-30))
    assert work_defect < 1e-6
    return affine+update, stress_affine, dict(nodes=int(active.sum()),
                  displacement_dof=int(active.sum())*3, free_dof=len(rhs),
                  true_residual=true_residual, work_defect=work_defect, iterations=iters)


def run():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cells", type=int, default=112)
    parser.add_argument("--workers", type=int, default=3)
    parser.add_argument("--limit", type=int, default=3)
    args = parser.parse_args()
    OUT.mkdir(exist_ok=True)
    ct = CT()
    macro = Macro()
    traces = json.loads(TRACES.read_text())["traces"]
    by_trace = {int(row["id"]): row for row in traces}
    references = [("slice1194", ct.origin+ct.pitch*np.array([318.,1127.,1194.]), 2)]
    for row in traces:
        coords = np.array(row["points_registered_native_xyz_mm"])
        references.append((None, coords[len(coords)//2], row["id"]))
    completed = []
    used = set()
    kernel = compile_operator()
    for name, center, trace_id in references:
        if len(completed) >= args.limit:
            break
        target = args.cells
        start = np.rint((center-ct.origin)/ct.pitch).astype(int)-target//2
        location = ct.origin+(start+(target-1)/2)*ct.pitch
        if np.any(start<0) or np.any(start+target>ct.shape[::-1]):
            continue
        index = macro.locate([location])[0]
        if index < 0:
            continue
        parent = macro.parents[index]
        regions = [j for j in REGIONS if parent in macro.regions[j]]
        name = name or next((j for j in ("Rcr","R0","RA","RB") if j in regions and j not in used),None)
        if name is None or any(np.linalg.norm(location-x["center_mm"]) < target*ct.pitch for x in completed):
            continue
        try:
            gradient, fit_residual = macro.drive(location,target*ct.pitch,9)
            check, _ = macro.drive(location,target*ct.pitch,11)
        except ValueError:
            continue
        mask = ct.cube(start,target)
        faces = [np.take(mask,[0,-1],axis=j).mean() for j in range(3)]
        if min(faces) < .985 or mask.mean() < .94:
            continue
        labels, _ = ndi.label(~mask, structure=ndi.generate_binary_structure(3,1))
        seeds = np.rint((np.array(by_trace[trace_id]["points_registered_native_xyz_mm"])-ct.origin)/ct.pitch).astype(int) - start
        seeds = seeds[(seeds >= 0).all(1) & (seeds < target).all(1)]
        assigned = labels[tuple(seeds[:,::-1].T)]
        counts = np.bincount(assigned)
        if len(counts) <= 1:
            continue
        counts[0] = 0
        cavity = labels==counts.argmax()
        collar = mask & (ndi.distance_transform_edt(~cavity) <= 2.0001)
        if collar.sum() < 30:
            continue
        print(f"ROI {name}: {target} cubed, {int((~mask).sum())} void cells, strain from {regions}",flush=True)
        disp, reference_stress, checks = solve_mask(mask,gradient,kernel,args.workers)
        indices = np.argwhere(collar)
        corners = indices[:,None] + OFFSETS
        local_u = disp[tuple(corners.transpose(2,0,1))]
        sigma = strain_to_stress(local_u.transpose(0,2,1) @ shape_gradient(np.full(3,.5)))
        filled, porous = float(mises(reference_stress)), mises(sigma)
        principal = np.linalg.eigvalsh(sigma)[:,-1]
        q95 = float(np.quantile(porous,.95,method="inverted_cdf"))
        gnorm = max(np.linalg.norm(gradient),np.finfo(float).tiny)
        strain = (gradient+gradient.T)*.5
        check_strain = (check+check.T)*.5
        strain_difference = float(np.linalg.norm(strain-check_strain)/np.linalg.norm(strain))
        result = dict(name=name, macro_regions=regions, trace_id=trace_id, center_mm=location.tolist(),
                      crop_start_xyz=start.tolist(), side_mm=target*ct.pitch, cells=int(mask.sum()),
                      void_cells=int((~mask).sum()), selected_cavity_voxels=int(cavity.sum()),
                      roi_threshold_void_fraction=float((~mask).mean()), collar_cells=len(indices),
                      filled_vm_MPa=filled, porous_vm_q95_MPa=q95, q95_ratio=q95/filled,
                      filled_principal_max_MPa=float(np.linalg.eigvalsh(reference_stress)[-1]),
                      porous_principal_max_q95_MPa=float(np.quantile(principal,.95,method="inverted_cdf")),
                      collar_mean_paired_vm_difference_MPa=float(np.mean(porous-filled)),
                      collar_paired_MSE_MPa2=float(np.mean((porous-filled)**2)),
                      fit_residual=fit_residual, fit_gradient_9_11_relative_difference=float(np.linalg.norm(gradient-check)/gnorm),
                      fit_strain_9_11_relative_difference=strain_difference, boundary_gradient=gradient.tolist(), **checks)
        completed.append(result)
        used.add(name)
        print(json.dumps(result),flush=True)
        np.savez_compressed(OUT/f"{name}.npz",mask=mask,cavity=cavity,indices=indices,
                            stress_MPa=sigma,filled_stress_MPa=reference_stress,center_mm=location,start_xyz=start,
                            voxel_pitch_mm=ct.pitch,trace_xyz_mm=ct.origin+(seeds+start)*ct.pitch)
        (OUT/"coupling.json").write_text(json.dumps(dict(status="verified_paired_local_elasticity",
                    native_geometry="Binary native CT cells, six-connected void selection",
                    macro_case=str(A3.relative_to(ROOT)), macro_case_sha256=digest(A3),
                    macro_dof=macro.points.size, E_MPa=E_MPA, poisson=NU,
                    transfer="Exact A3 displacements at systematic points; fitted affine boundary on all cube faces.",
                    scope="Conditional local stress solutions, without crack propagation or whole-tooth porous ground truth.",
                    cases=completed),indent=2)+"\n")
    if not completed:
        raise RuntimeError("No registered native ROI passed validation")
    print(f"Completed {len(completed)} ROI pairs",flush=True)


if __name__ == "__main__":
    run()
