#!/usr/bin/env python3
"""Repeat the three cap-depth cases at quadratic order on the unchanged L0 mesh."""
from argparse import ArgumentParser
from pathlib import Path
import json
import platform
from time import monotonic
import numpy as np
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import cg
import matched_cap_refinement as matched
import p1_p2_common_domain_v2 as p2

I = np.eye(3)


def make_quadratic(p, cells, faces):
    all_edges = np.sort(cells[:,p2.EDGES].reshape(-1,2),axis=1)
    edges, inv = np.unique(all_edges,axis=0,return_inverse=True)
    pairs = np.sort(faces[:,[[0,1],[1,2],[2,0]]].reshape(-1,2),axis=1)
    edge_key = edges[:,0].astype(np.int64)*len(p)+edges[:,1]
    face_key = pairs[:,0].astype(np.int64)*len(p)+pairs[:,1]
    where = np.searchsorted(edge_key, face_key)
    np.testing.assert_array_equal(edge_key[where], face_key)
    return (np.vstack([p,p[edges].mean(1)]),
            np.column_stack([cells,len(p)+inv.reshape(-1,6)]),
            edges, (len(p)+where).reshape(-1,3))


def assemble_quadratic(n, conn, g, volume, bary):
    m = len(conn)*900
    row = np.empty(m, dtype=np.int32)
    col = np.empty_like(row)
    val = np.empty(m)
    la, mu = matched.LAM, matched.MU
    for i in range(0,len(conn),1500):
        sl = slice(i,min(i+1500,len(conn)))
        G = p2.gradients(g[sl],bary)
        local = (la*np.einsum("eqai,eqbk->eaibk",G,G) +
                 mu*np.einsum("eqak,eqbi->eaibk",G,G))
        local += mu*np.einsum("eab,ik->eaibk",np.einsum("eqaj,eqbj->eab",G,G),I)
        local = (local*(volume[sl,None,None,None,None]/len(bary))).reshape(-1,30,30)
        dof = (3*conn[sl,:,None]+np.arange(3)).reshape(-1,30)
        dst = slice(i*900,sl.stop*900)
        row[dst] = np.broadcast_to(dof[:,:,None],local.shape).ravel()
        col[dst] = np.broadcast_to(dof[:,None,:],local.shape).ravel()
        val[dst] = local.ravel()
    return coo_matrix((val,(row,col)),shape=(n,n)).tocsr()


def stress(u, conn, g, bary):
    G = p2.gradients(g,bary)
    grad = np.einsum("eai,eqaj->eqij",u[conn],G)
    eps = (grad + grad.swapaxes(-1,-2))/2
    sigma = matched.LAM*np.trace(eps,axis1=-2,axis2=-1)[...,None,None]*I + 2*matched.MU*eps
    return sigma, eps, G


def stress_readback(u, conn, g, volume, bary):
    forces = np.zeros_like(u)
    energy = 0.
    for i in range(0,len(conn),5000):
        sl = slice(i,min(i+5000,len(conn)))
        sigma, eps, G = stress(u,conn[sl],g[sl],bary)
        energy += np.einsum("eqij,eqij,e->",sigma,eps,volume[sl])/(2*len(bary))
        local = np.einsum("eqij,eqaj,e->eai",sigma,G,volume[sl])/len(bary)
        for j in range(10):
            np.add.at(forces,conn[sl,j],local[:,j])
    return forces,energy


def q95_regions(u, conn, g, volume, masks, order):
    bary, weights = p2.duffy(order)
    vm = np.empty((len(conn),len(weights)))
    for i in range(0,len(conn),700):
        sl = slice(i,min(i+700,len(conn)))
        sigma, _, _ = stress(u,conn[sl],g[sl],bary)
        dev = sigma - np.trace(sigma,axis1=-2,axis2=-1)[...,None,None]*I/3
        vm[sl] = np.sqrt(1.5*np.einsum("eqij,eqij->eq",dev,dev))/1e6
    return {name:float(p2.wquant(vm[mask].ravel(),(volume[mask,None]*weights).ravel(),(.95,))[0])
            for name,mask in masks.items()}


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("--p1",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    opts = parser.parse_args()
    start = monotonic()
    p1 = {row["cap_depth"]:row for row in json.loads(opts.p1.read_text())["cases"]
          if row["mesh"]=="L0"}
    source = matched.fe.B/"numerics/L0/solution.npz"
    p2record = matched.PAPER/"numerics/p1_p2_common_domain/results.json"
    with np.load(source) as obj:
        p,cells = obj["points_m"],obj["tets"]
    fixed_data = matched.fe.fixed_experiment(p,cells)
    faces = fixed_data["faces"]
    p2nodes,conn,edges,face_mid = make_quadratic(p,cells,faces)
    g,volume = matched.fe.basis_data(p,cells)
    choose = fixed_data["loaded"]
    face_force = -matched.PRESSURE*fixed_data["areas"][choose,None]*fixed_data["normals"][choose]/3
    load = np.zeros_like(p2nodes)
    for j in range(3):
        np.add.at(load,face_mid[choose,j],face_force)
    resultant = load.sum(0)
    extent = np.ptp(p2nodes,axis=0).max()
    np.testing.assert_allclose(resultant,fixed_data["force"].sum(0),rtol=1e-12,atol=1e-8)
    np.testing.assert_allclose(np.cross(p2nodes,load).sum(0),np.cross(p,fixed_data["force"]).sum(0),rtol=1e-11,atol=1e-9)
    beta = .1381966011250105
    bary = np.full((4,4),beta)
    np.fill_diagonal(bary,1-3*beta)
    A = assemble_quadratic(p2nodes.size,conn,g,volume,bary)
    print(f"Assembled quadratic stiffness, {A.nnz:,} nonzeros",flush=True)
    q = (p-fixed_data["center"])@fixed_data["basis"]
    ns, _, _ = matched.fe.core.geometric_coordinates(q,fixed_data["surface_q"])
    side = q[:,0]>=0
    smax = np.where(side,ns[side].max(),ns[~side].max())
    x = (p2nodes-p2nodes.mean(0))/extent
    modes = np.zeros((len(x),3,6))
    modes[:,:,:3] = I
    for j in range(3):
        modes[:,:,3+j] = np.cross(I[j],x)
    cases = []
    for depth in matched.DEPTHS:
        cap = (ns>=.80)&(ns>=smax-depth)
        p2cap = np.concatenate((cap,cap[edges].all(1)))
        free = np.repeat(~p2cap,3)
        A_free = A[free,:][:,free].tocsr()
        rhs = load.ravel()[free]
        np.random.seed(20261127)
        ml = matched.fe.pyamg.smoothed_aggregation_solver(
            A_free.tobsr(blocksize=(3,3)), B=modes.reshape(-1,6)[free],
            symmetry="symmetric", max_coarse=250, max_levels=12,
            presmoother=("block_gauss_seidel",{"sweep":"symmetric"}),
            postsmoother=("block_gauss_seidel",{"sweep":"symmetric"}))
        count = []
        uf, info = cg(A_free,rhs,M=ml.aspreconditioner(),rtol=2e-10,atol=0,maxiter=2500,
                      callback=lambda _:count.append(1))
        if info:
            raise RuntimeError(f"CG failed for depth {depth}, info={info}")
        del ml
        residual = float(np.linalg.norm(A_free@uf-rhs)/np.linalg.norm(rhs))
        del A_free
        u = np.zeros(p2nodes.size)
        u[free] = uf
        u = u.reshape(-1,3)
        internal, energy = stress_readback(u,conn,g,volume,bary)
        imbalance = internal-load
        reaction = np.where(p2cap[:,None],imbalance,0)
        force_error = float(np.linalg.norm((reaction+load).sum(0))/np.linalg.norm(resultant))
        moment_error = float(np.linalg.norm(np.cross(p2nodes,reaction+load).sum(0))/(extent*np.linalg.norm(resultant)))
        energy_error = abs(2*energy-float((u*load).sum()))/(2*energy)
        readback = float(np.linalg.norm(imbalance.ravel()[free])/np.linalg.norm(rhs))
        if max(residual,force_error,moment_error,energy_error,readback)>2e-7:
            raise RuntimeError(f"Independent verification failed for depth {depth}")
        levels = {n:q95_regions(u,conn,g,volume,fixed_data["masks"],n) for n in (5,7)}
        q95 = levels[7]
        if depth==.04:
            previous = json.loads(p2record.read_text())
            np.testing.assert_allclose(energy,previous["P2_energy_J"],rtol=3e-8)
            if previous["quadrature"][-1]["order"] != 7:
                raise RuntimeError("Archived comparison uses a different Q95 quadrature")
            reference = {row["region"]:row["P2_vm_MPa"][1] for row in previous["regions"]}
            np.testing.assert_allclose(list(q95.values()),[reference[r] for r in q95],rtol=3e-8)
        coarse = {r:z["von_mises_Q95_MPa"] for r,z in p1[depth]["regions"].items()}
        cases.append(dict(depth=depth,free_dofs=int(free.sum()),iterations=len(count),
                          energy_J=float(energy),p1_Q95_MPa=coarse,p2_Q95_MPa=q95,
                          order_change_percent={r:100*(q95[r]/coarse[r]-1) for r in q95},
                          quadrature_125_to_343_percent={r:100*(q95[r]/levels[5][r]-1) for r in q95},
                          free_residual=residual,force_readback=readback,force_balance=force_error,
                          moment_balance=moment_error,work_energy_error=energy_error))
        print(f"L0 P2 depth={depth:.2f}: root {q95['Rroot']:.6f} MPa; max readback {max(readback,residual):.3g}",flush=True)
    baseline = cases[1]
    for c in cases:
        c.update({f"support_{order}_change_percent":{r:100*(v/baseline[f"{order}_Q95_MPa"][r]-1)
                  for r,v in c[f"{order}_Q95_MPa"].items()} for order in ("p1","p2")})
    record = dict(status="passed",host=platform.platform(),cells=len(cells),p2_total_dofs=p2nodes.size,
                  input_sha256={str(path.resolve().relative_to(matched.PROJECT)):matched.file_sha256(path) for path in (source,p2record,opts.p1)},
                  scope="Same L0 geometry, mesh, load, regions and cap subcomplex. Higher-order fixed edge nodes have both endpoints fixed. Finite P1/P2 contrast, not a certified discretization error.",
                  cases=cases,runtime_seconds=monotonic()-start)
    opts.output.write_text(json.dumps(record,indent=2)+"\n")


if __name__=="__main__":
    main()
