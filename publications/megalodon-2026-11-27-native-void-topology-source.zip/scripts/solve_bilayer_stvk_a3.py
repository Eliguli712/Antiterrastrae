#!/usr/bin/env python3
"""Solve the candidate A3 bilayer at its archived 1 MPa reference load."""
import argparse
import ctypes
import hashlib
import json
from pathlib import Path
import sys
import time
import subprocess

import numpy as np
from scipy.sparse.linalg import LinearOperator, cg

PAPER = Path(__file__).resolve().parents[1]
PROJECT = PAPER.parents[2]
VALIDATION = PROJECT / "output/publication_validation_2026-11-12"
SOURCE = VALIDATION / "data/bilayer_A3_0p5mm/fields.npz"
OUT = PAPER / "numerics/bilayer_stvk_a3"
sys.path.insert(0, str(VALIDATION / "scripts"))
import elastic_diagnostics as elasticity
import finite_strain_bilayer as stvk
import pyamg


def evaluate(u, tets, gradients, volumes, lam, mu, recover=False):
    """Integrate first Piola equilibrium and optionally recover Cauchy stress."""
    internal = np.zeros_like(u)
    energy = 0.0
    min_j = np.inf
    scalar = np.empty(len(tets)) if recover else None
    stress = np.empty((len(tets), 3, 3)) if recover else None
    for start in range(0, len(tets), 45_000):
        block = slice(start, start + 45_000)
        cells, g, v = tets[block], gradients[block], volumes[block]
        grad_u = np.einsum("eai,eaj->eij", u[cells[:, 1:]] - u[cells[:, :1]], g[:, 1:])
        deformation = np.eye(3) + grad_u
        piola, _, density, _ = stvk.tensor(
            deformation, lam[block], mu[block], np.ones(len(cells), dtype=bool), G=grad_u
        )
        j = np.linalg.det(deformation)
        min_j = min(min_j, float(j.min()))
        energy += float(np.dot(v, density))
        local = np.einsum("eij,eaj,e->eai", piola, g, v)
        np.add.at(internal, cells, local)
        if recover:
            cauchy = piola @ deformation.swapaxes(1, 2) / j[:, None, None]
            dev = cauchy - np.trace(cauchy, axis1=1, axis2=2)[:, None, None] * np.eye(3) / 3
            stress[block] = cauchy
            scalar[block] = np.sqrt(1.5 * np.einsum("eij,eij->e", dev, dev))
    return internal, energy, min_j, scalar, stress


def quantiles(values, weights):
    order = values.argsort()
    mass = np.cumsum(weights[order], dtype=np.longdouble)
    return (values[order[np.searchsorted(mass, mass[-1]*np.array([.5, .95, .99]))]]/1e6).tolist()


def newton_kernel():
    path = Path(__file__).with_name("stvk_a3_jacobian.cpp")
    target = OUT / "stvk_a3_jacobian.dylib"
    subprocess.run(["c++", "-std=c++17", "-O3", "-shared", "-fPIC",
                    str(path), "-o", str(target)], check=True)
    library = ctypes.CDLL(str(target))
    tangent = library.stvk_jacobian
    double = np.ctypeslib.ndpointer(dtype=np.float64, flags="C_CONTIGUOUS")
    integer = np.ctypeslib.ndpointer(dtype=np.int32, flags="C_CONTIGUOUS")
    tangent.argtypes = [integer] + [double]*8 + [ctypes.c_int64, ctypes.c_int64]
    tangent.restype = None
    return tangent


def tangent_state(u, t, g, lam, mu):
    F = np.empty((len(t),3,3))
    S = np.empty_like(F)
    for start in range(0,len(t),80_000):
        block = slice(start,start+80_000)
        nodes = t[block]
        gradient = np.einsum("eai,eaj->eij",u[nodes[:,1:]]-u[nodes[:,:1]],g[block,1:])
        F[block] = np.eye(3)+gradient
        _,S[block],_,_ = stvk.tensor(F[block],lam[block],mu[block],np.ones(len(nodes),bool),G=gradient)
    return F,S


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--newton", action="store_true")
    args = parser.parse_args()
    start = time.monotonic()
    checks = stvk.selfcheck()
    OUT.mkdir(exist_ok=True)
    if (OUT / "fields.npz").is_file():
        raise FileExistsError(OUT / "fields.npz")
    with np.load(SOURCE) as archive:
        p, t = (archive[k] for k in ("points_m", "tets"))
        t = np.ascontiguousarray(t,dtype=np.int32)
        force, fixed = (archive[k] for k in ("force_N", "fixed_nodes"))
        lam, mu = (archive[k] for k in ("lambda_Pa", "mu_Pa"))
        u = archive["displacement_m"]
        boundary = archive["boundary_faces"]
        linear = archive["von_mises_Pa"]
    g, v = elasticity.basis_data(p, t)
    free = np.ones_like(u, dtype=bool)
    free[fixed] = False
    indices = np.flatnonzero(free.ravel())
    load_norm = np.linalg.norm(force[free])
    x = (p - p.mean(0)) / np.ptp(p, axis=0).max()
    modes = np.zeros((len(p), 3, 6))
    modes[:, :, :3] = np.eye(3)
    for j, row in enumerate(np.eye(3)):
        modes[:, :, j + 3] = np.cross(row, x)
    print(f"Assemble A3 reference tangent: {len(t):,} tetrahedra and {free.sum():,} free DOFs", flush=True)
    matrix = elasticity.assemble(p, t, g, v, lam, mu)
    k0 = matrix[indices][:, indices].tocsr()
    del matrix
    print(f"AMG for A3: {k0.nnz:,} nonzeros", flush=True)
    hierarchy = pyamg.smoothed_aggregation_solver(
        k0.tobsr(blocksize=(3, 3)), B=modes.reshape(-1, 6)[indices],
        symmetry="symmetric", max_levels=11, max_coarse=250,
        presmoother=("block_gauss_seidel", {"sweep": "symmetric"}),
        postsmoother=("block_gauss_seidel", {"sweep": "symmetric"}),
    )
    preconditioner = hierarchy.aspreconditioner()
    tol = 2e-7
    history = []
    if args.newton:
        tangent = newton_kernel()

        def action(candidate, F, S):
            result = np.empty_like(candidate)
            tangent(t,g,v,lam,mu,F,S,candidate,result,len(t),len(p))
            return result

        rng = np.random.default_rng(712)
        perturb = rng.standard_normal(p.shape)
        perturb[~free] = 0
        F0,S0 = tangent_state(np.zeros_like(u),t,g,lam,mu)
        check = action(perturb,F0,S0)[free]
        reference = k0@perturb[free]
        err = np.linalg.norm(check-reference)/np.linalg.norm(reference)
        assert err < 2e-13
        checks["compiled_zero_state_tangent_error"] = float(err)
        del F0,S0
    for iteration in range(60):
        internal, energy, min_j, _, _ = evaluate(u, t, g, v, lam, mu)
        residual = (internal - force)[free]
        err = float(np.linalg.norm(residual) / load_norm)
        history.append(dict(iteration=iteration, residual=err, minimum_J=min_j, strain_energy_J=energy))
        print(json.dumps(history[-1]), flush=True)
        if err < tol:
            break
        step_matrix = k0
        if args.newton:
            F,S = tangent_state(u,t,g,lam,mu)

            def matvec(x):
                vector = np.zeros_like(u)
                vector[free] = x
                return action(vector,F,S)[free]

            step_matrix = LinearOperator(k0.shape,matvec=matvec,dtype=float)
        delta, code = cg(step_matrix, -residual, M=preconditioner, rtol=1e-4, atol=0., maxiter=180 if args.newton else 700)
        if args.newton and (code != 0 or float(residual @ delta) >= 0):
            delta, code = cg(k0, -residual, M=preconditioner, rtol=1e-4, atol=0., maxiter=700)
        if args.newton:
            del F,S
        if code != 0:
            raise RuntimeError(f"Reference tangent correction CG failed: {code}")
        step = np.zeros_like(u)
        step[free] = delta
        slope = float(residual @ delta)
        assert slope < 0
        potential = energy - float(np.einsum("ij,ij->", u, force))
        for scale in 0.5**np.arange(15):
            trial = u + scale * step
            _, trial_energy, trial_j, _, _ = evaluate(trial, t, g, v, lam, mu)
            trial_potential = trial_energy - float(np.einsum("ij,ij->", trial, force))
            roundoff = 64*np.finfo(float).eps*max(abs(potential), abs(energy), 1e-30)
            if (trial_j > .2 and
                    trial_potential <= potential + 1e-4*scale*slope + roundoff):
                u = trial
                history[-1]["step"] = float(scale)
                np.save(OUT/"checkpoint.npy",u)
                break
        else:
            raise RuntimeError("StVK residual/energy line search failed")
    else:
        raise RuntimeError("A3 StVK did not reach the prescribed equilibrium tolerance")
    del k0, hierarchy, preconditioner
    internal, energy, min_j, vm, sig = evaluate(u, t, g, v, lam, mu, recover=True)
    reaction = np.zeros_like(force)
    reaction[fixed] = (internal - force)[fixed]
    external = force + reaction
    normalization = np.linalg.norm(force.sum(0))
    force_defect = float(np.linalg.norm(external.sum(0)) / normalization)
    moment_defect = float(np.linalg.norm(np.cross(p + u, external).sum(0))
                          / (normalization * np.ptp(p, axis=0).max()))
    assert max(force_defect, moment_defect) < 2e-6
    assert np.isfinite(sig).all() and min_j > .2
    filename = OUT / "fields.npz"
    np.savez_compressed(filename, points_m=p, tets=t, boundary_faces=boundary,
                        volumes_m3=v, displacement_m=u, cauchy_stress_Pa=sig,
                        von_mises_Pa=vm, fixed_nodes=fixed, force_N=force)
    with SOURCE.open("rb") as stream:
        provenance = hashlib.file_digest(stream, "sha256").hexdigest()
    record = dict(status="passed", model="A3 candidate bilayer StVK, 1 MPa dead reference load",
                  source=str(SOURCE.relative_to(PROJECT)), source_sha256=provenance,
                  nodes=len(p), total_dof=p.size, free_dof=int(free.sum()), tetrahedra=len(t),
                  finite_element_boundary_faces=len(boundary), equilibrium_residual=history[-1]["residual"],
                  minimum_J=min_j, force_defect=force_defect, current_moment_defect=moment_defect,
                  energy_J=energy, max_displacement_mm=float(np.linalg.norm(u, axis=1).max()*1000),
                  linear_Q50_Q95_Q99_MPa=quantiles(linear, v), nonlinear_Q50_Q95_Q99_MPa=quantiles(vm, v),
                  history=history, checks=checks,
                  runtime_s=time.monotonic()-start)
    (OUT / "solve.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2), flush=True)


if __name__ == "__main__":
    main()
