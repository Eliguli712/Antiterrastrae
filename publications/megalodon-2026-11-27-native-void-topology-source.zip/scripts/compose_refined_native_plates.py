#!/usr/bin/env python3
"""Preserve the latest calculation charts and replace only refined map panels."""
import argparse
import io
import json
from pathlib import Path
from tempfile import TemporaryDirectory

import fitz
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, LogNorm
import numpy as np
from PIL import Image
from scipy.spatial import cKDTree

import revise_figures as layout
from render_continuous_native_comparisons import CACHE, PROJECT, PAPER, continuous_projection
from render_full_surface_stress import TRIANGLES, VERTICES, make_rasterizer, send_triangles
from render_native_field_plates import BASELINE, volume_average

F = PAPER/"figures"
OUT = PAPER/"numerics/margin_a30_a3"
SCALE = 72/25.4


def compose(base, strip, rect, stem):
    with fitz.open(base) as old, fitz.open(stream=strip.getvalue(),filetype="pdf") as new, fitz.open() as doc:
        page = doc.new_page(width=old[0].rect.width,height=old[0].rect.height)
        for area in (
            fitz.Rect(0,0,page.rect.width,rect.y0),
            fitz.Rect(0,rect.y1,page.rect.width,page.rect.height),
            fitz.Rect(0,rect.y0,rect.x0,rect.y1),
            fitz.Rect(rect.x1,rect.y0,page.rect.width,rect.y1),
        ):
            if not area.is_empty:
                page.show_pdf_page(area,old,0,clip=area)
        page.show_pdf_page(rect,new,0)
        doc.save(F/f"{stem}.pdf",garbage=4,deflate=True)
        doc.rewrite_images(dpi_threshold=450,dpi_target=355,quality=91)
        doc.save(F/f"{stem}_preview.pdf",garbage=4,deflate=True)


def bilayer(stvk=False):
    label = "StVK" if stvk else "linear"
    stem = f"bilayer_A3_{label.lower()}_native74"
    record = json.loads((PAPER/"review"/f"{stem}.json").read_text())
    assert record["status"]=="passed" and record["mesh_faces"]==TRIANGLES
    norm = LogNorm(.1,300)
    fig = layout.canvas(183,50)
    for j,name in enumerate(("Front","Oblique","Reverse")):
        origin = 61*j
        img = Image.open(F/f"{stem}_{j}.png")
        ax = layout.axmm(fig,origin+5,9,51,33)
        ax.imshow(img,interpolation="none")
        ax.set_axis_off()
        layout.panel(fig,origin+1,48,"ghi"[j])
        layout.txt(fig,origin+31,48,f"{name} · A3 bilayer {label}",6.2,ha="center",va="top")
    bar = fig.colorbar(plt.cm.ScalarMappable(norm=norm,cmap="turbo"),
                       cax=layout.axmm(fig,63,4,54,1.3),orientation="horizontal",extend="both")
    bar.set_ticks([.1,1,10,100,300],labels=["0.1","1","10","100","300"])
    bar.ax.tick_params(labelsize=5,pad=1)
    layout.txt(fig,60,4.65,"MPa",5.2,ha="right")
    layout.txt(fig,121,4.65,"FE boundary field on native CT",5.2)
    encoded = io.BytesIO()
    fig.savefig(encoded,format="pdf",dpi=600)
    plt.close(fig)
    base = F/"review_base_validation_material_attachment_native_continuous.pdf"
    with fitz.open(base) as pdf:
        rect = pdf[0].rect
        replacement = fitz.Rect(0,rect.height-50*SCALE,rect.width,rect.height)
    compose(base,encoded,replacement,f"validation_material_attachment_A3_{label.lower()}_native74")


def margin():
    record = json.loads((OUT/"results.json").read_text())
    assert record["status"]=="passed"
    with np.load(OUT/"field.npz") as r, np.load(BASELINE/"L0/solution.npz") as b:
        points,tets,weight = (r[k] for k in ("points_m","tets","volumes_m3"))
        ids = np.unique(r["boundary_faces"])
        scalar = volume_average(tets,points,weight,r["tension_Pa_per_N"]/1e6)
        p1_local = (b["points_m"]-b["center_m"])@b["basis"]*1000
        center,basis = b["center_m"]*1000,b["basis"]
    tree = cKDTree(points[ids]*1000)
    nodal = scalar[ids,None]
    vertex = np.memmap(CACHE/"vertices.f64","<f8","r",shape=(VERTICES,3))
    face = np.memmap(CACHE/"triangles.u32","<u4","r",shape=(TRIANGLES,3))
    colors = np.empty((VERTICES,3),dtype=np.uint8)
    pal = np.array(json.loads((PAPER/"numerics/reference_palette_512.json").read_text())["RGBA_8bit"])[:,:3]
    exceed = 0
    for j in range(0,VERTICES,200_000):
        sl = slice(j,j+200_000)
        values,distance = continuous_projection(tree,nodal,vertex[sl])
        exceed += int((distance>1.5).sum())
        colour = np.rint(np.clip((np.log10(np.maximum(values[:,0],1e-4))+4)/3,0,1)*(len(pal)-1)).astype(int)
        colors[sl] = pal[colour]
    span, lower = np.ptp(p1_local[:,1]),p1_local[:,1].min()
    with TemporaryDirectory(prefix="a3-edge-") as tmp:
        tmp = Path(tmp)
        with make_rasterizer(tmp) as renderer:
            for j in range(0,TRIANGLES,800_000):
                block=face[j:j+800_000]
                uid,mapping=np.unique(block,return_inverse=True)
                q=(vertex[uid]-center)@basis
                projected=np.column_stack((900+26*q[:,0],95+27*(q[:,1]-lower),-q[:,2]))
                send_triangles(renderer,2,projected,colors[uid]/255,mapping.reshape(-1,3))
            renderer.stdin.close()
            log=renderer.stderr.read().decode().strip()
            assert renderer.wait()==0 and log.endswith(f"2 triangles submitted {TRIANGLES}")
        raster=Image.frombytes("RGBA",(1800,1600),(tmp/"native_figure8_2.rgba").read_bytes())
        raster.save(F/"margin_a30_A3_native74.png")
    fig = layout.canvas(45.5,68)
    cmap = ListedColormap(pal/255)
    ax = layout.axmm(fig,4.5,15,31,47)
    ax.imshow(raster,extent=[-900/26,900/26,(1600-95)/(27*span),-95/(27*span)],
              aspect="auto",interpolation="none")
    ax.set_xlim(p1_local[:,0].min()-1,p1_local[:,0].max()+1)
    ax.set_ylim(1.03,-.03)
    ax.set_xlabel("Transverse (mm)",fontsize=5.5,labelpad=1)
    ax.set_ylabel("Rootward position s",fontsize=5.5,labelpad=1)
    ax.tick_params(labelsize=5.2,pad=1)
    c = fig.colorbar(plt.cm.ScalarMappable(norm=LogNorm(1e-4,.1),cmap=cmap),
                     cax=layout.axmm(fig,37.0,18,1.3,39),extend="both")
    c.set_ticks([1e-4,1e-3,1e-2,.1])
    c.ax.tick_params(labelsize=5,pad=1)
    layout.panel(fig,1.4,67,"b")
    layout.txt(fig,22,67,"A3 submodel · margin A, 30°",6.0,ha="center",va="top")
    layout.txt(fig,22,6,r"Principal tension ($\mathrm{MPa\,N^{-1}}$)",5.2,ha="center")
    encoded=io.BytesIO()
    fig.savefig(encoded,format="pdf",dpi=600)
    plt.close(fig)
    base = F/"review_base_boundary_edge_transmission_distributed.pdf"
    compose(base,encoded,fitz.Rect(46.5*SCALE,0,92*SCALE,68*SCALE),
            "boundary_edge_transmission_a3_native74")
    (OUT/"render.json").write_text(json.dumps(dict(status="passed",native_triangles=TRIANGLES,
        exceeded_1p5mm_display_distance=exceed,render=log),indent=2)+"\n")


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("which",choices=("linear","stvk","margin"))
    choice=parser.parse_args().which
    if choice=="margin":
        margin()
    else:
        bilayer(choice=="stvk")
