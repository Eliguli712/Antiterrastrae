#!/usr/bin/env python3
"""Six affine tests of a nested native CT block in orthonormal Kelvin notation."""
import json
import numpy as np

from coupled_ct_submodels import (
    E_MPA, NU, OFFSETS, OUT, compile_operator, shape_gradient, solve_mask, strain_to_stress,
)


def main():
    with np.load(OUT/"Rcr.npz") as source:
        target = np.argwhere(source["cavity"])
        cells = source["mask"]
        position = source["start_xyz"]
        center=np.round(target.mean(0)).astype(int)
        extent=56
        low=np.clip(center-extent//2,0,np.asarray(cells.shape)-extent)
        mask=cells[tuple(slice(s,s+extent) for s in low)]
    basis=np.zeros((6,3,3))
    for i in range(3):
        basis[i,i,i]=1.
    for row,(i,j) in enumerate(((1,2),(0,2),(0,1)),3):
        basis[row,i,j]=basis[row,j,i]=1/np.sqrt(2)
    h=1e-4
    reference=np.einsum("aij,bij->ab",basis,strain_to_stress(basis))
    tensor=np.empty((6,6))
    kernel=compile_operator()
    xyz=np.argwhere(mask)
    g=shape_gradient([.5,.5,.5])
    checks=[]
    for i, e in enumerate(basis):
        print(f"Apparent tensor mode {i+1}/6",flush=True)
        disp,_,audit=solve_mask(mask,h*e,kernel,2)
        mean=np.zeros((3,3))
        for start in range(0,len(xyz),30_000):
            points=xyz[start:start+30_000,None]+OFFSETS
            values=disp[tuple(points.transpose(2,0,1))]
            mean+=strain_to_stress(values.swapaxes(1,2)@g).sum(0)
        mean/=mask.size
        tensor[:,i]=np.einsum("aij,ij->a",basis,mean)/h
        checks.append(audit)
    symmetry=float(np.linalg.norm(tensor-tensor.T)/np.linalg.norm(tensor))
    c=(tensor+tensor.T)*.5
    eig=np.linalg.eigvalsh(c)
    L=np.linalg.cholesky(reference)
    invL=np.linalg.inv(L)
    relative=np.linalg.eigvalsh(invL@c@invL.T)
    assert symmetry < 3e-6 and min(eig)>0 and max(relative) <= 1.00001
    summary=dict(status="passed_six_affine_KUBC_tests",crop_start_xyz=(position+low[::-1]).tolist(),
                 cells_per_side=extent, side_mm=extent*.018, retained_void_fraction=float((~mask).mean()),
                 E_solid_MPa=E_MPA,nu_solid=NU,shear_convention="Kelvin sqrt(2)",
                 stiffness_MPa=c.tolist(), asymmetry_relative=symmetry, relative_to_filled_energy_eigenvalues=relative.tolist(),
                 free_checks=checks, scope="Selected CT subwindow with kinematic uniform boundary strain. Finite-window apparent tensor, not an identified bulk tissue property.")
    (OUT/"transition_apparent_tensor.json").write_text(json.dumps(summary,indent=2)+"\n")
    print(json.dumps(summary,indent=2),flush=True)


if __name__=="__main__":
    main()
