#!/usr/bin/env python3
"""Keep paired cells together and resample spatial blocks in each fixed ROI."""
import argparse
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from coupled_ct_submodels import INTERACTIVE, OUT, PAPER, TRACES, Macro, mises


def bootstrap(indices, delta, block, draws, seed):
    keys = indices//block
    _, membership = np.unique(keys, axis=0, return_inverse=True)
    z_mean = np.bincount(membership, weights=indices[:,0])/np.bincount(membership)
    partitions = np.digitize(z_mean, np.quantile(z_mean,[1/3,2/3]))
    group_mass = np.bincount(membership)
    group_sum = np.bincount(membership, weights=delta)
    group_square = np.bincount(membership, weights=delta**2)
    rng = np.random.default_rng(seed)
    paired = np.zeros((draws,2))
    for stratum in (0,1,2):
        ids = np.flatnonzero(partitions==stratum)
        if len(ids) < 2:
            raise ValueError("Fewer than two independent spatial blocks in a stratum")
        runs = rng.choice(ids, size=(draws,len(ids)),replace=True)
        mass = group_mass[runs].sum(axis=1)
        weight = group_mass[ids].sum()/len(indices)
        paired[:,0] += weight*group_sum[runs].sum(axis=1)/mass
        paired[:,1] += weight*group_square[runs].sum(axis=1)/mass
    return dict(block_voxels=block, block_count=len(group_mass),
                stratum_counts=np.bincount(partitions,minlength=3).tolist(),
                bootstrap_repetitions=draws, standard_error=paired.std(axis=0,ddof=1).tolist(),
                confidence_interval=np.quantile(paired,[.025,.975],axis=0).T.tolist())


def cavity_survey():
    with (INTERACTIVE/"review/microtubes/inner-shells.csv").open() as file:
        rows = list(csv.DictReader(file))
    closed = [r for r in rows if abs(float(r["signed_volume_mm3"])) > .001]
    volume = sum(abs(float(r["signed_volume_mm3"])) for r in closed)
    traces = json.loads(TRACES.read_text())
    assert len(closed)==684, len(closed)
    return dict(closed_components=len(closed), closed_volume_mm3=volume,
                demonstrated_scan_traces=traces["survey"]["traces_qualified"],
                atlas_comparison="No registered reference canal graph or histological tissue labels.")


def alignment(source):
    macro = Macro()
    traces = json.loads(source.read_text())["traces"]
    starts, stops, keys = [], [], []
    for item in traces:
        path = np.asarray(item["points_registered_native_xyz_mm"])
        starts.append(path[:-1])
        stops.append(path[1:])
        keys.append(np.full(len(path)-1,item["id"]))
    starts = np.concatenate(starts)
    stops = np.concatenate(stops)
    keys = np.concatenate(keys)
    points = (starts+stops)/2
    edges = stops-starts
    weight = np.linalg.norm(edges,axis=1)
    ids = macro.locate(points)
    contains = (ids >= 0) & (weight > 0)
    points,edges,weight,ids,keys=(x[contains] for x in (points,edges,weight,ids,keys))
    tet = macro.tets[ids]
    x = macro.points[tet]*1000
    a = x[:,1:] - x[:,:1]
    beta = np.linalg.solve(a.swapaxes(1,2),(points-x[:,0])[...,None])[...,0]
    certified = (beta.min(1)>=-1e-7) & (beta.sum(1)<=1+1e-7)
    ids,weight,keys,unit=(q[certified] for q in (ids,weight,keys,edges/weight[:,None]))
    tet = macro.tets[ids]
    disp = macro.displacement[tet]*1000
    grad = np.linalg.solve(a[certified],disp[:,1:]-disp[:,:1]).swapaxes(1,2)
    strain = (grad+grad.swapaxes(1,2))/2
    eig,axes = np.linalg.eigh(strain)
    gap = np.diff(eig,axis=1)>1e-5*np.maximum(np.linalg.norm(eig,axis=1),1e-12)[:,None]
    cosines=abs(np.einsum("ni,nij->nj",unit,axes))
    angles=np.rad2deg(np.arccos(cosines.clip(0,1)))
    parent=macro.parents[ids]

    def weighted_angle(values,weights):
        if not len(values): return None
        order=values.argsort()
        c=np.cumsum(weights[order])
        return float(values[order[np.searchsorted(c,.5*c[-1])]])

    result={}
    for label,original in macro.regions.items():
        mask=np.isin(parent,original)
        if not mask.any():
            result[label]=dict(traces=0)
            continue
        u,w,a,g=unit[mask],weight[mask],angles[mask],gap[mask]
        fabric=np.einsum("ni,nj,n->ij",u,u,w)/w.sum()
        eigen,direction=np.linalg.eigh(fabric)
        result[label]=dict(traces=int(np.unique(keys[mask]).size),trace_length_mm=float(w.sum()),
            fabric=fabric.tolist(),fabric_eigenvalues=eigen.tolist(),leading_direction_xyz=direction[:,-1].tolist(),
            weighted_median_angle_max_principal_deg=weighted_angle(a[g[:,1],2],w[g[:,1]]),
            weighted_median_angle_min_principal_deg=weighted_angle(a[g[:,0],0],w[g[:,0]]))
    return dict(source=source.name,traces=len(traces),valid_segments=len(ids),excluded_segments=int(len(contains)-len(ids)),
                region_results=result,
                scope="Non-random CT trace subset. Selected directions are descriptive and require a registered independent histological comparison.")


def plate(cases):
    fig, axes=plt.subplots(2,len(cases),figsize=(7.15,3.8),squeeze=False,
                           gridspec_kw={"height_ratios":[1.1,1]})
    for j, case in enumerate(cases):
        with np.load(OUT/f"{case['name']}.npz") as data:
            mask,cavity,indices = data["mask"],data["cavity"],data["indices"]
            stress=mises(data["stress_MPa"])
            filled=float(mises(data["filled_stress_MPa"]))
            pitch=float(data["voxel_pitch_mm"])
        z=int(cavity.sum(axis=(1,2)).argmax())
        color=np.zeros((*mask[z].shape,3))
        color[mask[z]]=[.90,.90,.86]
        color[cavity[z]]=[.04,.42,.60]
        lim=mask.shape[0]*pitch
        axes[0,j].imshow(color,origin="lower",extent=(0,lim,0,lim),interpolation="nearest")
        label="Axial 1194 vicinity" if case["name"]=="slice1194" else case["name"]
        axes[0,j].set(title=label,xlabel="X (mm)")
        axes[0,j].set_ylabel("Y (mm)" if j==0 else "")
        val=np.sort(stress)
        axes[1,j].plot(val,(np.arange(len(val))+1)/len(val),color="#087497",lw=1.4,label="CT cavities")
        axes[1,j].axvline(filled,color="#a36623",ls="--",lw=1.1,label="Filled control")
        axes[1,j].axhline(.95,color="#888888",lw=.5)
        axes[1,j].set(xlabel="Collar von Mises (MPa)",ylim=(0,1.02))
        if j==0:
            axes[1,j].set_ylabel("Cumulative fraction")
    axes[1,-1].legend(frameon=False,fontsize=7,loc="lower right")
    for ax in axes.ravel(): ax.tick_params(labelsize=7)
    fig.tight_layout(pad=.75)
    fig.savefig(PAPER/"figures/ct_multiscale_bridge.pdf", dpi=600)
    plt.close(fig)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--alignment",action="store_true")
    parser.add_argument("--expanded",action="store_true")
    args=parser.parse_args()
    coupled=json.loads((OUT/"coupling.json").read_text())
    cases=coupled["cases"]
    stats = []
    for k, case in enumerate(cases):
        with np.load(OUT/f"{case['name']}.npz") as data:
            cells=data["indices"]
            delta=float(mises(data["filled_stress_MPa"]))-mises(data["stress_MPa"])
        entries=[]
        for block in (8,12,16):
            try:
                entries.append(bootstrap(cells,delta,block,2000,7120+k*20+block))
            except ValueError:
                continue
        stats.append(dict(name=case["name"], bias_MPa=float(np.mean(delta)),
                          MSE_MPa2=float(np.mean(delta**2)), block_bootstrap=entries))
    report=dict(geometry=cavity_survey(), error_order=["filled minus porous mean MPa","paired MSE MPa²"],
                spatial_bootstrap=stats,
                scope="Blocks within the fixed collar, stratified along native Z. Finite-domain resampling; no whole-tooth porous truth.")
    if args.alignment:
        report["descriptive_fabric_alignment"]=alignment(OUT/"native-microtubes-fine.json" if args.expanded else TRACES)
    (OUT/"sampling.json").write_text(json.dumps(report,indent=2)+"\n")
    plate(cases)
    print(json.dumps(report,indent=2))


if __name__=="__main__":
    main()
