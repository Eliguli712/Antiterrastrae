"""Figure 4 cervical band in registered native geometry and fitted jaw pose."""
import json

import matplotlib.patheffects as effects
from matplotlib.colors import to_rgb
import numpy as np

import render_consistent_figure4 as prior
import render_shared_cervical_figure as shared

STEM = "field_qf_topological_cervical"


class BandGuide(shared.CervicalGuide):
    def paint(self, local):
        crown, root = self.offsets(local)
        region = np.where(crown < 0, 0, np.where(root < 0, 1, 2))
        ink = shared.COLORS[region].copy()
        for distance, colour in zip((crown, root), shared.TRACE_COLORS, strict=True):
            weight = (1 - shared.smoothstep(np.abs(distance) / .21))[:, None]
            ink += weight * (to_rgb(colour) - ink)
        return ink


def main():
    with np.load(prior.native.BASELINE / "L0/solution.npz") as domain:
        center, basis = domain["center_m"] * 1000, domain["basis"]
    guide = BandGuide()
    masks, counts = prior.membership_masks(center, basis)
    images, rendered = prior.render_native_guide(guide, center, basis, None,
                                                  ink=lambda points, colour, trace: colour)
    xx = (np.arange(shared.WIDTH) + .5 - 900) / prior.native.SCALE
    yy = (748 - np.arange(shared.HEIGHT) - .5) / prior.native.SCALE

    def fixation(axis, index):
        if index != 1:
            return
        mask = masks[1]
        axis.contourf(xx, yy, mask, levels=[.5, 1.5], colors=[prior.FIXED], alpha=.23)
        edge = axis.contour(xx, yy, mask, levels=[.5], colors=[prior.FIXED], linewidths=.66)
        edge.set_path_effects([effects.withStroke(linewidth=1.12, foreground="#fffaf0")])

    # Apply the identical region rule to the frontal surface in panel b (the
    # cached display uses the earlier identical curves at equivalent sampling).
    for preview in (False, True):
        suffix = "_preview" if preview else ""
        shared.compose(guide, destination=prior.native.FIGURES/f"{STEM}{suffix}.pdf",
                       images=images, foreground=fixation, preview=preview,
                       legend_text="B: red outlines fixed exterior faces. Cyan and gold delimit the cervical band.")
    notes = {
        "separation_mm_in_longitudinal_coordinate": guide.separation,
        "topology": "Surface region on original depth-bearing triangular geometry. A vertex lies in band if it is between the two registered photo-derived guide surfaces. Tissue junction is not independently measured.",
        "a3_fixed_faces_projected_in_b": counts[1], "a3_pressure_faces_omitted_from_b": counts[0],
        "submitted_triangles_oblique_jaw_unused": rendered,
    }
    (prior.native.REVIEW/f"{STEM}.json").write_text(json.dumps(notes,indent=2)+"\n")
    print(json.dumps(notes),flush=True)


if __name__ == "__main__":
    main()
