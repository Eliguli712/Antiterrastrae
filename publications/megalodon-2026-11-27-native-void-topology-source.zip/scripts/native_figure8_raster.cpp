#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
constexpr int W=1800,H=1600;
struct V{float x,y,z,r,g,b;};
struct Plate{std::vector<float>z;std::vector<uint8_t>im;long long count=0;};
int main(int argc,char**argv){if(argc!=2)return 2;std::array<Plate,3>plates;for(auto&p:plates){p.z.assign(W*H,1e30f);p.im.assign(W*H*4,0);}uint32_t target,nv,nf;
while(std::cin.read((char*)&target,4)){std::cin.read((char*)&nv,4);std::cin.read((char*)&nf,4);if(target>2)return 3;std::vector<V>v(nv);std::vector<uint32_t>f(3*nf);std::cin.read((char*)v.data(),nv*sizeof(V));std::cin.read((char*)f.data(),nf*12);if(!std::cin)return 4;auto&p=plates[target];p.count+=nf;
for(uint32_t i=0;i<nf;i++){auto&a=v[f[3*i]],&b=v[f[3*i+1]],&c=v[f[3*i+2]];float area=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);if(std::abs(area)<1e-9)continue;int x0=std::max(0,(int)std::floor(std::min({a.x,b.x,c.x}))),x1=std::min(W-1,(int)std::ceil(std::max({a.x,b.x,c.x})));int y0=std::max(0,(int)std::floor(std::min({a.y,b.y,c.y}))),y1=std::min(H-1,(int)std::ceil(std::max({a.y,b.y,c.y})));
for(int y=y0;y<=y1;y++)for(int x=x0;x<=x1;x++){float u=((b.x-x-.5f)*(c.y-y-.5f)-(b.y-y-.5f)*(c.x-x-.5f))/area,w=((c.x-x-.5f)*(a.y-y-.5f)-(c.y-y-.5f)*(a.x-x-.5f))/area,z=1-u-w;if(std::min({u,w,z})<-.00001f)continue;float depth=u*a.z+w*b.z+z*c.z;int k=y*W+x;if(depth>p.z[k])continue;p.z[k]=depth;p.im[4*k]=std::clamp((u*a.r+w*b.r+z*c.r)*255.f,0.f,255.f);p.im[4*k+1]=std::clamp((u*a.g+w*b.g+z*c.g)*255.f,0.f,255.f);p.im[4*k+2]=std::clamp((u*a.b+w*b.b+z*c.b)*255.f,0.f,255.f);p.im[4*k+3]=255;}}
}for(int j=0;j<3;j++){std::ofstream o(std::string(argv[1])+"/native_figure8_"+std::to_string(j)+".rgba",std::ios::binary);o.write((char*)plates[j].im.data(),plates[j].im.size());std::cerr<<"panel "<<j<<" triangles submitted "<<plates[j].count<<"\n";}return 0;}
