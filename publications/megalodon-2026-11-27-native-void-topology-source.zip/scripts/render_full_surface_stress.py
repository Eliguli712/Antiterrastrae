"""Rasterize the complete 18 µm surface with the recovered bilayer proxy field."""
import json
import struct
import subprocess
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np
from PIL import Image
from scipy.spatial import cKDTree
from matplotlib.colors import LogNorm
import matplotlib.pyplot as plt

PAPER = Path(__file__).resolve().parents[1]
PROJECT = PAPER.parents[2]
FIGURES = PAPER / 'figures'
WIDTH, HEIGHT = 1800, 1600
VERTICES, TRIANGLES = 37_951_699, 74_293_846


def send_triangles(process, panel, position, rgb, faces):
    records = np.column_stack((position, rgb)).astype('<f4', copy=False)
    process.stdin.write(struct.pack('<III', panel, len(records), len(faces)))
    process.stdin.write(records.tobytes())
    process.stdin.write(np.asarray(faces, dtype='<u4').tobytes())


def read_render(directory, panel):
    raw = directory / f'native_figure8_{panel}.rgba'
    return Image.frombytes('RGBA', (WIDTH, HEIGHT), raw.read_bytes())


def make_rasterizer(directory):
    exe = directory / 'zbuffer'
    subprocess.run(['c++', '-O3', '-std=c++17',
                    str(PAPER / 'scripts/native_figure8_raster.cpp'), '-o', str(exe)], check=True)
    return subprocess.Popen([str(exe), str(directory)], stdin=subprocess.PIPE,
                            stderr=subprocess.PIPE)


def finish_render(process, face_count):
    process.stdin.close()
    log = process.stderr.read().decode().strip()
    assert process.wait() == 0, log
    expected = [f'panel {i} triangles submitted {face_count}' for i in range(3)]
    assert log.splitlines() == expected, log
    return log


def render_bilayer():
    src = PROJECT / 'output/publication_validation_2026-11-12/data/bilayer_StVK_L1/fields.npz'
    ref = PROJECT / 'output/pdf/debunk_myth_full_reconstruction_2026-10-31/numerics/L1/solution.npz'
    with np.load(src) as state, np.load(ref) as frame:
        points = state['points_m'] * 1000
        tets, volumes = state['tets'], state['volumes_m3']
        boundary = np.unique(state['boundary_faces'])
        tensor = state['cauchy_stress_Pa']
        deviator = tensor - np.trace(tensor, axis1=1, axis2=2)[:, None, None] * np.eye(3) / 3
        vm = np.sqrt(1.5 * np.einsum('ijk,ijk->i', deviator, deviator))
        maximum_error = np.max(np.abs(vm - state['von_mises_Pa']))
        np.testing.assert_allclose(vm, state['von_mises_Pa'], rtol=1e-12, atol=1e-6)
        center, basis = frame['center_m'] * 1000, frame['basis']
    nodal_volume = np.zeros(len(points))
    integral = np.zeros(len(points))
    for nodes in tets.T:
        np.add.at(nodal_volume, nodes, volumes)
        np.add.at(integral, nodes, volumes * vm)
    values = integral[boundary] / nodal_volume[boundary] / 1e6
    tree = cKDTree(points[boundary])
    cache = PROJECT / 'output/current_native74_stress_2026-11-20/cache'
    xyz = np.memmap(cache / 'vertices.f64', dtype='<f8', mode='r', shape=(VERTICES, 3))
    faces = np.memmap(cache / 'triangles.u32', dtype='<u4', mode='r', shape=(TRIANGLES, 3))
    cmap = plt.colormaps['turbo']
    norm = LogNorm(.1, 300, clip=True)
    unsupported = np.array([231, 208, 243]) / 255
    angles = np.array([(0, 0, 150), (100, 20, 140), (0, 0, -150)], dtype=float)
    cameras = []
    for angle in angles:
        inward = -angle / np.linalg.norm(angle)
        right = np.cross(inward, [0., 1., 0.])
        right /= np.linalg.norm(right)
        cameras.append(np.column_stack((right, np.cross(right, inward), inward)))
    with TemporaryDirectory(prefix='meg-bilayer-') as tmp:
        tmp = Path(tmp)
        colours = np.memmap(tmp / 'rgb.f32', dtype='<f4', mode='w+', shape=(VERTICES, 3))
        n_valid = 0
        bounds = [None] * len(cameras)
        for first in range(0, len(xyz), 200_000):
            block = slice(first, first + 200_000)
            coordinates = xyz[block]
            d, idx = tree.query(coordinates, k=8, workers=4, distance_upper_bound=2.5)
            w = 1 / np.maximum(d, 1e-9)**2
            estimate = (values[np.minimum(idx, len(values)-1)] * w).sum(1) / np.maximum(w.sum(1), 1e-30)
            valid = d[:, 0] <= 1.5
            n_valid += int(valid.sum())
            rgb = cmap(norm(np.maximum(estimate, .1)))[:, :3]
            rgb[~valid] = unsupported
            colours[block] = rgb
            q = (coordinates - center) @ basis
            q[:, :2] *= -1
            for j, camera in enumerate(cameras):
                xy = (q @ camera)[:, :2]
                lo, hi = xy.min(0), xy.max(0)
                if bounds[j] is not None:
                    lo, hi = np.minimum(lo, bounds[j][0]), np.maximum(hi, bounds[j][1])
                bounds[j] = (lo, hi)
        process = make_rasterizer(tmp)
        # One common px/mm size across all views.
        spans = np.array([hi - lo for lo, hi in bounds])
        scale = float(np.min((np.array([WIDTH, HEIGHT]) - 40) / spans))
        for first in range(0, len(faces), 700_000):
            batch = faces[first:first + 700_000]
            indices, local = np.unique(batch, return_inverse=True)
            q = (xyz[indices] - center) @ basis
            q[:, :2] *= -1
            for j, camera in enumerate(cameras):
                projected = q @ camera
                projected[:, :2] -= (bounds[j][0] + bounds[j][1]) / 2
                projected[:, 0] = WIDTH / 2 + scale * projected[:, 0]
                projected[:, 1] = HEIGHT / 2 - scale * projected[:, 1]
                send_triangles(process, j, projected, colours[indices], local.reshape(-1, 3))
        log = finish_render(process, TRIANGLES)
        for panel in range(3):
            image = read_render(tmp, panel)
            crop = image.getbbox()
            assert crop and crop[0] > 0 and crop[1] > 0 and crop[2] < WIDTH and crop[3] < HEIGHT
            image.crop(crop).save(FIGURES / f'bilayer_stvk_native_{panel}.png')
    record = dict(
        status='passed', mesh_faces=TRIANGLES, mesh_vertices=VERTICES,
        verified_source_cells=len(tets), source_boundary_vertices=len(boundary),
        max_invariant_error_Pa=float(maximum_error), max_assignment_distance_mm=1.5,
        assigned_native_vertices=n_valid, visual_range_MPa=[.1, 300],
        unsolved_colour='#e7d0f3',
        method='Volume-weighted incident-cell recovery then inverse-square interpolation using up to eight boundary nodes within 2.5 mm. Nearest must be within 1.5 mm.',
        scope='Closed-solid L1 bilayer proxy projected to complete native CT surface; no new porous FEM.',
        raster=log.splitlines())
    (PAPER / 'review/bilayer_stvk_native_readback.json').write_text(json.dumps(record, indent=2))
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    render_bilayer()
