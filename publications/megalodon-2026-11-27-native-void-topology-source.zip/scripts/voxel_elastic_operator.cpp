// Matrix-free hex elasticity. A 27-point full-grid stencil followed by
// exact subtraction of the absent elements. Dirichlet rows are omitted.
#include <algorithm>
#include <cstdint>
#include <thread>
#include <vector>

extern "C" void apply_voxel_elasticity(
    int n, const double *u, double *f, const double *blocks,
    const double *kel, const int32_t *void_cells, int64_t void_count,
    int workers, bool stencil) {
    const int rows = n*n*n;
    const int dz = n*n;
    std::fill(f, f + 3*rows, 0.);
    if (stencil) {
        workers = std::max(1, std::min(workers, n-2));
        auto stripe = [=](int worker) {
            const int start = 1 + worker*(n-2)/workers;
            const int end = 1 + (worker+1)*(n-2)/workers;
            for (int z = start; z < end; ++z) {
                for (int y = 1; y < n-1; ++y) {
                    const int i = (z*n+y)*n;
                    for (int qz = -1; qz <= 1; ++qz)
                        for (int qy = -1; qy <= 1; ++qy)
                            for (int qx = -1; qx <= 1; ++qx) {
                                const int j = i + qz*dz + qy*n + qx;
                                const auto *k = blocks + 9*((qz+1)*9 + (qy+1)*3 + qx+1);
                                for (int x = 1; x < n-1; ++x) {
                                    const double *v = u + 3*(j+x);
                                    double *w = f + 3*(i+x);
                                    w[0] += k[0]*v[0] + k[1]*v[1] + k[2]*v[2];
                                    w[1] += k[3]*v[0] + k[4]*v[1] + k[5]*v[2];
                                    w[2] += k[6]*v[0] + k[7]*v[1] + k[8]*v[2];
                                }
                            }
                }
            }
        };
        std::vector<std::thread> threads;
        threads.reserve(workers-1);
        for (int i = 1; i < workers; ++i) threads.emplace_back(stripe, i);
        stripe(0);
        for (auto& thread : threads) thread.join();
    }
    const int corners[] = {0,1,n,n+1,dz,dz+1,dz+n,dz+n+1};
    for (int64_t i = 0; i < void_count; ++i) {
        const int base = void_cells[i];
        double ue[24];
        for (int a = 0; a < 8; ++a)
            for (int k = 0; k < 3; ++k)
                ue[3*a+k] = u[3*(base+corners[a])+k];
        for (int a = 0; a < 8; ++a) {
            double *g = f + 3*(base+corners[a]);
            for (int k = 0; k < 3; ++k) {
                double part = 0.;
                const double *row = kel + 24*(3*a+k);
                for (int j = 0; j < 24; ++j) part += row[j]*ue[j];
                g[k] -= part;
            }
        }
    }
}
