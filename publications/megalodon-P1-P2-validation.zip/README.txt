Same-domain P1/P2 verification, 20 November 2026.
Extract this archive and keep the supplied output/ directory structure.
The primary code and all four pinned inputs are unchanged from seeded run_002.
Run from the extracted archive root:
  python3 output/pdf/debunk_myth_preprint_2026-11-19/scripts/p1_p2_common_domain_v2.py
Install the recorded dependencies first. The larger project vendor directory is
not required: the code falls back to the installed PyAMG package. The imported
solver_core module supplies boundary construction and region names; its older
standalone main routine is not the experiment replay command.
The supplied run_002 manifest records the executed command and pre/post hashes.
Replaying writes fresh displacements and results over the extracted copies;
retain the original ZIP as the immutable reference.

Only one unchanged L0 polyhedron (55,852 tetrahedra) is tested. Exact quadratic
stiffness/constant traction and positive 27/125/343-point stress quadrature are
used. The last quadrature step still changes up to 0.55504% of the 42 checked
percentiles. No A3 P2, continuum upper error bound, biological calibration,
fracture, dynamic impact or shock result is claimed.
