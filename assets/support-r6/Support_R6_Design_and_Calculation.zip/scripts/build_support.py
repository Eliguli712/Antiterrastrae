"""R6: unchanged lower frame, per-size CT-derived split root sockets.

The 72 um sampled CT is used ONLY for manufacturing tooling. It never
supplies a claimed native-resolution tooth FEM solution.
"""
import argparse, sys, json, hashlib, math, struct, zipfile
from pathlib import Path
import numpy as np
from scipy import ndimage as ndi
from scipy.spatial import ConvexHull
from skimage.measure import marching_cubes
import trimesh, manifold3d as mf

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'dist/assets/support-r6'
sys.path.insert(0,str(ROOT/'scripts'))
from build_assets import mesh, solid, unite, sphere, cyl, convex, box

def binary(m,path):
    a=np.column_stack([m.vertices,m.vertex_normals]).astype('<f4')
    path.write_bytes(struct.pack('<II',len(m.vertices),len(m.faces))+a.tobytes()+m.faces.astype('<u4').tobytes())

def level(a,pitch,origin):
    v,f,_,_=marching_cubes(np.pad(a.astype('f4'),1,constant_values=-pitch),0,spacing=(pitch,)*3,allow_degenerate=False)
    m=trimesh.Trimesh(v[:,[2,1,0]]+origin-pitch,f,process=True)
    s=solid(m)
    return unite([x for x in s.decompose() if x.volume()>.06])

def export(s,path):
    m=mesh(s);m.export(path)
    q=trimesh.load_mesh(path,process=True)
    if not q.is_watertight or not q.is_winding_consistent:raise ValueError('Unclosed print mesh '+str(path))
    components=q.split(only_watertight=False);keep=[x for x in components if abs(x.volume)>.01]
    if len(keep)!=1:raise ValueError('More than one structural component '+str(path))
    removed=sum(abs(x.volume) for x in components if abs(x.volume)<=.01)
    q=keep[0];q.export(path)
    return {'file':path.name,'bytes':path.stat().st_size,'sha256':hashlib.file_digest(path.open('rb'),'sha256').hexdigest(),'triangles':len(q.faces),'watertight':True,'volume_mm3':float(q.volume),'bounds_mm':q.bounds.tolist(),'components':1,'removed_disconnected_microparticles_mm3':removed}

def frame(base):
    nodes={k:list(v) for k,v in base['nodes'].items() if k!='P'}
    edges=[list(e) for e in base['edges'] if 'P' not in e]
    z=base['nodes']['A5'][2]
    triangles=[]
    for layer,(r,dz) in enumerate([(23.,0.),(21.2,1.8),(20.2,3.2)]):
        names=[]
        for j in range(3):
            th=math.pi/2+2*math.pi*j/3
            name=f'T{layer}_{j}';nodes[name]=[r*math.cos(th),r*math.sin(th),z+dz];names.append(name)
        triangles.append(names)
        edges.extend([[names[j],names[(j+1)%3]] for j in range(3)])
        if layer:edges.extend([[triangles[layer-1][j],names[j]] for j in range(3)])
    for old in ['A5','A7','B3','B7']:
        near=sorted(triangles[0],key=lambda n:np.linalg.norm(np.array(nodes[n])-nodes[old]))[:2]
        edges.extend([[old,n] for n in near])
    nodes['P']=[0.,0.,z+6.]
    edges.extend([[n,'P'] for n in triangles[-1]])
    radii={k:8. if k in base['feet'] else 4.2 if k=='Q_bottom' else 3.8 if k.startswith('T') else 5.5 if k=='P' else 5.7 for k in nodes}
    parts=[cyl(nodes[a],nodes[b],3.2) for a,b in edges]
    parts.extend(sphere(p,radii[k]) for k,p in nodes.items())
    # Three equal triangular profiles form two visible bevel bands.
    for k in range(2):
        parts.append(convex([nodes[n] for n in triangles[k]+triangles[k+1]]))
    s=unite(parts).split_by_plane((0,0,1),0)[0]
    eq=[]
    for names in triangles:
        lengths=[float(np.linalg.norm(np.array(nodes[names[j]])-nodes[names[(j+1)%3]])) for j in range(3)]
        assert max(lengths)-min(lengths)<1e-10
        eq.append(lengths)
    return s,nodes,edges,radii,triangles,eq

def run(maskpath):
    OUT.mkdir(parents=True,exist_ok=True)
    base=json.loads((ROOT/'dist/assets/model.json').read_text())
    geo=json.loads((ROOT/'dist/assets/native74-r5/geometry.json').read_text())
    mask=np.load(maskpath,mmap_mode='r').astype(bool)
    mask=ndi.binary_fill_holes(mask) # Tooling envelope only; native CT remains unchanged.
    labels,n=ndi.label(mask);cnt=np.bincount(labels.ravel());cnt[0]=0;mask=labels==cnt.argmax();del labels
    fs,nodes,edges,radii,triangles,eq=frame(base)
    anchor=np.array([0.,0.,86.73910524340096]);native_origin=np.array([7.056,1.368,1.368]);J=np.array([[0,0,1],[0,1,0],[1,0,0]])
    cases={}
    for size in [50,100]:
        factor=size/100;R=np.array(geo['display_affine_R'])*factor
        T=anchor+factor*(np.array(geo['display_affine_T'])-anchor)
        halfx=36*factor+5;halfy=13*factor+6;h=.40*size;pitch=.15 if size==50 else .20
        origin=np.array([-halfx,-halfy,anchor[2]-2.5]);shape=np.ceil([2*halfx/pitch,2*halfy/pitch,(h+6)/pitch]).astype(int)
        mat=J@np.linalg.inv(R)@J*pitch/.072
        off=J@(np.linalg.inv(R)@(origin-T)-native_origin)/.072
        tool=ndi.affine_transform(mask.astype('u1'),mat,offset=off,output_shape=tuple(shape[::-1]),order=0,prefilter=False)>0
        tool=ndi.binary_fill_holes(tool)
        sdf=(ndi.distance_transform_edt(~tool,sampling=pitch)-ndi.distance_transform_edt(tool,sampling=pitch)).astype('f4')
        z=origin[2]+np.arange(tool.shape[0])*pitch;y=origin[1]+np.arange(tool.shape[1])*pitch
        gap=.35 if size==50 else .45;wall=2.2 if size==50 else 3.4
        outer=wall+gap-sdf
        clip=np.minimum(anchor[2]+h-z,z-anchor[2]+1.2)[:,None,None]
        frontdist=np.minimum.accumulate(sdf,axis=1);backdist=np.minimum.accumulate(sdf[:,::-1,:],axis=1)[:,::-1,:]
        rear=level(np.minimum.reduce(np.broadcast_arrays(outer,backdist-gap,y[None,:,None]-.12,clip)),pitch,origin)
        front=level(np.minimum.reduce(np.broadcast_arrays(outer,frontdist-gap,-.12-y[None,:,None],clip)),pitch,origin)
        root=level(1.0-sdf,pitch,origin)
        bbox=mesh(root).bounds;xs=[float(bbox[0,0]-3),float(bbox[1,0]+3)];ez=anchor[2]+h*.64
        holes=[];rp=[rear];fp=[front]
        for x in xs:
            ear=box([7,12,10],[x,0,ez]);rr,ff=ear.split_by_plane((0,1,0),0)
            rp.append(rr);fp.append(ff)
            holes.append(cyl([x,-8,ez],[x,8,ez],1.45))
        negative=level(gap-sdf,pitch,origin)
        # Sweep clearance keeps the split clamp installable from front/back.
        sweepr=level(np.minimum(backdist-gap,clip),pitch,origin)
        sweepf=level(np.minimum(frontdist-gap,clip),pitch,origin)
        rear=unite(rp)-unite(holes)-negative
        front=unite(fp)-unite(holes)-negative
        spine=np.array([0.,bbox[1,1]+4.,anchor[2]+h*.40])
        braces=[cyl(nodes['P'],spine,3.8),sphere(spine,4.4)]
        for x in xs:braces.append(cyl(spine,[x,4.,ez],3.2))
        front=front.as_original().set_tolerance(.02).simplify(.02)
        # Explicit part-to-part allowance; keep the cap itself unchanged and
        # carve its six translated clearance envelopes into the main frame.
        expanded=unite([front]+[front.translate((np.eye(3)[ax]*sign*.12).tolist()) for ax in range(3) for sign in [-1,1]])
        main=((unite([fs,rear,unite(braces)])-negative)-expanded).as_original().set_tolerance(.012).simplify(.012)
        # Verification refers to this explicit tool envelope, not all 74M source faces.
        envelope=level(-sdf,pitch,origin)
        checks={'main_envelope_intersection_mm3':float((main^envelope).volume()),'cap_envelope_intersection_mm3':float((front^envelope).volume()),'main_cap_intersection_mm3':float((main^front).volume())}
        assert max(checks.values())<.001,checks
        rec=[]
        for name,s in [('main',main),('cap',front)]:
            path=OUT/f'Support_R6_{size}mm_{name}.stl';rec.append(export(s,path));binary(trimesh.load_mesh(path,process=True),OUT/f'{size}mm-{name}.bin')
        fm=trimesh.load_mesh(OUT/f'Support_R6_{size}mm_main.stl',process=True)+trimesh.load_mesh(OUT/f'Support_R6_{size}mm_cap.stl',process=True)
        oldraw=(ROOT/'dist/assets/main.bin').read_bytes();nv,nf=struct.unpack_from('<II',oldraw);old=np.frombuffer(oldraw,dtype='<f4',offset=8,count=nv*6).reshape(-1,6)[:,:3]
        framebounds=mesh(fs).bounds
        cases[str(size)]={'size_mm':size,'frame_scale':1,'root_clearance_mm':gap,'cap_frame_axis_clearance_mm':.12,'root_wall_mm':wall,'root_height_mm':h,'tooling_pitch_mm':pitch,'tooling_source_sampling_um':72,'ct_native_spacing_um':18,'tooth_anchor_mm':anchor.tolist(),'tooth_display_scale':factor,'display_R':R.tolist(),'display_T':T.tolist(),'parts':rec,'resin_volume_ml':float(fm.volume/1000),'resin_center_mm':fm.center_mass.tolist(),'frame_bounds_mm':framebounds.tolist(),'unchanged_lower_frame':True,'geometry_checks':checks,'native_74M_collision_test_completed':False,'status':'digital_tool_fit_candidate','notes':['Root tooling uses a sampled, cavity-filled external envelope only.','Original 18 um CT and every native display face remain unchanged.','Clearance is a digital nominal value; physical fit, screws and pull-out force are untested.']}
        print('BUILT',size,len(fm.faces),checks,flush=True)
    data={'revision':'R6','unit':'mm','nodes':nodes,'edges':edges,'radii_mm':radii,'feet':base['feet'],'rod_diameter_mm':6.4,'top_triangles':triangles,'top_side_lengths_mm':eq,'bevel_bands':2,'all_edge_endpoints_have_spheres':all(a in radii and b in radii for a,b in edges),'cases':cases,'frame_note':'Original lower-node coordinates, rods and feet are unchanged; only the upper connector and per-size tooling are redesigned.'}
    (OUT/'support.json').write_text(json.dumps(data,indent=2)+'\n')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--mask',type=Path,required=True);run(p.parse_args().mask)
