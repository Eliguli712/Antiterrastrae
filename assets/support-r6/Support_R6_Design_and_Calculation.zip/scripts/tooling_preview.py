from pathlib import Path
import sys,json,struct
import numpy as np
from scipy import ndimage as ndi
from skimage.measure import marching_cubes
import trimesh,manifold3d as mf
ROOT=Path(__file__).resolve().parents[2];sys.path.insert(0,str(ROOT/'scripts'));from build_assets import mesh,solid
m=np.load('/workspace/scratch/798f43faaad4/native-cache/tool_mask_stride4.npy').astype(bool);labs,n=ndi.label(m);count=np.bincount(labs.ravel());count[0]=0;m=ndi.binary_fill_holes(labs==count.argmax());del labs
v,f,_,_=marching_cubes(np.pad(ndi.gaussian_filter(m.astype('f4'),.8),1),.5,spacing=(.072,)*3,allow_degenerate=False);v=v[:,[2,1,0]]-.072+np.array([7.056,1.368,1.368]);g=json.loads((ROOT/'dist/assets/native74-r5/geometry.json').read_text());v=v@np.array(g['display_affine_R']).T+g['display_affine_T'];s=solid(trimesh.Trimesh(v,f,process=True)).as_original().simplify(.08);q=mesh(s);a=np.c_[q.vertices,q.vertex_normals].astype('<f4');out=ROOT/'dist/assets/support-r6';(out/'tooling-tooth.bin').write_bytes(struct.pack('<II',len(q.vertices),len(q.faces))+a.tobytes()+q.faces.astype('<u4').tobytes());(out/'tooling-tooth.json').write_text(json.dumps({'tooling_preview_only':True,'source_sampling_um':72,'tool_surface_simplification_tolerance_mm':.08,'preview_gaussian_sigma_voxels':.8,'triangles':len(q.faces),'not_the_native_FEM_mesh':True}));print('TOOL_PREVIEW',len(q.vertices),len(q.faces),flush=True)
