"""Round-trip manufacturing records and meaningful elasticity checks."""
from pathlib import Path
import importlib.util,json,hashlib,zipfile
import numpy as np
import trimesh
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'dist/assets/support-r6'
sp=importlib.util.spec_from_file_location('frame_fem',ROOT/'scripts/support-r6/frame_fem.py');f=importlib.util.module_from_spec(sp);sp.loader.exec_module(f)
model=json.loads((OUT/'support.json').read_text());checks={'beam_analytic':f.checks(),'parts':[],'spherical_patch':[]}
for size,case in model['cases'].items():
 assert case['frame_scale']==1
 for r in case['parts']:
  p=OUT/r['file'];assert hashlib.file_digest(p.open('rb'),'sha256').hexdigest()==r['sha256'];m=trimesh.load_mesh(p,process=True);assert m.is_watertight and m.is_winding_consistent and len(m.split())==1;assert len(m.faces)==r['triangles'];checks['parts'].append({'file':p.name,'sha256':r['sha256'],'watertight':True,'connected':True})
assert model['cases']['50']['frame_bounds_mm']==model['cases']['100']['frame_bounds_mm']
for variant in ['solid','wall']:
 p,t,grad,vol,K,free,factor,outer,dirs,faces=f.shell_mesh(5.5,variant);n=len(p)
 B=np.zeros((n,3,6));B[:,:,:3]=np.eye(3);B[:,0,4]=p[:,2];B[:,0,5]=-p[:,1];B[:,1,3]=-p[:,2];B[:,1,5]=p[:,0];B[:,2,3]=p[:,1];B[:,2,4]=-p[:,0];B=B.reshape(3*n,6)
 rigid=float(np.linalg.norm(K@B)/(np.linalg.norm(K.data)*np.linalg.norm(B)))
 A=np.array([[.01,.002,.003],[-.001,.02,.004],[.002,-.002,.012]]);u=(p@A.T).ravel();ra=(K@u).reshape(n,3)
 boundary=np.array(outer);nv=len(dirs)
 if variant=='wall':boundary=np.r_[np.arange(nv),outer]
 inside=np.setdiff1d(np.arange(n),boundary);patch=float(np.linalg.norm(ra[inside])/np.linalg.norm(ra));assert rigid<1e-13 and patch<1e-9,(rigid,patch)
 checks['spherical_patch'].append({'variant':variant,'positive_volumes':bool((vol>0).all()),'tetrahedra':len(t),'rigid_motion_relative_residual':rigid,'affine_patch_relative_residual':patch})
balls=json.loads((OUT/'ball-fem.json').read_text());checks['all_sphere_submodel_max_gauge_reaction_relative']=max(r['gauge_reaction_relative'] for c in balls['cases'].values() for r in c);assert checks['all_sphere_submodel_max_gauge_reaction_relative']<1e-7
checks['native_porous_tooth_FEM_completed']=False;checks['physical_retention_test_completed']=False;checks['Chien_shell_equations_implemented']=False
(OUT/'support-verification.json').write_text(json.dumps(checks,indent=2)+'\n')
readme='''Otodus megalodon — R6 support design and calculation
Units: millimetres, newtons, megapascals.

The unchanged lower frame is 84.939102 mm across both horizontal axes.
The 50 mm and 100 mm teeth receive separately generated split sockets.
Nominal root gaps: 0.35 mm / 0.45 mm. Cap/frame axis allowance: 0.12 mm.
Two upper equilateral bevel bands; every graph endpoint has a sphere.
The four STL parts are connected, consistently oriented and watertight.
Use the main frame and matching front cap at 100% scale in millimetres.
Fastener holes: 2.9 mm nominal; screw contact and retention remain untested.

The digital fit test uses the explicitly recorded sampled tooling envelope,
not an exact collision certification against all 74,293,846 native faces.
The root tool envelope is derived at 72 um; the original 18 um CT and all
native tooth downloads remain unchanged. Actual print shrinkage, fit,
clamping force, friction, creep and impact capacity have not been tested.

Support mechanics: Euler–Bernoulli frame, assumed effective resin E=1375 MPa,
nu=0.38, density=1.18 g/cm3. Distributed beam/node weights are scaled to match exact CAD mass, with a
connector couple correcting total gravitational moment. Local self-weight
distribution remains idealized. A 3g tooth gravity load is applied. Tooth masses assume solid PLA 1.24g/cm3.
This gravity load differs from the earlier crown-pressure tooth study.
Spherical nodes: balanced finite-area load patches in one-way 3D elasticity
submodels. Solid nodes match the design reference; a 1.2mm hollow-wall case
is a distinct research comparison. Its t/R is too large to assert thin-shell
accuracy without comparison. Chien shell equations are not implemented.
Short connector beams violate the slender-beam premise; per-member shear
parameters are included. No local joint peak convergence is claimed.
The top bevel plates, split socket and screw contact are not resolved by
the global beam idealization. It is a screening calculation, not strength
certification of the complete manufactured support.

Full native porous tooth FEM is NOT completed. The earlier independent
closed-solid tooth solutions retain their original labels. Native pore,
boundary-layer and filled-material requests require distinct audited meshes
and native-resolution distributed solves. See native-feasibility.json.

Primary sources:
Euler, 1744, De curvis elasticis (Appendix I):
https://scholarlycommons.pacific.edu/euler-works/65/
Complete English translation (1933):
https://boulderschool.yale.edu/sites/default/files/files/euler_1744.pdf
Chien, 1944, intrinsic shell theory I: https://doi.org/10.1090/qam/9744
Chien, 1944, intrinsic shell theory III: https://doi.org/10.1090/qam/10867
von Karman & Tsien, 1939, spheres: https://doi.org/10.2514/8.1019
von Karman & Tsien, 1941, cylinders: https://doi.org/10.2514/8.10722
Cylinder paper reprint: https://phoogenboom.nl/b17_paper_Von_Karman.pdf
Wittrick, 1964, shell edge stresses:
https://doi.org/10.1016/0020-7225(64)90002-3

Reproduction scripts are included. They require numpy, scipy, trimesh,
manifold3d and scikit-image. Build support with --mask pointing to the
recorded 72 um sampled tooling array. This array is a tooling intermediate;
it must never be used as the source of a native porous tooth FEM claim.
'''
(OUT/'README.txt').write_text(readme)
with zipfile.ZipFile(OUT/'Support_R6_Design_and_Calculation.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in OUT.glob('*'):
  if p.suffix in ['.json','.stl','.txt','.png']:z.write(p,p.name)
 for p in (ROOT/'scripts/support-r6').glob('*.py'):z.write(p,'scripts/'+p.name)
print(json.dumps(checks,indent=2));print('PACKAGED', (OUT/'Support_R6_Design_and_Calculation.zip').stat().st_size)
