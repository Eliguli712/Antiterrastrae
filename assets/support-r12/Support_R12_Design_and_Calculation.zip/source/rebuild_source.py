"""Rebuild the refined CAD and support mechanics from complete native inputs."""
from pathlib import Path
import os,sys,argparse,json,subprocess,shutil
R=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--native',type=Path,required=True,help='Directory containing geometry.json and all 75 verified geometry-XX.bin.gz chunks');a=p.parse_args()
env=os.environ.copy();env['MEGALODON_NATIVE']=str(a.native.resolve());env['MEGALODON_LEGACY_SUPPORT']=str(R/'inputs/legacy-support')
def run(*args):subprocess.run([sys.executable,*map(str,args)],cwd=R,env=env,check=True)
run('native-fit/build_native_fit.py','--prepare-only');run('native-fit50/build_native_fit.py','--prepare-only');run('assemble_refined.py')
run('geometry/size_joints.py','--cad-model',R/'assets/support-r12/support.json');run('geometry/mechanics_review.py','--support',R/'geometry/support.json');run('geometry/validate_mechanics.py')
out=R/'assets/support-r12';g=json.loads((R/'geometry/support.json').read_text());d=json.loads((out/'support.json').read_text())
for size,c in d['cases'].items():c['frame_graph']=g['cases'][size]['frame_graph']
(out/'support.json').write_text(json.dumps(d,indent=2)+'\n')
for name in ['frame-fem.json','ball-fem.json','radius-design.json','mechanics-model-review.json','mechanics-validation.json']:shutil.copyfile(R/'geometry'/name,out/name)
run('audit_refined_cad.py')
print('Rebuilt four closed manufacturing STL parts and independent support fields in',out)
