"""Fit the unchanged native 100 mm tooth with a conservative swept cavity.

The original root is not approximated by the old 41,180-face tooling model.
All native source chunks are hash-checked, every root vertex contributes to a
Y-envelope, and the maximum relevant source triangle edge covers interiors.
"""
from pathlib import Path
import argparse, gzip, hashlib, json, struct, time, os
import numpy as np
from scipy import ndimage
import trimesh
import manifold3d as mf

HERE=Path(__file__).resolve().parent
WORK=HERE/'work'; ASSETS=HERE/'assets'
WORK.mkdir(exist_ok=True);ASSETS.mkdir(exist_ok=True)
NATIVE=Path(os.environ.get('MEGALODON_NATIVE','/workspace/scratch/798f43faaad4/r7-native'))
OLD=Path(os.environ.get('MEGALODON_LEGACY_SUPPORT','/workspace/sites/megalodon-r12-recovery/.sites-checkout/dist/assets/support-r8'))

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def as_mesh(s):
    q=s.to_mesh64()
    return trimesh.Trimesh(np.asarray(q.vert_properties)[:,:3],np.asarray(q.tri_verts),process=False)
def as_solid(m):
    s=mf.Manifold(mf.Mesh64(np.ascontiguousarray(m.vertices,dtype=np.float64),np.ascontiguousarray(m.faces,dtype=np.uint64)))
    if str(s.status())!='Error.NoError':raise ValueError('Invalid input solid: '+str(s.status()))
    return s
def save_solid(s,path):
    m=as_mesh(s);np.savez_compressed(path,vertices=m.vertices,faces=m.faces)
def load_solid(path):
    d=np.load(path);return as_solid(trimesh.Trimesh(d['vertices'],d['faces'],process=False))

def extract_profile():
    dest=WORK/'native-root-profile.npz'
    if dest.exists():return
    manifest=json.loads((NATIVE/'geometry.json').read_text())
    pitch=.1;x0,x1,z0,z1=-45.,45.,84.,132.
    nx,nz=int(round((x1-x0)/pitch))+1,int(round((z1-z0)/pitch))+1
    front=np.full((nz,nx),np.inf);rear=np.full((nz,nx),-np.inf)
    total_faces=total_vertices=selected_count=relevant_count=0;max_edge=0.;start=time.time()
    full_low=np.full(3,np.inf);full_high=-full_low
    hashes=[]
    for idx,rec in enumerate(manifest['chunks']):
        raw=(NATIVE/rec['url']).read_bytes();digest=hashlib.sha256(raw).hexdigest();assert digest==rec['sha256'];hashes.append(digest)
        raw=gzip.decompress(raw);n=struct.unpack_from('<I',raw)[0];h=json.loads(raw[4:4+n]);base=4+n+(-n)%4
        def array(key,dtype,width):
            seg=h['segments'][key];return np.frombuffer(raw,dtype=dtype,count=seg['bytes']//np.dtype(dtype).itemsize,offset=base+seg['offset']).reshape(-1,width)
        v=array('positions','<f4',3);f=array('indices','<u4',3)
        total_vertices+=len(v);total_faces+=len(f);full_low=np.minimum(full_low,v.min(0));full_high=np.maximum(full_high,v.max(0))
        q=v[(v[:,2]>=z0)&(v[:,2]<=z1)&(v[:,0]>=x0)&(v[:,0]<=x1)]
        selected_count+=len(q)
        if len(q):
            ix=np.floor((q[:,0].astype(float)-x0)/pitch).astype(int);iz=np.floor((q[:,2].astype(float)-z0)/pitch).astype(int);flat=iz*nx+ix
            np.minimum.at(front.ravel(),flat,q[:,1]);np.maximum.at(rear.ravel(),flat,q[:,1])
        z=v[f,2];chosen=f[(z.min(1)<=z1)&(z.max(1)>=z0)];relevant_count+=len(chosen)
        if len(chosen):
            tri=v[chosen].astype(float)
            for a,b in [(0,1),(1,2),(2,0)]:max_edge=max(max_edge,float(np.linalg.norm(tri[:,a]-tri[:,b],axis=1).max()))
        if idx%10==0:print('NATIVE',idx+1,'/75','seconds',round(time.time()-start,2),'max_edge',max_edge,flush=True)
    assert total_faces==74293846 and len(manifest['chunks'])==75
    np.savez_compressed(dest,front=front,rear=rear,pitch=pitch,x0=x0,z0=z0,max_edge=max_edge)
    audit={'source_faces':total_faces,'source_unique_vertices':manifest['vertices'],'chunk_vertices_including_boundary_duplicates':total_vertices,'selected_root_vertices':selected_count,'relevant_source_triangles':relevant_count,'verified_chunks':len(hashes),'source_chunk_sha256':hashes,'source_geometry_sha256':manifest['source_sha256'],'native_global_bounds_mm':[full_low.tolist(),full_high.tolist()],'maximum_relevant_triangle_edge_mm':max_edge,'profile_pitch_mm':pitch,'profile_bounds_x_z_mm':[x0,x1,z0,z1],'tooth_geometry_modified':False,'all_source_triangle_indices_retained':True,'method':'Complete source positions, original relevant triangle edges; per-bin min/max Y. No source tooth decimation or smoothing.','elapsed_seconds':time.time()-start}
    (ASSETS/'native-source-fit-audit.json').write_text(json.dumps(audit,indent=2)+'\n')

def height_solid(height,x0,z0,pitch,front):
    nz,nx=height.shape;X,Z=np.meshgrid(x0+np.arange(nx)*pitch,z0+np.arange(nz)*pitch)
    roof=np.c_[X.ravel(),height.ravel(),Z.ravel()];back=roof.copy();back[:,1]=55. if front else -55.;nv=len(roof)
    ids=np.arange(nv).reshape(nz,nx);a,b=ids[:-1,:-1].ravel(),ids[:-1,1:].ravel();c,d=ids[1:,1:].ravel(),ids[1:,:-1].ravel()
    faces=np.r_[np.c_[a,b,c],np.c_[a,c,d],np.c_[a+nv,c+nv,b+nv],np.c_[a+nv,d+nv,c+nv]]
    border=np.r_[ids[0],ids[1:,-1],ids[-1,-2::-1],ids[-2:0:-1,0]];next=np.roll(border,-1)
    faces=np.r_[faces,np.c_[border,border+nv,next+nv],np.c_[border,next+nv,next]]
    mesh=trimesh.Trimesh(np.r_[roof,back],faces,process=False)
    if mesh.volume<0:mesh.invert()
    assert mesh.is_watertight and mesh.is_winding_consistent
    return as_solid(mesh)

def build_cutters():
    data=np.load(WORK/'native-root-profile.npz');pitch=float(data['pitch']);edge=float(data['max_edge'])
    specs=[('front',False,False),('rear',False,False),('outer-front',True,False),('outer-rear',True,False),('verify-front',False,True),('verify-rear',False,True)]
    audit={};start=time.time()
    for key,outer,verify in specs:
        dest=WORK/(key+'.npz')
        allowance=.003 if verify else .035
        vertical=.45+edge+allowance+(3.4 if outer else 0.)
        radius=vertical+(2 if verify else 4)*np.sqrt(2)*pitch+allowance
        tolerance=.0005 if verify else .002
        audit[key]={'vertical_offset_mm':vertical,'xz_dilation_radius_mm':radius,'cutter_simplification_tolerance_mm':tolerance,'guard_mm':allowance}
        if dest.exists():continue
        size=int(np.ceil(radius/pitch));zz,xx=np.mgrid[-size:size+1,-size:size+1];disk=(xx*pitch)**2+(zz*pitch)**2<=radius**2
        front=key.endswith('front')
        if front:
            h=ndimage.minimum_filter(data['front'],footprint=disk,mode='constant',cval=np.inf)-vertical;h[~np.isfinite(h)]=35.
        else:
            h=ndimage.maximum_filter(data['rear'],footprint=disk,mode='constant',cval=-np.inf)+vertical;h[~np.isfinite(h)]=-35.
        solid=height_solid(h,float(data['x0']),float(data['z0']),pitch,front).as_original().set_tolerance(tolerance).simplify(tolerance)
        save_solid(solid,dest);print('CUTTER',key,solid.num_tri(),'seconds',round(time.time()-start,2),flush=True)
    report={'requested_minimum_clearance_mm':.45,'maximum_source_triangle_edge_mm':edge,'profile_pitch_mm':pitch,'raster_bin_and_piecewise_linear_interpolation_guard_mm':2*np.sqrt(2)*pitch,'root_nominal_wall_mm':3.4,'cutters':audit,'proof':'For any relevant source triangle, every triangle point is within its measured maximum edge length of a source vertex. Any point in the desired 0.45 mm neighbourhood is consequently within 0.45+max_edge of a source vertex. Vertex binning and each interpolation-cell corner together shift X/Z by at most 2*sqrt(2)*pitch. The cutter radial and Y offsets cover these distances plus explicit guards. Its Y sweep contains the whole protected neighbourhood. A separate tighter cutter is intersected with each final float32 STL, so cleanup and export are audited.','exact_rational_interval_proof':False,'physical_print_fit_tested':False}
    (ASSETS/'clearance-construction.json').write_text(json.dumps(report,indent=2)+'\n')

def cylinder(a,b,r,r2=None,n=112):
    a,b=np.array(a,float),np.array(b,float);v=b-a;t=trimesh.geometry.align_vectors([0,0,1],v/np.linalg.norm(v));t[:3,3]=a
    return mf.Manifold.cylinder(float(np.linalg.norm(v)),r,r if r2 is None else r2,circular_segments=n).transform(t[:3])
def cube(size,center):return mf.Manifold.cube(size,center=True).translate(center)

def mesh_stats(m):
    _,counts=np.unique(m.edges_sorted,axis=0,return_counts=True)
    parts=m.split(only_watertight=False)
    return {'triangles':len(m.faces),'vertices':len(m.vertices),'watertight':bool(m.is_watertight),'winding_consistent':bool(m.is_winding_consistent),'components':len(parts),'all_edges_have_two_incident_faces':bool(np.all(counts==2)),'zero_area_faces':int(np.count_nonzero(m.area_faces==0)),'volume_mm3':float(m.volume),'center_mm':m.center_mass.tolist(),'bounds_mm':m.bounds.tolist()}

def export_verified(s,name):
    # Removing originalID/faceID boundaries is essential before tolerance cleanup.
    components=s.decompose();large=[x for x in components if abs(x.volume())>=.001]
    if len(large)!=1:raise RuntimeError('Disconnected structural components before STL export '+name)
    removed_volumes=[float(x.volume()) for x in components if abs(x.volume())<.001]
    original=large[0].as_original();last=None
    dest=ASSETS/f'Support_R11_100mm_{name}.stl'
    for tolerance in [0.,.0001,.0003,.0005,.001,.002,.003,.005]:
        candidate=original if not tolerance else original.set_tolerance(tolerance).simplify(tolerance)
        m=as_mesh(candidate);m.export(dest);q=trimesh.load_mesh(dest,process=True)
        exact_zero=(q.area_faces==0)
        if exact_zero.any():
            q.update_faces(~exact_zero);q.remove_unreferenced_vertices();q.export(dest);q=trimesh.load_mesh(dest,process=True)
        rec=mesh_stats(q)
        print('STL',name,tolerance,rec['triangles'],rec['watertight'],rec['components'],rec['zero_area_faces'],flush=True)
        last=rec
        if rec['watertight'] and rec['winding_consistent'] and rec['components']==1 and rec['all_edges_have_two_incident_faces'] and rec['zero_area_faces']==0:
            rec.update(file=dest.name,bytes=dest.stat().st_size,sha256=sha(dest),STL_cleanup_tolerance_mm=tolerance,microscopic_boundary_components_removed_mm3=removed_volumes)
            # Return the actual rounded geometry for later assembly/collision checks.
            return q,as_solid(q),rec
    save_solid(original,WORK/(name+'-unrounded.npz'))
    raise RuntimeError('No valid binary STL produced: '+name+' '+json.dumps(last))

def packed(m,path):
    vertices=np.c_[m.vertices,m.vertex_normals].astype('<f4')
    path.write_bytes(struct.pack('<II',len(m.vertices),len(m.faces))+vertices.tobytes()+np.asarray(m.faces,dtype='<u4').tobytes())

def build_parts(main_path,cap_path):
    main_path,cap_path=Path(main_path),Path(cap_path)
    cutters={k:load_solid(WORK/(k+'.npz')) for k in ['front','rear','outer-front','outer-rear','verify-front','verify-rear']}
    split=-1.4925520750669339;xs=[-38.72293266921084,35.827540438659746]
    holes=[]
    for x in xs:
        holes += [cylinder([x,split-25,117.83910524340095],[x,split+25,117.83910524340095],1.45),cylinder([x,split-11.1,117.83910524340095],[x,split-7.9,117.83910524340095],2.7),cylinder([x,split+8.5,117.83910524340095],[x,split+11.2,117.83910524340095],3.01,n=6)]
    holes=mf.Manifold.batch_boolean(holes,mf.OpType.Add)
    pinholes=mf.Manifold.batch_boolean([cylinder([x,split-.1,109.83910524340095],[x,split+3.7,109.83910524340095],1.5) for x in xs],mf.OpType.Add)
    solids={};records=[]
    for name,path,side,seam in [('main',main_path,'rear',-1.417551040649414),('cap',cap_path,'front',-1.5675525665283203)]:
        original=trimesh.load_mesh(path,process=True);s=as_solid(original)
        lo,hi=(-30.,seam) if side=='front' else (seam,30.)
        zlo,zhi=85.53910827636719,127.839111328125
        region=cube([90,hi-lo,zhi-zlo],[0,(lo+hi)/2,(zlo+zhi)/2])
        reinforcement=cutters['outer-'+side]^region
        result=(s+reinforcement)-cutters[side]-holes
        if name=='main':result=result-pinholes
        else:result=(result-solids['main']).translate([0,-.002,0])
        print('SOLID',name,'triangles',result.num_tri(),'components',[float(p.volume()) for p in result.decompose()],flush=True)
        m,solid,rec=export_verified(result,name)
        rec.update(source_file=str(path),source_sha256=sha(path),source_volume_mm3=float(original.volume),volume_change_mm3=float(m.volume-original.volume),minimum_designed_native_tooth_clearance_mm=.45)
        solids[name]=solid;records.append(rec)
        packed(m,ASSETS/f'100mm-{name}.bin')
        rec.update(packed_file=f'100mm-{name}.bin',packed_sha256=sha(ASSETS/f'100mm-{name}.bin'))
        (ASSETS/'parts.json').write_text(json.dumps(records,indent=2)+'\n')
        forbidden=solid^cutters['verify-'+side]
        print('VERIFY_CLEARANCE',name,forbidden.volume(),forbidden.num_tri(),flush=True)
        rec['verification_envelope_intersection_mm3']=float(forbidden.volume())
        if abs(forbidden.volume())>1e-6:raise RuntimeError('Final STL violates native clearance certificate '+name)
    tests={'main_cap_intersection_mm3':float((solids['main']^solids['cap']).volume())}
    for distance in [.5,1.,2.,5.,10.,40.]:tests[f'cap_main_withdrawal_{distance:g}mm_intersection_mm3']=float((solids['main']^solids['cap'].translate([0,-distance,0])).volume())
    if max(abs(v) for v in tests.values())>1e-6:raise RuntimeError('Assembly path interference '+json.dumps(tests))
    source=json.loads((ASSETS/'native-source-fit-audit.json').read_text())
    report={'revision':'R11','size_mm':100,'units':'mm','parts':records,'native_tooth_faces':source['source_faces'],'native_source_chunks_verified':source['verified_chunks'],'minimum_native_tooth_surface_clearance_mm':.45,'clearance_check_passed':True,'clearance_check_method':'All native triangle interiors covered by conservative source-vertex/maximum-edge swept envelopes; final reread manufacturing STL intersection with independent tighter envelopes <=1e-6 mm3.','assembly_checks':tests,'front_cap_and_main_single_closed_components':True,'front_cap_withdrawal_direction':[0,-1,0],'tooth_insertion_direction':[0,1,0],'front_cap_additional_withdrawal_clearance_mm':.002,'hardware_axes_x_z_preserved':True,'tooth_geometry_modified':False,'internal_CT_void_geometry_modified':False,'physical_print_tested':False,'FEM_recomputed_by_this_script':False}
    (ASSETS/'native-fit-validation.json').write_text(json.dumps(report,indent=2)+'\n')
    (ASSETS/'parts.json').write_text(json.dumps(records,indent=2)+'\n')
    print('COMPLETE',json.dumps(tests),flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--prepare-only',action='store_true');p.add_argument('--main');p.add_argument('--cap',default=str(OLD/'Support_R8_100mm_cap.stl'));a=p.parse_args()
    extract_profile();build_cutters()
    if not a.prepare_only:
        if not a.main:p.error('--main is required for final parts')
        build_parts(a.main,a.cap)
