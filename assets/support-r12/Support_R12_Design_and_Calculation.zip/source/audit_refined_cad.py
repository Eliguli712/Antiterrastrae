from pathlib import Path
import json,hashlib,numpy as np,manifold3d as mf,trimesh,igl
R=Path(__file__).resolve().parent;out=R/'assets/support-r12';model=json.loads((out/'support.json').read_text());records=[]
for size in [50,100]:
 c=model['cases'][str(size)];g=c['frame_graph'];m=trimesh.load_mesh(out/c['parts'][0]['file'],process=True)
 names=list(g['nodes']);points=np.array([g['nodes'][n] for n in names]);sample=np.concatenate([np.linspace(g['nodes'][a],g['nodes'][b],33) for a,b in g['edges']])
 w=igl.fast_winding_number(np.asarray(m.vertices),np.asarray(m.faces,dtype=np.int32),np.r_[points,sample])
 inside=np.abs(w)>.5
 print('GRAPH_EMBEDDING',size,'nodes',sum(inside[:len(points)]),'/',len(points),'samples',sum(inside[len(points):]),'/',len(sample),flush=True)
 if not inside.all():
  print('missingnodes',[n for n,b in zip(names,inside) if not b]);print('missingsamples',sample[~inside[len(points):]][:20].tolist());raise ValueError('Mechanical graph not contained in CAD')
 curve={}
 for seg in [24,192]:
  q=mf.Manifold.sphere(1.,seg).to_mesh64();v=np.array(q.vert_properties)[:,:3];f=np.array(q.tri_verts);tri=v[f];n=np.cross(tri[:,1]-tri[:,0],tri[:,2]-tri[:,0]);n/=np.linalg.norm(n,axis=1)[:,None];err=1-np.abs(np.einsum('ij,ij->i',n,tri[:,0]));curve[str(seg)]={'sphere_faces':len(f),'maximum_unit_facet_sag':float(err.max())}
 records.append({'size_mm':size,'nodes_inside_manufacturing_main':len(points),'beam_centerline_samples_inside_manufacturing_main':len(sample),'centerline_samples_per_beam':33,'sphere_segment_count':192,'cylinder_circular_segments':224,'regular_sphere_radius_mm':4.4,'foot_sphere_radius_mm':8.1,'maximum_foot_sphere_facet_sag_mm':8.1*curve['192']['maximum_unit_facet_sag'],'legacy_foot_sphere_facet_sag_mm_at_same_radius':8.1*curve['24']['maximum_unit_facet_sag'],'rod_radius_mm':3.2,'maximum_rod_chord_sag_mm':3.2*(1-np.cos(np.pi/224)),'legacy_rod_chord_sag_mm':3.2*(1-np.cos(np.pi/28)),'analytic_unit_sphere_comparison':curve,'CAD_parts':c['parts']})
report={'revision':'R12','actual_curved_surfaces_rebuilt':True,'coplanar_subdivision_used_for_smoothing':False,'original_native_tooth_faces':74293846,'tooth_stress_fields_recomputed_in_this_change':False,'all_graph_node_centers_and_sampled_centerlines_retained':True,'registered_source_SHA256':model['source_geometry']['sha256'],'cases':records}
(out/'manufacturing-validation.json').write_text(json.dumps(report,indent=2)+'\n')
