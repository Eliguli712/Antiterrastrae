"""Source-correct smooth frame with native-surface fitted split sockets.
All physical source tooth faces are retained; frame CAD uses analytic curves.
"""
from pathlib import Path
import importlib.util, json, math, shutil, time, os
import numpy as np
import trimesh, manifold3d as mf
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'assets/support-r12';OUT.mkdir(parents=True,exist_ok=True)
SITE=Path('/workspace/sites/megalodon-r12-recovery/.sites-checkout')
sp=importlib.util.spec_from_file_location('fit',ROOT/'native-fit/build_native_fit.py');fit=importlib.util.module_from_spec(sp);sp.loader.exec_module(fit)
OLD=Path(os.environ.get('MEGALODON_LEGACY_SUPPORT',str(SITE/'dist/assets/support-r8')));OLD_ANCHOR=86.73910524340096

def unite(a):return mf.Manifold.batch_boolean(a,mf.OpType.Add)
def cube(size,center):return mf.Manifold.cube(size,center=True).translate(center)
def sphere(p,r):return mf.Manifold.sphere(r,192).translate(p)
def cyl(a,b,r,n=224):return fit.cylinder(a,b,r,n=n)
def chamfer(size,c,d=.9):
 import itertools
 a,b,h=np.array(size)/2;v=[]
 for x,y,z in itertools.product([-1,1],repeat=3):v.extend([[x*a,y*(b-d),z*(h-d)],[x*(a-d),y*b,z*(h-d)],[x*(a-d),y*(b-d),z*h]])
 return mf.Manifold.hull_points(np.array(v)+c)
def frame(graph):
 parts=[cyl(graph['nodes'][a],graph['nodes'][b],graph['rod_diameter_mm']/2) for a,b in graph['edges']]
 parts.extend(sphere(p,graph['radii_mm'][n]) for n,p in graph['nodes'].items())
 return unite(parts).split_by_plane((0,0,1),0)[0]
def export(s,path):
 components=s.decompose();large=[x for x in components if abs(x.volume())>=.001]
 if len(large)!=1:raise RuntimeError('Disconnected structural CAD '+str(path)+str([p.volume() for p in components]))
 original=large[0].as_original();removed=[float(x.volume()) for x in components if abs(x.volume())<.001]
 for tol in [0.,.0001,.0003,.0005,.001,.002]:
  candidate=original if not tol else original.set_tolerance(tol).simplify(tol)
  fit.as_mesh(candidate).export(path);m=trimesh.load_mesh(path,process=True)
  zero=m.area_faces==0
  if zero.any():m.update_faces(~zero);m.remove_unreferenced_vertices();m.export(path);m=trimesh.load_mesh(path,process=True)
  weld_digits=None;welded_vertices=0
  if not m.is_watertight:
   # STL float32 can split a mathematically identical ear-edge intersection by
   # under one micron. Merge only such coincident positions; never fill holes.
   for digits in [6,5]:
    q=m.copy();nv=len(q.vertices);q.merge_vertices(digits_vertex=digits)
    q.update_faces(q.area_faces!=0);q.remove_unreferenced_vertices()
    if q.is_watertight and q.is_winding_consistent:
     welded_vertices=nv-len(q.vertices);weld_digits=digits;m=q;m.export(path);m=trimesh.load_mesh(path,process=True);break
  rec=fit.mesh_stats(m);print('EXPORT',path.name,tol,rec['triangles'],rec['watertight'],rec['components'],flush=True)
  if rec['watertight'] and rec['winding_consistent'] and rec['components']==1 and rec['all_edges_have_two_incident_faces'] and not rec['zero_area_faces']:
   rec.update(file=path.name,sha256=fit.sha(path),bytes=path.stat().st_size,cleanup_tolerance_mm=tol,microscopic_components_removed_mm3=removed,coincident_vertex_weld_decimal_places=weld_digits,coincident_vertices_welded=welded_vertices,coincident_weld_maximum_possible_displacement_mm=None if weld_digits is None else float(math.sqrt(3)*10**(-weld_digits)),holes_filled=False)
   return m,fit.as_solid(m),rec
 fit.save_solid(original,OUT/(path.stem+'-unrounded.npz'))
 raise RuntimeError('No valid float32 STL '+str(path))
def build(size,graph):
 start=time.time();folder=ROOT/('native-fit' if size==100 else 'native-fit50');shift=np.array(graph['nodes']['P'])-[0,0,OLD_ANCHOR]
 cs={k:fit.load_solid(folder/'work'/(k+'.npz')) for k in ['front','rear','outer-front','outer-rear','verify-front','verify-rear']}
 if size==100:
  split=-1.4925520750669339;xs=[-38.72293266921084,35.827540438659746];zlo,zhi=85.53910827636719,127.839111328125
  seam={'front':-1.5675525665283203,'rear':-1.417551040649414};ez=117.83910524340095
  ears=[chamfer((10,22,18),[x,split,114.83910524340095]).split_by_plane((0,1,0),seam['rear'])[0] for x in xs]
  holes=unite([fit.cylinder([x,split-25,ez],[x,split+25,ez],1.45) for x in xs]+[fit.cylinder([x,split-11.1,ez],[x,split-7.9,ez],2.7) for x in xs]+[fit.cylinder([x,split+8.5,ez],[x,split+11.2,ez],3.01,n=6) for x in xs])
  pinholes=unite([fit.cylinder([x,split-.1,109.83910524340095],[x,split+3.7,109.83910524340095],1.5) for x in xs])
  spine=[0.,14.969537222006522,107.83910524340095];tips=[[x,split+8,114.83910524340095] for x in xs];arm=3.8
 else:
  split=0.;xs=[-20.850000381469727,20.899999618530273];zlo,zhi=85.53910827636719,106.73910522460938;seam={'front':-.12,'rear':.12};ez=99.53910524340095
  ears=[cube([7,12,10],[x,0,ez]).split_by_plane((0,1,0),seam['rear'])[0] for x in xs]
  holes=unite([fit.cylinder([x,-20,ez],[x,20,ez],1.45) for x in xs]);pinholes=mf.Manifold()
  spine=[0.,10.,94.73910524340095];tips=[[x,4.,ez] for x in xs];arm=3.8
 region={}
 for side in ['front','rear']:
  lo,hi=(-30.,seam[side]) if side=='front' else (seam[side],30.)
  region[side]=cube([90,hi-lo,zhi-zlo],[0,(lo+hi)/2,(zlo+zhi)/2])
 new_frame=frame(graph)
 rear=cs['outer-rear']^region['rear']
 braces=unite([cyl([0,0,OLD_ANCHOR],spine,arm),sphere(spine,4.4)]+[cyl(spine,p,arm) for p in tips])
 # Root relief applies to connector and ears as well as the new rear socket.
 main=(new_frame+(unite([rear,braces,*ears])-cs['rear']-holes-pinholes).translate(shift.tolist()))
 oldcap=fit.as_solid(trimesh.load_mesh(OLD/f'Support_R8_{size}mm_cap.stl',process=True))
 # The matching original front hardware is retained and fitted to all source faces.
 cap=((oldcap+(cs['outer-front']^region['front']))-cs['front']-holes).translate(shift.tolist())
 main=main-cs['rear'].translate(shift.tolist())
 # A 2 micron withdrawal offset protects nominally coincident old interface planes
 # from float32 re-encoding. Hardware X/Z axes and requested tooth gap are kept.
 cap=cap.translate([0,-.002,0])
 if size==50:
  # Full front-cap projection provides a continuous withdrawal corridor.
  # This conservative prism stops before the rear clamp seam.
  projected=cap.rotate([90,0,0]).project()
  section=mf.CrossSection(projected.to_polygons(),mf.FillRule.Positive).offset(.03,circular_segments=32)
  cb=cap.bounding_box();ymin=cb[1]-45.;ymax=cb[4]+.03
  corridor=section.extrude(ymax-ymin).translate([0,0,ymin]).rotate([-90,0,0])
  main=main-corridor
 main=main-cap
 m,ms,mr=export(main,OUT/f'Support_R12_{size}mm_main.stl')
 cap=cap-ms
 c,csld,cr=export(cap,OUT/f'Support_R12_{size}mm_cap.stl')
 tests={'main_cap_intersection_mm3':float((ms^csld).volume())}
 if size==50:
  pc=csld.rotate([90,0,0]).project();section_verify=mf.CrossSection(pc.to_polygons(),mf.FillRule.Positive).offset(.01,circular_segments=32)
  cb=csld.bounding_box();lo=cb[1]-44.9;hi=cb[4]+.01
  verify_corridor=section_verify.extrude(hi-lo).translate([0,0,lo]).rotate([-90,0,0])
  tests['main_independent_continuous_cap_corridor_intersection_mm3']=float((ms^verify_corridor).volume())
 for dist in [.5,1.,2.,5.,10.,40.]:tests[f'cap_withdrawal_{dist:g}mm_intersection_mm3']=float((ms^csld.translate([0,-dist,0])).volume())
 for name,s,side in [('main',ms,'rear'),('cap',csld,'front')]:tests[name+'_native_protected_envelope_intersection_mm3']=float((s^cs['verify-'+side].translate(shift.tolist())).volume())
 print('CHECKS',size,tests,flush=True)
 if max(abs(x) for x in tests.values())>1e-6:raise RuntimeError('Final assembly/cavity verification failed '+json.dumps(tests))
 for name,mesh,rec in [('main',m,mr),('cap',c,cr)]:
  path=OUT/f'{size}mm-{name}.bin';fit.packed(mesh,path);rec.update(packed_file=path.name,packed_sha256=fit.sha(path))
  # Lighter display-only CPU fallback; the full STL and GPU retain every face.
  preview=fit.as_solid(mesh).as_original().set_tolerance(.06).simplify(.06);fit.packed(fit.as_mesh(preview),OUT/f'{size}mm-{name}-preview.bin')
 combined=m+c;gap=.45 if size==100 else .35
 audit={'revision':'R12','size_mm':size,'source_faces_audited':74293846,'source_chunks_verified':75,'minimum_clearance_mm':gap,'passed':True,'continuous_withdrawal_corridor_mm':45. if size==50 else None,'corridor_XZ_clearance_mm':.03 if size==50 else None,'physical_print_fit_tested':False,'tooth_geometry_modified':False,'tooth_rigid_translation_mm':shift.tolist(),'front_cap_additional_withdrawal_mm':.002,'tests':tests,'method':'All source vertex profiles with measured maximum native triangle edge, guarded swept envelopes, and independent protected-envelope intersections against final rounded STL.'}
 (OUT/f'{size}mm-native-fit-validation.json').write_text(json.dumps(audit,indent=2)+'\n')
 for filename in ['native-source-fit-audit.json','clearance-construction.json']:
  shutil.copyfile(folder/'assets'/filename,OUT/f'{size}mm-{filename}')
 return {'size_mm':size,'revision':'R12','frame_scale':1,'root_clearance_mm':gap,'root_wall_mm':3.4 if size==100 else 2.2,'root_height_mm':40 if size==100 else 20,'root_base_z_mm':zlo+shift[2],'tooling_pitch_mm':.1 if size==100 else .05,'ct_native_spacing_um':18,'tooth_anchor_mm':graph['nodes']['P'],'tooth_display_scale':size/100,'frame_graph':graph,'bevel_bands':1,'top_transition':'Four equilateral source-cut triangle loops, one shared apex P; t=0.50a','parts':[mr,cr],'resin_volume_ml':float(combined.volume/1000),'resin_center_mm':combined.center_mass.tolist(),'frame_bounds_mm':fit.as_mesh(new_frame).bounds.tolist(),'all_edge_endpoints_have_spheres':True,'native_surface_clearance':audit,'geometry_checks':tests,'native_74M_collision_test_completed':True,'status':'digitally_fitted_source_correct_candidate','seconds':time.time()-start,'notes':['Native tooth geometry and existing numerical stress fields are unchanged.','The complete source-correct frame is new analytic high-resolution CAD, not subdivision of legacy planar triangles.','Socket, fasteners, contact and strength are not solved as a fully coupled continuum.','Physical print retention/strength are untested.']}

def main():
 model=json.loads((ROOT/'geometry/support.json').read_text());cases={}
 for size in [50,100]:
  graph=model['cases'][str(size)]['frame_graph'];cases[str(size)]=build(size,graph)
  draft=dict(model);draft['cases']=cases;(OUT/'support-partial.json').write_text(json.dumps(draft,indent=2)+'\n')
 model['cases']=cases;model['frame_note']='Both physical sizes use the uploaded half-edge-trimmed dual-cube graph, four equilateral triangles and one common apex. Real rod crossings are fused in CAD and frame mechanics.'
 (OUT/'support.json').write_text(json.dumps(model,indent=2)+'\n')
 for name in ['source-graph.json','source-geometry-validation.json','source-registration-audit.json','diagram-common-apex.svg','diagram-common-apex.png','DoubleCube_CommonPoint_Height100mm.stl']:
  p=ROOT/'geometry'/name
  if p.exists():shutil.copyfile(p,OUT/name)
 print('DONE',json.dumps({k:{x:v[x] for x in ['resin_volume_ml','resin_center_mm','seconds']} for k,v in cases.items()}),flush=True)
if __name__=='__main__':main()
