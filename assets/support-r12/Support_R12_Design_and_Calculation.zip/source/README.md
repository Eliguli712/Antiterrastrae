# Refined source support R12

Both sizes preserve the uploaded dual-cube source: four equilateral triangular cuts, one shared apex, 52 mm original cube edge. Every graph node has a spherical junction. Main and front cap are separate printable parts.

Use Python 3.12 and the pinned requirements. Supply the complete native geometry directory containing geometry.json and all 75 geometry-XX.bin.gz chunks; no native tooth faces are reduced. The original geometry manifest is included in native-source/. Public source: https://raw.githubusercontent.com/Eliguli712/Antiterrastrae/native74-r5-data/data/geometry.json . Download each chunk from that same directory and verify its manifest SHA-256.

Run from this source directory:

    python -m pip install -r requirements.txt
    python rebuild_source.py --native /absolute/path/to/native_geometry

This reconstructs guarded native root tooling, analytic 192-segment spheres / 224-segment rods, four manufacturing STLs and independent Euler–Bernoulli + spherical-node 3D elastic support models. Complete input front-cap hardware is preserved in inputs/legacy-support/. The 50 mm full-sphere mesh is geometrically scaled from the same source; its support load/stress system is assembled and solved independently. Socket profiles include every original native face via conservative source-vertex / triangle-edge envelopes; the source tooth geometry and stored tooth stress fields remain unchanged.

See geometry/README.md for material assumptions, load factors, radius floors, force/moment checks, short-member shear sensitivity, idealized foot/node geometry and unconverged local peaks. This is a candidate digital design; physical clamp retention and printed strength have not been tested. Native porous-volume tooth FEM is not solved by these scripts.

Minimum-height orientations have a separate source package and certificate. The displayed tooth colours remain the independently assembled earlier proxy fields, explicitly identified on the website.
