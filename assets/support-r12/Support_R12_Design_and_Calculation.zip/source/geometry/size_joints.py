"""Independent two-size solid joint sizing with source-specific frame solves.

Preliminary assumed CAD weights are superseded by --cad-model once rebuilt
solids have been measured. Radius trials are deliberately limited to solid
printed nodes; hollow-wall submodels are a separately reported research case.
"""
from pathlib import Path
import argparse,copy,json,math,time,hashlib
import numpy as np
import frame_fem_r12 as fem
HERE=Path(__file__).resolve().parent
fem.ROOT=HERE;fem.OUT=HERE

def run(cad_model=None):
 model=json.loads((HERE/'source-graph.json').read_text())
 if cad_model:
  measured=json.loads(Path(cad_model).read_text())
  for size in ['50','100']:
   for key in ['resin_volume_ml','resin_center_mm']:
    model['cases'][size][key]=measured['cases'][size][key]
   model['cases'][size]['CAD_mass_status']='measured exact rebuilt STL geometry'
 cad_provenance=None
 if cad_model:
  cad_provenance={'file_name':Path(cad_model).name,'input_support_JSON_SHA256':hashlib.sha256(Path(cad_model).read_bytes()).hexdigest(),'cases':{size:{'resin_volume_ml':measured['cases'][size]['resin_volume_ml'],'resin_center_mm':measured['cases'][size]['resin_center_mm'],'parts':[{k:p[k] for k in ['file','sha256','triangles','volume_mm3'] if k in p} for p in measured['cases'][size].get('parts',[])]} for size in ['50','100']}}
 initial=copy.deepcopy(model);history=[];allowable=5.;manufacturing_min=4.4
 # Threefold tooth gravity already in the solver; nominal assumed strength30
 # divided by safetyfactor3 and separate local-modelling reserve2 =>5MPa.
 for iteration in range(8):
  frames={str(s):fem.solve_frame(model,s) for s in [50,100]}
  balls=fem.ball_submodels(model,frames)
  changes=[]
  for size in ['50','100']:
   graph=model['cases'][size]['frame_graph'];solid=[r for r in balls['cases'][size] if r['variant']=='solid']
   for r in solid:
    name=r['node'];old=graph['radii_mm'][name];stress=r['max_element_vm_MPa']
    if stress>allowable:
     new=math.ceil(max(old+.1,old*math.sqrt(stress/allowable))*10)/10
     graph['radii_mm'][name]=new;changes.append({'size_mm':int(size),'node':name,'old_radius_mm':old,'new_radius_mm':new,'trial_element_peak_vm_MPa':stress})
  history.append({'iteration':iteration,'changed_nodes':changes,'beam_peaks_MPa':{size:frames[size]['max_vm_envelope_MPa'] for size in frames},'solid_node_peaks_MPa':{size:max(r['max_element_vm_MPa'] for r in balls['cases'][size] if r['variant']=='solid') for size in frames}})
  if not changes:break
 else:raise RuntimeError('Joint radius loop did not stabilize')
 design=[]
 for size in ['50','100']:
  graph=model['cases'][size]['frame_graph'];solid={r['node']:r for r in balls['cases'][size] if r['variant']=='solid'}
  for name,radius in graph['radii_mm'].items():
   record=solid[name];minimum=initial['cases'][size]['frame_graph']['radii_mm'][name]
   design.append({'size_mm':int(size),'node':name,'selected_radius_mm':radius,'manufacturing_floor_mm':minimum,'governing_constraint':'manufacturing/contact floor' if abs(radius-minimum)<1e-9 else 'solid-node FE trial stress','solid_node_FE_peak_MPa':record['max_element_vm_MPa'],'solid_node_FE_surface_q95_MPa':record['surface_q95_vm_MPa'],'assumed_allowable_MPa':allowable,'peak_mesh_convergence_verified':False,'member_load_count':len(frames[size]['node_loads'][name])})
 report={'revision':'R12','method':'Candidate solid spherical-node radius iteration using independently solved 5cm and10cm source-correct Euler–Bernoulli global frames and balanced finite-area 3D P1 elasticity submodels.','source_geometry_sha256':model['source_geometry']['sha256'],'CAD_masses_are_measured':bool(cad_model),'CAD_provenance':cad_provenance,'radius_increment_mm':.1,'nominal_assumed_strength_MPa':30.,'nominal_strength_is_not_a_measured_resin_property':True,'material_safety_factor':3.,'local_model_reserve_factor':2.,'assumed_allowable_MPa':allowable,'tooth_gravity_factor':3.,'physical_print_fit_or_strength_tested':False,'solid_node_peak_mesh_convergence_verified':False,'full_native_tooth_volumetric_FEM_solved':False,'geometry_modified_native_tooth':False,'notes':['All physical rod crossings are fused and share DOFs.','Beam gravity and first moment use measured CAD only when CAD_masses_are_measured is true.','Each independent tooth mass and centroid were integrated over all native source faces, including original internal void boundaries.','The tooth is reduced to its force and eccentric moment at the shared apex for support mechanics.','All sizes can legitimately select equal radii when manufacturing and foot contact floors govern the gravity study.','Overlapping patches represent fused nearby rod branches; their balanced forces and moments superpose.','P1 local node peaks are discretization-dependent and not a strength certification.','Local foot submodels use full spheres; manufactured flat contact clipping is not resolved.','The cap withdrawal relief near the root and detailed socket topology affect calibrated CAD mass and centroid but not the idealized beam centreline stiffness or full-sphere local model.','Euler–Bernoulli nominal section stresses omit socket/contact/fastener/creep and local bevel-plate bending.','Solid printed nodes and 1.2 mm hollow research nodes are explicitly separate results.'], 'geometry':model['geometry_validation'],'iterations':history,'nodes':design}
 (HERE/'support.json').write_text(json.dumps(model,indent=2)+'\n')
 (HERE/'radius-design.json').write_text(json.dumps(report,indent=2)+'\n')
 (HERE/'frame-fem-with-loads.json').write_text(json.dumps({'revision':'R12','unit_system':'N,mm,MPa','validation':fem.checks(),'cases':frames},indent=2)+'\n')
 for frame in frames.values():frame.pop('node_loads')
 (HERE/'frame-fem.json').write_text(json.dumps({'revision':'R12','unit_system':'N,mm,MPa','validation':fem.checks(),'cases':frames},indent=2)+'\n')
 (HERE/'ball-fem.json').write_text(json.dumps(balls,separators=(',',':'))+'\n')
 print(json.dumps({'passes':len(history),'radii':{size:model['cases'][size]['frame_graph']['radii_mm'] for size in ['50','100']},'peak_beam':history[-1]['beam_peaks_MPa'],'peak_node':history[-1]['solid_node_peaks_MPa'],'CAD_masses_measured':bool(cad_model)},indent=2),flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--cad-model');args=p.parse_args();run(args.cad_model)
