"""Independent source registration and common-apex checks, no remeshing."""
from pathlib import Path
import hashlib,json
import numpy as np
import trimesh,igl
HERE=Path(__file__).resolve().parent
model=json.loads((HERE/'source-graph.json').read_text());meta=model['source_geometry']
SOURCE=HERE/'DoubleCube_CommonPoint_Height100mm.stl'
if not SOURCE.exists():SOURCE=Path('/workspace/scratch/798f43faaad4/upload/DoubleCube_CommonPoint_Height100mm(1).stl')
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest()==meta['sha256']
source=trimesh.load_mesh(SOURCE,process=True);vertices=np.array(source.vertices)*meta['uniform_scale']+meta['translation_mm'];nodes=np.array(list(model['nodes'].values()));dist=np.min(np.linalg.norm(nodes[:,None,:]-vertices[None,:,:],axis=2),axis=1)
points=[]
for a,b in model['edges']:
 x,y=np.array(model['nodes'][a]),np.array(model['nodes'][b]);points.extend([x+(y-x)*t for t in np.linspace(0,1,21)])
sq,idx,closest=igl.point_mesh_squared_distance(np.array(points),vertices,np.array(source.faces,dtype=np.int64))
common=set(model['top_triangles'][0]);edge_values=[]
for tri in model['top_triangles']:
 common&=set(tri);p=np.array([model['nodes'][n] for n in tri]);ll=np.linalg.norm(p-np.roll(p,1,axis=0),axis=1);assert np.ptp(ll)<1e-12;edge_values.extend(ll.tolist())
assert common=={'P'} and len(edge_values)==12 and dist.max()<1e-7 and np.sqrt(sq).max()<1e-7
report={'all_node_source_registration_max_error_mm':float(dist.max()),'rod_centerline_surface_samples':len(points),'rod_centerline_max_distance_to_original_STL_boundary_mm':float(np.sqrt(sq).max()),'source_SHA256':meta['sha256'],'source_file':meta['file'],'four_equilateral_triangles':True,'twelve_3D_triangle_edges_mm':edge_values,'exactly_one_common_vertex':'P','method':'All 30 graph nodes compared to source STL vertices; 21 samples on each of 52 rod centrelines independently compared to the original 72 triangles with libigl squared distance. All 12 triangle sides checked from 3D coordinates.','all_node_centers_source_registered':True,'centerline_samples_are_not_fullsolidcollision_certification':True}
(HERE/'source-registration-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
