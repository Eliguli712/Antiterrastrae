"""Exact coordinate projections of the source-derived structural graph."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
matplotlib.rcParams['svg.fonttype']='none'
from matplotlib import pyplot as plt
from matplotlib.patches import Polygon,Circle
HERE=Path(__file__).resolve().parent
m=json.loads((HERE/'source-graph.json').read_text());v={n:np.array(p,float) for n,p in m['nodes'].items()}
bg='#091419';fg='#e5e5dc';muted='#8ca6b0';rule='#314753';col=['#b9a1fa','#6bc8ec','#7fceaa','#e0b485']
fig=plt.figure(figsize=(18,10.2),facecolor=bg)
fig.text(.045,.941,'FORM, JOINED AT ONE POINT',fontfamily='DejaVu Sans',fontsize=11,color=muted)
fig.text(.045,.882,'Four equilateral cuts. One shared apex.',fontfamily='DejaVu Serif',fontstyle='italic',fontsize=31,color=fg)
fig.text(.045,.825,'Exact source geometry · the same 52 mm cube frame for 50 mm and 100 mm teeth',fontfamily='DejaVu Sans',fontsize=13,color=muted)
fig.add_artist(plt.Line2D([.045,.955],[.785,.785],color=rule,lw=1))
left=fig.add_axes([.035,.155,.49,.59],facecolor=bg);right=fig.add_axes([.57,.18,.385,.54],facecolor=bg)
for ax in [left,right]:ax.set_aspect('equal');ax.axis('off')
# Orthographic affine projection, computed directly from the true millimetre coordinates.
eye=np.array([1.1,-1.45,.9]);eye/=np.linalg.norm(eye);horizontal=np.cross([0.,0.,1.],eye);horizontal/=np.linalg.norm(horizontal);vertical=np.cross(eye,horizontal)
center=np.array([0.,0.,40.])
def proj(p):
 q=p-center;return np.array([q@horizontal,q@vertical])
pr={n:proj(p) for n,p in v.items()};items=[]
for a,b in m['edges']:items.append(((v[a]+v[b])@eye/2,'edge',(a,b)))
for i,tri in enumerate(m['top_triangles']):items.append((np.mean([v[n] for n in tri],axis=0)@eye,'tri',(i,tri)))
for n in v:items.append((v[n]@eye,'node',n))
for dep,kind,data in sorted(items,key=lambda k:k[0]):
 if kind=='edge':
  a,b=data;p,q=pr[a],pr[b];left.plot([p[0],q[0]],[p[1],q[1]],color='#718c96',alpha=.75,lw=2.0,zorder=2+dep/1000)
 elif kind=='tri':
  i,tri=data;left.add_patch(Polygon([pr[n] for n in tri],facecolor=col[i],edgecolor=col[i],alpha=.23,lw=2,zorder=2+dep/1000))
 else:
  n=data;isP=n=='P';left.add_patch(Circle(pr[n],radius=.72 if isP else .48,facecolor=fg if isP else '#a3b9c0',edgecolor=bg,lw=.3,zorder=2+dep/1000))
P=pr['P'];left.annotate('P',P,xytext=(P[0]+4,P[1]+4),color=fg,fontsize=17,fontfamily='DejaVu Serif',arrowprops={'arrowstyle':'-','color':muted,'lw':.8})
left.set_xlim(-60,60);left.set_ylim(-48,53)
left.text(-58,50,'SOURCE FRAME',color=muted,fontsize=11)
left.text(-58,-47,'30 shared nodes · 52 frame elements · 8 fused rod crossings',color=muted,fontsize=10)
# Plan view is an exact XY projection. Equilateral side lengths refer to 3D.
for i,tri in enumerate(m['top_triangles']):
 q=[v[n][:2] for n in tri];right.add_patch(Polygon(q,facecolor=col[i],edgecolor=col[i],alpha=.25,lw=2.3));right.plot(*np.array(q+[q[0]]).T,color=col[i],lw=2)
 for n in tri:
  if n!='P':right.add_patch(Circle(v[n][:2],.55,facecolor=col[i],edgecolor=bg,lw=.6))
right.add_patch(Circle([0,0],1.35,facecolor=bg,edgecolor=fg,lw=1.6));right.add_patch(Circle([0,0],.44,facecolor=fg,edgecolor='none'))
right.text(2.8,.5,'P',color=fg,fontsize=17,fontfamily='DejaVu Serif')
right.text(0,31.4,'NORTH',ha='center',color=col[2],fontsize=10)
right.text(0,-34.0,'SOUTH',ha='center',color=col[3],fontsize=10)
right.text(-33,0,'WEST',ha='right',va='center',color=col[0],fontsize=10)
right.text(33,0,'EAST',ha='left',va='center',color=col[1],fontsize=10)
right.set_xlim(-44,44);right.set_ylim(-37,37)
right.text(-43,36,'TOP VIEW · TRUE XY PROJECTION',color=muted,fontsize=11)
fig.text(.586,.143,'Every 3D side 36.769553 mm',color=fg,fontsize=16,fontfamily='DejaVu Serif')
fig.text(.586,.108,'Four faces share exactly P · cut distance 0.50 a',color=muted,fontsize=11)
fig.add_artist(plt.Line2D([.045,.955],[.074,.074],color=rule,lw=1))
fig.text(.045,.040,'Source: DoubleCube_CommonPoint_Height100mm(1).stl  ·  SHA-256 0520a5e7…c09d922',color=muted,fontsize=9)
fig.text(.955,.040,'Exact node positions · joint circles are schematic',color=muted,fontsize=9,ha='right')
for ext in ['svg','png']:fig.savefig(HERE/('diagram-common-apex.'+ext),dpi=150,facecolor=bg)
print('diagram-common-apex.svg / diagram-common-apex.png')
