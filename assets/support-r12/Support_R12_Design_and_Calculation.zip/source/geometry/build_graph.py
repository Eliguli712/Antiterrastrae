"""Source-derived clipped two-cube structural skeleton with shared midpoint cuts.

The uploaded watertight CAD STL, rather than any older stand, sets the
chamfer topology. Original cube edge is retained at 52 mm in both cases.
All physical rod crossings are split into shared frame nodes.
"""
from pathlib import Path
import hashlib,json,math
import numpy as np
import trimesh
HERE=Path(__file__).resolve().parent
SOURCE=HERE/'DoubleCube_CommonPoint_Height100mm.stl'
if not SOURCE.exists():SOURCE=Path('/workspace/scratch/798f43faaad4/upload/DoubleCube_CommonPoint_Height100mm(1).stl')
a=52.;source_a=50*math.sqrt(2);scale=a/source_a;lift=7.2;s=math.sqrt(2)*a/2
# Analytic reconstruction respects exact equality lost only at Float32 source rounding.
nodes={'A0':[-a/2,0,lift],'A1':[-a/2,s,lift+s],'A2':[a/2,0,lift],'A3':[a/2,s,lift+s],
 'A4':[-a/2,-s,lift+s],'A6':[a/2,-s,lift+s],
 'B0':[0,a/2,lift],'B1':[-s,a/2,lift+s],'B2':[s,a/2,lift+s],
 'B4':[0,-a/2,lift],'B5':[-s,-a/2,lift+s],'B6':[s,-a/2,lift+s],
 'Q_bottom':[0,0,lift], 'P':[0,0,lift+2*s]}
oldtop={'A5':[-a/2,0,lift+2*s],'A7':[a/2,0,lift+2*s], 'B3':[0,a/2,lift+2*s],'B7':[0,-a/2,lift+2*s]}
connections={'A5':['A1','A4'],'A7':['A3','A6'],'B3':['B1','B2'],'B7':['B5','B6']}
edges=[['A0','A1'],['A0','Q_bottom'],['Q_bottom','A2'],['A0','A4'],['A1','A3'],['A2','A3'],['A2','A6'],['A4','A6'],['B0','B1'],['B0','B2'],['B0','Q_bottom'],['Q_bottom','B4'],['B1','B5'],['B2','B6'],['B4','B5'],['B4','B6']]
triangles=[]
for top,adj in connections.items():
 names=[]
 for other in adj:
  name=top+'_'+other+'_mid';nodes[name]=((np.array(oldtop[top])+nodes[other])/2).tolist();names.append(name);edges.append([other,name])
 triangles.append([names[0],names[1],'P'])
 edges.extend([[names[0],names[1]],[names[1],'P'],['P',names[0]]])
# Split every interior rod intersection; source CSG fuses these crossings.
newnodes={};parameters={k:[(0.,a),(1.,b)] for k,(a,b) in enumerate(edges)}
for i,(a,b) in enumerate(edges):
 p,q=np.array(nodes[a]),np.array(nodes[b]);u=q-p
 for j,(c,d) in enumerate(edges[:i]):
  if {a,b}&{c,d}:continue
  r,t=np.array(nodes[c]),np.array(nodes[d]);v=t-r
  st,res,rank,_=np.linalg.lstsq(np.c_[u,-v],r-p,rcond=None)
  if rank<2:continue
  x,y=st
  if 1e-8<x<1-1e-8 and 1e-8<y<1-1e-8 and np.linalg.norm(p+x*u-r-y*v)<1e-7:
   pt=(p+x*u+r+y*v)/2
   existing=next((n for n,w in newnodes.items() if np.linalg.norm(pt-w)<1e-7),None)
   name=existing or 'J'+str(len(newnodes)+1).zfill(2)
   newnodes[name]=pt;parameters[i].append((float(x),name));parameters[j].append((float(y),name))
nodes.update({k:v.tolist() for k,v in newnodes.items()})
splitedges=[]
for i,values in parameters.items():
 values=sorted(set(values))
 for (_,a),(_,b) in zip(values,values[1:]):
  if a!=b:splitedges.append([a,b])
edges=splitedges
feet=['A0','A2','B0','B4']
# Explicit manufacturing constraints; stresses may increase each radius later.
rod_radius=3.2;radial_ligament=1.2;foot_contact_radius=3.5
foot_radius=math.ceil(math.sqrt(lift**2+foot_contact_radius**2)*10-1e-12)/10
radii={n:foot_radius if n in feet else rod_radius+radial_ligament for n in nodes}
# Verify exact four triangles, midpoint cuts, common point, source registration.
m=trimesh.load_mesh(SOURCE,process=True);sourcev=np.array(m.vertices)*scale+[0,0,lift]
tri_reports=[]
for tri in triangles:
 p=np.array([nodes[n] for n in tri]);lengths=np.linalg.norm(p-np.roll(p,1,axis=0),axis=1)
 distances=np.min(np.linalg.norm(p[:,None,:]-sourcev[None,:,:],axis=2),axis=1)
 tri_reports.append({'nodes':tri,'lengths_mm':lengths.tolist(),'maximum_edge_spread_mm':float(np.ptp(lengths)),'source_vertex_registration_error_mm':float(distances.max())})
common=set(triangles[0])
for tri in triangles[1:]:common&=set(tri)
assert common=={'P'} and len(newnodes)==8 and len(nodes)==30 and len(edges)==52
assert max(t['maximum_edge_spread_mm'] for t in tri_reports)<1e-12
assert max(t['source_vertex_registration_error_mm'] for t in tri_reports)<1e-7
incidence={n:[] for n in nodes}
for a,b in edges:
 for n,o in [(a,b),(b,a)]:
  v=np.array(nodes[o])-nodes[n];incidence[n].append((o,v/np.linalg.norm(v)))
angles={}
for n,items in incidence.items():
 av=[math.degrees(math.acos(np.clip(np.dot(u,v),-1,1))) for i,(_,u) in enumerate(items) for _,v in items[:i]]
 angles[n]={'degree':len(items),'minimum_incident_angle_degrees':min(av),'patches_may_overlap':min(av)<2*math.degrees(math.asin(min(.8,rod_radius/radii[n])))}
geom={'revision':'R12','unit':'mm','nodes':nodes,'edges':edges,'radii_mm':radii,'feet':feet,'rod_diameter_mm':2*rod_radius,'top_triangles':triangles,'top_side_lengths_mm':[x['lengths_mm'] for x in tri_reports],'bevel_bands':1,'case_specific_graphs':True,'all_edge_endpoints_have_spheres':True,'tooth_anchor_mm':nodes['P'],'source_geometry':{'file':'DoubleCube_CommonPoint_Height100mm(1).stl','sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'triangles':len(m.faces),'source_original_cube_edge_mm':source_a,'target_original_cube_edge_mm':52.,'uniform_scale':scale,'translation_mm':[0,0,lift],'cut_fraction':.5,'four_equilateral_common_point_triangles':True,'shared_vertex':'P','source_STL_watertight':bool(m.is_watertight),'source_STL_winding_consistent':bool(m.is_winding_consistent),'note':'STL sets cut triangle planes and topology; structural rods follow the original two cubes plus the four cut perimeters. Internal polyhedron union seams are not added as rods. Every crossing of existing rods is fused and split into one shared structural node.'},'geometry_validation':{'triangles':tri_reports,'common_vertices':sorted(common),'shared_apex_count':len(common),'structural_nodes':len(nodes),'beam_elements':len(edges),'fused_rod_crossing_nodes':sorted(newnodes),'cut_fraction':.5,'cube_edge_mm':52.,'unchanged_foot_centers':True,'manufacturing_node_radius_floor_mm':rod_radius+radial_ligament,'foot_radius_floor_mm':foot_radius,'incidence':angles},'sizing_constraints':{'rod_radius_mm':rod_radius,'radial_solid_ligament_mm':radial_ligament,'radial_ligament_is_assumed_manufacturing_constraint':True,'foot_center_height_mm':lift,'minimum_flat_contact_disk_radius_mm':foot_contact_radius,'foot_radius_formula':'ceil_0.1(sqrt(foot_center_height^2 + contact_radius^2))','patch_overlap_allowed_for_fused_rod_branches':True,'nominal_allowable_MPa':5.,'allowable_is_assumed_not_measured':True,'gravity_load_factor':3,'caution':'Individual load patches are allowed to overlap at fused near-parallel branches. Requiring disjoint patches would enlarge the common apex sphere until neighbouring short branches disappear. Stress checks use superposed balanced tractions on the same solid node.'},'cases':{}}
for size in [50,100]:
 geom['cases'][str(size)]={'size_mm':size,'tooth_anchor_mm':nodes['P'],'frame_graph':{'nodes':nodes,'edges':edges,'radii_mm':radii,'feet':feet,'rod_diameter_mm':2*rod_radius,'top_triangles':triangles},'resin_volume_ml':60.106891329356294 if size==50 else 71.,'resin_center_mm':[0.,0.,48.],'CAD_mass_status':'provisional until exact rebuilt main and cap solids are supplied'}
(HERE/'source-graph.json').write_text(json.dumps(geom,indent=2)+'\n')
(HERE/'source-geometry-validation.json').write_text(json.dumps(geom['geometry_validation'],indent=2)+'\n')
print(json.dumps({'nodes':len(nodes),'edges':len(edges),'apex':nodes['P'],'triangle_edges':geom['top_side_lengths_mm'],'foot_radius':foot_radius,'node_minimum_radius':rod_radius+radial_ligament,'source_scale':scale},indent=2))
