"""Euler–Bernoulli frame + finite-area-load 3D spherical-node submodels.

The spherical submodel is three-dimensional elasticity, not a claimed
implementation of Chien's thin-shell equations. Printed nodes are solid;
a hollow-wall research variant is also solved and explicitly distinguished.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import json, math, sys
from pathlib import Path
import numpy as np
import scipy.linalg as la
from scipy.sparse import coo_matrix
from scipy.sparse.linalg import splu
sys.path.insert(0,str(Path(__file__).with_name('deps')))
import trimesh
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'dist/assets/support-r8'
E,NU,RHO=1375.,.38,1.18e-6 # MPa, dimensionless, kg/mm3
G=E/(2*(1+NU));LAM=E*NU/((1+NU)*(1-2*NU));GRAVITY=9.81

def local_k(L,d):
    A=math.pi*d*d/4;I=math.pi*d**4/64;J=2*I;K=np.zeros((12,12))
    def put(ids,a,c):K[np.ix_(ids,ids)]+=np.array(a)*c
    put([0,6],[[1,-1],[-1,1]],E*A/L);put([3,9],[[1,-1],[-1,1]],G*J/L)
    put([1,5,7,11],[[12,6*L,-12,6*L],[6*L,4*L*L,-6*L,2*L*L],[-12,-6*L,12,-6*L],[6*L,2*L*L,-6*L,4*L*L]],E*I/L**3)
    put([2,4,8,10],[[12,-6*L,-12,-6*L],[-6*L,4*L*L,6*L,2*L*L],[-12,6*L,12,6*L],[-6*L,2*L*L,6*L,4*L*L]],E*I/L**3)
    return K

def solve_frame(model,size):
    model={**model['cases'][str(size)]['frame_graph'],'cases':model['cases']}
    names=list(model['nodes']);idx={k:i for i,k in enumerate(names)};xyz=np.array([model['nodes'][n] for n in names]);N=6*len(names)
    K=np.zeros((N,N));F=np.zeros(N);external=np.zeros((len(names),6));elements=[];d=model['rod_diameter_mm'];A=math.pi*d*d/4;I=math.pi*d**4/64;J=2*I
    raw_volume=0.;raw_moment=np.zeros(3)
    for a,b in model['edges']:
        va,vb=np.array(model['nodes'][a]),np.array(model['nodes'][b]);v=np.linalg.norm(vb-va)*A;raw_volume+=v;raw_moment+=v*(va+vb)/2
    for n,r in model['radii_mm'].items():
        v=4/3*math.pi*r**3;raw_volume+=v;raw_moment+=v*np.array(model['nodes'][n])
    cad=model['cases'][str(size)];cad_volume=cad['resin_volume_ml']*1000;weight_scale=cad_volume/raw_volume;raw_cg=raw_moment/raw_volume
    for a,b in model['edges']:
        x,y=xyz[idx[a]],xyz[idx[b]];v=y-x;L=np.linalg.norm(v);ex=v/L;up=np.array([0,0,1]) if abs(ex[2])<.95 else np.array([1,0,0]);ey=np.cross(up,ex);ey/=np.linalg.norm(ey);ez=np.cross(ex,ey);R=np.stack([ex,ey,ez]);T=la.block_diag(R,R,R,R);k=local_k(L,d);ids=np.r_[np.arange(6*idx[a],6*idx[a]+6),np.arange(6*idx[b],6*idx[b]+6)]
        gravity=R@np.array([0.,0.,-RHO*weight_scale*A*GRAVITY]);gx,gy,gz=gravity
        f=np.array([gx*L/2,gy*L/2,gz*L/2,0,-gz*L*L/12,gy*L*L/12,gx*L/2,gy*L/2,gz*L/2,0,gz*L*L/12,-gy*L*L/12])
        K[np.ix_(ids,ids)]+=T.T@k@T;F[ids]+=T.T@f;elements.append((a,b,L,R,T,k,ids,f))
    # Ball and tooth weights are independent nodal loads. Frame self-weight
    # above is an Euler–Bernoulli consistent distributed line load.
    for n,i in idx.items():
        mass=4/3*math.pi*model['radii_mm'][n]**3*RHO*weight_scale
        external[i,2]-=mass*GRAVITY
    gravity_couple=np.cross(np.array(cad['resin_center_mm'])-raw_cg,[0,0,-cad_volume*RHO*GRAVITY])
    external[idx['P'],3:]+=gravity_couple
    props=json.loads((ROOT/f'dist/assets/fem-r5/{size}mm-properties.json').read_text());massg=props['solid_pla_mass_g']
    tooth_force=np.array([0.,0.,-massg/1000*GRAVITY*3])
    tooth_relative_cg=np.array(props['native_material_centroid_mm'],float)
    tooth_couple=np.cross(tooth_relative_cg,tooth_force)
    external[idx['P'],:3]+=tooth_force
    external[idx['P'],3:]+=tooth_couple
    F+=external.ravel();fixed=np.array([6*idx[n]+j for n in model['feet'] for j in range(3)]);free=np.setdiff1d(np.arange(N),fixed)
    U=np.zeros(N);U[free]=la.solve(K[np.ix_(free,free)],F[free],assume_a='pos');reaction=K@U-F
    residual=np.linalg.norm(reaction[free])/np.linalg.norm(F[free]);assert residual<1e-9
    node_loads={n:[] for n in names};members=[]
    for a,b,L,R,T,k,ids,f in elements:
        q=k@(T@U[ids])-f;qg=T.T@q
        for off,n,other in [(0,a,b),(6,b,a)]:
            direction=np.array(model['nodes'][other])-model['nodes'][n];direction/=np.linalg.norm(direction)
            node_loads[n].append({'direction':direction.tolist(),'wrench':(-qg[off:off+6]).tolist(),'source':other})
        stress=0
        for j in [0,6]:
            sigma=abs(q[j])/A+math.hypot(q[j+4],q[j+5])*d/2/I
            tau=4/3*math.hypot(q[j+1],q[j+2])/A+abs(q[j+3])*d/2/J
            stress=max(stress,math.sqrt(sigma*sigma+3*tau*tau))
        shear_ratio=12*E*I/(.9*G*A*L*L)
        members.append({'a':a,'b':b,'length_mm':float(L),'vm_envelope_MPa':stress,'local_end_resultants':q.tolist(),'shear_parameter_phi':shear_ratio,'L_over_d':L/d})
    for n,i in idx.items():
        ext=external[i].copy()
        if n in model['feet']:ext+=reaction[6*i:6*i+6]
        node_loads[n].append({'direction':[0,0,-1] if n in model['feet'] else [0,0,1],'wrench':ext.tolist(),'source':'floor' if n in model['feet'] else 'weight'})
        assert np.linalg.norm(np.sum([x['wrench'] for x in node_loads[n]],axis=0))<1e-8
    strain_energy=.5*float(U@K@U);work=float(U@F)
    energy_relative=abs(2*strain_energy-work)/max(abs(work),1e-30)
    symmetry=float(np.linalg.norm(K-K.T)/np.linalg.norm(K))
    assert energy_relative<1e-9 and symmetry<1e-13
    resultants=reaction.reshape(-1,6)+F.reshape(-1,6)
    moment_balance=np.sum(np.cross(xyz,resultants[:,:3])+resultants[:,3:],axis=0)
    force_balance=np.sum(resultants[:,:3],axis=0)
    assert np.linalg.norm(force_balance)<1e-8 and np.linalg.norm(moment_balance)<1e-7
    assert not np.any(U[fixed])
    return {'strain_energy_N_mm':strain_energy,'external_work_N_mm':work,'energy_balance_relative_error':energy_relative,'stiffness_symmetry_relative_error':symmetry,'nodal_displacement_components':['ux_mm','uy_mm','uz_mm','rx_rad','ry_rad','rz_rad'],'fixed_foot_translations':model['feet'],'fixed_displacement_dofs':len(fixed),'fixed_translation_max_mm':float(abs(U[fixed]).max()),'foot_rotations':'free (pinned translations)','moment_balance_N_mm':moment_balance.tolist(),'size_mm':size,'element_type':'3D Euler–Bernoulli frame, 6 DOF/node','material':{'E_MPa':E,'nu':NU,'density_g_cm3':RHO*1e6},'self_weight':{'CAD_volume_mm3':cad_volume,'CAD_center_mm':cad['resin_center_mm'],'CAD_mass_g':cad_volume*RHO*1000,'idealized_line_ball_weight_scale':weight_scale,'centroid_correction_couple_at_P_N_mm':gravity_couple.tolist(),'total_force_N':cad_volume*RHO*GRAVITY,'method':'Distributed beam/node weights scaled to exact CAD mass; connector couple corrects total CAD gravitational moment. Local body-force distribution remains idealized.'},'tooth_load':{'force_N':tooth_force.tolist(),'native_centroid_relative_to_anchor_mm':tooth_relative_cg.tolist(),'eccentric_gravity_couple_at_P_N_mm':tooth_couple.tolist(),'native_properties_source_faces':props['triangles'],'source_properties_include_original_CT_void_boundaries':True},'tooth_mass_g':massg,'tooth_gravity_factor':3,'frame_nodes':len(names),'beam_elements':len(elements),'free_relative_residual':residual,'force_balance_N':np.sum(reaction.reshape(-1,6)[:,:3]+F.reshape(-1,6)[:,:3],axis=0).tolist(),'max_translation_mm':float(np.linalg.norm(U.reshape(-1,6)[:,:3],axis=1).max()),'nodal_displacements':{n:U[6*i:6*i+6].tolist() for n,i in idx.items()},'members':members,'node_loads':node_loads,'max_vm_envelope_MPa':max(x['vm_envelope_MPa'] for x in members),'assumptions':['Linear isotropic resin with assumed effective E.','Beam–ball interfaces are rigid in the global frame; local 3D submodels are one-way, not a coupled contact solution.','Nominal beam section envelopes exclude bevel, socket, screws, adhesion, creep and failure.','Short connector members violate slender-beam assumptions; phi is reported for every member.','Self-weight force and moment match full CAD, while their spatial reduction to a frame is approximate.']}

def shell_mesh(radius,variant,subdiv=3,layers=3):
    m=trimesh.creation.icosphere(subdivisions=subdiv,radius=1);v=np.array(m.vertices);faces=np.sort(m.faces,axis=1);nv=len(v)
    if variant=='solid':
        # Three concentric layers plus a central star; avoids zero-volume
        # coincident copies of the centre.
        rs=np.linspace(radius/4,radius,4);p=np.concatenate([v*r for r in rs]+[np.zeros((1,3))]);tt=[]
        center=len(p)-1
        for a,b,c in faces:tt.append([center,a,b,c])
    else:
        rs=np.linspace(radius-1.2,radius,layers+1);p=np.concatenate([v*r for r in rs]);tt=[]
    for k in range(len(rs)-1):
        for a,b,c in faces:
            aa,bb,cc=a+(k+1)*nv,b+(k+1)*nv,c+(k+1)*nv;a+=k*nv;b+=k*nv;c+=k*nv
            tt.extend([[a,b,c,cc],[a,b,bb,cc],[a,aa,bb,cc]])
    t=np.array(tt,np.int32);tet=p[t];D=np.transpose(tet[:,1:]-tet[:,:1],(0,2,1));det=np.linalg.det(D);neg=det<0;t[neg,:2]=t[neg,1::-1];tet=p[t];D=np.transpose(tet[:,1:]-tet[:,:1],(0,2,1));vol=np.linalg.det(D)/6;assert (vol>1e-12).all();grad=np.empty((len(t),4,3));grad[:,1:]=np.linalg.inv(D);grad[:,0]=-grad[:,1:].sum(1)
    nd=3*len(p);dofs=(3*t[:,:,None]+np.arange(3)).reshape(len(t),12);data=np.zeros((len(t),12,12))
    for a in range(4):
        for b in range(4):
            x,y=grad[:,a],grad[:,b];block=LAM*x[:,:,None]*y[:,None,:]+G*y[:,:,None]*x[:,None,:]+G*np.sum(x*y,axis=1)[:,None,None]*np.eye(3)
            data[:,3*a:3*a+3,3*b:3*b+3]=vol[:,None,None]*block
    K=coo_matrix((data.ravel(),(np.repeat(dofs,12,axis=1).ravel(),np.tile(dofs,(1,12)).ravel())),shape=(nd,nd)).tocsc()
    rigid=np.zeros((len(p),3,6));rigid[:,:,:3]=np.eye(3);rigid[:,0,4]=p[:,2];rigid[:,0,5]=-p[:,1];rigid[:,1,3]=-p[:,2];rigid[:,1,5]=p[:,0];rigid[:,2,3]=p[:,1];rigid[:,2,4]=-p[:,0]
    pin=la.qr(rigid.reshape(nd,6).T,pivoting=True)[2][:6];free=np.setdiff1d(np.arange(nd),pin);factor=splu(K[free][:,free]);outer=(len(rs)-1)*nv+np.arange(nv)
    # Mesh conformity: every face has multiplicity one or two.
    fs=np.sort(np.concatenate([t[:,[0,1,2]],t[:,[0,1,3]],t[:,[0,2,3]],t[:,[1,2,3]]]),axis=1);_,counts=np.unique(fs,axis=0,return_counts=True);assert counts.max()==2
    return p,t,grad,vol,K,free,factor,outer,v,m.faces

def ball_submodels(model,frames):
    results={};mesh_cache={};vertex_fields={}
    for size,frame in frames.items():
        case_model=model['cases'][str(size)]['frame_graph']
        out=[]
        for name,loads in frame['node_loads'].items():
            radius=case_model['radii_mm'][name]
            for variant in ['solid','wall']:
                key=(radius,variant)
                if key not in mesh_cache:mesh_cache[key]=shell_mesh(radius,variant)
                p,t,grad,vol,K,free,factor,outer,dirs,faces=mesh_cache[key];F=np.zeros((len(p),3));capdirs=[]
                for load in loads:
                    W=np.array(load['wrench']);d=np.array(load['direction']);angle=math.asin(min(.8,3.2/radius));ids=np.flatnonzero(dirs@d>math.cos(angle));ids=outer[ids]
                    if np.linalg.norm(W)<1e-13:continue
                    if len(ids)<6:raise ValueError('Finite patch too small')
                    B=np.zeros((6,3*len(ids)))
                    for j,i in enumerate(ids):
                        x,y,z=p[i];B[:3,3*j:3*j+3]=np.eye(3);B[3:,3*j:3*j+3]=[[0,-z,y],[z,0,-x],[-y,x,0]]
                    forces=B.T@la.solve(B@B.T,W,assume_a='pos');assert np.linalg.norm(B@forces-W)<1e-8
                    F[ids]+=forces.reshape(-1,3);capdirs.append((d,angle))
                flat=F.ravel();u=np.zeros_like(flat);u[free]=factor.solve(flat[free]);res=K@u-flat
                rel=np.linalg.norm(res[free])/max(np.linalg.norm(flat),1e-30);assert rel<1e-7
                uu=u.reshape(-1,3);gu=np.einsum('eai,eaj->eij',uu[t],grad);eps=(gu+gu.transpose(0,2,1))/2;sigma=2*G*eps+LAM*np.trace(eps,axis1=1,axis2=2)[:,None,None]*np.eye(3);dev=sigma-np.trace(sigma,axis1=1,axis2=2)[:,None,None]*np.eye(3)/3;vm=np.sqrt(1.5*np.sum(dev*dev,axis=(1,2)))
                val=np.zeros(len(p));weight=np.zeros(len(p))
                for a in range(4):np.add.at(val,t[:,a],vm*vol);np.add.at(weight,t[:,a],vol)
                val/=np.maximum(weight,1e-30);sv=val[outer]
                # Distance from the nearest loaded connection patch boundary.
                distance=np.full(len(dirs),np.inf)
                for direction,angle in capdirs:distance=np.minimum(distance,np.maximum(0,np.arccos(np.clip(dirs@direction,-1,1))-angle)*radius)
                bands=[]
                for lo,hi in zip([0,.6,1.2,2.4,4.8],[.6,1.2,2.4,4.8,30]):
                    values=sv[(distance>=lo)&(distance<hi)]
                    if len(values):bands.append({'distance_mm':[lo,hi],'vertices':len(values),'median_vm_MPa':float(np.median(values)),'q95_vm_MPa':float(np.quantile(values,.95))})
                out.append({'node':name,'variant':variant,'radius_mm':radius,'wall_mm':1.2 if variant=='wall' else None,'t_over_R':1.2/radius if variant=='wall' else None,'nodes':len(p),'tetrahedra':len(t),'max_element_vm_MPa':float(vm.max()),'surface_q95_vm_MPa':float(np.quantile(sv,.95)),'max_displacement_mm':float(np.linalg.norm(uu,axis=1).max()),'free_relative_residual':float(rel),'gauge_reaction_relative':float(np.linalg.norm(res)/max(np.linalg.norm(flat),1e-30)),'distance_bands':bands,'surface_vm_MPa':sv.round(8).tolist()})
            print('BALL',size,name,flush=True)
        results[size]=out
    unit=trimesh.creation.icosphere(subdivisions=3,radius=1)
    return {'method':'3D linear tetrahedral elasticity under balanced finite-area beam resultants; one-way spherical-node submodels','not_a_Chien_shell_implementation':True,'thin_shell_applicability':'The 1.2 mm research wall has t/R varying with each sized radius (reported per record); retain 3D elasticity. No thin-shell equivalence is claimed.','peak_convergence_verified':False,'manufacturing_geometry_scope':'Idealized full spherical nodes, including foot nodes. Flat ground clipping, local cap-withdrawal relief and detailed socket contact are not resolved by these one-way node submodels.','unit_vertices':unit.vertices.round(8).tolist(),'unit_faces':unit.faces.tolist(),'cases':results}

def checks():
    L,d,F=80.,4.,2.;k=local_k(L,d);ids=np.arange(6,12);u=la.solve(k[np.ix_(ids,ids)],[0,F,0,0,0,0]);exact=F*L**3/(3*E*(math.pi*d**4/64));assert abs(u[1]/exact-1)<1e-12
    return {'cantilever_F_L3_over_3EI_relative_error':float(abs(u[1]/exact-1))}

if __name__=='__main__':
    model=json.loads((OUT/'support.json').read_text());frames={str(s):solve_frame(model,s) for s in [50,100]};print('FRAME_SOLVED',[(k,v['max_translation_mm'],v['max_vm_envelope_MPa']) for k,v in frames.items()],flush=True);balls=ball_submodels(model,frames)
    for f in frames.values():f.pop('node_loads')
    (OUT/'frame-fem.json').write_text(json.dumps({'revision':'R8','unit_system':'N,mm,MPa','validation':checks(),'cases':frames},indent=2)+'\n');(OUT/'ball-fem.json').write_text(json.dumps(balls,separators=(',',':'))+'\n')
