"""Supplementary shear-sensitive frame comparison, not a safety certification."""
from pathlib import Path
import argparse,json,math
import numpy as np
import scipy.linalg as la
import frame_fem_r12 as fem
HERE=Path(__file__).resolve().parent;fem.ROOT=HERE
KAPPA=.9

def local_timoshenko(L,d):
 A=math.pi*d*d/4;I=math.pi*d**4/64;J=2*I;phi=12*fem.E*I/(KAPPA*fem.G*A*L*L);K=np.zeros((12,12))
 def put(ids,m,c):K[np.ix_(ids,ids)]+=np.array(m)*c
 put([0,6],[[1,-1],[-1,1]],fem.E*A/L);put([3,9],[[1,-1],[-1,1]],fem.G*J/L)
 put([1,5,7,11],[[12,6*L,-12,6*L],[6*L,(4+phi)*L*L,-6*L,(2-phi)*L*L],[-12,-6*L,12,-6*L],[6*L,(2-phi)*L*L,-6*L,(4+phi)*L*L]],fem.E*I/(L**3*(1+phi)))
 put([2,4,8,10],[[12,-6*L,-12,-6*L],[-6*L,(4+phi)*L*L,6*L,(2-phi)*L*L],[-12,6*L,12,6*L],[-6*L,(2-phi)*L*L,6*L,(4+phi)*L*L]],fem.E*I/(L**3*(1+phi)))
 return K

def run(path):
 model=json.loads(Path(path).read_text());original=fem.local_k
 L=80.;d=4.;force=2.;I=math.pi*d**4/64;A=math.pi*d*d/4
 K=local_timoshenko(L,d);ids=np.arange(6,12);u=la.solve(K[np.ix_(ids,ids)],[0,force,0,0,0,0]);exact=force*L**3/(3*fem.E*I)+force*L/(KAPPA*fem.G*A);error=float(abs(u[1]/exact-1));assert error<1e-12
 euler={str(s):fem.solve_frame(model,s) for s in [50,100]}
 try:
  fem.local_k=local_timoshenko;timo={str(s):fem.solve_frame(model,s) for s in [50,100]}
 finally:fem.local_k=original
 cases={}
 for size in ['50','100']:
  e,t=euler[size],timo[size]
  cases[size]={'Euler_Bernoulli_max_translation_mm':e['max_translation_mm'],'Timoshenko_max_translation_mm':t['max_translation_mm'],'Timoshenko_to_Euler_max_translation_ratio':t['max_translation_mm']/e['max_translation_mm'],'Euler_Bernoulli_peak_nominal_section_vm_MPa':e['max_vm_envelope_MPa'],'Timoshenko_peak_nominal_section_vm_MPa':t['max_vm_envelope_MPa'],'minimum_centerline_L_over_d':min(m['L_over_d'] for m in e['members']),'maximum_shear_parameter_phi':max(m['shear_parameter_phi'] for m in e['members']),'members_below_L_over_d_10':int(sum(m['L_over_d']<10 for m in e['members'])),'total_members':len(e['members']),'Timoshenko_free_relative_residual':t['free_relative_residual'],'Timoshenko_force_balance_N':t['force_balance_N'],'Timoshenko_moment_balance_N_mm':t['moment_balance_N_mm']}
 report={'revision':'R12','purpose':'Sensitivity of requested Euler–Bernoulli idealization to beam transverse shear on the same source-correct frame.','primary_published_frame_model':'Euler–Bernoulli','secondary_model':'Linear 3D Timoshenko frame with circular-section shear factor0.9','circular_section_shear_factor':KAPPA,'cantilever_F_L3_over_3EI_plus_F_L_over_kGA_relative_error':error,'Timoshenko_load_vector':'The same consistent distributed uniform gravity forces and end moments as primary model.','cases':cases,'limitations':['All members are short enough that Euler–Bernoulli slenderness is limited; the shear comparison is a model sensitivity check.','Neither beam formulation resolves fused solid joint geometry, finite socket/contact/fastener loading, adhesion, creep or failure.','Short element centreline portions inside spheres remain part of the idealized beam model.','A one-way spherical submodel is not a fully coupled3D frame/socket solution.','No eigenbuckling or nonlinear fracture safety claim is made.']}
 (HERE/'mechanics-model-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(cases,indent=2))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--support',default=str(HERE/'support.json'));a=p.parse_args();run(a.support)
