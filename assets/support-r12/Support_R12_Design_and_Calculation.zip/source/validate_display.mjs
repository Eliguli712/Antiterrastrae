import fs from 'node:fs';
const base=new URL('./',import.meta.url);
const source=fs.readFileSync(new URL('frontend/assembly-viewer-r12.js',base),'utf8');
const helper=source.slice(source.indexOf('const jointSurfaceCache'),source.indexOf('function supportMeshes'));
const mod=await import('data:text/javascript;base64,'+Buffer.from(helper).toString('base64'));
const balls=JSON.parse(fs.readFileSync(new URL('assets/support-r12/ball-fem.json',base),'utf8')),surface=mod.refineJointSurface(balls);
if(surface!==mod.refineJointSurface(balls))throw Error('Topology not cached');
let maxNorm=0,fields=0;
for(const p of surface.vertices)maxNorm=Math.max(maxNorm,Math.abs(Math.hypot(...p)-1));
// Original exported unit directions are rounded to 8 decimals.
if(maxNorm>1e-8)throw Error('Non spherical joint display');
for(const cases of Object.values(balls.cases))for(const record of cases){
 const v=mod.refineJointValues(record.surface_vm_MPa,surface),original=Float32Array.from(record.surface_vm_MPa,x=>x*1e6);
 const lo=Math.min(...original),hi=Math.max(...original);
 for(let i=0;i<original.length;i++)if(v[i]!==original[i])throw Error('Source field changed');
 for(const x of v)if(x<lo||x>hi)throw Error('New stress extreme');
 fields++;
}
const report={cases:fields,source_unit_vertices:balls.unit_vertices.length,display_vertices:surface.vertices.length,source_faces:balls.unit_faces.length,display_faces:surface.faces.length,maximum_unit_direction_error:maxNorm,original_encoded_field_values_preserved:true,new_values_are_convex_interpolation:true,new_stress_extrema_created:false,display_refinement_is_not_additional_FEM_elements:true,topology_cached:true};
fs.writeFileSync(new URL('assets/support-r12/display-refinement-validation.json',base),JSON.stringify(report,null,2)+'\n');console.log(report);
