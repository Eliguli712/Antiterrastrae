#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
pdflatex -interaction=nonstopmode -halt-on-error poster.tex
pdflatex -interaction=nonstopmode -halt-on-error poster.tex
