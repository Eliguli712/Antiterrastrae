# Source to Sculpture - English

This is a genuine, self-contained LaTeX reproduction package for the supplied
four-page artwork by Eliguli Han. It includes the complete existing PDF as a
faithful layout/background asset. The original illustrated pages and their
wording are preserved; this package does not present their flattened artwork
or body text as newly authored, editable LaTeX.

The supplied purple Kakeya-set mark is already embedded at the centre of the
page-4 QR code. That existing QR is retained, with its four-module quiet zone,
finder patterns and high error correction. It leads to:

https://eliguli712.github.io/Antiterrastrae/design/megalodon/

The mark's coloured outline is irregular. The QR's functional module grid and
quiet zone remain intact for scanning. The badge supplied again in this task
is included as `supplied-kakeya-reference.jpeg`; it is a reference/provenance
asset, rather than an alternative drawing of the geometry.

## Compile

Requires pdfLaTeX and the standard `pdfpages`, `hyperref`, and `eso-pic` packages
(for example, a configured TeX Live or MiKTeX installation).

Unzip all files together and run either:

```sh
pdflatex -interaction=nonstopmode -halt-on-error poster.tex
pdflatex -interaction=nonstopmode -halt-on-error poster.tex
```

or `sh compile.sh` on macOS/Linux. The result is `poster.pdf`, with all four
original pages and the original clickable URI regions restored by LaTeX.
No Python program, network access, private font, or external image download is
required to compile the LaTeX package.

`poster-artwork.pdf` is the original branded PDF, retained byte-for-byte.
`poster.tex` is the compilable LaTeX wrapper. `validation.json` records actual
compilation and rendered-page scanning checks. `SHA256SUMS` authenticates the
source files included in this package.
