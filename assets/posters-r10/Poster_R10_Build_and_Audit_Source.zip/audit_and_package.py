"""Scan final poster PDFs, compare source artwork, and package compiled LaTeX."""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import shutil
import sys
import zipfile
from pathlib import Path

import fitz
import numpy as np
from PIL import Image

try:
    import zxingcpp
except ImportError:
    sys.path.insert(0, str(Path(__file__).resolve().parent / "deps"))
    import zxingcpp

CANONICAL = "https://eliguli712.github.io/Antiterrastrae/design/megalodon/"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def render(page: fitz.Page, dpi: int) -> Image.Image:
    pix = page.get_pixmap(matrix=fitz.Matrix(dpi / 72, dpi / 72), alpha=False)
    return Image.frombytes("RGB", (pix.width, pix.height), pix.samples)


def original_art_hashes(doc: fitz.Document) -> list[str]:
    hashes = []
    for page in doc:
        artworks = [im for im in page.get_images(full=True) if im[2:4] == (2550, 3300)]
        assert len(artworks) == 1, artworks
        hashes.append(hashlib.sha256(doc.extract_image(artworks[0][0])["image"]).hexdigest())
    return hashes


def badge_pixel_hash(doc: fitz.Document) -> str:
    candidates = [im for im in doc[3].get_images(full=True) if im[2:4] == (413, 384)]
    assert len(candidates) == 1, candidates
    image = Image.open(io.BytesIO(doc.extract_image(candidates[0][0])["image"])).convert("RGB")
    return hashlib.sha256(image.tobytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original-root", required=True, type=Path)
    parser.add_argument("--output-root", required=True, type=Path)
    parser.add_argument("--source-root", required=True, type=Path)
    parser.add_argument("--badge", required=True, type=Path)
    args = parser.parse_args()
    previews = args.source_root / "previews"
    previews.mkdir(exist_ok=True)
    motif = Image.open(args.original_root / "kakeya-mark.png").convert("RGB")
    supplied = Image.open(args.badge).convert("RGB")
    assert motif.size == supplied.size == (413, 384)
    difference = np.asarray(motif).astype(float) - np.asarray(supplied).astype(float)
    motif_record = {
        "existing_embedded_mark_png_sha256": sha(args.original_root / "kakeya-mark.png"),
        "newly_supplied_reference_jpeg_sha256": sha(args.badge),
        "dimensions_px": [413, 384],
        "reference_jpeg_vs_existing_png_rgb_rmse": float(np.sqrt(np.mean(difference ** 2))),
        "existing_same_kakeya_motif_retained_without_redrawing": True,
        "original_png_rgb_pixel_sha256": hashlib.sha256(motif.tobytes()).hexdigest(),
    }
    records = {}
    downloads = []
    for lang in ("en", "de", "it"):
        destination = args.output_root / lang
        package = args.source_root / "packages" / lang
        source_path = args.original_root / lang / "source.pdf"
        original = fitz.open(source_path)
        download = fitz.open(destination / "source.pdf")
        compiled = fitz.open(package / "poster.pdf")
        assert len(original) == len(download) == len(compiled) == 4
        assert sha(source_path) == sha(destination / "source.pdf")
        assert original_art_hashes(compiled) == original_art_hashes(original)
        assert badge_pixel_hash(compiled) == badge_pixel_hash(original) == motif_record["original_png_rgb_pixel_sha256"]
        pixels = []
        for i in range(4):
            before = np.asarray(render(original[i], 150))
            after = np.asarray(render(compiled[i], 150))
            assert before.shape == after.shape
            diff = np.abs(before.astype(np.int16) - after.astype(np.int16))
            pixels.append({
                "page": i + 1,
                "render_dpi": 150,
                "changed_pixels": int(np.any(diff, axis=2).sum()),
                "mean_absolute_channel_difference": float(diff.mean()),
                "maximum_channel_difference": int(diff.max()),
            })
            # PDF import may introduce sub-pixel rounding, but must not alter layout.
            assert float(diff.mean()) < 0.25, pixels[-1]
        scans = []
        for document_name, document in (("download_pdf", download), ("latex_compiled_pdf", compiled)):
            for dpi in (110, 150, 200, 300):
                values = [x.text for x in zxingcpp.read_barcodes(render(document[3], dpi))]
                assert values == [CANONICAL], (lang, document_name, dpi, values)
                scans.append({"document": document_name, "page": 4,
                              "render_dpi": dpi, "decoded": values})
        render(compiled[3], 150).save(previews / f"{lang}-compiled-page-04.png")
        record = json.loads((package / "validation.json").read_text())
        record.update({
            "all_original_artwork_image_streams_preserved_in_compiled_pdf": True,
            "original_embedded_kakeya_mark_pixel_hash_preserved": True,
            "download_pdf_exactly_matches_original_branded_pdf": True,
            "existing_qr_did_not_require_regeneration": True,
            "qr_functional_grid_quiet_zone_and_finder_patterns_retained": True,
            "qr_target": CANONICAL,
            "scan_tests": scans,
            "latex_render_comparison": pixels,
            "mark_reference": motif_record,
        })
        (package / "validation.json").write_text(json.dumps(record, indent=2) + "\n")
        (destination / "validation.json").write_text(json.dumps(record, indent=2) + "\n")
        sums = "".join(
            f"{sha(package / name)}  {name}\n" for name in (
                "poster.tex", "poster-artwork.pdf", "README.md", "compile.sh",
                "supplied-kakeya-reference.jpeg", "validation.json"
            )
        )
        (package / "SHA256SUMS").write_text(sums)
        archive = destination / f"Source_to_Sculpture_{lang.upper()}_LaTeX.zip"
        with zipfile.ZipFile(archive, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for name in ("poster.tex", "poster-artwork.pdf", "README.md", "compile.sh",
                         "supplied-kakeya-reference.jpeg", "validation.json", "SHA256SUMS"):
                z.write(package / name, f"Source_to_Sculpture_{lang.upper()}_LaTeX/{name}")
        shutil.copyfile(package / "poster.tex", destination / "poster.tex")
        downloads.append({
            "language": lang,
            "pages": 4,
            "pdf": {"url": f"{lang}/source.pdf", "bytes": (destination / "source.pdf").stat().st_size,
                    "sha256": sha(destination / "source.pdf")},
            "latex": {"url": f"{lang}/{archive.name}", "bytes": archive.stat().st_size,
                      "sha256": sha(archive), "self_contained": True,
                      "compiled_successfully": True,
                      "method": "Original PDF as faithful artwork background; editable LaTeX wrapper and links."},
            "validation": f"{lang}/validation.json",
        })
        records[lang] = record
        original.close()
        download.close()
        compiled.close()
        print(lang, "source art and badge preserved; both PDFs decoded at four resolutions; LaTeX ZIP ready", flush=True)
    shutil.copyfile(args.original_root / "kakeya-mark.png", args.output_root / "kakeya-mark.png")
    shutil.copyfile(args.badge, args.output_root / "supplied-kakeya-reference.jpeg")
    (args.output_root / "validation.json").write_text(json.dumps({
        "revision": "R10", "target": CANONICAL,
        "poster_content_changes": "None: existing original art and branded QR are preserved.",
        "languages": records,
    }, indent=2) + "\n")
    (args.output_root / "poster-downloads.json").write_text(json.dumps({
        "revision": "R10", "canonical_gallery_url": CANONICAL,
        "latex_method": "Self-contained, compiled LaTeX wrapper with original poster PDF as faithful artwork background.",
        "languages": downloads,
    }, indent=2) + "\n")


if __name__ == "__main__":
    main()
