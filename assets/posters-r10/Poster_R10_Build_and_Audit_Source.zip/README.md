# R10 poster and LaTeX deliverables

The existing R8 EN/DE/IT four-page PDFs already contain the requested purple
Kakeya-set mark in their page-4 QR codes. They are retained byte-for-byte.
Their QR codes lead to the current clean gallery URL.

`build_latex_packages.py` creates a genuine `poster.tex` and self-contained
package for each edition. The original PDF is included as a faithful artwork
background. Original body text and illustrations are not presented as editable
LaTeX that was never supplied. Original clickable URI areas are restored by
the LaTeX wrapper. Standard pdfLaTeX, pdfpages, hyperref and eso-pic are needed.

`audit_and_package.py` scans both the download PDF and actual compiled LaTeX
PDF at 110, 150, 200 and 300 dpi, checks the original text and artwork image
streams, compares full-page rendering at 150 dpi, and builds the public ZIPs.

The compiled LaTeX reproductions have zero changed pixels on all twelve pages
at 150 dpi. All 24 final QR tests passed. The original embedded geometric mark
is retained exactly; the newly supplied JPEG is the same motif with minor JPEG
compression differences and is retained in each package for provenance.

The public asset root is `dist/assets/posters-r10`. Its `poster-downloads.json`
contains all per-language PDF/LaTeX paths, byte counts and SHA-256 hashes.
The public LaTeX ZIPs contain only seven necessary/documentation files each;
local dependency directories, format files, compile logs and intermediate
previews are not required for publication.

## Reproduce

```sh
python build_latex_packages.py \
  --original-root /path/to/posters-r8 \
  --output-root /path/to/posters-r10 \
  --source-root /path/to/reproduction-work \
  --badge /path/to/current-supplied-kakeya-reference.jpeg

python audit_and_package.py \
  --original-root /path/to/posters-r8 \
  --output-root /path/to/posters-r10 \
  --source-root /path/to/reproduction-work \
  --badge /path/to/current-supplied-kakeya-reference.jpeg
```

The source-root directory must exist before running the scripts. Python audit
dependencies are listed in `requirements.txt`. No Python dependency is required
to compile any of the finished, self-contained LaTeX ZIPs.
