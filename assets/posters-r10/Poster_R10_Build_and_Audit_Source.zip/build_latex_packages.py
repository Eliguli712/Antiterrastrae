"""Preserve the branded R8 posters and add genuine, self-contained LaTeX packages."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import zipfile
from pathlib import Path

import fitz

CANONICAL = "https://eliguli712.github.io/Antiterrastrae/design/megalodon/"
LANGUAGE_NAMES = {"en": "English", "de": "Deutsch", "it": "Italiano"}


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tex_link(link: dict, page_height: float) -> str:
    rect = fitz.Rect(link["from"])
    uri = link["uri"]
    assert "{" not in uri and "}" not in uri
    return (
        "  \\put(%.6f,%.6f){\\href{%s}{\\phantom{\\rule{%.6fbp}{%.6fbp}}}}%%\n"
        % (rect.x0, page_height - rect.y1, uri, rect.width, rect.height)
    )


def tex_source(source: Path, lang: str) -> str:
    doc = fitz.open(source)
    assert len(doc) == 4
    dimensions = [(float(page.rect.width), float(page.rect.height)) for page in doc]
    assert all(x == (612.0, 792.0) for x in dimensions)
    uri_links = [[link for link in page.get_links() if link.get("uri")] for page in doc]
    lines = [
        "% Faithful LaTeX reproduction of Eliguli Han's supplied poster artwork.\n",
        "% The complete original PDF is an included artwork asset.\n",
        "% This file does not pretend that flattened artwork/text is editable LaTeX.\n",
        "\\documentclass[letterpaper]{article}\n",
        "\\usepackage{pdfpages}\n",
        "\\usepackage[hidelinks]{hyperref}\n",
        "\\usepackage{eso-pic}\n",
        "\\hypersetup{pdfauthor={Eliguli Han},pdftitle={Source to Sculpture - %s}}\n" % LANGUAGE_NAMES[lang],
        "\\pagestyle{empty}\n",
        "\\paperwidth=612bp \\paperheight=792bp\n",
        "\\pdfpagewidth=612bp \\pdfpageheight=792bp\n",
        "% Quantize the near-zero PDF import offset to exactly zero.\n",
        "\\pdfdecimaldigits=2\n",
        "\\pdfinfoomitdate=1\n",
        "\\pdftrailerid{}\n",
        "\\pdfsuppressptexinfo=15\n",
        "\\pdflinkmargin=0pt\n",
        "\\begin{document}\n",
    ]
    for i, page in enumerate(doc):
        if uri_links[i]:
            lines += [
                "% Restore the original clickable URI regions on this page.\n",
                "\\AddToShipoutPictureFG*{\\AtPageLowerLeft{%%\n",
                "  \\setlength{\\unitlength}{1bp}%%\n",
                *[tex_link(link, page.rect.height) for link in uri_links[i]],
                "}}\n",
            ]
        lines.append(
            "\\includepdf[pages={%d},noautoscale=true,scale=1,pagecommand={}]{poster-artwork.pdf}\n"
            % (i + 1)
        )
    lines.append("\\end{document}\n")
    doc.close()
    return "".join(lines)


def readme(lang: str) -> str:
    return f"""# Source to Sculpture - {LANGUAGE_NAMES[lang]}

This is a genuine, self-contained LaTeX reproduction package for the supplied
four-page artwork by Eliguli Han. It includes the complete existing PDF as a
faithful layout/background asset. The original illustrated pages and their
wording are preserved; this package does not present their flattened artwork
or body text as newly authored, editable LaTeX.

The supplied purple Kakeya-set mark is already embedded at the centre of the
page-4 QR code. That existing QR is retained, with its four-module quiet zone,
finder patterns and high error correction. It leads to:

{CANONICAL}

The mark's coloured outline is irregular. The QR's functional module grid and
quiet zone remain intact for scanning. The badge supplied again in this task
is included as `supplied-kakeya-reference.jpeg`; it is a reference/provenance
asset, rather than an alternative drawing of the geometry.

## Compile

Requires pdfLaTeX and the standard `pdfpages`, `hyperref`, and `eso-pic` packages
(for example, a configured TeX Live or MiKTeX installation).

Unzip all files together and run either:

```sh
pdflatex -interaction=nonstopmode -halt-on-error poster.tex
pdflatex -interaction=nonstopmode -halt-on-error poster.tex
```

or `sh compile.sh` on macOS/Linux. The result is `poster.pdf`, with all four
original pages and the original clickable URI regions restored by LaTeX.
No Python program, network access, private font, or external image download is
required to compile the LaTeX package.

`poster-artwork.pdf` is the original branded PDF, retained byte-for-byte.
`poster.tex` is the compilable LaTeX wrapper. `validation.json` records actual
compilation and rendered-page scanning checks. `SHA256SUMS` authenticates the
source files included in this package.
"""


def build_one(original_root: Path, output_root: Path, source_root: Path,
              badge: Path, lang: str, env: dict) -> dict:
    origin = original_root / lang
    destination = output_root / lang
    package = source_root / "packages" / lang
    package.mkdir(parents=True, exist_ok=True)
    destination.mkdir(parents=True, exist_ok=True)
    source = origin / "source.pdf"
    shutil.copyfile(source, destination / "source.pdf")
    for pattern in ("page-*.jpg", "thumb-*.jpg", "qr-with-kakeya.png", "qr-validation.json"):
        for path in origin.glob(pattern):
            shutil.copyfile(path, destination / path.name)
    shutil.copyfile(source, package / "poster-artwork.pdf")
    shutil.copyfile(badge, package / "supplied-kakeya-reference.jpeg")
    (package / "poster.tex").write_text(tex_source(source, lang))
    (package / "README.md").write_text(readme(lang))
    (package / "compile.sh").write_text(
        "#!/bin/sh\nset -eu\ncd -- \"$(dirname -- \"$0\")\"\n"
        "pdflatex -interaction=nonstopmode -halt-on-error poster.tex\n"
        "pdflatex -interaction=nonstopmode -halt-on-error poster.tex\n"
    )
    os.chmod(package / "compile.sh", 0o755)
    logs = []
    for pass_number in (1, 2):
        result = subprocess.run(
            ["pdflatex", "-interaction=nonstopmode", "-halt-on-error", "poster.tex"],
            cwd=package, env=env, text=True, capture_output=True,
        )
        logs.append(f"PASS {pass_number}\n" + result.stdout + result.stderr)
        assert result.returncode == 0, f"LaTeX compilation failed for {lang}"
    (source_root / f"compile-{lang}.log").write_text("\n".join(logs))
    final = fitz.open(package / "poster.pdf")
    assert len(final) == 4
    original = fitz.open(source)
    assert [page.get_text() for page in final] == [page.get_text() for page in original]
    original_links = [sorted(x["uri"] for x in p.get_links() if x.get("uri")) for p in original]
    final_links = [sorted(x["uri"] for x in p.get_links() if x.get("uri")) for p in final]
    assert original_links == final_links, "Clickable poster links were not preserved"
    final.close()
    original.close()
    record = {
        "language": lang,
        "original_pdf_sha256": digest(source),
        "download_pdf_sha256": digest(destination / "source.pdf"),
        "download_pdf_is_unchanged_branded_original": True,
        "latex_compilation_exit_code": result.returncode,
        "compiled_pdf_sha256": digest(package / "poster.pdf"),
        "latex_source_sha256": digest(package / "poster.tex"),
        "all_original_text_preserved_in_compiled_pdf": True,
        "original_clickable_uri_links_restored": True,
        "pdf_pages": 4,
        "latex_method": "Complete original PDF included as faithful artwork; not an editable reconstruction of flattened original text or illustrations.",
    }
    (package / "validation.json").write_text(json.dumps(record, indent=2) + "\n")
    sums = "".join(
        f"{digest(package / name)}  {name}\n"
        for name in ("poster.tex", "poster-artwork.pdf", "README.md", "compile.sh",
                     "supplied-kakeya-reference.jpeg", "validation.json")
    )
    (package / "SHA256SUMS").write_text(sums)
    # The public ZIP is created after the separate render/QR validation pass.
    return record


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original-root", required=True, type=Path)
    parser.add_argument("--output-root", required=True, type=Path)
    parser.add_argument("--source-root", required=True, type=Path)
    parser.add_argument("--badge", required=True, type=Path)
    args = parser.parse_args()
    env = os.environ.copy()
    records = {}
    for lang in LANGUAGE_NAMES:
        records[lang] = build_one(args.original_root, args.output_root,
                                  args.source_root, args.badge, lang, env)
        print(lang, "LaTeX compiled; four original pages, text and links retained", flush=True)
    (args.source_root / "compile-validation.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
