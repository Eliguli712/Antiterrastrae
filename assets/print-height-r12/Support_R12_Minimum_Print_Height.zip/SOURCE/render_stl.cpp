#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
struct V{float x,y,z;};
struct P{float x,y,z;};
int main(int argc,char**argv){
 if(argc!=2)return 2;uint32_t W,H,parts;float scale,centerZ,yaw,pitch;
 std::cin.read((char*)&W,4);std::cin.read((char*)&H,4);std::cin.read((char*)&parts,4);
 for(float* p:{&scale,&centerZ,&yaw,&pitch})std::cin.read((char*)p,4);
 std::vector<uint8_t>image(W*H*4,0);std::vector<float>depth(W*H,-1e30f);
 float sy=std::sin(yaw),cy=std::cos(yaw),sp=std::sin(pitch),cp=std::cos(pitch);
 auto project=[&](V v){v.z-=centerZ;return P{W*.5f+(cy*v.x+sy*v.y)*scale,H*.5f-(-sy*sp*v.x+cy*sp*v.y+cp*v.z)*scale,sy*cp*v.x-cy*cp*v.y+sp*v.z};};
 uint64_t consumed=0;
 for(uint32_t k=0;k<parts;k++){
  uint32_t count;float colour[3];std::cin.read((char*)&count,4);std::cin.read((char*)colour,12);
  for(uint32_t i=0;i<count;i++){
   float t[12];std::cin.read((char*)t,48);if(!std::cin)return 3;consumed++;
   P a=project({t[0],t[1],t[2]}),b=project({t[3],t[4],t[5]}),c=project({t[6],t[7],t[8]});
   float area=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);if(std::abs(area)<1e-8f)continue;
   float nx=t[9],ny=t[10],nz=t[11],len=std::sqrt(nx*nx+ny*ny+nz*nz);float shade=.40f;
   if(len>1e-15f)shade+=.60f*std::max(0.f,(-.35f*nx-.55f*ny+.76f*nz)/len);
   uint8_t rgb[3];for(int ch=0;ch<3;ch++)rgb[ch]=(uint8_t)std::clamp(colour[ch]*shade,0.f,255.f);
   int x0=std::max(0,(int)std::floor(std::min({a.x,b.x,c.x}))),x1=std::min((int)W-1,(int)std::ceil(std::max({a.x,b.x,c.x})));
   int y0=std::max(0,(int)std::floor(std::min({a.y,b.y,c.y}))),y1=std::min((int)H-1,(int)std::ceil(std::max({a.y,b.y,c.y})));
   for(int y=y0;y<=y1;y++)for(int x=x0;x<=x1;x++){
    float u=((b.x-x-.5f)*(c.y-y-.5f)-(b.y-y-.5f)*(c.x-x-.5f))/area;
    float v=((c.x-x-.5f)*(a.y-y-.5f)-(c.y-y-.5f)*(a.x-x-.5f))/area,w=1-u-v;
    if(u<0||v<0||w<0)continue;float z=u*a.z+v*b.z+w*c.z;int at=y*W+x;
    if(z<=depth[at])continue;depth[at]=z;for(int ch=0;ch<3;ch++)image[4*at+ch]=rgb[ch];image[4*at+3]=255;
   }
  }
 }
 std::ofstream out(argv[1],std::ios::binary);out.write((char*)image.data(),image.size());
 std::cerr<<consumed<<" complete source triangles processed\n";return 0;
}
