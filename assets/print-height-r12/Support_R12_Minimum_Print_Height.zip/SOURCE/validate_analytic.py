from pathlib import Path
import json,itertools,importlib.util
import numpy as np
from scipy.spatial.transform import Rotation
from solve_print_height_r12 import solve_points
HERE=Path(__file__).resolve().parent;work=HERE/'validation-work';work.mkdir(exist_ok=True)
R=Rotation.from_euler('xyz',[.372,.714,-.291]).as_matrix()
box=np.array(list(itertools.product([-1.,1.],repeat=3)))
cases=[('rotated_cube',box@R.T,2.),('rotated_thin_box',(box*np.array([.5,3,5]))@R.T,1.),('regular_tetrahedron',np.array([[1,1,1],[-1,-1,1],[-1,1,-1],[1,-1,-1]],float)@R.T,2.),('regular_octahedron',np.r_[np.eye(3),-np.eye(3)]@R.T,2/np.sqrt(3))]
records=[]
for name,vertices,exact in cases:
 result=solve_points(vertices,name,work,1e-7);error=abs(result['width_mm']-exact)
 assert error<2e-8 and result['certificate']['gap_mm']<=1.01e-7
 records.append({'name':name,'analytical_minimum_width_mm':float(exact),'computed_width_mm':result['width_mm'],'absolute_error_mm':error,'certificate':result['certificate']})
(HERE/'analytic-validation.json').write_text(json.dumps({'passed':True,'maximum_absolute_error_mm':max(x['absolute_error_mm'] for x in records),'cases':records},indent=2)+'\n')
print('Analytic checks passed',max(x['absolute_error_mm'] for x in records))
