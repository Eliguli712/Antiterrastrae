"""Full-STL print orientation with independent full-sphere numerical bounds.

Seed optimization only proposes an upper bound; the C++ spherical branch and
bound supplies the global numerical gap. No face/edge-pair enumeration is used.
"""
from pathlib import Path
import argparse, csv, hashlib, json, math, os, struct, subprocess, time
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
import numpy as np
from scipy.optimize import minimize
from scipy.spatial import ConvexHull

SOURCE = Path(__file__).resolve().parent
DT = np.dtype([('normal', '<f4', (3,)), ('vertices', '<f4', (3, 3)), ('attribute', '<u2')])

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read_stl(path):
    raw = Path(path).read_bytes()
    count = struct.unpack_from('<I', raw, 80)[0]
    if len(raw) != 84 + count * 50:
        raise ValueError('Expected binary STL: ' + str(path))
    return np.frombuffer(raw, DT, count=count, offset=84).copy(), hashlib.sha256(raw).hexdigest()

def axes_from_angles(t):
    a, b = t
    return np.array([math.cos(a)*math.cos(b), math.sin(a)*math.cos(b), math.sin(b)])

def seed_axes(points):
    hull = ConvexHull(points)
    hp = points[np.sort(hull.vertices)]
    normals = hull.equations[:, :3].copy()
    normals /= np.linalg.norm(normals, axis=1)[:, None]
    normals = normals[np.unique(np.round(normals, 10), axis=0, return_index=True)[1]]
    j = np.arange(512)
    z = 1 - 2*(j+.5)/len(j)
    phi = j*2.39996322972865332
    seeds = np.r_[np.eye(3), -np.eye(3),
                  np.c_[np.sqrt(1-z*z)*np.cos(phi), np.sqrt(1-z*z)*np.sin(phi), z], normals]
    widths = np.empty(len(seeds))
    for start in range(0, len(seeds), 128):
        projected = hp @ seeds[start:start+128].T
        widths[start:start+128] = np.ptp(projected, axis=0)
    selected = []
    for k in np.argsort(widths):
        n = seeds[k]
        if all(abs(n @ old) < .9995 for old in selected):
            selected.append(n)
        if len(selected) >= 24:
            break
    optimized = []
    def objective(t): return np.ptp(hp @ axes_from_angles(t))
    for n in selected:
        angles = [math.atan2(n[1], n[0]), math.asin(np.clip(n[2], -1, 1))]
        result = minimize(objective, angles, method='Nelder-Mead',
                          options={'xatol': 1e-12, 'fatol': 1e-12, 'maxiter': 1500})
        optimized.append(axes_from_angles(result.x))
    seeds = np.r_[optimized, seeds]
    widths = np.array([np.ptp(hp @ n) for n in seeds])
    seeds = seeds[np.argsort(widths)]
    return hp, seeds, {'all_STL_unique_vertices': len(points), 'convex_hull_vertices': len(hp),
                       'triangulated_hull_faces': len(hull.simplices), 'seed_directions': len(seeds),
                       'local_search_starts': len(selected), 'source_coordinates_quantized': False}

def solve_points(points, stem, work, tolerance):
    start = time.perf_counter()
    hp, seeds, counts = seed_axes(points)
    path = work / (stem + '.bin')
    with path.open('wb') as stream:
        stream.write(struct.pack('<III', len(points), len(hp), len(seeds)))
        for value in [points, hp, seeds]:
            stream.write(np.asarray(value, dtype='<f8').tobytes())
    run = subprocess.run([str(SOURCE/'min_width_bb'), str(path), str(tolerance)],
                         text=True, capture_output=True, check=True)
    if run.stderr: print(run.stderr, end='', flush=True)
    result = json.loads(run.stdout)
    result['counts'] = counts
    result['computation_seconds'] = time.perf_counter()-start
    result['candidate_search_scope'] = 'Convex-hull face normals, a spherical seed lattice and local numerical minimization propose candidates. No edge-pair enumeration is used.'
    result['global_certificate_method'] = 'Independent spherical branch-and-bound covers all eight octants. Lower bounds are minima of actual source-vertex difference dot products over an enclosing spherical cap, plus a conservative box-diagonal Lipschitz bound. Upper bounds are checked over all source STL vertices.'
    result['certificate']['arithmetic'] = 'long double with explicit roundoff allowance; numerical certificate, not exact rational/interval proof'
    axis = np.asarray(result['axis'])
    result['all_STL_vertices_height_recheck_mm'] = float(np.ptp(points @ axis))
    result['hull_vertices_height_recheck_mm'] = float(np.ptp(hp @ axis))
    result['convex_hull_equivalence_recheck_error_mm'] = abs(result['all_STL_vertices_height_recheck_mm']-result['hull_vertices_height_recheck_mm'])
    assert result['certificate']['gap_mm'] <= tolerance+1e-8
    assert abs(result['all_STL_vertices_height_recheck_mm']-result['width_mm']) < 1e-8
    return result

def contacts(points, axis):
    projection = points.astype(np.longdouble) @ np.asarray(axis, dtype=np.longdouble)
    answer = []
    for name, value in [('lower', projection.min()), ('upper', projection.max())]:
        selected = points[np.abs(projection-value) <= 1e-7]
        singular = np.linalg.svd(selected-selected.mean(axis=0), full_matrices=False)[1]
        rank = int(np.count_nonzero(singular > 1e-6))
        answer.append({'side': name, 'projection_mm': float(value), 'vertices': len(selected),
                       'affine_dimension_at_tolerance': rank, 'near_contact_tolerance_mm': 1e-7,
                       'coordinates_mm': selected.tolist()})
    return answer

def place(data, axis, path):
    import trimesh
    triangles = data['vertices'].astype(float)
    points = np.unique(triangles.reshape(-1, 3), axis=0)
    n = np.asarray(axis, dtype=float); n /= np.linalg.norm(n)
    contact = contacts(points, n)
    if (contact[1]['affine_dimension_at_tolerance'], contact[1]['vertices']) > (contact[0]['affine_dimension_at_tolerance'], contact[0]['vertices']):
        n = -n; contact = contacts(points, n)
    reference = np.array([1., 0., 0.]) if abs(n[0]) < .9 else np.array([0., 1., 0.])
    ex = reference-(reference@n)*n; ex /= np.linalg.norm(ex)
    R = np.stack([ex, np.cross(n, ex), n])
    assert np.max(np.abs(R@R.T-np.eye(3))) < 1e-12 and np.linalg.det(R) > 0
    rotated = triangles @ R.T
    low=rotated.reshape(-1,3).min(axis=0);high=rotated.reshape(-1,3).max(axis=0)
    translation=-low
    # Centred XY coordinates retain more float32 precision than an arbitrary
    # positive-XY offset. Z remains exactly on the printing plane.
    translation[:2]=-(low[:2]+high[:2])/2
    placed=rotated+translation
    result=data.copy();result['vertices']=placed.astype('<f4')
    result['normal']=(data['normal'].astype(float) @ R.T).astype('<f4')
    rounded_before=result['vertices'].copy()
    vertices,inverse=np.unique(result['vertices'].reshape(-1,3),axis=0,return_inverse=True)
    mesh=trimesh.Trimesh(vertices,inverse.reshape(-1,3),process=False)
    zero_before=int(np.count_nonzero(mesh.area_faces==0));welded_vertices=0;actual_merge=0.;removed=[];digits=None
    keep=np.ones(len(data),bool)
    if not mesh.is_watertight or zero_before:
        digits=6;count=len(mesh.vertices)
        mesh.merge_vertices(digits_vertex=digits)
        welded_vertices=count-len(mesh.vertices)
        merged=mesh.vertices[mesh.faces]
        actual_merge=float(np.max(np.linalg.norm(merged-rounded_before.astype(float),axis=2)))
        assert actual_merge<=math.sqrt(3)*1e-6+1e-12
        keep=mesh.area_faces!=0
        removed=np.flatnonzero(~keep).tolist()
        result=result[keep].copy();result['vertices']=merged[keep].astype('<f4')
        # Only true zero-area float32 collapses are removed, in original order.
        v=result['vertices'].astype(float)
        normal=np.cross(v[:,1]-v[:,0],v[:,2]-v[:,0]);normal/=np.linalg.norm(normal,axis=1)[:,None]
        result['normal']=normal.astype('<f4')
    path.write_bytes(b'R12 rigid STL; mm; export-collapse cleanup audited; no tooth/auxiliaries'.ljust(80,b' ')+struct.pack('<I',len(result))+result.tobytes())
    reread,digest=read_stl(path);q=reread['vertices'].astype(float).reshape(-1,3)
    bounds=np.stack([q.min(axis=0),q.max(axis=0)])
    assert bounds[0,2]==0 and np.array_equal(reread['attribute'],data['attribute'][keep])
    vert,inv=np.unique(q,axis=0,return_inverse=True);actual=trimesh.Trimesh(vert,inv.reshape(-1,3),process=False)
    edges,counts=np.unique(actual.edges_sorted,axis=0,return_counts=True)
    components=trimesh.graph.connected_components(actual.face_adjacency,nodes=np.arange(len(actual.faces)))
    expected=2 if 'assembly' in path.name else 1
    topology={'watertight':bool(actual.is_watertight),'winding_consistent':bool(actual.is_winding_consistent),'zero_area_faces':int(np.count_nonzero(actual.area_faces==0)),'all_edges_have_two_incident_faces':bool(np.all(counts==2)),'components':len(components),'expected_components':expected}
    assert topology['watertight'] and topology['winding_consistent'] and topology['zero_area_faces']==0 and topology['all_edges_have_two_incident_faces'] and len(components)==expected, topology
    maximum_rounding=float(np.max(np.abs(rounded_before.astype(float)-placed)))
    original_volume=float(np.einsum('ij,ij->i',triangles[:,0],np.cross(triangles[:,1],triangles[:,2])).sum()/6)
    export_tri=reread['vertices'].astype(float)
    export_volume=float(np.einsum('ij,ij->i',export_tri[:,0],np.cross(export_tri[:,1],export_tri[:,2])).sum()/6)
    exact=np.array_equal(result['vertices'],rounded_before) and len(result)==len(data)
    return {'print_axis_in_source_coordinates':n.tolist(),'rotation_matrix_column_vector':R.tolist(),
            'placement_translation_mm':translation.tolist(),'transformation':'p_print = R @ p_source + t, followed only by audited float32 export-collapse cleanup when required',
            'z0_translation_mm':float(translation[2]),'print_bounds_mm':bounds.tolist(),
            'full_precision_oriented_extent_mm':np.ptp(placed.reshape(-1,3),axis=0).tolist(),
            'exported_STL_height_mm':float(bounds[1,2]),'STL_source_triangle_count':len(data),'STL_export_triangle_count':len(result),
            'STL_triangle_count_preserved':len(result)==len(data),'STL_original_face_order_preserved':len(result)==len(data),
            'relative_order_of_surviving_faces_preserved':True,'STL_original_attribute_words_preserved_for_surviving_faces':True,
            'export_removed_degenerate_count':len(removed),'export_removed_original_face_indices':removed,
            'export_welded_vertex_count':welded_vertices,'export_coincident_vertex_weld_decimal_places':digits,
            'maximum_actual_weld_displacement_mm':actual_merge,'maximum_possible_weld_displacement_mm':None if digits is None else math.sqrt(3)*1e-6,
            'holes_filled':False,'native_tooth_geometry_modified':False,'export_topology':topology,
            'maximum_float32_reencoding_coordinate_error_mm':maximum_rounding,
            'certificate_scope':'Full original valid manufacturing STL before binary export quantization/cleanup; actual exported Z extent is separately rechecked.',
            'source_signed_volume_mm3':original_volume,'export_signed_volume_mm3':export_volume,
            'signed_volume_relative_change':abs(export_volume-original_volume)/max(abs(original_volume),1.),
            'exported_file':path.name,'exported_SHA256':digest,'export_bytes':path.stat().st_size,
            'contact_features':contact,'polarity_tie_break':'Prefer larger affine-dimensional bottom contact, then more source vertices; not a stability certification.',
            'XY_twist_rule':'Projection of source X, or source Y near parallelism; XY translation centres the model for float32 precision, not XY packing optimization.'}

def aggregate(out):
    records = []
    for size in [50, 100]:
        for part in ['main', 'cap', 'assembly']:
            path = out / f'{size}mm-{part}-minimum-height.json'
            if path.exists(): records.append(json.loads(path.read_text()))
    report = {'revision': 'R12', 'units': 'mm', 'input_geometry_revision': 'R12',
              'objective': 'Minimum vertical extent over every rigid print-axis direction of each complete manufacturing STL surface.',
              'continuous_CAD_sphere_equivalence_claimed': False, 'mesh_decimation_performed': False,
              'generated_supports_and_rafts_included': False,
              'method': 'Seeded upper bound plus independent whole-sphere numerical branch-and-bound; no edge-pair enumeration.',
              'oriented_export_cleanup':'Exact-zero float32-collapse facets may be removed after coincident-vertex welding; every original valid source face is used in the height certificate. Export topology and surviving face order are explicitly audited.', 'completed_case_count': len(records), 'expected_case_count': 6,
              'all_six_cases_present': len(records) == 6, 'cases': records}
    (out/'minimum-print-height.json').write_text(json.dumps(report, indent=2)+'\n')
    with (out/'minimum-print-height.csv').open('w', newline='') as stream:
        fields = ['size_mm', 'part', 'full_original_triangles', 'original_Z_height_mm', 'width_mm',
                  'height_reduction_percent', 'certificate_lower_mm', 'certificate_upper_mm', 'certificate_gap_mm',
                  'axis_x', 'axis_y', 'axis_z', 'exported_STL_height_mm', 'exported_file']
        writer = csv.DictWriter(stream, fieldnames=fields); writer.writeheader()
        for result in records:
            row = {k: result[k] for k in fields if k in result}
            row.update(dict(zip(['axis_x', 'axis_y', 'axis_z'], result['print_axis_in_source_coordinates'])))
            row.update({'certificate_lower_mm': result['certificate']['lower_bound_mm'],
                        'certificate_upper_mm': result['certificate']['upper_bound_mm'],
                        'certificate_gap_mm': result['certificate']['gap_mm']})
            writer.writerow(row)

def main():
    p = argparse.ArgumentParser();p.add_argument('--input-map', type=Path, required=True)
    p.add_argument('--output-dir', type=Path, default=SOURCE/'assets/print-height-r12')
    p.add_argument('--tolerance-mm', type=float, default=1e-5)
    p.add_argument('--case', action='append', choices=[f'{size}-{part}' for size in [50, 100] for part in ['main', 'cap', 'assembly']])
    args = p.parse_args();out=args.output_dir;out.mkdir(parents=True, exist_ok=True)
    work=SOURCE/'work';work.mkdir(exist_ok=True)
    mapping=json.loads(args.input_map.read_text())
    cases=args.case or [f'{size}-{part}' for size in [50,100] for part in ['main','cap','assembly']]
    for key in cases:
        size, part=key.split('-');size=int(size);used=['main','cap'] if part=='assembly' else [part]
        parts=[(name, Path(mapping[str(size)][name])) for name in used]
        data=[];sources=[]
        for name,path in parts:
            item,digest=read_stl(path);data.append(item)
            sources.append({'file':path.name,'SHA256':digest,'triangles':len(item)})
        data=np.concatenate(data);points=np.unique(data['vertices'].astype(float).reshape(-1,3),axis=0)
        stem=f'{size}mm-{part}'
        print('SOLVE', stem, 'faces',len(data),'unique vertices',len(points),flush=True)
        result=solve_points(points,stem,work,args.tolerance_mm)
        result.update({'size_mm':size,'part':part,'original_Z_height_mm':float(np.ptp(points[:,2])),
                       'source_STLs':sources,'full_original_triangles':len(data),
                       'includes_tooth':False,'includes_generated_print_supports':False,'includes_raft':False,
                       'includes_hardware':False,'assembly_union_or_fusion_performed':False,
                       'object_scope':'Assembly envelope in assembled positions; two independent printable parts' if part=='assembly' else 'Complete manufacturing part'})
        result['height_reduction_percent']=100*(1-result['width_mm']/result['original_Z_height_mm'])
        result.update(place(data,result['axis'],out/f'Support_R12_{size}mm_{part}_Minimum_Height.stl'))
        result['export_float32_height_change_mm']=result['exported_STL_height_mm']-result['width_mm']
        (out/f'{stem}-minimum-height.json').write_text(json.dumps(result,indent=2)+'\n')
        aggregate(out)
        print('DONE',stem,'height',result['width_mm'],'gap',result['certificate']['gap_mm'],
              'cells',result['certificate']['sphere_cells_evaluated'],flush=True)

if __name__=='__main__': main()
