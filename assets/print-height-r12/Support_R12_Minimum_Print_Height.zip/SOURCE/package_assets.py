from pathlib import Path
import json,hashlib,zipfile,shutil
HERE=Path(__file__).resolve().parent;OUT=HERE.parent/'assets/print-height-r12'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 report=json.loads((OUT/'minimum-print-height.json').read_text())
 assert report['all_six_cases_present'] and len(report['cases'])==6
 for r in report['cases']:
  t=r['export_topology'];assert t['watertight'] and t['winding_consistent'] and t['zero_area_faces']==0 and t['all_edges_have_two_incident_faces'] and t['components']==t['expected_components']
  p=OUT/r['exported_file'];assert sha(p)==r['exported_SHA256']
  assert r['certificate']['gap_mm']<=1e-5+1e-10
 topology=[dict(size_mm=r['size_mm'],part=r['part'],exported_file=r['exported_file'],source_faces=r['full_original_triangles'],export_faces=r['STL_export_triangle_count'],removed_degenerate_faces=r['export_removed_degenerate_count'],welded_vertices=r['export_welded_vertex_count'],max_actual_weld_displacement_mm=r['maximum_actual_weld_displacement_mm'],height_difference_from_source_certificate_mm=r['export_float32_height_change_mm'],**r['export_topology']) for r in report['cases']]
 (OUT/'export-topology-validation.json').write_text(json.dumps({'all_six_exports_passed':True,'no_holes_filled':True,'cases':topology},indent=2)+'\n')
 shutil.copyfile(HERE/'README.md',OUT/'README.md');shutil.copyfile(HERE/'analytic-validation.json',OUT/'analytic-validation.json')
 source_names=['min_width_bb.cpp','solve_print_height_r12.py','validate_analytic.py','render_stl.cpp','render_figures_r12.py','recompute.py','package_assets.py','requirements.txt','README.md']
 archive=OUT/'Support_R12_Minimum_Print_Height.zip'
 records=[p for p in OUT.iterdir() if p.is_file() and p.suffix in ['.json','.csv','.png','.stl','.md'] and p.name!='asset-manifest.json' and (p.suffix!='.stl' or '_assembly_' in p.name)]
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(records):z.write(p,p.name)
  for name in source_names:z.write(HERE/name,'SOURCE/'+name)
 with zipfile.ZipFile(archive) as z:assert z.testzip() is None;entries=len(z.namelist())
 manifest={'revision':'R12','complete':True,'all_six_orientations_present':True,'archive_STL_scope':'Both combined main+cap assembly orientations. Individual main and cap oriented STLs are separate downloads; all six numerical records and source code are included.','maximum_original_surface_numeric_certificate_gap_mm':max(r['certificate']['gap_mm'] for r in report['cases']),'all_six_binary_exports_pass_strict_topology':True,'download_archive':{'file':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive),'entries':entries,'CRC_passed':True},'files':[{'file':p.name,'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='asset-manifest.json' and (p.suffix!='.stl' or '_assembly_' in p.name)]}
 (OUT/'asset-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(json.dumps({'zip_bytes':archive.stat().st_size,'zip_mib':archive.stat().st_size/1024**2,'sha256':sha(archive),'entries':entries,'under_95MiB':archive.stat().st_size<95*1024**2,'total_assets_bytes':sum(p.stat().st_size for p in OUT.iterdir() if p.is_file())}),flush=True)
if __name__=='__main__':main()
