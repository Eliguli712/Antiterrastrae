"""Exact-STL pose comparison; every supplied manufacturing face is submitted."""
from pathlib import Path
import json,struct,subprocess,math,hashlib,argparse
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from solve_print_height_r12 import read_stl
HERE=Path(__file__).resolve().parent;OUT=HERE.parent/'assets/print-height-r12';INPUT=HERE.parent/'assets/support-r12'
FONT=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf');SERIF=Path('/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf')
def font(n,serif=False):return ImageFont.truetype(str(SERIF if serif else FONT),n)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 global OUT,INPUT
 parser=argparse.ArgumentParser();parser.add_argument('--input-dir',type=Path,default=INPUT);parser.add_argument('--output-dir',type=Path,default=OUT);args=parser.parse_args();OUT=args.output_dir;INPUT=args.input_dir
 report=json.loads((OUT/'minimum-print-height.json').read_text());records=[]
 for size in [50,100]:
  rec=next(c for c in report['cases'] if c['size_mm']==size and c['part']=='assembly')
  source=[]
  for name in ['main','cap']:
   q,d=read_stl(INPUT/f'Support_R12_{size}mm_{name}.stl');source.append((name,q,d))
  R=np.array(rec['rotation_matrix_column_vector']);T=np.array(rec['placement_translation_mm']);yaw=.65;pitch=.35
  cy,sy,cp,sp=math.cos(yaw),math.sin(yaw),math.cos(pitch),math.sin(pitch)
  extent=[];posed=[]
  for panel in [0,1]:
   parts=[]
   for name,q,d in source:
    v=q['vertices'].astype(float);n=q['normal'].astype(float)
    if panel:v=v@R.T+T;n=n@R.T
    parts.append([name,v,n])
   allv=np.concatenate([p[1].reshape(-1,3) for p in parts]);center=(allv.min(0)+allv.max(0))/2;center[2]=0
   for p in parts:p[1]-=center
   xyz=allv-center;cz=float(np.ptp(xyz[:,2])/2)
   py=-sy*sp*xyz[:,0]+cy*sp*xyz[:,1]+cp*(xyz[:,2]-cz);px=cy*xyz[:,0]+sy*xyz[:,1]
   extent.append((float(np.ptp(px)),float(np.ptp(py))));posed.append((parts,cz))
  scale=min(850/max(x[0] for x in extent),760/max(x[1] for x in extent))
  image=Image.new('RGB',(2100,1200),'#081a21');draw=ImageDraw.Draw(image)
  draw.text((60,42),f'{size/10:g} cm support · complete manufacturing geometry',font=font(38,True),fill='#e8eeea')
  faces=sum(len(q) for _,q,_ in source)
  draw.text((60,102),f'{faces:,} triangles per pose · frame + front cap · tooth, hardware and print auxiliaries excluded',font=font(22),fill='#9eb9c1')
  for panel,(parts,cz) in enumerate(posed):
   xoff=35+panel*1050;yoff=210;W,H=980,820
   draw.text((xoff+25,157),'Original assembled pose' if not panel else 'Minimum-height pose',font=font(27),fill='#e1e9e4')
   raw=HERE/f'.render-{size}-{panel}.rgba'
   proc=subprocess.Popen([str(HERE/'render_stl'),str(raw)],stdin=subprocess.PIPE,stderr=subprocess.PIPE)
   proc.stdin.write(struct.pack('<IIIffff',W,H,len(parts),scale,cz,yaw,pitch))
   for name,v,n in parts:
    colour=[145.,202.,217.] if name=='main' else [192.,231.,211.]
    proc.stdin.write(struct.pack('<Ifff',len(v),*colour));proc.stdin.write(np.c_[v.reshape(len(v),9),n].astype('<f4').tobytes())
   proc.stdin.close();err=proc.stderr.read().decode();status=proc.wait();assert status==0,err
   def project(x,y,z):return(xoff+W*.5+(cy*x+sy*y)*scale,yoff+H*.5-(-sy*sp*x+cy*sp*y+cp*(z-cz))*scale)
   floor=Image.new('RGBA',(W,H),(0,0,0,0));fd=ImageDraw.Draw(floor)
   def local(q):return(q[0]-xoff,q[1]-yoff)
   for value in range(-80,81,20):
    fd.line([local(project(value,-80,0)),local(project(value,80,0))],fill='#1b343f',width=1)
    fd.line([local(project(-80,value,0)),local(project(80,value,0))],fill='#1b343f',width=1)
   image.paste(floor,(xoff,yoff),floor)
   layer=Image.frombytes('RGBA',(W,H),raw.read_bytes());raw.unlink();image.paste(layer,(xoff,yoff),layer)
   height=rec['original_Z_height_mm'] if not panel else rec['width_mm']
   title=f'{height:.3f} mm high'+(f' · {rec["height_reduction_percent"]:.2f}% lower' if panel else '')
   draw.text((xoff+25,1044),title,font=font(30,True),fill='#ddebe3')
  axis=rec['print_axis_in_source_coordinates']
  draw.text((60,1111),'Print axis in source coordinates: n = ('+', '.join(f'{x:.6f}' for x in axis)+')',font=font(22),fill='#afcfc6')
  draw.text((60,1152),'Numerical whole-sphere gap < 0.00001 mm · full STL geometry retained · individual parts remain separable',font=font(19),fill='#8caab4')
  dest=OUT/f'{size}mm-assembly-height-comparison.png';image.save(dest,optimize=True)
  records.append({'size_mm':size,'file':dest.name,'sha256':sha(dest),'bytes':dest.stat().st_size,'width':2100,'height':1200,'complete_original_STL_triangles_per_pose':faces,'mesh_decimation_performed':False,'convex_hull_solid_rendered':False,'render_method':'Every manufacturing STL triangle rasterized with face Lambert shading and a shared orthographic scale. Rendering is a geometry comparison, not physical resin shading.','source_STLs':[{'file':name,'sha256':d,'triangles':len(q)} for name,q,d in source],'original_pose_height_mm':rec['original_Z_height_mm'],'minimum_pose_height_mm':rec['width_mm'],'display_XY_centering_only':True})
  print('RENDERED',dest.name,'triangles',faces,'bytes',dest.stat().st_size,flush=True)
 (OUT/'figure-provenance.json').write_text(json.dumps(records,indent=2)+'\n')
if __name__=='__main__':main()
