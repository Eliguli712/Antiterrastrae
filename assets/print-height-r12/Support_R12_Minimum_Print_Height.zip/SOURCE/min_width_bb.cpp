// Full-sphere numerical minimum-width bounds. Source points are unmodified.
#include <algorithm>
#include <array>
#include <cfloat>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <queue>
#include <vector>
using LD=long double;
struct V{LD x,y,z;V operator+(V b)const{return{x+b.x,y+b.y,z+b.z};}V operator-(V b)const{return{x-b.x,y-b.y,z-b.z};}V operator*(LD s)const{return{x*s,y*s,z*s};}};
LD dot(V a,V b){return a.x*b.x+a.y*b.y+a.z*b.z;}LD norm(V a){return sqrtl(std::max(0.L,dot(a,a)));}V unit(V a){return a*(1/norm(a));}
V canonical(V a){if(a.z<0||(a.z==0&&a.y<0)||(a.z==0&&a.y==0&&a.x<0))return a*(-1);return a;}
struct Ext{LD width;V d;};
Ext extent(const std::vector<V>&p,V n){LD lo=1e400L,hi=-1e400L;V a{},b{};for(V q:p){LD s=dot(q,n);if(s<lo){lo=s;a=q;}if(s>hi){hi=s;b=q;}}return{hi-lo,b-a};}
LD cap_min_dot(V d,V center,LD cosr,LD sinr){LD r=norm(d);if(r==0)return 0;LD a=dot(d,center);if(-a>=r*cosr)return-r;LD perpendicular=sqrtl(std::max(0.L,r*r-a*a));return a*cosr-perpendicular*sinr;}
struct Cell{V a,b,c;LD lower;unsigned depth;};
struct Greater{bool operator()(const Cell&a,const Cell&b)const{return a.lower>b.lower;}};
int main(int argc,char**argv){
 if(argc!=3){std::cerr<<"usage: min_width_bb input.bin tolerance_mm\n";return 2;}
 std::ifstream in(argv[1],std::ios::binary);uint32_t na,nh,ns;in.read((char*)&na,4);in.read((char*)&nh,4);in.read((char*)&ns,4);
 auto read=[&](uint32_t count){std::vector<V>p; p.reserve(count);for(uint32_t i=0;i<count;i++){double q[3];in.read((char*)q,24);p.push_back({q[0],q[1],q[2]});}return p;};
 auto all=read(na),hull=read(nh),seeds=read(ns);if(!in||all.empty()||hull.empty()||seeds.empty())return 3;
 const LD tol=std::stold(argv[2]),roundoff=1e-9L;
 V minp=all[0],maxp=all[0];for(V p:all){minp.x=std::min(minp.x,p.x);minp.y=std::min(minp.y,p.y);minp.z=std::min(minp.z,p.z);maxp.x=std::max(maxp.x,p.x);maxp.y=std::max(maxp.y,p.y);maxp.z=std::max(maxp.z,p.z);}
 LD diameter=norm(maxp-minp)+roundoff;
 V bestaxis=unit(seeds[0]);LD best=extent(all,bestaxis).width,ub=best+roundoff;
 std::vector<V>witness;
 for(V n:seeds){n=unit(n);auto e=extent(hull,n);if(e.width+roundoff<ub){LD w=extent(all,n).width;if(w<best){best=w;bestaxis=n;ub=best+roundoff;}}}
 // These are actual source vertex differences. Every one individually yields
 // a valid lower bound; they do not presume a convex-hull algorithm is exact.
 for(int j=0;j<96;j++){LD z=1-2*(j+.5L)/96,phi=j*2.399963229728653322L;LD r=sqrtl(1-z*z);witness.push_back(extent(hull,{r*cosl(phi),r*sinl(phi),z}).d);}
 for(V n:seeds){if(witness.size()>160)break;witness.push_back(extent(hull,unit(n)).d);}
 uint64_t evaluated=0,popped=0,pruned=0,updates=0;unsigned maxdepth=0;size_t peak=0;LD minpruned=1e400L;
 auto make=[&](V a,V b,V c,unsigned depth){
  V center=unit(a+b+c);LD cosr=std::min({dot(center,a),dot(center,b),dot(center,c)});cosr=std::clamp(cosr-4e-18L,-1.L,1.L);LD sinr=sqrtl(std::max(0.L,1-cosr*cosr));
  auto e=extent(hull,center);if(e.width+roundoff<ub){LD w=extent(all,center).width;if(w<best){best=w;bestaxis=center;ub=best+roundoff;updates++;}}
  LD lower=e.width-diameter*sqrtl(std::max(0.L,2-2*cosr))-roundoff;
  lower=std::max(lower,cap_min_dot(e.d,center,cosr,sinr)-roundoff);
  for(V n:{a,b,c})lower=std::max(lower,cap_min_dot(extent(hull,n).d,center,cosr,sinr)-roundoff);
  for(V d:witness)lower=std::max(lower,cap_min_dot(d,center,cosr,sinr)-roundoff);
  lower=std::max(0.L,lower);evaluated++;maxdepth=std::max(maxdepth,depth);return Cell{a,b,c,lower,depth};
 };
 std::priority_queue<Cell,std::vector<Cell>,Greater>queue;
 for(int x:{-1,1})for(int y:{-1,1})for(int z:{-1,1})queue.push(make({(LD)x,0,0},{0,(LD)y,0},{0,0,(LD)z},0));
 auto push=[&](Cell c){if(c.lower>=ub-tol){minpruned=std::min(minpruned,c.lower);pruned++;}else queue.push(c);};
 while(!queue.empty()&&queue.top().lower<ub-tol){Cell c=queue.top();queue.pop();popped++;V ab=unit(c.a+c.b),bc=unit(c.b+c.c),ca=unit(c.c+c.a);push(make(c.a,ab,ca,c.depth+1));push(make(ab,c.b,bc,c.depth+1));push(make(ca,bc,c.c,c.depth+1));push(make(ab,bc,ca,c.depth+1));peak=std::max(peak,queue.size());if(popped%100000==0)std::cerr<<"BOUND "<<popped<<" cells "<<queue.size()<<" upper "<<(double)ub<<" gap "<<(double)(ub-std::min(minpruned,queue.empty()?ub:queue.top().lower))<<"\n";if(popped>10000000){std::cerr<<"Cell budget exhausted\n";return 4;}}
 LD lower=std::min(minpruned,queue.empty()?ub:queue.top().lower);lower=std::min(lower,ub);bestaxis=canonical(bestaxis);LD recomputed=extent(all,bestaxis).width;
 std::cout<<std::setprecision(18)<<"{\"axis\":["<<(double)bestaxis.x<<","<<(double)bestaxis.y<<","<<(double)bestaxis.z<<"],\"width_mm\":"<<(double)recomputed<<",\"certificate\":{\"lower_bound_mm\":"<<(double)lower<<",\"upper_bound_mm\":"<<(double)ub<<",\"gap_mm\":"<<(double)(ub-lower)<<",\"target_tolerance_mm\":"<<(double)tol<<",\"dot_roundoff_allowance_mm\":"<<(double)roundoff<<",\"diameter_upper_bound_mm\":"<<(double)diameter<<",\"sphere_cells_evaluated\":"<<evaluated<<",\"sphere_cells_subdivided\":"<<popped<<",\"sphere_cells_pruned\":"<<pruned<<",\"sphere_cells_remaining\":"<<queue.size()<<",\"max_depth\":"<<maxdepth<<",\"peak_heap_cells\":"<<peak<<",\"upper_bound_updates\":"<<updates<<",\"long_double_mantissa_bits\":"<<LDBL_MANT_DIG<<",\"covers_all_unit_directions\":true,\"exact_rational_interval_arithmetic\":false,\"spherical_cap_dot_bound\":true}}\n";
}
