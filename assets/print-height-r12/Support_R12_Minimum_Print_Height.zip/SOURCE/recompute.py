"""Compile and rerun all six full-STL printing directions."""
from pathlib import Path
import argparse,json,subprocess,sys
HERE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--support-dir',type=Path,required=True);p.add_argument('--output-dir',type=Path,default=HERE.parent/'recomputed');p.add_argument('--figures',action='store_true');args=p.parse_args()
source=args.support_dir.resolve();output=args.output_dir.resolve()
for size in [50,100]:
 for part in ['main','cap']:
  if not (source/f'Support_R12_{size}mm_{part}.stl').exists():raise SystemExit('Missing complete manufacturing STL')
subprocess.run(['g++','-O3','-std=c++17',str(HERE/'min_width_bb.cpp'),'-o',str(HERE/'min_width_bb')],check=True)
work=HERE/'work';work.mkdir(exist_ok=True)
mapping={str(s):{n:str(source/f'Support_R12_{s}mm_{n}.stl') for n in ['main','cap']} for s in [50,100]}
(work/'input-map.json').write_text(json.dumps(mapping,indent=2)+'\n')
subprocess.run([sys.executable,str(HERE/'solve_print_height_r12.py'),'--input-map',str(work/'input-map.json'),'--output-dir',str(output)],check=True)
if args.figures:
 subprocess.run(['g++','-O3','-std=c++17',str(HERE/'render_stl.cpp'),'-o',str(HERE/'render_stl')],check=True)
 subprocess.run([sys.executable,str(HERE/'render_figures_r12.py'),'--input-dir',str(source),'--output-dir',str(output)],check=True)
