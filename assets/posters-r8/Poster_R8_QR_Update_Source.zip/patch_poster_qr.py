"""Add the supplied, unchanged Kakeya mark to the original poster QR codes.

Only the QR square on page 4 is overpainted. Source artwork, PDF image streams,
text, page boxes and existing links are preserved. The QR overlay is vector;
the supplied geometric mark is embedded without redrawing or recolouring it.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import shutil
from pathlib import Path

import fitz
import numpy as np
import qrcode
import zxingcpp
from PIL import Image
from reportlab.lib.utils import ImageReader
from reportlab.pdfgen import canvas

CANONICAL_URL = "https://eliguli712.github.io/Antiterrastrae/design/megalodon/"
QR_RECT = fitz.Rect(408.24, 626.40, 482.40, 700.56)
LANGUAGES = ("en", "de", "it")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def make_overlay(badge: Path, width: float, height: float) -> tuple[bytes, dict]:
    qr = qrcode.QRCode(
        error_correction=qrcode.constants.ERROR_CORRECT_H,
        box_size=16,
        border=4,
    )
    qr.add_data(CANONICAL_URL)
    qr.make(fit=True)
    matrix = qr.get_matrix()
    count = len(matrix)
    x, y, side = QR_RECT.x0, height - QR_RECT.y1, QR_RECT.width
    module = side / count
    buffer = io.BytesIO()
    c = canvas.Canvas(buffer, pagesize=(width, height), pageCompression=1)
    c.setFillColorRGB(1, 1, 1)
    c.rect(x, y, side, side, stroke=0, fill=1)
    c.setFillColorRGB(0, 0, 0)
    path = c.beginPath()
    for row, cells in enumerate(matrix):
        for col, black in enumerate(cells):
            if black:
                path.rect(x + col * module, y + (count - row - 1) * module,
                          module, module)
    c.drawPath(path, stroke=0, fill=1)

    # 21.6% of the complete QR side (including its four-module quiet zone).
    # This compact patch never reaches any finder or timing pattern.
    patch_side = 16.0
    badge_width = 15.0
    with Image.open(badge) as original:
        badge_height = badge_width * original.height / original.width
    cx, cy = x + side / 2, y + side / 2
    c.setFillColorRGB(1, 1, 1)
    c.rect(cx - patch_side / 2, cy - patch_side / 2,
           patch_side, patch_side, stroke=0, fill=1)
    c.drawImage(ImageReader(str(badge)), cx - badge_width / 2,
                cy - badge_height / 2, width=badge_width, height=badge_height,
                preserveAspectRatio=True, mask="auto")
    c.showPage()
    c.save()
    return buffer.getvalue(), {
        "target": CANONICAL_URL,
        "error_correction": "H",
        "version": qr.version,
        "data_modules": qr.modules_count,
        "quiet_zone_modules": 4,
        "outer_rect_pdf_pt": list(QR_RECT),
        "centre_white_patch_side_pt": patch_side,
        "badge_width_pt": badge_width,
        "badge_height_pt": badge_height,
        "badge_is_original_unchanged_image": True,
    }


def page_image(page: fitz.Page, dpi: int) -> Image.Image:
    pix = page.get_pixmap(matrix=fitz.Matrix(dpi / 72, dpi / 72), alpha=False)
    return Image.frombytes("RGB", (pix.width, pix.height), pix.samples)


def decode(image: Image.Image) -> list[str]:
    return [barcode.text for barcode in zxingcpp.read_barcodes(image)]


def original_image_hashes(doc: fitz.Document) -> list[str]:
    records = []
    for page in doc:
        matches = [im for im in page.get_images(full=True)
                   if im[2:4] == (2550, 3300)]
        assert len(matches) == 1, "Original full-resolution artwork not found"
        records.append(hashlib.sha256(doc.extract_image(matches[0][0])["image"]).hexdigest())
    return records


def patch_one(source: Path, output: Path, badge: Path) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    doc = fitz.open(source)
    assert len(doc) == 4
    source_text = [p.get_text() for p in doc]
    source_art_hashes = original_image_hashes(doc)
    before_150 = page_image(doc[3], 150)
    before_array = np.array(before_150)
    overlay_bytes, qr_record = make_overlay(badge, doc[3].rect.width, doc[3].rect.height)
    overlay = fitz.open(stream=overlay_bytes, filetype="pdf")
    doc[3].show_pdf_page(doc[3].rect, overlay, 0, overlay=True)
    doc[3].insert_link({"kind": fitz.LINK_URI, "from": QR_RECT,
                        "uri": CANONICAL_URL})
    destination = output / "source.pdf"
    doc.save(destination, garbage=3, deflate=True)
    doc.close()
    result = fitz.open(destination)
    assert [p.get_text() for p in result] == source_text, "Poster wording changed"
    assert original_image_hashes(result) == source_art_hashes, "Original artwork image streams changed"

    after_array = np.array(page_image(result[3], 150))
    changed = np.any(before_array != after_array, axis=2)
    # Include one raster pixel around the only modified PDF rectangle.
    x0, y0 = int(QR_RECT.x0 * 150 / 72) - 1, int(QR_RECT.y0 * 150 / 72) - 1
    x1, y1 = int(np.ceil(QR_RECT.x1 * 150 / 72)) + 1, int(np.ceil(QR_RECT.y1 * 150 / 72)) + 1
    outside = changed.copy()
    outside[y0:y1, x0:x1] = False
    assert not outside.any(), "Pixels changed outside the original QR location"

    scan_tests = []
    for dpi in (110, 150, 200, 300):
        image = page_image(result[3], dpi)
        values = decode(image)
        assert values == [CANONICAL_URL], (source, dpi, values)
        scan_tests.append({"render_dpi": dpi, "decoded": values,
                           "complete_page_scan": True})
    for i, page in enumerate(result):
        image = page_image(page, 300)
        image.save(output / f"page-{i+1:02}.jpg", quality=96, subsampling=0,
                   dpi=(300, 300), optimize=True)
        thumb = image.copy()
        thumb.thumbnail((360, 466), Image.Resampling.LANCZOS)
        thumb.save(output / f"thumb-{i+1:02}.jpg", quality=94, subsampling=0,
                   optimize=True)
    qr_preview = page_image(result[3], 300)
    scale = 300 / 72
    qr_preview.crop(tuple(int(v * scale) for v in QR_RECT)).save(output / "qr-with-kakeya.png")
    result.close()
    record = {
        "source_pdf_sha256": sha(source),
        "output_pdf_sha256": sha(destination),
        "badge_sha256": sha(badge),
        "pages": 4,
        "modified_page": 4,
        "all_original_artwork_image_streams_unchanged": True,
        "all_original_wording_unchanged": True,
        "changed_pixels_outside_qr_rect_at_150dpi": int(outside.sum()),
        "qr": qr_record,
        "scan_tests": scan_tests,
        "preview_dimensions_px": [2550, 3300],
    }
    (output / "qr-validation.json").write_text(json.dumps(record, indent=2) + "\n")
    return record


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input-root", type=Path, required=True)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--badge", type=Path, required=True)
    args = parser.parse_args()
    args.output_root.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(args.badge, args.output_root / "kakeya-mark.png")
    records = {}
    for lang in LANGUAGES:
        records[lang] = patch_one(args.input_root / lang / "source.pdf",
                                  args.output_root / lang, args.badge)
        print(lang, "original artwork retained; clean QR decoded at 110/150/200/300 dpi", flush=True)
    (args.output_root / "validation.json").write_text(json.dumps({
        "revision": "R8", "target": CANONICAL_URL, "languages": records,
        "only_qr_area_modified": True,
    }, indent=2) + "\n")


if __name__ == "__main__":
    main()
