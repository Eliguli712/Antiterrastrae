# Source to Sculpture: QR update R8

The EN, DE and IT original four-page poster editions are preserved. Only the
existing QR square on page 4 is overpainted with a vector QR and the supplied,
unchanged purple Kakeya-set image. A clickable link covers the same QR square.
The original CV text and existing CV hyperlink remain unchanged.

The new QR target is:

https://eliguli712.github.io/Antiterrastrae/design/megalodon/

The QR uses error correction H, version 7, 45 data modules and a four-module
quiet zone. The original logo image is embedded at 15 pt width in a 16 pt white
centre patch. Its coloured contours retain their irregular fan outline.

## Reproduce

Install the dependencies listed in `requirements.txt`, then run:

```sh
python patch_poster_qr.py \
  --input-root /path/to/original/studio-r4/posters \
  --output-root /path/to/posters-r8 \
  --badge /path/to/kakeya-mark.png
```

The program checks all original 2550 x 3300-pixel artwork image streams and
all extracted text for exact preservation. It requires zero changed pixels
outside the QR region on the rendered final page, and decodes the actual
completed PDF page at 110, 150, 200 and 300 dpi using ZXing.

`source.pdf` is the edited original PDF, not a reconstruction from previews.
`page-01.jpg` through `page-04.jpg` are 300 dpi, 2550 x 3300-pixel website views.
`thumb-01.jpg` through `thumb-04.jpg` are 360-pixel-wide rail thumbnails.
`qr-validation.json` records the input/output checksums and scan results.
