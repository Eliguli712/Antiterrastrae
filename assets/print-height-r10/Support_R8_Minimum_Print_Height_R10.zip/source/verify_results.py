"""Check all original vertices, rigid placement, faces, volume and certificates."""
from pathlib import Path
import argparse,json
import numpy as np
from scipy.spatial import ConvexHull
from solve_print_height import stl

def volume(v):return float(np.sum(np.einsum('ij,ij->i',v[:,0],np.cross(v[:,1],v[:,2])))/6)
def main():
    p=argparse.ArgumentParser();p.add_argument('--input-dir',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);a=p.parse_args()
    report=json.loads((a.output_dir/'minimum-print-height.json').read_text());checks=[]
    for c in report['cases']:
        parts=['main','cap'] if c['part']=='assembly' else [c['part']]
        original=np.concatenate([stl(a.input_dir/f'Support_R8_{c["size_mm"]}mm_{part}.stl')[0] for part in parts])
        actual,_,digest=stl(a.output_dir/c['exported_file']);R=np.array(c['rotation_matrix_column_vector']);t=np.array(c['placement_translation_mm']);expected=original@R.T+t
        error=float(np.max(np.abs(actual-expected)));relative_volume=abs(volume(actual)-volume(original))/abs(volume(original))
        assert len(actual)==len(original)==c['full_original_triangles'] and actual[:,:,2].min()==0
        assert error<2e-5 and relative_volume<2e-6
        assert np.linalg.det(R)>0 and np.max(np.abs(R@R.T-np.eye(3)))<1e-12
        assert c['nonparallel_edge_candidates']+c['exactly_parallel_pairs']==c['edge_pairs_total']
        assert c['certificate']['gap_mm']<=c['certificate']['target_tolerance_mm']+1e-9
        points=np.unique(original.reshape(-1,3),axis=0);axis=np.array(c['axis']);h=ConvexHull(points)
        c['all_STL_vertices_height_recheck_mm']=float(np.ptp(points@axis))
        c['hull_vertices_height_recheck_mm']=float(np.ptp(points[h.vertices]@axis))
        c['convex_hull_equivalence_recheck_error_mm']=abs(c['all_STL_vertices_height_recheck_mm']-c['hull_vertices_height_recheck_mm'])
        c['long_double_full_STL_recheck_error_mm']=abs(c['all_STL_vertices_height_recheck_mm']-c['width_mm'])
        c['antipodal_pair_count_includes_coplanar_triangulation_diagonals']=True
        assert c['convex_hull_equivalence_recheck_error_mm']<1e-8
        checks.append({'size_mm':c['size_mm'],'part':c['part'],'triangles_preserved':len(actual),'z_min_exactly_zero':True,
            'maximum_float32_reencoding_coordinate_error_mm':error,'relative_signed_volume_change':relative_volume,
            'certificate_gap_mm':c['certificate']['gap_mm'],'convex_hull_width_recheck_error_mm':c['convex_hull_equivalence_recheck_error_mm'],'SHA256':digest})
        (a.output_dir/f'{c["size_mm"]}mm-{c["part"]}-minimum-height.json').write_text(json.dumps(c,indent=2)+'\n')
    report['verification_scope']='Numerical certificate relative to exact source-STL coordinates; not a physical manufacturing precision claim.'
    (a.output_dir/'minimum-print-height.json').write_text(json.dumps(report,indent=2)+'\n')
    fixture=json.loads((Path(__file__).parent/'analytic-validation.json').read_text())
    (a.output_dir/'verification.json').write_text(json.dumps({'all_checks_passed':True,'cases':checks,'analytic_fixtures':fixture},indent=2)+'\n')
    print('Verified all six complete oriented STL exports and whole-sphere certificates.')

if __name__=='__main__':main()
