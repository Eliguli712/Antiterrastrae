"""Full-STL minimum vertical extent with complete candidates and a sphere bound.

Usage: python solve_print_height.py --input-dir PATH --output-dir PATH
No decimation is performed. Exact duplicate vertex tuples may be deduplicated.
"""
from pathlib import Path
import argparse,csv,hashlib,json,math,struct,subprocess,time
import numpy as np
from scipy.spatial import ConvexHull

SOURCE=Path(__file__).resolve().parent
DT=np.dtype([('normal','<f4',(3,)),('vertices','<f4',(3,3)),('attribute','<u2')])

def stl(path):
    raw=path.read_bytes();count=struct.unpack_from('<I',raw,80)[0]
    if len(raw)!=84+50*count:raise ValueError('Expected complete binary STL: '+str(path))
    data=np.frombuffer(raw,DT,count=count,offset=84)
    return data['vertices'].astype('f8').copy(),data['normal'].astype('f8').copy(),hashlib.sha256(raw).hexdigest()

def normalized_integer(vector):
    if not any(vector):return np.zeros(3)
    v=np.array([np.longdouble(str(x)) for x in vector],dtype=np.longdouble)
    return np.asarray(v/np.sqrt(v@v),dtype='<f8')

def exact_cross(a,b):
    return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]

def prepare(points,path):
    hull=ConvexHull(points)
    selected=np.sort(hull.vertices);vertices=points[selected]
    inverse=np.full(len(points),-1,dtype=np.int64);inverse[selected]=np.arange(len(selected))
    faces=inverse[hull.simplices].astype('<u4')
    edges=np.unique(np.sort(np.concatenate([faces[:,[0,1]],faces[:,[1,2]],faces[:,[2,0]]]),axis=1),axis=0).astype('<u4')
    # Original STL coordinates are exact dyadic rationals. Common scaling
    # converts them to unbounded integers for robust near-parallel normals.
    ratios=[[float(x).as_integer_ratio() for x in p] for p in vertices]
    power=max(q.bit_length()-1 for p in ratios for _,q in p)
    integer=[[p<<(power-(q.bit_length()-1)) for p,q in row] for row in ratios]
    exact_edges=[[integer[b][k]-integer[a][k] for k in range(3)] for a,b in edges]
    face_normals=[]
    for a,b,c in faces:
        u=[integer[b][k]-integer[a][k] for k in range(3)]
        v=[integer[c][k]-integer[a][k] for k in range(3)]
        face_normals.append(normalized_integer(exact_cross(u,v)))
    vectors=np.asarray(vertices[edges[:,1]]-vertices[edges[:,0]],dtype=np.longdouble)
    lengths=np.sqrt(np.sum(vectors*vectors,axis=1));near=[]
    for i,a in enumerate(vectors):
        cross=np.cross(a,vectors[i+1:]);norm=np.sqrt(np.sum(cross*cross,axis=1))
        # Wider than the native program's 1e-10 threshold, so every native
        # near-parallel case has a corresponding exact integer cross product.
        ids=np.flatnonzero(norm<=2e-10*lengths[i]*lengths[i+1:])+i+1
        for j in ids:near.append((i,int(j),normalized_integer(exact_cross(exact_edges[i],exact_edges[j]))))
    with path.open('wb') as w:
        w.write(struct.pack('<IIIII',len(points),len(vertices),len(faces),len(edges),len(near)))
        for a in [points.astype('<f8'),vertices.astype('<f8'),faces,edges,np.asarray(face_normals,dtype='<f8')]:w.write(a.tobytes())
        for i,j,n in near:w.write(struct.pack('<II3d',i,j,*n))
    return hull,vertices,faces,edges,{'all_STL_unique_vertices':len(points),'convex_hull_vertices':len(vertices),
        'triangulated_hull_faces':len(faces),'triangulated_hull_edges_including_coplanar_diagonals':len(edges),
        'near_parallel_pairs_prepared_with_exact_integers':len(near),'STL_coordinate_quantization_applied':False}

def contacts(points,axis):
    projection=np.asarray(points,dtype=np.longdouble)@np.asarray(axis,dtype=np.longdouble)
    lo,hi=projection.min(),projection.max();tol=1e-7;output=[]
    for side,value in [('lower',lo),('upper',hi)]:
        ids=np.flatnonzero(np.abs(projection-value)<=tol);p=points[ids]
        _,singular,_=np.linalg.svd(p-p.mean(0),full_matrices=False)
        rank=int(np.sum(singular>1e-6))
        output.append({'side':side,'projection_mm':float(value),'near_contact_tolerance_mm':tol,
            'vertices':len(ids),'affine_dimension_at_tolerance':rank,
            'feature':'vertex' if rank==0 else 'edge' if rank==1 else 'face_or_coplanar_contacts',
            'coordinates_mm':p.tolist()})
    return output

def placement(triangles,normals,axis,path):
    n=np.asarray(axis,dtype='f8');n/=np.linalg.norm(n)
    contact=contacts(np.unique(triangles.reshape(-1,3),axis=0),n)
    # Among the two equal-height polarities, favour a higher-dimensional
    # lower contact. This is a deterministic tie-break, not stability analysis.
    if (contact[1]['affine_dimension_at_tolerance'],contact[1]['vertices'])>(contact[0]['affine_dimension_at_tolerance'],contact[0]['vertices']):n=-n;contact=contacts(np.unique(triangles.reshape(-1,3),axis=0),n)
    ref=np.array([1.,0.,0.]) if abs(n[0])<.9 else np.array([0.,1.,0.])
    ex=ref-(ref@n)*n;ex/=np.linalg.norm(ex);ey=np.cross(n,ex);R=np.stack([ex,ey,n])
    assert np.max(np.abs(R@R.T-np.eye(3)))<1e-12 and np.linalg.det(R)>0
    rotated=triangles@R.T;minimum=rotated.reshape(-1,3).min(0);translation=-minimum
    placed=rotated+translation
    data=np.empty(len(triangles),dtype=DT);data['vertices']=placed.astype('<f4');data['normal']=(normals@R.T).astype('<f4');data['attribute']=0
    header=b'R10 full STL; rigid orientation only; no tooth/support/raft; mm'.ljust(80,b' ')
    path.write_bytes(header+struct.pack('<I',len(data))+data.tobytes())
    reread,_,digest=stl(path);bounds=np.stack([reread.reshape(-1,3).min(0),reread.reshape(-1,3).max(0)])
    assert bounds[0,2]==0 and len(reread)==len(triangles)
    return {'print_axis_in_source_coordinates':n.tolist(),'rotation_matrix_column_vector':R.tolist(),
        'placement_translation_mm':translation.tolist(),'transformation':'p_print = R @ p_source + t',
        'z0_translation_mm':float(translation[2]),'print_bounds_mm':bounds.tolist(),
        'full_precision_oriented_extent_mm':(placed.reshape(-1,3).max(0)-placed.reshape(-1,3).min(0)).tolist(),
        'exported_STL_height_mm':float(bounds[1,2]-bounds[0,2]),
        'STL_triangle_count_preserved':len(triangles),'exported_file':path.name,'exported_SHA256':digest,
        'export_bytes':path.stat().st_size,'contact_features':contact,
        'polarity_tie_break':'Prefer larger affine-dimension bottom contact, then more contact vertices.',
        'XY_twist_rule':'Projection of source X, or source Y near parallelism; not XY packing optimization.'}

def solve(points,stem,tolerance,work):
    binary=work/(stem+'.bin');hull,hp,faces,edges,counts=prepare(points,binary)
    start=time.perf_counter();run=subprocess.run([str(SOURCE/'min_width'),str(binary),str(tolerance)],text=True,capture_output=True,check=True)
    if run.stderr:print(run.stderr,end='',flush=True)
    result=json.loads(run.stdout);result['counts']=counts;result['computation_seconds']=time.perf_counter()-start
    result['candidate_search_scope']='All hull face normals and every non-parallel pair of triangulated hull edges; no antipodal pruning.'
    result['global_certificate_method']='Independent spherical triangle branch-and-bound over all eight octants. Uses a subset of actual STL vertices for valid lower bounds and the complete STL vertex set for the upper bound.'
    result['certificate']['covers_all_unit_directions']=True
    result['certificate']['exact_rational_interval_arithmetic']=False
    assert result['certificate']['gap_mm']<=tolerance+1e-8
    axis=np.array(result['axis']);full=points@axis
    result['all_STL_vertices_height_recheck_mm']=float(np.ptp(full));result['hull_vertices_height_recheck_mm']=float(np.ptp(hp@axis));result['convex_hull_equivalence_recheck_error_mm']=abs(float(np.ptp(full))-float(np.ptp(hp@axis)));result['long_double_full_STL_recheck_error_mm']=abs(float(np.ptp(full))-result['width_mm'])
    result['antipodal_pair_count_includes_coplanar_triangulation_diagonals']=True
    assert result['convex_hull_equivalence_recheck_error_mm']<1e-8
    return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input-dir',type=Path,required=True);ap.add_argument('--output-dir',type=Path,required=True);ap.add_argument('--tolerance-mm',type=float,default=.00001);args=ap.parse_args()
    out=args.output_dir;out.mkdir(parents=True,exist_ok=True);work=SOURCE/'work';work.mkdir(exist_ok=True)
    records=[]
    for size in [50,100]:
        parts={}
        for part in ['main','cap']:
            path=args.input_dir/f'Support_R8_{size}mm_{part}.stl';tri,normal,digest=stl(path)
            parts[part]=(tri,normal,{'file':path.name,'SHA256':digest,'triangles':len(tri)})
        for part in ['main','cap','assembly']:
            used=['main','cap'] if part=='assembly' else [part]
            triangles=np.concatenate([parts[p][0] for p in used]);normals=np.concatenate([parts[p][1] for p in used])
            points=np.unique(triangles.reshape(-1,3),axis=0);stem=f'{size}mm-{part}'
            print('SOLVE',stem,'full faces',len(triangles),'unique vertices',len(points),flush=True)
            result=solve(points,stem,args.tolerance_mm,work)
            result.update({'size_mm':size,'part':part,'original_Z_height_mm':float(np.ptp(points[:,2])),
                'source_STLs':[parts[p][2] for p in used],'full_original_triangles':len(triangles),
                'includes_tooth':False,'includes_generated_print_supports':False,'includes_raft':False,
                'includes_hardware':False,'assembly_union_or_fusion_performed':False,
                'object_scope':'Assembly envelope in the original assembled positions; two independent parts' if part=='assembly' else 'Full original manufacturing part'})
            result['height_reduction_percent']=100*(1-result['width_mm']/result['original_Z_height_mm'])
            result.update(placement(triangles,normals,result['axis'],out/f'Support_R8_{size}mm_{part}_Minimum_Height.stl'))
            result['export_float32_height_change_mm']=result['exported_STL_height_mm']-result['width_mm']
            (out/f'{stem}-minimum-height.json').write_text(json.dumps(result,indent=2)+'\n');records.append(result)
            print('DONE',stem,'height',result['width_mm'],'bound gap',result['certificate']['gap_mm'],'cells',result['certificate']['sphere_cells_evaluated'],flush=True)
    report={'revision':'R10','units':'mm','input_geometry_revision':'R8',
        'objective':'Minimum vertical extent over every rigid print-axis orientation of each complete manufacturing STL surface.',
        'continuous_CAD_sphere_equivalence_claimed':False,'mesh_decimation_performed':False,
        'generated_supports_and_rafts_included':False,
        'reference':{'authors':'Michael E. Houle and Godfried Toussaint','title':'Computing the Width of a Set',
            'journal':'IEEE Transactions on Pattern Analysis and Machine Intelligence 10(5), 761–765, 1988',
            'DOI':'10.1109/34.6790','paper':'https://cgm.cs.mcgill.ca/~godfried/publications/width.pdf','theorem':'Theorem 3.1 / Corollary 3.1'},
        'cases':records}
    (out/'minimum-print-height.json').write_text(json.dumps(report,indent=2)+'\n')
    with (out/'minimum-print-height.csv').open('w',newline='') as file:
        fields=['size_mm','part','full_original_triangles','original_Z_height_mm','width_mm','height_reduction_percent','certificate_lower_mm','certificate_upper_mm','certificate_gap_mm','axis_x','axis_y','axis_z','exported_STL_height_mm','exported_file']
        writer=csv.DictWriter(file,fieldnames=fields);writer.writeheader()
        for r in records:
            row={k:r[k] for k in fields if k in r};row.update(dict(zip(['axis_x','axis_y','axis_z'],r['print_axis_in_source_coordinates'])));row.update({'certificate_lower_mm':r['certificate']['lower_bound_mm'],'certificate_upper_mm':r['certificate']['upper_bound_mm'],'certificate_gap_mm':r['certificate']['gap_mm']});writer.writerow(row)

if __name__=='__main__':main()
