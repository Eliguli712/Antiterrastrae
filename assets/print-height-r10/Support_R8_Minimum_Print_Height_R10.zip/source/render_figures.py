"""Scientific pose comparison from every original manufacturing STL triangle."""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from solve_print_height import stl

def surface(ax,triangles,normals,colour):
    normal=normals.copy();length=np.linalg.norm(normal,axis=1)
    valid=length>1e-12;normal[valid]/=length[valid,None]
    light=np.array([-.35,-.55,.76]);light/=np.linalg.norm(light)
    shade=.40+.60*np.maximum(0,normal@light)
    rgb=np.clip(np.array(colour)[None,:]*shade[:,None],0,1)
    collection=Poly3DCollection(triangles,facecolors=rgb,edgecolors='none',linewidths=0,
        antialiased=False,zsort='average')
    ax.add_collection3d(collection)

def main():
    p=argparse.ArgumentParser();p.add_argument('--input-dir',type=Path,required=True);p.add_argument('--output-dir',type=Path,required=True);args=p.parse_args()
    report=json.loads((args.output_dir/'minimum-print-height.json').read_text())
    fig_records=[]
    for size in [50,100]:
        record=next(c for c in report['cases'] if c['size_mm']==size and c['part']=='assembly')
        parts=[]
        for name in ['main','cap']:
            triangles,normals,_=stl(args.input_dir/f'Support_R8_{size}mm_{name}.stl');parts.append((triangles,normals))
        complete=np.concatenate([x[0] for x in parts]);old_bounds=np.stack([complete.reshape(-1,3).min(0),complete.reshape(-1,3).max(0)])
        R=np.array(record['rotation_matrix_column_vector']);t=np.array(record['placement_translation_mm'])
        rotated=complete@R.T+t;new_bounds=np.stack([rotated.reshape(-1,3).min(0),rotated.reshape(-1,3).max(0)])
        fig=plt.figure(figsize=(14,8),facecolor='#081a21')
        fig.suptitle(f'{size/10:g} cm support · complete manufacturing geometry',fontsize=22,color='#edf5ef',x=.045,y=.965,ha='left')
        fig.text(.045,.91,f'{len(complete):,} triangles in each view  ·  main frame + front cap  ·  tooth, print supports and raft excluded',color='#abc3c7',fontsize=11)
        titles=[f'Original assembled pose\n{record["original_Z_height_mm"]:.3f} mm high',
            f'Minimum-height pose\n{record["width_mm"]:.3f} mm high  ·  {record["height_reduction_percent"]:.2f}% lower']
        for panel in [0,1]:
            ax=fig.add_subplot(1,2,panel+1,projection='3d');ax.set_facecolor('#081a21')
            bounds=old_bounds if panel==0 else new_bounds;centre=(bounds[0,:2]+bounds[1,:2])/2
            shift=np.array([-centre[0],-centre[1],0.])
            for (triangles,normals),colour in zip(parts,[[.58,.80,.88],[.76,.91,.84]]):
                tv=triangles+shift if panel==0 else triangles@R.T+t+shift
                nv=normals if panel==0 else normals@R.T
                surface(ax,tv,nv,colour)
            floor=np.array([[[-74,-74,0],[74,-74,0],[74,74,0],[-74,74,0]]])
            ax.add_collection3d(Poly3DCollection(floor,facecolors=[(.5,.7,.75,.055)],edgecolors='#36505a',linewidths=.6))
            height=record['original_Z_height_mm'] if panel==0 else record['width_mm']
            x,y=67.,67.
            ax.plot([x,x],[y,y],[0,height],color='#e1e9dd',linewidth=1.4)
            for z in [0,height]:ax.plot([x-3,x+3],[y,y],[z,z],color='#e1e9dd',linewidth=1.4)
            ax.text(x+3,y,height*.5,f'{height:.3f}\nmm',color='#edf5ef',fontsize=11)
            # Source-frame n on the original view; vertical print Z after R.
            direction=np.array(record['print_axis_in_source_coordinates']) if panel==0 else np.array([0.,0.,1.])
            origin=np.array([-61.,-54.,15.])
            ax.quiver(*origin,*direction,length=34,normalize=True,color='#b5e4c7',linewidth=2.1,arrow_length_ratio=.15)
            ax.text(*(origin+direction*38),'n' if panel==0 else 'print Z',color='#c5efd3',fontsize=12,
                ha='left' if panel==0 else 'right',zorder=100)
            fig.text(.265 if panel==0 else .755,.855,titles[panel],ha='center',va='top',color='#e3eeea',fontsize=15)
            ax.set_xlim(-78,78);ax.set_ylim(-78,78);ax.set_zlim(0,140)
            ax.set_box_aspect((1,1,.90));ax.view_init(elev=20,azim=-57);ax.set_axis_off()
        axis=record['print_axis_in_source_coordinates']
        fig.text(.045,.070,'Axis in source coordinates: n = ('+', '.join(f'{x:.6f}' for x in axis)+')',color='#d1e3df',fontsize=12)
        fig.text(.045,.032,'Full sphere bound gap < 0.00001 mm for the supplied STL  ·  XY centring is for display only; downloadable STL is placed at z = 0',color='#91acb5',fontsize=10)
        fig.subplots_adjust(left=.015,right=.985,top=.86,bottom=.105,wspace=.02)
        name=f'{size}mm-assembly-height-comparison.png';path=args.output_dir/name
        fig.savefig(path,dpi=150,facecolor=fig.get_facecolor());plt.close(fig)
        fig_records.append({'size_mm':size,'file':name,'all_original_STL_triangles_per_pose':len(complete),
            'convex_hull_solid_rendered':False,'mesh_decimation_performed':False,
            'normal_shading':'Per-original-STL-face Lambert-style mathematical shading; not a physical resin rendering.',
            'original_pose_height_mm':record['original_Z_height_mm'],'oriented_pose_height_mm':record['width_mm'],
            'XY_display_centring_only':True})
        print('RENDERED',name,path.stat().st_size,'bytes',flush=True)
    (args.output_dir/'figure-provenance.json').write_text(json.dumps(fig_records,indent=2)+'\n')

if __name__=='__main__':main()
