// Full finite minimum-width candidates + independent whole-sphere lower bounds.
// No STL decimation or coordinate quantization is used.
#include <algorithm>
#include <array>
#include <cfloat>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <queue>
#include <string>
#include <vector>
#include <unordered_map>
struct V { long double x,y,z; V operator+(V b)const{return{x+b.x,y+b.y,z+b.z};} V operator-(V b)const{return{x-b.x,y-b.y,z-b.z};} V operator*(long double t)const{return{x*t,y*t,z*t};} };
long double dot(V a,V b){return a.x*b.x+a.y*b.y+a.z*b.z;}
V cross(V a,V b){return{a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x};}
long double length(V a){return std::sqrt(dot(a,a));}
V unit(V a){return a*(1/length(a));}
V canonical(V a){if(a.z<0||(a.z==0&&a.y<0)||(a.z==0&&a.y==0&&a.x<0))return a*(-1);return a;}
struct Edge {uint32_t a,b;V d;};
std::vector<V> hull,all;
double widthFast(V axis,double*loout=nullptr,double*hiout=nullptr){double x=(double)axis.x,y=(double)axis.y,z=(double)axis.z,lo=1e300,hi=-1e300;for(V p:hull){double q=(double)p.x*x+(double)p.y*y+(double)p.z*z;lo=std::min(lo,q);hi=std::max(hi,q);}if(loout)*loout=lo;if(hiout)*hiout=hi;return hi-lo;}
long double widthLD(const std::vector<V>&points,V axis,long double*loout=nullptr,long double*hiout=nullptr){long double lo=1e400L,hi=-1e400L;for(V p:points){long double q=dot(p,axis);lo=std::min(lo,q);hi=std::max(hi,q);}if(loout)*loout=lo;if(hiout)*hiout=hi;return hi-lo;}
struct Cell {V a,b,c;long double lower;unsigned depth;};
struct Greater {bool operator()(const Cell&a,const Cell&b)const{return a.lower>b.lower;}};
int main(int argc,char**argv){if(argc!=3){std::cerr<<"usage: min_width input.bin tolerance_mm\n";return 2;}
 std::ifstream input(argv[1],std::ios::binary);uint32_t na,nh,nf,ne,nn;input.read((char*)&na,4);input.read((char*)&nh,4);input.read((char*)&nf,4);input.read((char*)&ne,4);input.read((char*)&nn,4);
 auto readPoints=[&](uint32_t n){std::vector<V>points;points.reserve(n);for(uint32_t i=0;i<n;i++){double p[3];input.read((char*)p,24);points.push_back({p[0],p[1],p[2]});}return points;};
 all=readPoints(na);hull=readPoints(nh);std::vector<std::array<uint32_t,3>>faces(nf);std::vector<std::array<uint32_t,2>>edgeIds(ne);input.read((char*)faces.data(),12ull*nf);input.read((char*)edgeIds.data(),8ull*ne);std::vector<V>faceNormals=readPoints(nf);std::unordered_map<uint64_t,V>exactNear;for(uint32_t k=0;k<nn;k++){uint32_t ij[2];double normal[3];input.read((char*)ij,8);input.read((char*)normal,24);exactNear[uint64_t(ij[0])*ne+ij[1]]={normal[0],normal[1],normal[2]};}if(!input)return 3;
 std::vector<Edge>edges;for(auto e:edgeIds)edges.push_back({e[0],e[1],hull[e[1]]-hull[e[0]]});
 double best=1e300;V axis{};std::string kind;uint64_t bestA=0,bestB=0,nonparallel=0,parallel=0,nearExact=0,antipodal=0;
 auto visit=[&](V n,const char*type,uint64_t a,uint64_t b){n=unit(n);double w=widthFast(n);if(w<best){best=w;axis=n;kind=type;bestA=a;bestB=b;}return n;};
 for(uint64_t i=0;i<faces.size();i++){V n=faceNormals[i];if(length(n)>0)visit(n,"face_normal",i,0);}
 for(uint64_t i=0;i<edges.size();i++)for(uint64_t j=i+1;j<edges.size();j++){
  const auto&a=edges[i];const auto&b=edges[j];V n=cross(a.d,b.d);long double norm=length(n),scale=length(a.d)*length(b.d);
  if(norm<=scale*1e-10L){nearExact++;auto found=exactNear.find(i*edges.size()+j);if(found==exactNear.end()){std::cerr<<"Missing exact near-parallel cross";return 4;}n=found->second;if(n.x==0&&n.y==0&&n.z==0){parallel++;continue;}norm=length(n);}
  if(norm==0){parallel++;continue;}nonparallel++;n=visit(n,"edge_cross",i,j);
  // Count numerically valid antipodal edge-pair contacts, without using
  // this test to discard any candidate direction.
  double lo,hi;widthFast(n,&lo,&hi);double va=(double)dot(hull[a.a],n),vb=(double)dot(hull[b.a],n);
  if((std::abs(va-lo)<=1e-7&&std::abs(vb-hi)<=1e-7)||(std::abs(vb-lo)<=1e-7&&std::abs(va-hi)<=1e-7))antipodal++;
 }
 axis=canonical(axis);long double lo,hi;long double upper=widthLD(all,axis,&lo,&hi);
 // Conservative arithmetic allowance: many orders above the ordinary
 // forward error of these 3-term long-double dot products at this scale.
 long double tolerance=std::stold(argv[2]),roundoff=1e-9L;
 long double diameter=0;for(V a:hull)for(V b:hull)diameter=std::max(diameter,length(a-b));diameter=std::nextafter(diameter+roundoff,std::numeric_limits<long double>::infinity());
 long double ub=upper+roundoff,minimumPruned=1e400L;uint64_t evaluated=0,popped=0,pruned=0;unsigned maxDepth=0;size_t peakHeap=0;
 auto makeCell=[&](V a,V b,V c,unsigned depth){V center=unit(a+b+c);long double cosr=std::min({dot(center,a),dot(center,b),dot(center,c)});long double radius=std::sqrt(std::max(0.L,2-2*cosr))+1e-12L;long double lower=widthLD(hull,center)-diameter*radius-roundoff;evaluated++;maxDepth=std::max(maxDepth,depth);return Cell{a,b,c,lower,depth};};
 std::priority_queue<Cell,std::vector<Cell>,Greater>queue;for(int x:{-1,1})for(int y:{-1,1})for(int z:{-1,1})queue.push(makeCell({(long double)x,0,0},{0,(long double)y,0},{0,0,(long double)z},0));
 auto push=[&](Cell c){if(c.lower>=ub-tolerance){minimumPruned=std::min(minimumPruned,c.lower);pruned++;}else queue.push(c);};
 while(!queue.empty()&&queue.top().lower<ub-tolerance){Cell c=queue.top();queue.pop();popped++;V ab=unit(c.a+c.b),bc=unit(c.b+c.c),ca=unit(c.c+c.a);push(makeCell(c.a,ab,ca,c.depth+1));push(makeCell(ab,c.b,bc,c.depth+1));push(makeCell(ca,bc,c.c,c.depth+1));push(makeCell(ab,bc,ca,c.depth+1));peakHeap=std::max(peakHeap,queue.size());if(popped%1000000==0)std::cerr<<"BOUND "<<popped<<" queue "<<queue.size()<<" gap "<<(double)(ub-std::min(queue.empty()?ub:queue.top().lower,minimumPruned))<<"\n";}
 long double lower=std::min(minimumPruned,queue.empty()?ub:queue.top().lower);if(lower>ub)lower=ub;
 std::cout<<std::setprecision(18)<<"{\"axis\":["<<(double)axis.x<<","<<(double)axis.y<<","<<(double)axis.z<<"],\"width_mm\":"<<(double)upper<<",\"projection_min_mm\":"<<(double)lo<<",\"projection_max_mm\":"<<(double)hi<<",\"candidate\":\""<<kind<<"\",\"candidate_indices\":["<<bestA<<","<<bestB<<"],\"face_candidates\":"<<nf<<",\"edge_pairs_total\":"<<uint64_t(ne)*(ne-1)/2<<",\"nonparallel_edge_candidates\":"<<nonparallel<<",\"exactly_parallel_pairs\":"<<parallel<<",\"near_parallel_exact_arithmetic_checks\":"<<nearExact<<",\"antipodal_pairs_within_1e_minus7_mm\":"<<antipodal<<",\"certificate\":{\"lower_bound_mm\":"<<(double)lower<<",\"upper_bound_mm\":"<<(double)ub<<",\"gap_mm\":"<<(double)(ub-lower)<<",\"target_tolerance_mm\":"<<(double)tolerance<<",\"dot_roundoff_allowance_mm\":"<<(double)roundoff<<",\"diameter_upper_bound_mm\":"<<(double)diameter<<",\"sphere_cells_evaluated\":"<<evaluated<<",\"sphere_cells_subdivided\":"<<popped<<",\"sphere_cells_pruned\":"<<pruned<<",\"sphere_cells_remaining\":"<<queue.size()<<",\"max_depth\":"<<maxDepth<<",\"peak_heap_cells\":"<<peakHeap<<",\"long_double_mantissa_bits\":"<<LDBL_MANT_DIG<<"}}\n";
}
