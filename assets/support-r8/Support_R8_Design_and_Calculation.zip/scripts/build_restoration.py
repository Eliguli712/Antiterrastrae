"""Restore the original 100 mm support and preserve the fitted 50 mm support.

No tooth coordinates, tooth volume mesh or tooth stress values are changed.
The 100 mm CAD inputs are the actual archived R2.1 manufacturing meshes, rather
than a reconstruction from a screenshot. The repeated R6 upper rings are
removed by restoring the original single terminal transition to node P.
"""
from pathlib import Path
import sys, json, struct, hashlib, shutil
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).with_name('deps')))
import trimesh
import manifold3d as mf
OUT=ROOT/'dist/assets/support-r8';OUT.mkdir(parents=True,exist_ok=True)
ASSETS=ROOT/'dist/assets'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def decode(path):
    data=path.read_bytes();nv,nf=struct.unpack_from('<II',data)
    packed=np.frombuffer(data,dtype='<f4',offset=8,count=6*nv).reshape(nv,6)
    faces=np.frombuffer(data,dtype='<u4',offset=8+24*nv,count=3*nf).reshape(nf,3)
    return trimesh.Trimesh(packed[:,:3].copy(),faces.copy(),process=True)
def solid(mesh):
    return mf.Manifold(mf.Mesh(np.asarray(mesh.vertices,dtype=np.float32),np.asarray(mesh.faces,dtype=np.uint32)))
def binary(mesh,path):
    packed=np.c_[mesh.vertices,mesh.vertex_normals].astype('<f4')
    path.write_bytes(struct.pack('<II',len(mesh.vertices),len(mesh.faces))+packed.tobytes()+mesh.faces.astype('<u4').tobytes())
def record(mesh,path,source_path=None):
    assert mesh.is_watertight and mesh.is_winding_consistent
    components=mesh.split(only_watertight=False);assert len(components)==1
    if source_path is None:mesh.export(path)
    else:shutil.copyfile(source_path,path)
    again=trimesh.load_mesh(path,process=True)
    assert again.is_watertight and again.is_winding_consistent and len(again.split())==1
    return {'file':path.name,'bytes':path.stat().st_size,'sha256':sha(path),
        'triangles':len(again.faces),'vertices':len(again.vertices),'watertight':True,
        'components':1,'volume_mm3':float(again.volume),'bounds_mm':again.bounds.tolist()}

base=json.loads((ASSETS/'model.json').read_text())
old=json.loads((ASSETS/'support-r6/support.json').read_text())
common=('nodes','edges','radii_mm','feet','rod_diameter_mm','top_triangles','top_side_lengths_mm')
graph50={k:old[k] for k in common}
radii100={n:8. if n in base['feet'] else 4.2 if n=='Q_bottom' else 5.5 if n=='P' else 5.7 for n in base['nodes']}
graph100={'nodes':base['nodes'],'edges':base['edges'],'radii_mm':radii100,
    'feet':base['feet'],'rod_diameter_mm':base['rod_diameter_mm'],
    'top_triangles':[['A5','B7','P'],['B7','A7','P'],['A7','B3','P'],['B3','A5','P']],
    'top_side_lengths_mm':[]}
cases={};meshes={}
for size in [50,100]:
    case=dict(old['cases'][str(size)])
    graph=graph50 if size==50 else graph100
    parts=[]
    for name in ['main','cap']:
        source=ASSETS/'support-r6'/f'{size}mm-{name}.bin' if size==50 else ASSETS/f'{name}.bin'
        shutil.copyfile(source,OUT/f'{size}mm-{name}.bin')
        if size==100:
            master=Path(__file__).with_name('original-r21-kit')/'Megalodon_R2_1/PRINT'/('Main_Frame_RearSocket_C045.stl' if name=='main' else 'Front_Lock_Cap_C045.stl')
            q=trimesh.load_mesh(master,process=True);binary(q,OUT/f'{size}mm-{name}.bin')
        else:
            master=ASSETS/'support-r6'/f'Support_R6_{size}mm_{name}.stl';q=trimesh.load_mesh(master,process=True)
        meshes[size,name]=q
        rec=record(q,OUT/f'Support_R8_{size}mm_{name}.stl',master)
        rec.update({'packed_file':f'{size}mm-{name}.bin','packed_sha256':sha(OUT/f'{size}mm-{name}.bin'),
            'historical_display_packed_sha256':sha(source),'source_STL_sha256':sha(master),'manufacturing_master_restored_without_reconstruction':size==100})
        parts.append(rec)
    main,cap=meshes[size,'main'],meshes[size,'cap'];combined=main+cap
    overlap=float((solid(main)^solid(cap)).volume())
    assert abs(overlap)<1e-4
    case.update({'revision':'R8','parts':parts,'resin_volume_ml':float(combined.volume/1000),
        'resin_center_mm':combined.center_mass.tolist(),'frame_graph':graph,
        'bevel_bands':2 if size==50 else 1,
        'top_transition':'Two retained equilateral bevel bands' if size==50 else 'Original single terminal corner transition; no repeated upper bands',
        'historical_CAD_restored':size==100,'all_edge_endpoints_have_spheres':all(n in graph['radii_mm'] for e in graph['edges'] for n in e),
        'lower_frame_span_xy_mm':[84.93910217285156,84.93910217285156],
        'geometry_checks':{'main_cap_intersection_mm3':overlap},
        'root_clearance_mm':.35 if size==50 else base['root_clearance_mm'],
        'root_wall_mm':2.2 if size==50 else base['root_wall_mm'],
        'root_height_mm':20. if size==50 else base['root_height_mm'],
        'root_base_z_mm':86.73910524340096-1.2 if size==50 else base['root_base_z_mm'],
        'notes':(['50 mm main and cap meshes are bitwise copies of the R6 packed parts.'] if size==50 else [
            '100 mm manufacturing STLs are bitwise copies of the original R2.1 print masters; packed display surfaces retain every STL triangle.',
            'The original 18-node/28-beam top transition replaces the R6 27-node/50-beam repeated-ring connector.',
            'Bevel count denotes the original single terminal transition, not an added repeated ring or a newly invented machining operation.'])+[
            'No native tooth coordinates or tooth stress values are changed.',
            'Frame mechanics omit detailed socket, bevel-plate, fastener contact, friction, creep and failure.',
            'A full 74M-face manufacturing collision certification and physical retention testing remain unperformed.']})
    if size==50:
        case['geometry_checks'].update(old['cases']['50']['geometry_checks'])
        case['fit_reference']='Previously validated 72 micrometre tooling envelope, geometry unchanged.'
    else:
        tooth=decode(ASSETS/'tooth.bin');st=solid(tooth)
        case['geometry_checks'].update({'main_archived_tooth_intersection_mm3':float((solid(main)^st).volume()),
            'cap_archived_tooth_intersection_mm3':float((solid(cap)^st).volume())})
        assert max(abs(case['geometry_checks'][k]) for k in ['main_archived_tooth_intersection_mm3','cap_archived_tooth_intersection_mm3'])<1e-4
        case['fit_reference']='Restored historical geometry checked against the archived 41,180-face display/tooling tooth; not the complete native surface.'
        case['cap_frame_axis_clearance_mm']=None
        case['historical_display_simplification_tolerance_mm']=.12
        case['historical_extra_reinforcement_relief_mm']=.02
        case['tooling_pitch_mm']=None
        case['tooling_source_sampling_um']=None
    cases[str(size)]=case
    print('RESTORED',size,'nodes',len(graph['nodes']),'beams',len(graph['edges']),'CAD_volume_ml',case['resin_volume_ml'],flush=True)

data={k:old[k] for k in common};data.update({'revision':'R8','unit':'mm','cases':cases,
    'bevel_bands':{'50':2,'100':1},'case_specific_graphs':True,
    'all_edge_endpoints_have_spheres':True,'tooth_anchor_mm':[0,0,86.73910524340096],
    'frame_note':'100 mm: original R2.1 graph and CAD restored with its single terminal transition. 50 mm: independently fitted R6 geometry retained. Both use case-specific recalculated beam and node submodels.'})
(OUT/'support.json').write_text(json.dumps(data,indent=2)+'\n')
