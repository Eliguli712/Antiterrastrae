"""Validate restored CAD, actual per-case beam solves and spherical patch tests."""
from pathlib import Path
import sys, json, hashlib, zipfile, importlib.util
import numpy as np
ROOT=Path(__file__).resolve().parents[1];SOURCE=Path(__file__).resolve().parent
sys.path.insert(0,str(SOURCE/'deps'))
import trimesh
OUT=ROOT/'dist/assets/support-r8'
spec=importlib.util.spec_from_file_location('frame_r8',SOURCE/'frame_fem.py')
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
model=json.loads((OUT/'support.json').read_text())
frames={str(s):f.solve_frame(model,s) for s in [50,100]}
for c in frames.values():c.pop('node_loads')
(OUT/'frame-fem.json').write_text(json.dumps({'revision':'R8','unit_system':'N,mm,MPa',
    'validation':f.checks(),'cases':frames},indent=2)+'\n')
validation={'revision':'R8','beam_analytic':f.checks(),'cases':{},'parts':[],'spherical_patch':[]}
for size,c in model['cases'].items():
    graph=c['frame_graph'];result=frames[size]
    assert len(graph['nodes'])==result['frame_nodes'] and len(graph['edges'])==result['beam_elements']
    assert c['frame_scale']==1 and c['unchanged_lower_frame']
    validation['cases'][size]={'nodes':len(graph['nodes']),'beam_elements':len(graph['edges']),
        'bevel_bands':c['bevel_bands'],'all_edge_endpoints_have_spheres':c['all_edge_endpoints_have_spheres'],
        'fixed_translation_max_mm':result['fixed_translation_max_mm'],
        'free_relative_residual':result['free_relative_residual'],
        'force_balance_N':result['force_balance_N'],'moment_balance_N_mm':result['moment_balance_N_mm'],
        'energy_balance_relative_error':result['energy_balance_relative_error'],
        'stiffness_symmetry_relative_error':result['stiffness_symmetry_relative_error'],
        'max_beam_shear_parameter_phi':max(m['shear_parameter_phi'] for m in result['members'])}
    for part in c['parts']:
        p=OUT/part['file'];assert hashlib.sha256(p.read_bytes()).hexdigest()==part['sha256']
        m=trimesh.load_mesh(p,process=True)
        assert m.is_watertight and m.is_winding_consistent and len(m.split())==1
        packed=OUT/part['packed_file'];assert hashlib.sha256(packed.read_bytes()).hexdigest()==part['packed_sha256']
        assert part['source_STL_sha256']==part['sha256']
        validation['parts'].append({'file':p.name,'sha256':part['sha256'],'watertight':True,
            'connected':True,'restored_STL_master_bitwise_equal_to_source':size=='100'})
for variant in ['solid','wall']:
    p,t,grad,vol,K,free,factor,outer,dirs,faces=f.shell_mesh(5.5,variant);n=len(p)
    rigid=np.zeros((n,3,6));rigid[:,:,:3]=np.eye(3)
    rigid[:,0,4]=p[:,2];rigid[:,0,5]=-p[:,1];rigid[:,1,3]=-p[:,2]
    rigid[:,1,5]=p[:,0];rigid[:,2,3]=p[:,1];rigid[:,2,4]=-p[:,0]
    rigid=rigid.reshape(3*n,6)
    rigid_residual=float(np.linalg.norm(K@rigid)/(np.linalg.norm(K.data)*np.linalg.norm(rigid)))
    A=np.array([[.01,.002,.003],[-.001,.02,.004],[.002,-.002,.012]])
    force=(K@(p@A.T).ravel()).reshape(n,3)
    boundary=np.array(outer)
    if variant=='wall':boundary=np.r_[np.arange(len(dirs)),outer]
    inside=np.setdiff1d(np.arange(n),boundary)
    patch=float(np.linalg.norm(force[inside])/np.linalg.norm(force))
    assert rigid_residual<1e-13 and patch<1e-9 and (vol>0).all()
    validation['spherical_patch'].append({'variant':variant,'tetrahedra':len(t),
        'positive_volumes':True,'rigid_motion_relative_residual':rigid_residual,'affine_patch_relative_residual':patch})
balls=json.loads((OUT/'ball-fem.json').read_text())
for size,case in balls['cases'].items():
    assert {r['node'] for r in case}==set(model['cases'][size]['frame_graph']['nodes'])
    assert len(case)==2*len(model['cases'][size]['frame_graph']['nodes'])
    for r in case:
        assert r['free_relative_residual']<1e-7 and r['gauge_reaction_relative']<1e-7
        assert np.isfinite(r['surface_vm_MPa']).all() and min(r['surface_vm_MPa'])>=0
validation['spherical_submodel_count']=sum(len(c) for c in balls['cases'].values())
validation['all_sphere_submodel_max_gauge_reaction_relative']=max(r['gauge_reaction_relative'] for c in balls['cases'].values() for r in c)
validation['native_porous_tooth_FEM_completed']=False
validation['physical_retention_test_completed']=False
validation['Chien_shell_equations_implemented']=False
(OUT/'support-verification.json').write_text(json.dumps(validation,indent=2)+'\n')
readme='''Otodus megalodon — R8 restored support and mechanics
Units: mm, N, MPa. Resin assumptions: E 1375 MPa, nu 0.38, density 1.18 g/cm3.

100 mm restores the actual original R2.1 manufacturing STL masters, without
redrawing the support from a screenshot. The restored original single terminal
corner transition has no added repeated R6 upper bevel rings. Its graph has
18 nodes and 28 Euler–Bernoulli beams. Packed display geometry preserves every
restored STL triangle. Original split root socket and nominal 0.45 mm clearance
are retained. Root capture height: 40 mm.

50 mm preserves the independently fitted R6 main and front-cap geometry,
including its two existing equilateral bevel bands. Its graph has 27 nodes
and 50 beams. Nominal root clearance: 0.35 mm; capture height: 20 mm.
The lower frame remains 84.939102 mm across both horizontal axes for both sizes.
Every graph endpoint is covered by a spherical node. The four separate STL
parts are connected, consistently oriented and watertight. Print at 100% in mm.

Both sizes have independently recomputed 3D Euler–Bernoulli frame assemblies,
including distributed beam/node self-weight scaled to exact CAD mass and a
connector couple matching the CAD gravitational moment. Tooth gravity is
3 × g; masses assume solid PLA at 1.24 g/cm3. This load case differs from the
tooth's independent 1 MPa crown-pressure study. Translational foot DOFs are
fixed; foot rotations are free. Material properties remain assumptions.

Solid and 1.2 mm hollow-wall spherical-node studies were recomputed for the
actual per-size beam resultants using balanced finite connection patches.
They are one-way 3D elasticity submodels, not a coupled contact model or an
implementation of Chien thin-shell equations. Their t/R is too large to claim
thin-shell accuracy without comparison. No local peak convergence is claimed.
Short connector members require a shear-sensitive comparison; per-member phi
values are included. Socket, bevel-plate, screw, friction, creep and failure
details are excluded from the global beam idealization. Hardware mass is not
added to this baseline comparison.

CAD fit records identify their real reference geometry. The 100 mm fit retest
uses the archived 41,180-face display/tooling tooth; the 50 mm original tooling
test is retained because its geometry is unchanged. These are not complete
74M-face collision certifications. Physical clamp retention remains untested.
Original native tooth geometry, tooth stress values and independent tooth FEM
solutions are unchanged. Native porous-volume tooth FEM is not completed.

Source scripts and the exact restored original 100 mm STL inputs are included.
Dependencies: numpy, scipy, trimesh, manifold3d. Run build_restoration.py in
the supplied source layout, followed by frame_fem.py and validate_and_package.py.
The previous full 50 mm CAD inputs and physical tooth properties must be placed
at the paths recorded in the scripts. All required file SHA-256 values are
recorded in support.json and support-verification.json.

Original theory:
Euler 1744: https://scholarlycommons.pacific.edu/euler-works/65/
Chien 1944 I: https://doi.org/10.1090/qam/9744
Chien 1944 III: https://doi.org/10.1090/qam/10867
Wittrick 1964: https://doi.org/10.1016/0020-7225(64)90002-3
'''
(OUT/'README.txt').write_text(readme)
with zipfile.ZipFile(OUT/'Support_R8_Design_and_Calculation.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for p in OUT.iterdir():
        if p.suffix in ['.json','.stl','.txt','.bin']:z.write(p,p.name)
    for p in SOURCE.glob('*.py'):z.write(p,'scripts/'+p.name)
    for p in (SOURCE/'original-r21-kit/Megalodon_R2_1/PRINT').glob('*.stl'):z.write(p,'original-r21-STL/'+p.name)
print(json.dumps({'cases':validation['cases'],'spherical_submodels':validation['spherical_submodel_count'],
    'ZIP_bytes':(OUT/'Support_R8_Design_and_Calculation.zip').stat().st_size},indent=2))
