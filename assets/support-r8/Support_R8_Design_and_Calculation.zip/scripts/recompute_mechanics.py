"""Recompute the extracted flat R8 kit: python scripts/recompute_mechanics.py."""
from pathlib import Path
import importlib.util,json
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('frame_r8',Path(__file__).with_name('frame_fem.py'))
f=importlib.util.module_from_spec(spec);spec.loader.exec_module(f)
f.ROOT=ROOT;f.OUT=ROOT
model=json.loads((ROOT/'support.json').read_text())
# Re-measure the actual included CAD masters before assembling gravity loads.
for size,case in model['cases'].items():
    meshes=[f.trimesh.load_mesh(ROOT/part['file'],process=True) for part in case['parts']]
    combined=meshes[0]+meshes[1]
    case['resin_volume_ml']=float(combined.volume/1000)
    case['resin_center_mm']=combined.center_mass.tolist()
frames={str(s):f.solve_frame(model,s) for s in [50,100]}
balls=f.ball_submodels(model,frames)
for c in frames.values():c.pop('node_loads')
(ROOT/'frame-fem.json').write_text(json.dumps({'revision':'R8','unit_system':'N,mm,MPa',
    'validation':f.checks(),'cases':frames},indent=2)+'\n')
(ROOT/'ball-fem.json').write_text(json.dumps(balls,separators=(',',':'))+'\n')
print('Recomputed both beam frames and all 90 one-way spherical-node submodels.')
